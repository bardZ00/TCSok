-- TacticalCommandSystem/ui/assets.lua
-- Vocation icons / button medallions (D2DX images), screen size, scaled fonts.
-- Part of the HUD drawing code (see ui.lua); state shared with the other ui files lives in ui/shared.lua.

local X = require("TacticalCommandSystem.ui.shared")
local Safe = require("TacticalCommandSystem.lib.safe")
local I18 = require("TacticalCommandSystem.i18n")
local UI = X.UI
local images, iconSlots = X.images, X.iconSlots

------------------------------------------------------------------------------------------------
-- D2DX / reframework-d2d pictures
------------------------------------------------------------------------------------------------
-- name of the picture in `images` -> file under reframework/images/Tactical_Command_System/
local IMAGE_FILES = {}
for id = 1, 10 do IMAGE_FILES["job_" .. id] = "job_" .. id end            -- class emblems
IMAGE_FILES["heart"] = "heart"                                              -- the Arisen's heart
for _, n in ipairs({ "med", "cres_l", "cres_r", "plate_fade", "plate_line", "plate_disc",
                    "cell_fade_l", "cell_fade_r", "card_fade", "corner_halo", "diamond",
                    "soph_plate", "soph_plate_sel", "soph_smoke_dark", "soph_burst_ring", "flare", "card_tex", "card_tex_sel" }) do IMAGE_FILES[n] = "ui/" .. n end   -- 1.38: atb_* pictures dropped (unused)
for tint = 0, 10 do                                                          -- 1.21: the open style's vocation washes
    for _, n in ipairs({ "cell_tint_l_", "cell_tint_r_", "card_tint_" }) do IMAGE_FILES[n .. tint] = "ui/" .. n .. tint end
end
for _, shape in ipairs({ "hex", "spear", "chamfer", "rect", "pill" }) do    -- cell shapes (setting look_cell_shape)
    for _, n in ipairs({ "_idle", "_on" }) do IMAGE_FILES["frame_" .. shape .. n] = "ui/frame_" .. shape .. n end
    for tint = 0, 10 do IMAGE_FILES["frame_" .. shape .. "_sel_" .. tint] = "ui/frame_" .. shape .. "_sel_" .. tint end
end
for tint = 0, 6 do                                                          -- 0 = neutral, 1..6 = base vocations
    for _, n in ipairs({ "circle_", "band_", "band_sel_" }) do
        IMAGE_FILES[n .. tint] = "ui/" .. n .. tint
    end
end
for _, st in ipairs({ "free", "close", "wait", "ranged" }) do                        -- the stance medallions
    IMAGE_FILES["stance_" .. st] = "stance/" .. st
end
local IMAGE_COUNT = 0
for _ in pairs(IMAGE_FILES) do IMAGE_COUNT = IMAGE_COUNT + 1 end

local imagesLoaded = false
UI.icon_status = X.d2d_available and "waiting for d2d init" or "d2d / D2DX not installed"

-- Builds every picture the wheel draws with, once, inside d2d's own setup callback: a picture created while drawing
-- is a picture that flickers for a frame, and a hundred of them created lazily flickers for a hundred frames.
local function build_pictures()
    if imagesLoaded then return end
    local loaded = 0
    for name, file in pairs(IMAGE_FILES) do
        local okImg, img = pcall(d2d.Image.new, "Tactical_Command_System/" .. file .. ".png")
        if okImg and img then
            images[name] = img
            loaded = loaded + 1
        end
    end
    -- pad button pictures (A B X Y LB RB LT RT L3 R3 Select Start DPad)
    for _, n in ipairs({ "A", "B", "X", "Y", "LB", "RB", "LT", "RT", "L3", "R3", "Select", "Start", "DPad" }) do
        local okB, imB = pcall(d2d.Image.new, "Tactical_Command_System/buttons/" .. n .. ".png")
        if okB and imB then images["btn_" .. n] = imB end
    end
    -- 2.43: PlayStation pictures, stored under the Xbox names (A = Cross, LB = L1, Select = Share, Start = Options...)
    local PS_FILE = { A = "Cross", B = "Circle", X = "Square", Y = "Triangle", LB = "L1", RB = "R1", LT = "L2", RT = "R2",
        L3 = "L3", R3 = "R3", Select = "Share", Start = "Options", DPad = "DPad" }
    for n, f in pairs(PS_FILE) do
        local okP, imP = pcall(d2d.Image.new, "Tactical_Command_System/buttons_ps/" .. f .. ".png")
        if okP and imP then images["btnps_" .. n] = imP end
    end
    -- skill icons must be created here (d2d init callback), not lazily while drawing
    local sk = 0
    for n = 0, 99 do
        local okS, imS = pcall(d2d.Image.new, "Tactical_Command_System/skill_" .. n .. ".png")
        if okS and imS then images["skill_" .. n] = imS; sk = sk + 1 end
    end
    Safe.note("D2D skill icons: " .. sk .. "/100 loaded")
    imagesLoaded = true
    X.d2d_ready = loaded > 0
    UI.icon_status = loaded .. "/" .. IMAGE_COUNT .. " wheel pictures loaded, " .. sk .. "/100 skill icons"
    Safe.note("D2D Icons: " .. UI.icon_status)
end

if X.d2d_available then
    local ok, err = pcall(d2d.register, function()
        imagesLoaded = false
        build_pictures()
    end, function()
        if not imagesLoaded then
            pcall(build_pictures)
        end
        for _, slot in ipairs(iconSlots) do
            local img = slot.img and images[slot.img]
            if slot.line then
                -- 1.21: thin gold lines of the open style (arcs drawn as short segments)
                pcall(d2d.line, slot.x1, slot.y1, slot.x2, slot.y2, slot.t, slot.color)
            elseif slot.rect then
                -- the dark filter; if this d2d build has no fill_rect, the wheel draws it with imgui instead
                local okr = type(d2d.fill_rect) == "function" and pcall(d2d.fill_rect, slot.x, slot.y, slot.w, slot.h, slot.color)
                if not okr then X.d2d_rect_failed = true end
            elseif img then
                local x, w, h = slot.x, slot.w or slot.size, slot.h or slot.size
                if slot.ratio then                         -- keep the picture's own proportions (height is the reference)
                    local okS, iw, ih = pcall(img.size, img)
                    if okS and tonumber(iw) and tonumber(ih) and ih > 0 then
                        local rw = h * iw / ih
                        x, w = x + (w - rw) * 0.5, rw      -- stay centred when the real width differs
                    end
                end
                if slot.alpha then
                    pcall(d2d.image, img, x, slot.y, w, h, math.max(0, math.min(1, slot.alpha)))
                else
                    pcall(d2d.image, img, x, slot.y, w, h)
                end
            end
        end
    end)
    if not ok then
        X.d2d_available = false
        UI.icon_status = "d2d register failed: " .. tostring(err)
        pcall(log.error, "[Tactical_Command_System] " .. UI.icon_status)
    end
end

------------------------------------------------------------------------------------------------
-- Safe Display Size & Scaled Fonts
------------------------------------------------------------------------------------------------
local font_cache = {}
local font_count = 0
local FONT_MAX = 96

-- the screen, read where every other part of the mod reads it (lib/world.lua)
local get_screen_size = require("TacticalCommandSystem.lib.world").screen_size

-- Fonts are cached per face: a change of face does not throw the sizes of the previous face away (switching back is free).
-- A freshly loaded font is only usable once imgui has rebuilt its atlas, so for 0.4 s the nearest older size is used.
local function face_cache(file)
    local key = file or "default"
    local c = font_cache[key]
    if not c then c = {}; font_cache[key] = c end
    return c
end

-- French and typographic characters (œ, dashes, quotes, guillemets, ellipsis, arrows, triangles), and Cyrillic (1.08:
-- skill names read from a Russian game showed as "???")
local FONT_RANGES = { 0x0020, 0x00FF, 0x0152, 0x0153, 0x0400, 0x04FF, 0x2013, 0x2014, 0x2018, 0x201E, 0x2022, 0x2022,
    0x2026, 0x2026, 0x2039, 0x203A, 0x2190, 0x2193, 0x25B2, 0x25BC, 0 }

-- 1.08: shipped faces without Cyrillic letters. When the game runs in Russian, they give way to EB Garamond (a serif
-- with Cyrillic, the nearest in style), so the names the game supplies stay readable.
local NO_CYRILLIC = { ["TCS_Pagella.ttf"] = true, ["TCS_Bonum.ttf"] = true, ["TCS_Schola.ttf"] = true,
                      ["TCS_Caladea.ttf"] = true }
local CYRILLIC_FACE = "TCS_Garamond-SemiBold.ttf"

-- 2.22: the shipped faces have no Chinese characters. When the mod is set to Chinese it uses one of the two faces
-- below (Noto CJK, cut down to the common characters, OFL licence). The wide ranges are only asked for from those
-- two files: a face that does not hold a character simply skips it, so the other faces cost nothing here. The number
-- of Chinese sizes kept in memory is capped, because each one carries thousands of characters.
local ZH_FACES = { ["TCS_ZH_Serif.ttf"] = true, ["TCS_ZH_Sans.ttf"] = true }
local ZH_FACE_DEFAULT = "TCS_ZH_Serif.ttf"
local ZH_FONT_MAX = 10
local ZH_RANGES = { 0x0020, 0x00FF, 0x0152, 0x0153, 0x2013, 0x2014, 0x2018, 0x201E, 0x2022, 0x2022,
    0x2026, 0x2026, 0x2039, 0x203A, 0x2190, 0x2193, 0x25B2, 0x25BC,
    0x3000, 0x303F, 0x4E00, 0x9FA5, 0xFF01, 0xFF65, 0 }
local cyr = { need = nil, tries = 0, next_try = 0 }

-- the game's text language, read like the language setting reads it (i18n.lua); tried every 2 s, 30 times at most
local function game_uses_cyrillic()
    if cyr.need ~= nil then return cyr.need end
    local now = os.clock()
    if cyr.tries >= 30 or now < cyr.next_try then return false end
    cyr.tries, cyr.next_try = cyr.tries + 1, now + 2.0
    local ok, res = pcall(function()
        local td = sdk.find_type_definition("via.gui.GUISystem")
        local sing = sdk.get_native_singleton("via.gui.GUISystem")
        if not (td and sing) then return nil end
        local lang = sdk.call_native_func(sing, td, "get_MessageLanguage")
        if lang == nil then return nil end
        local ru = sdk.find_type_definition("via.Language"):get_field("Russian"):get_data(nil)
        return tonumber(lang) == tonumber(ru)
    end)
    if ok and res ~= nil then cyr.need = res end
    return cyr.need == true
end

function UI.get_scaled_font(base_px)
    local _, sh = get_screen_size()
    local font = UI.FONT
    local px = math.max(8, math.floor(base_px * (sh / 1080) * X.hud_scale * (font.scale or 1.0) + 0.5))
    local file = font.file
    if file and NO_CYRILLIC[file] and game_uses_cyrillic() then file = CYRILLIC_FACE end
    if I18.lang() == "zh" and not ZH_FACES[file] then file = ZH_FACE_DEFAULT end     -- 2.22
    local zh = ZH_FACES[file] == true
    local ranges = zh and ZH_RANGES or FONT_RANGES
    local cache = face_cache(file)
    local now = os.clock()
    if not cache[px] and font_count < (zh and ZH_FONT_MAX or FONT_MAX) then
        font_count = font_count + 1
        local f = nil
        pcall(function()
            if file then f = imgui.load_font(file, px, ranges) end
            if not f and zh then f = imgui.load_font("GoNotoCurrent-Regular.ttf", px) end     -- 2.22: last resort
            if not f then f = imgui.load_font(cyr.need and CYRILLIC_FACE or "TCS_Pagella.ttf", px, FONT_RANGES) end
            if not f then f = imgui.load_font("GoNotoCurrent-Regular.ttf", px) or imgui.load_font(nil, px) end
        end)
        cache[px] = { f = f, t = now }
    end
    local best, best_d = nil, 1e9
    for sz, e in pairs(cache) do
        if e.f and (now - e.t >= 0.4 or font_count <= 3) and math.abs(sz - px) < best_d then
            best, best_d = e.f, math.abs(sz - px)
        end
    end
    if not best then
        -- nothing usable yet for this face: the exact size if it exists, otherwise any size of any face
        if cache[px] then best = cache[px].f end
        if not best then
            for _, c in pairs(font_cache) do
                for _, e in pairs(c) do if e.f then best = e.f; break end end
                if best then break end
            end
        end
    end
    return best
end

-- the game's font (Quadraat) comes from the personal font zip of RPG Level Up (never shipped here): its witness
-- file tells which font file it installed in reframework/fonts
local function perso_font()
    local fh = io.open("BardN_RPG_Level_Up/police_perso.json", "r")
    if not fh then return nil end
    fh:close()
    local ok, d = pcall(json.load_file, "BardN_RPG_Level_Up/police_perso.json")
    if ok and type(d) == "table" and type(d.fichier) == "string" and d.fichier ~= "" then return d.fichier end
    return "BardN_RPG_Level_Up_Quadraat_PERSO.ttf"
end
UI.perso_font = perso_font

function UI.set_font(file)
    if file == "auto" or file == "quadraat" then
        file = perso_font() or "TCS_Pagella.ttf"
    end
    UI.FONT.file = (file ~= nil and file ~= "" and file ~= "default") and file or nil
end

function UI.set_scale(s)
    X.hud_scale = math.max(0.5, math.min(2.5, tonumber(s) or 1.0))
end

-- shared with the other ui files
X.get_screen_size = get_screen_size
