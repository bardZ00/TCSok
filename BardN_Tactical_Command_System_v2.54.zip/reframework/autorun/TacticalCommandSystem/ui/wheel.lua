-- TacticalCommandSystem/ui/wheel.lua
-- The wheel itself, and the targeting step drawn in its place.
-- Part of the HUD drawing code (see ui.lua); state shared with the other ui files lives in ui/shared.lua.
-- Tactical Command System: the wheel shows the Arisen (no centre circle by default, the game's button of each skill on its
-- cell) or a pawn (the full wheel). The top row is a carousel: the shown character is
-- always in the middle.
--
-- How it is drawn:
--   * the art (frames, circle, crescents, class bands, icons) is a set of pictures drawn by d2d, in the order
--     they are queued here (first queued = furthest back). The class of the pawn picks the tinted variant.
--   * texts, life / stamina bars, the lock lamp and the progress bar are drawn by imgui, which is always above d2d.
--   * every position below is written in "design pixels": the 1920 x 1080 mock-up. PX / PY turn them into screen pixels.
--   * without D2DX (no pictures) the wheel falls back to plain panels so it stays usable.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local AI = require("TacticalCommandSystem.cmd.init")
local IN = require("TacticalCommandSystem.input")
local I18 = require("TacticalCommandSystem.i18n")
local API = require("TacticalCommandSystem.api")
local Poss = require("TacticalCommandSystem.possess")
local X = require("TacticalCommandSystem.ui.shared")
local UI = X.UI
local COL = D.COL
local W = IN.W
local images, iconSlots = X.images, X.iconSlots

-- from ui/shapes
local draw_aligned_text, draw_arc, draw_panel, draw_status_lamp = X.draw_aligned_text, X.draw_arc, X.draw_panel, X.draw_status_lamp
local text_size, with_alpha = X.text_size, X.with_alpha
-- from ui/prompts
local bind_glyph, draw_dpad_switch, draw_glyph, draw_prompt_bar, glyph_width = X.bind_glyph, X.draw_dpad_switch, X.draw_glyph, X.draw_prompt_bar, X.glyph_width
-- from ui/markers
local draw_bars, draw_target_markers = X.draw_bars, X.draw_target_markers
-- from ui/assets
local get_screen_size = X.get_screen_size

local floor = math.floor

------------------------------------------------------------------------------------------------
-- Layout of the mock-up (design pixels, 1920 x 1080)
------------------------------------------------------------------------------------------------
local L = {
    cx = 960,                       -- vertical axis of the wheel
    circle_cy = 500,                -- centre of the central circle
    circle_img = 600,               -- size of the circle picture (circle + halo + medallion)
    badge_cy = 324, badge_h = 78,   -- class emblem in the medallion on top of the circle
    col_left = 250, col_right = 1150, col_cy = 528,           -- skill columns (left edge of each) and their middle
    btn_w = 520, btn_h = 72, btn_gap = 20, btn_pad = 24,      -- pad = empty margin around the frame in its picture
    med_cx = 62, med_size = 64,     -- skill medallion inside a button
    lamp_cx = 486,                  -- lock lamp: on the right diamond of a skill button
    corner_w = 320, corner_h = 56,  -- the two small cells under the skills (Cancel, Stance)
    corner_dx = 300,                -- their centres, left and right of the wheel axis
    cres_left = 56, cres_right = 1564, cres_top = 70, cres_w = 300, cres_h = 880,
    ring_r = 169,                   -- middle radius of the class ring (between the two gold lines of the circle picture)
    row_top = 26, band_w = 118, band_h = 172, band_sel_w = 156, band_sel_h = 226, band_gap = 30,
    prompt_top = 944,
    plate_w = 300, plate_h = 92,    -- the centre's information, on a plate between Cancel and Stance
}

-- Design -> screen. Set at the start of every draw.
local s, ox, oy = 1, 0, 0
local function PX(dx) return ox + dx * s end
local function PY(dy) return oy + dy * s end

-- Queue one picture (design coordinates of its top-left corner and its size). Returns false when it is not loaded.
local function image(name, dx, dy, dw, dh, alpha, keep_ratio)
    if not images[name] then return false end
    local slot = { img = name, x = floor(PX(dx) + 0.5), y = floor(PY(dy) + 0.5), w = floor(dw * s + 0.5), h = floor(dh * s + 0.5) }
    if alpha and alpha < 0.995 then slot.alpha = alpha end
    if keep_ratio then slot.ratio = true end
    iconSlots[#iconSlots + 1] = slot
    return true
end

-- Which tinted variant of the pictures a job uses: 1..10 = the vocations, 0 = neutral bronze.
-- The hybrid vocations (7..10) only have some pictures (hexagon frames): the others fall back to bronze.
local function tint_key(job)
    if UI.LOOK.tint and job and job >= 1 and job <= 10 then return job end
    return 0
end
local function tinted(prefix, tk)
    if tk ~= 0 and images[prefix .. tk] then return prefix .. tk end
    return prefix .. "0"
end

------------------------------------------------------------------------------------------------
-- 1.21: the open style. No closed frames: gold lines that fade away from the centre, dark washes that fade the same
-- way, the inner side of each cell curved along a circle around the middle of the wheel. Lines and the thin strips
-- along the curve are d2d primitives (screen pixels); the washes are stretched pictures.
------------------------------------------------------------------------------------------------
local GOLD_RGB, SEL_RGB, ACTIVE_RGB, DARK_RGB = 0xD9B358, 0xF6D67E, 0x6FCF7A, 0x0F0C08
-- the vocation washes' colour (the same as the pictures cell_tint_*), for the thin strips along the curve
local TINT_RGB = { [0] = 0x58472F, 0x5B3C2E, 0x5E4E28, 0x37453F, 0x4D4F2D, 0x59392B, 0x353646, 0x563161, 0x0D6356, 0x6F1037, 0x4E3D1F }

local function wheel_style() return UI.LOOK.cell_style or "open" end
-- "open" and "soph" (1.22, Sophistiquée) share the geometry of the open style; "fan" (1.22, Éventail) lays the
-- skills out as cards along the bottom of the screen
local function open_style() local st = wheel_style(); return st == "open" or st == "soph" end
local function soph_style() return wheel_style() == "soph" end
local function fan_style() return wheel_style() == "fan" end
local draw_open_ring, draw_open_crescents, draw_fan_header, draw_atb_layer   -- defined further down
local function argb(alpha, rgb) return (math.floor(math.max(0, math.min(1, alpha)) * 255 + 0.5) << 24) | rgb end
local function seg(x1, y1, x2, y2, t, alpha, rgb)            -- screen pixels
    if alpha <= 0.01 then return end
    iconSlots[#iconSlots + 1] = { line = true, x1 = x1, y1 = y1, x2 = x2, y2 = y2, t = t, color = argb(alpha, rgb) }
end
local function strip(x, y, w, h, alpha, rgb)                 -- screen pixels
    if alpha <= 0.01 or w <= 0 or h <= 0 then return end
    iconSlots[#iconSlots + 1] = { rect = true, x = x, y = y, w = w, h = h, color = argb(alpha, rgb) }
end
-- a horizontal gold line that fades in over the first 60 % from `x_out` (design pixels) to `x_in`
local function fading_line(x_out, x_in, y, t, alpha, rgb)
    local n = 10
    local span = (x_in - x_out) * 0.6
    for k = 0, n - 1 do
        seg(PX(x_out + span * k / n), PY(y), PX(x_out + span * (k + 1) / n), PY(y), t, alpha * (k + 0.5) / n, rgb)
    end
    seg(PX(x_out + span), PY(y), PX(x_in), PY(y), t, alpha, rgb)
end

------------------------------------------------------------------------------------------------
-- One button (a stance / order on the left, a skill or an item on the right)
------------------------------------------------------------------------------------------------
local glow_state, glow_last_t, glow_dt = {}, nil, 0

-- Everything a button needs to know about the current frame
local F = {}

local STANCE_TAG = { free = "[ FREE ]", close = "[ ESCORT ]", wait = "[ HOLD ]", ranged = "[ RANGED ]" }

local function button_tag(item, st)
    local hov = st.hov
    if st.debt then return "[ ! ATB INTO THE RED ! ]", 0xFF4040FF end     -- precipitation warning, always shown
    if item.arisen then
        if item.kind == "cancel" and hov then return item.sub, COL.GOLD_BRIGHT end
        if item.kind == "team" then                      -- the team's stance
            local t = F.team_stance
            if t == nil then return "[ NO PAWN ]", COL.MUTED end
            if t == "mixed" then return "[ MIXED ]", COL.AMBER end
            return STANCE_TAG[t] or STANCE_TAG.free, (t ~= "free") and COL.GREEN or (hov and COL.GOLD_BRIGHT or COL.MUTED)
        end
        if item.kind == "skill" and hov and IN.is_no_target(item.skill_id) then return "[ NO TARGETING ]", COL.GOLD_BRIGHT end
        return nil
    end
    if item.kind == "stance" then
        return STANCE_TAG[F.cur_stance] or STANCE_TAG.free, (F.cur_stance ~= "free") and COL.GREEN or (hov and COL.GOLD_BRIGHT or COL.MUTED)
    end
    if st.unavailable then return "[ NO TARGET ]", COL.MUTED end
    -- 2.10: the running order in gold, saying where it stands
    if st.running then
        local word = (st.phase == "sent" and "ORDER SENT") or (st.phase == "channel" and "CHANNELING") or "IN PROGRESS"
        return word, COL.GOLD_BRIGHT
    end
    -- 2.15: a waiting order shows its place in the strip under Cancel (the running one is N° 1)
    if st.qpos then
        local french = I18.t("ORDER QUEUE") ~= "ORDER QUEUE"
        return string.format(french and "N° %d" or "#%d", st.qpos + (F.cur_ord and 1 or 0)), COL.GOLD
    end
    if st.locked then return "[ MANUAL ONLY ]", COL.MUTED end
    if item.kind == "skill" and F.low_stam then return "[ LOW STAMINA ]", COL.AMBER end
    if hov and not st.is_empty and item.sub ~= "" then return item.sub, COL.GOLD_BRIGHT end
    return nil
end

local function frame_name() return "frame_" .. (UI.LOOK.cell_shape or "hex") end

-- 2.10: the running order's gauge (2.16: only the thin framed one is kept)
local EMBER = 0xFFA6E7FF

-- 2.15: the shown progress glides towards the engine's estimate instead of jumping (one number per order, no tables
-- made while the wheel is open once an order has been seen)
local SMOOTH = {}
local function smooth(addr, skill, target)
    local now = F.w_now or 0
    local per = SMOOTH[addr]
    if not per then per = {}; SMOOTH[addr] = per end
    local st = per[skill]
    if not st then st = { v = target, t = now }; per[skill] = st end
    local dt = math.min(0.1, math.max(0, now - st.t))
    st.t = now
    if target < st.v - 0.25 then st.v = target end                 -- a new order on the same skill: start again
    st.v = st.v + (target - st.v) * math.min(1, dt * 5)
    if target >= 0.999 and st.v > 0.985 then st.v = 1 end
    return st.v
end

-- a soft light: three discs, the widest faintest
local function soft_light(x, y, s, a)
    draw.filled_circle(x, y, 11 * s, with_alpha(EMBER, a * 0.10), 16)
    draw.filled_circle(x, y, 6.5 * s, with_alpha(EMBER, a * 0.22), 14)
    draw.filled_circle(x, y, 3 * s, with_alpha(0xFFE8F8FF, a * 0.85), 10)
end

-- the filled part fades in towards its tip, in a few steps, so the light seems to lead it
local function soft_fill(x0, y, fw, ph, a)
    if fw <= 0 then return end
    draw.filled_rect(x0, y, fw * 0.55, ph, with_alpha(COL.GOLD, a * 0.75))
    local steps = 6
    for i = 0, steps - 1 do
        local k0, k1 = 0.55 + 0.45 * i / steps, 0.55 + 0.45 * (i + 1) / steps
        local mix = (i + 1) / steps
        draw.filled_rect(x0 + fw * k0, y, fw * (k1 - k0) + 0.5, ph,
            with_alpha(mix > 0.5 and COL.GOLD_BRIGHT or COL.GOLD, a * (0.75 + 0.25 * mix)))
    end
end

local function draw_run_gauge(dx, dy, bw, bh, s, a, prog)
    -- 2.16: the thin framed gauge is the only look left (BardN)
    local x0, w = PX(dx + bw * 0.22), bw * 0.56 * s
    local ph = math.max(3, floor(4 * s + 0.5))
    local y = PY(dy + bh) - ph - 9 * s
    draw.filled_rect(x0 - 1, y - 1, w + 2, ph + 2, with_alpha(COL.GOLD, a * 0.55))   -- frame
    draw.filled_rect(x0, y, w, ph, with_alpha(0xFF000000, a * 0.75))                  -- dark inside
    local fw = w * prog
    soft_fill(x0, y, fw, ph, a)
    if prog < 0.999 then soft_light(x0 + fw, y + ph * 0.5, s, a) end
end

local function draw_button(item)
    local dx, dy, bw, bh, is_left = item.dx, item.dy, item.bw, item.bh, item.side == "left"
    local a, cur_pawn, cur_ord = F.open_anim, F.cur_pawn, F.cur_ord
    local is_skill = (item.kind == "skill")
    local st = {
        hov = (W.sel == item.idx),
        is_empty = (item.kind == "empty"),
        unavailable = is_skill and not AI.skill_available(item.skill_id),
        -- skill locked to "manual only" for this pawn: dimmed (still selectable to order it by hand)
        locked = is_skill and not item.arisen and cur_pawn ~= nil and item.skill_id > 0 and AI.is_locked(cur_pawn.name, item.skill_id),
        running = is_skill and not item.arisen and cur_ord and cur_ord.skill == item.skill_id and item.skill_id > 0,
        qpos = (is_skill and not item.arisen and cur_pawn and item.skill_id > 0) and AI.get_skill_queue_pos(cur_pawn.addr, item.skill_id) or nil,
    }
    -- 2.10: a chargeable skill ordered charged, still in its charge
    st.phase = st.running and cur_pawn ~= nil and AI.run_phase(cur_pawn.addr, item.skill_id) or nil
    -- ATB Combat System (2nd layer): cost of the skill in segments, greyed when the gauge cannot pay it now
    local cost, poor, debt, clabel = nil, false, false, nil
    if is_skill and F.atb and cur_pawn and item.skill_id > 0 then
        cost = API.atb_cost(cur_pawn.addr, item.skill_id)
        clabel = API.atb_cost_label(cur_pawn.addr, item.skill_id)   -- 2.04: two-step skill, cost of each activation
        local state = API.atb_state(cur_pawn.addr, item.skill_id)
        poor = (state == "no")
        debt = (state == "debt")        -- precipitation: allowed, but the gauge goes into the red
    end
    st.poor, st.debt = poor, debt
    local hov = st.hov
    local dim = st.is_empty or st.unavailable or st.locked or poor
    local active = st.running or (item.kind == "stance" and F.cur_stance ~= "free")
        or (item.kind == "team" and F.team_stance ~= nil and F.team_stance ~= "free" and F.team_stance ~= "mixed")

    -- smooth highlight: the button slides outwards a little and its tinted frame fades in
    local gkey = rawget(item, "gkey")       -- built once per cell, not every frame
    if not gkey then
        gkey = tostring(item.side) .. ":" .. tostring(item.kind) .. ":" .. tostring(item.slot or item.idx)
        rawset(item, "gkey", gkey)
    end
    local glv = glow_state[gkey] or 0
    glv = glv + ((hov and 1 or 0) - glv) * math.min(1, glow_dt * 14)
    if glv < 0.01 and not hov then glv = 0 end
    glow_state[gkey] = glv
    local fan = fan_style()
    local solo = (item.side == "solo")          -- 1.37: the chosen skill alone, during the targeting step
    if not fan and not solo then dx = dx + (is_left and -8 or 8) * glv end

    local kx, ky = bw / L.btn_w, bh / L.btn_h    -- smaller cells squeeze the frame picture (margin included)
    local fx, fy = dx - L.btn_pad * kx, dy - L.btn_pad * ky
    local fw, fh = (L.btn_w + 2 * L.btn_pad) * kx, (L.btn_h + 2 * L.btn_pad) * ky
    local base_a = a * ((dim and not hov) and 0.45 or 1.0)
    local open = open_style()
    local med_x = dx + L.med_cx
    local med_y, med_k, icon_h, lamp_y, fan_card   -- 1.22: the Éventail card puts these elsewhere          -- where the medallion sits (the open style moves it next to the curve)
    local x_near                         -- open style: inner side of the cell at its middle (design pixels)
    local drawn
    local solo_k                                 -- 1.37: "row", "banner" or "card": the solo cell's own look
    if solo and (open or fan) then
        drawn = true
        local cx, x0, x1 = dx + bw * 0.5, dx, dx + bw
        local pulse = 0.72 + 0.28 * math.sin((F.w_now or 0) * 2.4)
        if fan then
            -- Éventail: the card lies down under the character (landscape), gold frame and flare
            solo_k = "card"
            image("card_tex_sel", dx, dy, bw, bh, a)
            local t = 3 * s
            local X0, Y0, X1, Y1 = PX(x0), PY(dy), PX(x1), PY(dy + bh)
            seg(X0, Y0, X1, Y0, t, a, SEL_RGB); seg(X1, Y0, X1, Y1, t, a, SEL_RGB)
            seg(X1, Y1, X0, Y1, t, a, SEL_RGB); seg(X0, Y1, X0, Y0, t, a, SEL_RGB)
            local i0, j0, i1, j1 = PX(x0 + 8), PY(dy + 8), PX(x1 - 8), PY(dy + bh - 8)
            seg(i0, j0, i1, j0, s, a * 0.35, GOLD_RGB); seg(i1, j0, i1, j1, s, a * 0.35, GOLD_RGB)
            seg(i1, j1, i0, j1, s, a * 0.35, GOLD_RGB); seg(i0, j1, i0, j0, s, a * 0.35, GOLD_RGB)
            image("flare", cx - 80, dy - 36, 160, 72, a * pulse)
            med_x, med_k, icon_h = x0 + 62, 1.0, L.btn_h
        elseif soph_style() then
            -- Sophistiquée: the gold-flecked metal plate alone, its flare, a thin line under it
            solo_k = "row"
            image("soph_plate_sel", cx - 300, dy - 14, 600, bh + 28, a)
            image("flare", cx - 65, dy + bh - 30, 130, 59, a * pulse)
            fading_line(cx - 310, cx, dy + bh + 12, 1.5 * s, a * 0.8, GOLD_RGB)
            fading_line(cx + 310, cx, dy + bh + 12, 1.5 * s, a * 0.8, GOLD_RGB)
            med_x = cx - 150
        else
            -- Ouvert: bar, lens or banner (setting), lines fading on both sides
            -- Moderne: always the banner (1.38: bar and lens dropped)
            solo_k = "banner"
            local b0, b1 = x0 - 40, x1 + 40
            image("cell_fade_l", b0, dy - 10, cx - b0, bh + 30, a)
            image("cell_fade_r", cx, dy - 10, b1 - cx, bh + 30, a)
            fading_line(b0, cx, dy, 3 * s, a, SEL_RGB); fading_line(b1, cx, dy, 3 * s, a, SEL_RGB)
            fading_line(x0 + 60, cx, dy + bh + 16, 1.5 * s, a * 0.8, GOLD_RGB)
            fading_line(x1 - 60, cx, dy + bh + 16, 1.5 * s, a * 0.8, GOLD_RGB)
            med_x, med_y = cx, dy
        end
    elseif (open or fan) and item.small then
        -- Cancel / Stance: a dark halo under the word and a gold line under it
        image("corner_halo", dx - bw * 0.1, dy + bh * 0.5 - 34, bw * 1.2, 68, base_a)
        image("plate_line", dx, dy + bh - 3, bw, 3, base_a * (0.75 + 0.25 * glv))
        if active then image("plate_line", dx, dy + bh - 3, bw, 3, base_a) end
        drawn = true
    elseif open then
        drawn = true
        local arc = W.arc
        local shift = dx - item.dx                           -- the highlight slide moves the curve too
        local acx, acy, r = arc.cx + shift, arc.cy, arc.r
        local function x_in(y)
            local d = y - acy
            if math.abs(d) >= r then return is_left and (dx + bw) or dx end
            local q = math.sqrt(r * r - d * d)
            return is_left and (acx - q) or (acx + q)
        end
        local outer = is_left and dx or (dx + bw)
        local N = 12
        local xs = {}
        for j = 0, N do xs[j] = x_in(dy + bh * j / N) end
        local near = xs[0]                                    -- the inner side's point closest to the outer end
        for j = 1, N do
            if is_left then near = math.min(near, xs[j]) else near = math.max(near, xs[j]) end
        end
        x_near = near
        if soph_style() then
            -- 1.22 Sophistiquée: a plate of dark scratched metal with soft edges, the chosen one gold-flecked, and a
            -- slowly breathing flare on the curve
            local px0 = is_left and (near - 470) or (near - 50)
            local pa = base_a * 0.85 * (1 - glv)
            if pa > 0.01 then image("soph_plate", px0, dy - 9, 520, bh + 18, pa) end
            if glv > 0.02 then
                image("soph_plate_sel", px0, dy - 9, 520, bh + 18, a * glv)
                local pulse = 0.72 + 0.28 * math.sin((F.w_now or 0) * 2.4)
                image("flare", near - 65, dy + bh * 0.5 - 30, 130, 59, a * glv * pulse)
            end
            -- 2.11: a running order has its gold gauge on this edge: the green line stays for an active stance only
            if active and not st.running then fading_line(outer, near, dy + bh, 2 * s, base_a, ACTIVE_RGB) end
        else
        -- the wash: a stretched picture up to `near`, thin strips between `near` and the curve
        local lo, hi = math.min(outer, near), math.max(outer, near)
        image(is_left and "cell_fade_l" or "cell_fade_r", lo, dy, hi - lo, bh, base_a)
        local tint_on = UI.LOOK.sel_tint ~= false and glv > 0.02
        local tk = F.tint or 0
        if tint_on then image(tinted(is_left and "cell_tint_l_" or "cell_tint_r_", tk), lo, dy, hi - lo, bh, a * glv) end
        for j = 0, N - 1 do
            local xm = (xs[j] + xs[j + 1]) * 0.5
            local x0, x1 = math.min(near, xm), math.max(near, xm)
            local sy, sh = PY(dy + bh * j / N), (bh / N) * s + 1
            strip(PX(x0), sy, (x1 - x0) * s, sh, 0.85 * base_a, DARK_RGB)
            if tint_on then strip(PX(x0), sy, (x1 - x0) * s, sh, 0.55 * a * glv, TINT_RGB[tk] or TINT_RGB[0]) end
        end
        -- the gold lines: top and bottom fade in from the outer end, the curve closes the inner side
        local rgb = active and (st.running and SEL_RGB or ACTIVE_RGB) or ((glv > 0.5) and SEL_RGB or GOLD_RGB)   -- 2.11
        local t = (2.5 + 2.5 * glv) * s
        fading_line(outer, xs[0], dy, t, base_a, rgb)
        fading_line(outer, xs[N], dy + bh, t, base_a, rgb)
        for j = 0, N - 1 do
            seg(PX(xs[j]), PY(dy + bh * j / N), PX(xs[j + 1]), PY(dy + bh * (j + 1) / N), t, base_a, rgb)
        end
        end
        med_x = is_left and (near - 58) or (near + 58)
    elseif fan then
        -- 1.22 Éventail: an upright card; the chosen one rises and turns gold, the others fade with their distance
        drawn, fan_card = true, true
        local sel_item = W.sel and W.slices[W.sel]
        local sel_pos = (sel_item and sel_item.fan_pos) or ((W.fan_n or 1) + 1) * 0.5
        local fade = math.max(0.3, 1 - 0.15 * math.abs((item.fan_pos or sel_pos) - sel_pos))
        a, base_a = a * fade, base_a * fade
        local ck = W.fan_k or 1.0                -- 1.38: card scale (smaller with the ATB Combat System style)
        dy = dy - ((ck < 1) and 30 or 60) * glv
        if glv < 0.98 then image("card_tex", dx, dy, bw, bh, base_a * 0.9 * (1 - glv)) end
        if glv > 0.02 then image("card_tex_sel", dx, dy, bw, bh, a * glv) end
        local rgb = active and (st.running and SEL_RGB or ACTIVE_RGB) or ((glv > 0.5) and SEL_RGB or GOLD_RGB)   -- 2.11
        local t, la = (1.2 + 1.8 * glv) * s, base_a * (0.6 + 0.4 * glv)
        local x0, y0, x1, y1 = PX(dx), PY(dy), PX(dx + bw), PY(dy + bh)
        seg(x0, y0, x1, y0, t, la, rgb); seg(x1, y0, x1, y1, t, la, rgb)
        seg(x1, y1, x0, y1, t, la, rgb); seg(x0, y1, x0, y0, t, la, rgb)
        local i0, j0, i1, j1 = PX(dx + 10), PY(dy + 10), PX(dx + bw - 10), PY(dy + bh - 10)
        seg(i0, j0, i1, j0, s, base_a * 0.3, GOLD_RGB); seg(i1, j0, i1, j1, s, base_a * 0.3, GOLD_RGB)
        seg(i1, j1, i0, j1, s, base_a * 0.3, GOLD_RGB); seg(i0, j1, i0, j0, s, base_a * 0.3, GOLD_RGB)
        if glv > 0.02 then
            local pulse = 0.72 + 0.28 * math.sin((F.w_now or 0) * 2.4)
            image("flare", dx + bw * 0.5 - 90, dy - 40, 180, 81, a * glv * pulse)
        end
        med_x, med_y, med_k, icon_h, lamp_y = dx + bw * 0.5, dy + 100 * ck, 1.45 * ck, 72 * 1.45 * ck, dy + 24 * ck
    else
        drawn = image(active and (frame_name() .. "_on") or (frame_name() .. "_idle"), fx, fy, fw, fh, base_a)
        if drawn and glv > 0.02 then image(tinted(frame_name() .. "_sel_", F.tint), fx, fy, fw, fh, a * glv) end
    end
    if not drawn then
        draw_panel(PX(dx), PY(dy), bw * s, bh * s, hov and COL.PANEL_HOV or COL.PANEL,
            active and COL.GREEN or (hov and COL.GOLD_BRIGHT or COL.GOLD), base_a)
    end

    -- skill icon in its medallion
    local has_icon = false
    if is_skill and item.icon and IN.show_skill_icons ~= false and images["skill_" .. item.icon] then
        local mcy = med_y or (dy + bh * 0.5)
        local msz = L.med_size * (med_k or ky)
        image("med", med_x - msz * 0.5, mcy - msz * 0.5, msz, msz, base_a)
        local isz = (icon_h or bh) * 0.98                     -- the artwork's solid disc is ~0.75 of the picture
        has_icon = image("skill_" .. item.icon, med_x - isz * 0.5, mcy - isz * 0.5, isz, isz, base_a)
    end

    -- the stance icon, in the same medallion as the skill icons
    if (item.kind == "stance" or item.kind == "team") and UI.LOOK.stance_icons ~= false then
        local mode = (item.kind == "team") and F.team_stance or F.cur_stance
        if mode == "mixed" then mode = nil end
        -- Free deliberately has no picture. A pawn fighting as it likes has not been given an order, and a medallion
        -- sitting there would read as one; an empty cell says "nothing asked of them" better than any icon could.
        local key
        if mode == "close" then
            key = "stance_" .. (UI.LOOK.stance_close_art or "free")
        elseif mode == "wait" or mode == "ranged" then
            key = "stance_" .. mode
        end
        if key and images[key] then
            local mcy = med_y or (dy + bh * 0.5)
            local msz = L.med_size * (med_k or ky)
            image("med", med_x - msz * 0.5, mcy - msz * 0.5, msz, msz, base_a)
            local isz = (icon_h or bh) * 1.02 * (UI.LOOK.stance_icon_size or 1.0)
            has_icon = image(key, med_x - isz * 0.5, mcy - isz * 0.5, isz, isz, base_a)
        end
    end

    -- the right diamond of the cell: it follows the width of the cell (and its slide when highlighted)
    local diamond_x = dx + bw - (L.btn_w - L.lamp_cx) * kx
    -- 1.21 open style: the lamp and the slot keys go to the outer end (the inner end holds the medallion)
    local open_cell = open and not item.small and not solo_k     -- 1.37: not the solo cell
    if open_cell then diamond_x = is_left and (dx + 40) or (dx + bw - 40) end
    if fan_card then diamond_x = dx + bw - 24 end
    if solo_k then diamond_x = dx + bw - ((solo_k == "card") and 24 or 50) end
    -- 1.31: in the open styles the lock lamp sits on the centre side, between the medallion and the curve
    local lamp_x = diamond_x
    if open_cell and x_near then lamp_x = is_left and (x_near - 12) or (x_near + 12) end

    -- lock lamp on the right diamond (green = the pawn may cast it by itself, dark = manual only)
    if is_skill and item.skill_id > 0 and U.LAMP.enabled ~= false and cur_pawn and not item.arisen then
        local r = 11 * s * (U.LAMP.size or 1.0)
        draw_status_lamp(PX(lamp_x + (U.LAMP.dx or 0)), PY((lamp_y or (dy + bh * 0.5)) + (U.LAMP.dy or 0)), r, not st.locked, a)
    end

    -- the Arisen: the game's own button of this skill slot (X, Y, A, B, X+A, Y+B), for information only
    local keys_w = 0
    if item.arisen and item.keys and UI.LOOK.slot_keys ~= false then
        local gs = F.glyph_px * (UI.LOOK.slot_keys_size or 0.8)
        local gap = 3 * s
        local total = 0
        for i, g in ipairs(item.keys) do total = total + glyph_width(g, gs) + ((i > 1) and gap or 0) end
        local _, th = text_size("X", F.font_small)
        local x = PX(diamond_x + 10) - total
        if fan_card then x = PX(dx + bw * 0.5) - total * 0.5 end
        if open_cell and is_left then x = PX(dx + 30) end
        local cy = PY(fan_card and (dy + bh - 34 * (W.fan_k or 1)) or (dy + bh * 0.5))
        for _, g in ipairs(item.keys) do
            local gw = glyph_width(g, gs)
            draw_glyph(g, x + gw * 0.5, cy, gs, base_a, F.font_small, th)
            x = x + gw + gap
        end
        keys_w = total / s
    end

    -- live progress of the running order (2.10: three gold looks, menu "RUNNING ORDER")
    if st.running and cur_pawn then
        local prog = AI.get_skill_progress(cur_pawn.addr, item.skill_id, F.g_now)
        if prog and prog > 0 then
            draw_run_gauge(dx, dy, bw, bh, s, a, smooth(cur_pawn.addr, item.skill_id, prog))
        end
    end

    -- ATB cost: short slanted segments at the top of the cell (FF XIII-2 colours), grey when the gauge is too low
    if clabel or (cost and cost > 0) then
        local n = math.min(cost or 0, 8)
        local pw, ph, pg = 20 * s, math.max(3, 7 * s), 5 * s
        local sk = ph * 0.45
        local lw, lh = 0, 0
        if clabel then lw, lh = text_size(clabel, F.font_small) end
        local total = clabel and lw or (n * pw + (n - 1) * pg)
        local x0 = PX(dx + bw * 0.5 + (has_icon and 23 or 0) - keys_w * 0.5) - total * 0.5
        if open_cell then
            local tw = text_size(item.name, item.small and F.font_small or F.font_cell)
            local edge = PX(has_icon and (is_left and (med_x - 48) or (med_x + 48)) or (is_left and (x_near - 30) or (x_near + 30)))
            x0 = (is_left and (edge - tw * 0.5) or (edge + tw * 0.5)) - total * 0.5
        end
        local y0 = PY(dy) + bh * s * 0.10
        if fan_card then x0, y0 = PX(dx + bw * 0.5) - total * 0.5, PY(dy + bh - 52 * (W.fan_k or 1)) end
        if solo_k == "banner" then x0, y0 = PX(dx + bw * 0.5) - total * 0.5, PY(dy + bh - 4)
        elseif solo_k and has_icon then x0 = PX(med_x + 48) + sk
            if solo_k == "card" then y0 = PY(dy + bh - 30) end
        end
        local fill = poor and 0xFF4A443D or (debt and 0xFF3030FF or 0xFF5C8DFF)
        local edge = poor and 0xFF5A544D or (debt and 0xFF8080FF or 0xFFD8A88F)
        if debt then
            local pulse = 0.55 + 0.45 * math.sin(F.w_now * 8.0)
            fill = (math.floor(255 * pulse + 0.5) << 24) | (fill & 0x00FFFFFF)
        end
        if clabel then
            -- 2.04: two-step skill: "( 1st / 2nd )" in place of the segments, same colours
            local tc = poor and 0xFF8A847D or (debt and 0xFF6060FF or 0xFF9CC8FF)
            if debt then tc = (fill & 0xFF000000) | (tc & 0x00FFFFFF) end
            draw_aligned_text(clabel, x0, y0 + ph * 0.5 - (lh or 0) * 0.5, tc, a, F.font_small)
            n = 0
        end
        for i = 0, n - 1 do
            local x = x0 + i * (pw + pg)
            pcall(draw.filled_quad, x + sk, y0, x + pw + sk, y0, x + pw - sk, y0 + ph, x - sk, y0 + ph, with_alpha(edge, a))
            pcall(draw.filled_quad, x + sk + 1, y0 + 1, x + pw + sk - 1, y0 + 1, x + pw - sk - 1, y0 + ph - 1, x - sk + 1, y0 + ph - 1, with_alpha(fill, a))
        end
    end

    local txt_col = ((dim and not hov) or st.is_empty) and COL.MUTED or (hov and 0xFFFFFFFF or COL.TEXT)
    local tag, tag_col = button_tag(item, st)
    local mid_x = PX(dx + bw * 0.5 + (has_icon and 23 or 0) - keys_w * 0.5)
    local top, h = PY(dy), bh * s
    local font = item.small and F.font_small or F.font_cell
    local _, th = text_size(item.name, font)
    local align = "center"
    if solo_k then txt_col = 0xFFFFFFFF end
    if solo_k == "banner" then
        mid_x, top = PX(dx + bw * 0.5), PY(dy + 16)
    elseif solo_k then
        if has_icon then mid_x, align = PX(med_x + 48), "left" else mid_x = PX(dx + bw * 0.5) end
    elseif open_cell then
        -- 1.21: the text leans on the medallion, towards the centre of the wheel
        local edge = has_icon and (is_left and (med_x - 48) or (med_x + 48)) or (is_left and (x_near - 30) or (x_near + 30))
        mid_x, align = PX(edge), is_left and "right" or "left"
    end
    if fan_card then
        -- 1.22: centred under the medallion, on two lines when the name is too wide for the card
        local cxp, f2 = PX(dx + bw * 0.5), F.font_card or font
        local name = I18.t(item.name)
        local l1, l2 = name, nil
        local sp = name:find(" ", 1, true)
        if sp and text_size(name, f2) > (bw - 24) * s then l1, l2 = name:sub(1, sp - 1), name:sub(sp + 1) end
        local _, th2 = text_size(l1, f2)
        local ck = W.fan_k or 1
        draw_aligned_text(l1, cxp, PY(dy + 166 * ck), txt_col, a, f2, "center")
        if l2 then draw_aligned_text(l2, cxp, PY(dy + 166 * ck) + th2 + 2 * s, txt_col, a, f2, "center") end
        if tag then draw_aligned_text(tag, cxp, PY(dy + bh - 80 * ck), tag_col, 0.95 * a, F.font_small, "center") end
    elseif tag then
        draw_aligned_text(item.name, mid_x, top + h * 0.36 - th * 0.5, txt_col, a, font, align)
        draw_aligned_text(tag, mid_x, top + h * 0.70 - 6 * s, tag_col, 0.95 * a, F.font_small, align)
    else
        draw_aligned_text(item.name, mid_x, top + (h - th) * 0.5, txt_col, a, font, align)
    end
end

-- Where every cell sits (design pixels), from the "Position of the cells" settings (UI.POS). Runs every frame before the
-- stick is read, so the stick always aims at the cells where they are drawn (see in/steer.lua, W.aim).
local function place_cells()
    local P = UI.POS
    local gap, bh = P.skill_gap, L.btn_h
    local bw = L.btn_w * P.skill_w
    local col_h = 3 * bh + 2 * gap
    local mid_y = L.col_cy + P.skill_dy
    local y0 = mid_y - col_h * 0.5
    local left_edge  = L.col_left + L.btn_w - P.skill_dist     -- side of the left column next to the circle
    local right_edge = L.col_right + P.skill_dist              -- side of the right column next to the circle
    for _, item in ipairs(W.skill_items) do
        local row = (item.slot - 1) % 3
        item.bw, item.bh = bw, bh
        item.dx = (item.side == "left") and (left_edge - bw) or right_edge
        -- the middle cell of each column can stand out (or in), mirrored on both sides, for a rounder wheel
        if row == 1 then item.dx = item.dx + ((item.side == "left") and -1 or 1) * (P.skill_mid_dx or 0) end
        item.dy = y0 + row * (bh + gap)
    end
    -- Cancel bottom-left, Stance bottom-right: under the skills
    local cw = L.corner_w * P.corner_w
    local cy = y0 + col_h + 36 + L.corner_h * 0.5 + P.corner_dy
    for _, item in ipairs(W.corner_items) do
        local ccx = L.cx + ((item.side == "left") and -1 or 1) * P.corner_dx
        item.bw, item.bh, item.small = cw, L.corner_h, true
        item.dx, item.dy = ccx - cw * 0.5, cy - L.corner_h * 0.5
    end
    for _, item in ipairs(W.slices) do
        if item.bw then item.cx, item.cy = item.dx + item.bw * 0.5, item.dy + item.bh * 0.5 end
    end
    -- the stick aims from the middle of the skills towards an ellipse passing through the skill columns and the corners
    local rx = L.cx - (left_edge - bw * 0.5)
    W.aim = { cx = L.cx, cy = mid_y, rx = rx, ry = math.max(60, cy - mid_y + 30) }
    -- 1.21: the circle the inner side of the cells follows (open style), and the ring just inside it
    W.arc = { cx = L.cx, cy = mid_y, r = (L.cx - left_edge) + 25 }
    W.layout = nil
    if fan_style() then
        -- 1.22 Éventail: the skills as upright cards along the bottom, left column first; Cancel and Stance in the
        -- bottom corners. The cards are 200 x 320 design pixels, 190 apart, all at the same height (1.37: no more arc;
        -- the chosen one still rises).
        local order = {}
        for _, item in ipairs(W.skill_items) do order[#order + 1] = item end
        table.sort(order, function(p, q)
            local sp, sq = (p.side == "left") and 0 or 1, (q.side == "left") and 0 or 1
            if sp ~= sq then return sp < sq end
            return (p.slot or 0) < (q.slot or 0)
        end)
        local n = #order
        W.fan_order, W.fan_n, W.layout = {}, n, "fan"
        -- 1.38: with the ATB Combat System style the cards are 15 % smaller (bottom edge kept) to leave room for its gauge above
        local ck = (API.atb_on() and UI.LOOK.atb_style ~= false) and 0.85 or 1.0
        W.fan_k = ck
        for k, item in ipairs(order) do
            local d = (k - 1) - (n - 1) * 0.5
            local ccx, ccy = L.cx + d * 190 * ck, 1020 - 160 * ck
            item.bw, item.bh, item.small = 200 * ck, 320 * ck, nil
            item.dx, item.dy, item.fan_pos = ccx - 100 * ck, ccy - 160 * ck, k
            W.fan_order[k] = item.idx
        end
        for _, item in ipairs(W.corner_items) do
            item.bw, item.bh, item.small = 320, L.corner_h, true
            item.dx = (item.side == "left") and 40 or (1920 - 360)
            item.dy = 1000
        end
        for _, item in ipairs(W.slices) do
            if item.bw then item.cx, item.cy = item.dx + item.bw * 0.5, item.dy + item.bh * 0.5 end
        end
        W.aim = { cx = L.cx, cy = 860, rx = 600, ry = 160 }
    end
end

------------------------------------------------------------------------------------------------
-- Row of characters at the top (carousel): one coloured band per character (its class colour), its class emblem,
-- (and the ATB gauge with the ATB module). The shown character is always in the middle; switching makes the bands slide by one place.
------------------------------------------------------------------------------------------------
local function wrap(v, n) return v - n * math.floor(v / n) end

-- emblem of a character in the top row: the Arisen's heart, the class emblem of a pawn
local function emblem_of(p)
    if p.kind == "arisen" and images["heart"] then return "heart", 1.0 end
    return "job_" .. tostring(p.job), (D.JOB_ICON_ASPECT[p.job or 0] or 0.9)
end

local function draw_pawn_row(selected_pawn, a, dt)
    local pawns = W.pawns
    local n = #pawns
    if not UI.LOOK.top_row or n == 0 then return end
    -- 1.22 Sophistiquée: a sheet of dark smoke behind the character cards
    if soph_style() then image("soph_smoke_dark", L.cx - 260, 10, 520, 250, a * 0.45 * (UI.LOOK.soph_smoke or 1.0)) end

    -- shown position slides towards the selected index, along the shortest way round
    local pos = W.car_pos or W.pawn_idx
    local diff = wrap(W.pawn_idx - pos + n * 0.5, n) - n * 0.5
    local T = math.max(0.01, (UI.LOOK.carousel_ms or 150) / 1000)
    pos = pos + diff * math.min(1, dt * 3 / T)
    if math.abs(wrap(W.pawn_idx - pos + n * 0.5, n) - n * 0.5) < 0.002 then pos = W.pawn_idx end
    W.car_pos = wrap(pos - 1, n) + 1

    -- only the selected character and its two neighbours are shown, the selected one exactly in the middle;
    -- the others come in (fading) while the row slides. With 2 characters the other one is shown on both sides.
    local step = L.band_w + L.band_gap
    local extra = (L.band_sel_w - L.band_w) * 0.5
    local function x_of(d)
        local sgn = (d > 0) and 1 or ((d < 0) and -1 or 0)
        return L.cx + d * step + sgn * math.min(math.abs(d), 1) * extra
    end

    for i, p in ipairs(pawns) do
        local d0 = wrap(i - W.car_pos + n * 0.5, n) - n * 0.5
        for _, d in ipairs({ d0 - n, d0, d0 + n }) do
            local ad = math.abs(d)
            if ad < 1.5 and (n > 1 or ad < 0.5) then
                local edge = math.min(1, math.max(0, (1.5 - ad) * 2))
                local t = math.max(0, 1 - ad)                    -- 1 = in the middle (selected size)
                local bw = L.band_w + (L.band_sel_w - L.band_w) * t
                local bh = L.band_h + (L.band_sel_h - L.band_h) * t
                local top = L.row_top + 21 * (1 - t)
                local x = x_of(d) - bw * 0.5
                local ba = a * edge
                -- 1.38: the Cards style uses the same row as the others, in the middle (no more small discs at the top left)
                if ba > 0.01 then
                    local tk = tint_key(p.job)
                    local sel = t > 0.5
                    local open = open_style() or fan_style()     -- 1.38: Cards style: the Modern cards
                    if open then
                        -- 1.21: an open card: a dark wash fading downwards, the vocation's tint on the chosen one,
                        -- a gold line on top that fades at both ends
                        local ca = ba * (0.75 + 0.25 * t)
                        image("card_fade", x, top, bw, bh, ca)
                        if UI.LOOK.sel_tint ~= false and tk ~= 0 then image(tinted("card_tint_", tk), x, top, bw, bh, ca * t) end
                        image("plate_line", x, top - 1, bw, 2 + t, ca)
                    else
                        image(tinted(sel and "band_sel_" or "band_", tk), x, top, bw, bh, ba)
                    end

                    -- the locked character wears a golden frame (a small gold diamond on the open card), so the player
                    -- sees at a glance who closing the wheel returns them to
                    if open and Poss.is_locked(p) and Poss.available() then
                        image("diamond", x + bw * 0.5 - 9, top - 9, 18, 18, ba)
                    elseif Poss.is_locked(p) and Poss.available() then   -- 1.09: no frame without Direct Pawn Control
                        local col = with_alpha(COL.GOLD_BRIGHT, ba)
                        local x0, y0, x1, y1 = PX(x), PY(top), PX(x + bw), PY(top + bh)
                        for o = 0, 2 do
                            local d = o * s
                            draw.line(x0 - d, y0 - d, x1 + d, y0 - d, col)
                            draw.line(x0 - d, y1 + d, x1 + d, y1 + d, col)
                            draw.line(x0 - d, y0 - d, x0 - d, y1 + d, col)
                            draw.line(x1 + d, y0 - d, x1 + d, y1 + d, col)
                        end
                    end
                    local key, aspect = emblem_of(p)
                    local look = UI.LOOK
                    local base_h = 84 + (118 - 84) * t                       -- the emblem's place in the band
                    local cy = top + 30 + base_h * 0.5                       -- (its centre stays put whatever the size)
                    local ih = 84 * (1 + ((look.row_sel_scale or 1.4) - 1) * t) * (look.row_icon_size or 1.0)
                    if p.kind == "arisen" then ih = ih * (look.row_arisen_size or 1.0) end
                    local iw = ih * aspect
                    image(key, x + (bw - iw) * 0.5, cy - ih * 0.5, iw, ih, ba * (0.9 + 0.1 * t), true)
                    -- 1.12: no life / stamina bars under the portraits any more (not pretty, not useful).
                    -- 1.37: the ATB gauge is gone from the top row too (the ATB Combat System draws its own gauges).
                end
            end
        end
    end

    -- previous / next character: the D-pad picture (or the button really bound) beside the row
    if n > 1 then
        local look = UI.LOOK
        local cy = PY(L.row_top + 95)
        local gs = F.glyph_px * 1.3 * (look.dpad_size or 1.0)
        local _, th = text_size("X", F.font_small)
        local hint = look.dpad_hint or "arrow"
        local left_edge = x_of(-1) - L.band_w * 0.5
        local right_edge = x_of(1) + L.band_w * 0.5
        local function side(bind, gx, dir)
            local g = bind_glyph(bind)
            if W.kbm or W.mode == "mouse" then           -- keyboard key of the previous / next character
                local kb = (dir < 0) and IN.BINDS.kb_prev_pawn or IN.BINDS.kb_next_pawn
                g = (kb and kb > 0) and ("K:" .. X.kb_label(kb)) or nil
            end
            if not g then return end
            local is_dpad = (g == "DLeft" or g == "DRight")
            local gw = is_dpad and gs * ((hint == "arrow" or hint == "both") and 1.9 or 1.0) or glyph_width(g, gs)
            local gcx = PX(gx) + dir * gw * 0.5
            if is_dpad then
                draw_dpad_switch(PX(gx) + dir * gs * 0.5, cy, gs, a, dir, hint)
            else
                draw_glyph(g, gcx, cy, gs, a, F.font_small, th)
            end
            local lx = gcx + dir * (gw * 0.5 + 16 * s)
            for i = 0, 9 do     -- 10 segments, fading out
                draw.line(lx + dir * i * 19 * s, cy, lx + dir * (i + 1) * 19 * s, cy, with_alpha(COL.GOLD, a * (1 - i / 10)))
            end
        end
        side(IN.BINDS.pad_prev_pawn, left_edge - 48, -1)
        side(IN.BINDS.pad_next_pawn_2, right_edge + 48, 1)
    end
end

------------------------------------------------------------------------------------------------
-- Central circle: class emblem, class name, name, stance (pawns) and a hint
------------------------------------------------------------------------------------------------
local function center_hint(entry, sel_item, cur_queue)
    local B = IN.BINDS
    local a_lbl = X.pad_label(IN.get_pad_short_name(B.pad_confirm_close) or "A")
    local q_btn = X.pad_label(IN.get_pad_short_name(B.pad_queue_toggle) or "X")
    local npawns = #IN.pawns_only()
    if entry.kind ~= "arisen" and #cur_queue > 0 then return string.format("QUEUED: %d/%d", #cur_queue, D.MAX_QUEUE) end
    if sel_item and sel_item.kind == "team" then
        return a_lbl .. " = NEXT STANCE FOR ALL PAWNS"
    end
    if sel_item and sel_item.kind == "stance" then
        if npawns > 1 then return a_lbl .. " TO CHANGE STANCE | " .. q_btn .. " = ALL PAWNS" end
        return a_lbl .. " TO CHANGE STANCE"
    end
    if sel_item and sel_item.kind == "cancel" and entry.kind ~= "arisen" and npawns > 1 then
        return q_btn .. " = ALL PAWNS | " .. a_lbl .. " = ONE"
    end
    if sel_item and sel_item.kind ~= "empty" then
        -- 2.14: no more "order and stay" on the controller: the queue button keeps the wheel open instead
        if entry.kind == "arisen" then return a_lbl .. " TO ORDER" end
        return a_lbl .. " TO ORDER & CLOSE | " .. q_btn .. " TO QUEUE"
    end
    return "STEER LEFT OR RIGHT"
end

-- A thin decorative ring in the class colour (no gauge: just a full circle minus the medallion gap)
local function draw_thin_ring(cx, cy, a)
    if not UI.LOOK.ring_thin then return end
    local class_col = D.TINT_COL[F.tint] or D.TINT_COL[0]
    local w = 2.5 * s
    local r_in, r_out = L.ring_r * s - w * 0.5, L.ring_r * s + w * 0.5
    draw_arc(cx, cy, r_in, r_out, -math.pi * 0.5 + 0.34, math.pi * 1.5 - 0.06, with_alpha(class_col, 0.75 * a))
end

local function draw_center(entry, sel_item, cur_queue, a)
    local voc = UI.VOC
    local job = entry.job
    local cx = PX(L.cx)
    local half = L.circle_img * 0.5
    if not image(tinted("circle_", F.tint), L.cx - half, L.circle_cy - half, L.circle_img, L.circle_img, a) then
        pcall(draw.filled_circle, cx, PY(L.circle_cy), 178 * s, with_alpha(COL.PANEL, 0.92 * a), 64)
        pcall(draw.outline_circle, cx, PY(L.circle_cy), 178 * s, with_alpha(COL.GOLD_BRIGHT, a), 64)
    end
    draw_thin_ring(cx, PY(L.circle_cy), a)
    if voc.enabled and job then
        local key, aspect = emblem_of(entry)
        local ih = L.badge_h * voc.size
        local iw = ih * aspect
        image(key, L.cx + voc.dx - iw * 0.5, L.badge_cy + voc.dy - ih * 0.5, iw, ih, a * voc.opacity, true)
    end

    if voc.show_name and entry.job_info then
        draw_aligned_text(entry.job_info.name, cx, PY(394), COL.GOLD_BRIGHT, a, F.font_class, "center")
    end
    draw_aligned_text(U.upper(entry.name), cx, PY(424), COL.TEXT, a, F.font_title, "center")
    local y = 474
    if entry.kind ~= "arisen" then
        draw_aligned_text(D.STANCE_LABELS[F.cur_stance] or D.STANCE_LABELS.free, cx, PY(474),
            (F.cur_stance ~= "free") and COL.GREEN or COL.GOLD_BRIGHT, 0.95 * a, F.font_small, "center")
        y = 500
    end
    -- the hint: on two lines when it is too wide for the circle ("A : ... | R3 : ...")
    local hint = I18.t(center_hint(entry, sel_item, cur_queue))
    local cut = hint:find(" | ", 1, true)
    if cut and text_size(hint, F.font_small) > 300 * s then
        draw_aligned_text(hint:sub(1, cut - 1), cx, PY(y + 4), COL.TEXT, 0.85 * a, F.font_small, "center")
        draw_aligned_text(hint:sub(cut + 3), cx, PY(y + 27), COL.TEXT, 0.85 * a, F.font_small, "center")
    else
        draw_aligned_text(hint, cx, PY(y + 4), COL.TEXT, 0.85 * a, F.font_small, "center")
    end
end

-- 1.20: the same information as the circle, at the bottom middle, under the line of Cancel and Stance. No frame any
-- more: a thin gold line that fades at both ends, a dark shade under it that fades downwards and to the sides, the
-- class emblem set on the line, then the name and the vocation. The stance only shows when the pawn has been given one
-- (Free is the usual case). Its height is a setting (look_plate_offset); the key bar moves down when the two would meet.
local PLATE_GAP, PLATE_W, PLATE_H = 44, 800, 200
local function draw_center_plate(entry, sel_item, cur_queue, a)
    local row_cy
    for _, it in ipairs(W.corner_items) do
        if it.bw then row_cy = it.cy end
    end
    local ly = (row_cy or 668) + L.corner_h * 0.5 + PLATE_GAP + (UI.LOOK.plate_offset or 100)
    local cx = L.cx

    if soph_style() then
        -- 1.22 Sophistiquée: a sheet of dark smoke behind the name, a soft burst of light behind the emblem
        local sm = UI.LOOK.soph_smoke or 1.0
        image("soph_smoke_dark", cx - 450, ly - 42, 900, 432, a * 0.55 * sm)
        image("soph_burst_ring", cx - 60, ly - 70, 120, 141, a * 0.45)
    end
    image("plate_fade", cx - PLATE_W * 0.5, ly, PLATE_W, PLATE_H, a)
    image("plate_line", cx - PLATE_W * 0.5, ly - 1, PLATE_W, 3, a)

    -- the class emblem (the Arisen's heart) on the line, on a small dark disc
    local voc = UI.VOC
    if voc.enabled and entry.job then
        local key, aspect = emblem_of(entry)
        image("plate_disc", cx - 26, ly - 26, 52, 52, a)
        local ih = 34 * voc.size
        local iw = ih * aspect
        image(key, cx - iw * 0.5, ly - ih * 0.5, iw, ih, a * voc.opacity, true)
    end
    local mid = PX(cx)

    draw_aligned_text(U.upper(entry.name), mid, PY(ly + 30), COL.TEXT, a, F.font_plate_name, "center")

    -- second line: vocation (gold), then the stance in a quiet green, only when one has been given
    local parts = {}
    if voc.show_name and entry.job_info then parts[#parts + 1] = { entry.job_info.name, COL.GOLD_BRIGHT } end
    if entry.kind ~= "arisen" and F.cur_stance and F.cur_stance ~= "free" then
        local label = (D.STANCE_LABELS[F.cur_stance] or ""):gsub("^STANCE:%s*", "")
        if label ~= "" then parts[#parts + 1] = { label, COL.GREEN, 0.75 } end
    end
    local dot = "  .  "
    local total, dw = 0, text_size(dot, F.font_plate_sub)
    for i, p in ipairs(parts) do
        p.w = text_size(I18.t(p[1]), F.font_plate_sub)
        total = total + p.w + ((i > 1) and dw or 0)
    end
    local x = mid - total * 0.5
    for i, p in ipairs(parts) do
        if i > 1 then draw_aligned_text(dot, x, PY(ly + 64), COL.MUTED, 0.75 * a, F.font_plate_sub); x = x + dw end
        draw_aligned_text(p[1], x, PY(ly + 64), p[2], (p[3] or 0.95) * a, F.font_plate_sub)
        x = x + p.w
    end

    -- the hint, under the vocation (two lines when it is long: "A : ... | R3 : ...")
    local hint = I18.t(center_hint(entry, sel_item, cur_queue))
    local hy = ly + 92
    local cut = hint:find(" | ", 1, true)
    local bottom = hy + 22
    if cut and text_size(hint, F.font_small) > 520 * s then
        draw_aligned_text(hint:sub(1, cut - 1), PX(cx), PY(hy), COL.TEXT, 0.85 * a, F.font_small, "center")
        draw_aligned_text(hint:sub(cut + 3), PX(cx), PY(hy + 23), COL.TEXT, 0.85 * a, F.font_small, "center")
        bottom = hy + 45
    else
        draw_aligned_text(hint, PX(cx), PY(hy), COL.TEXT, 0.85 * a, F.font_small, "center")
    end
    F.plate_bottom = bottom
end

------------------------------------------------------------------------------------------------
-- 1.22 Éventail: the shown character's name, vocation and stance at the top left, under the row of characters
------------------------------------------------------------------------------------------------
draw_fan_header = function(entry, sel_item, cur_queue, a)
    local x, y = 330, 40
    draw_aligned_text(U.upper(entry.name), PX(x), PY(y), COL.TEXT, a, F.font_title)
    local line = (UI.VOC.show_name and entry.job_info) and I18.t(entry.job_info.name) or ""
    if entry.kind ~= "arisen" then
        local st = (D.STANCE_LABELS[F.cur_stance] or D.STANCE_LABELS.free):gsub("^STANCE:%s*", "")
        line = (line ~= "" and (line .. "  .  ") or "") .. I18.t(st)
    end
    draw_aligned_text(line, PX(x + 2), PY(y + 48), COL.GOLD_BRIGHT, 0.95 * a, F.font_small)
    image("plate_line", 60, 145, 520, 2, a)
    local hint = I18.t(center_hint(entry, sel_item, cur_queue))
    draw_aligned_text(hint, PX(62), PY(158), COL.TEXT, 0.8 * a, F.font_small)
end

------------------------------------------------------------------------------------------------
-- 1.22 style ATB Combat System: a big ATB gauge at the bottom left, the order queue sitting on it (each order as wide as the
-- segments it costs, the first one on the leftmost segment), the party list at the bottom right. Lines (open look)
-- or metal plates (Sophistiquée look), following the chosen style.
------------------------------------------------------------------------------------------------
local ATB_RGB, HP_RGB, ATB_GAP = 0x5C8DFF, 0x6FC266, 8

local function fit(str, font, max_px)              -- shortens with "…" when it does not fit (screen pixels)
    if text_size(str, font) <= max_px then return str end
    local t = str
    while #t > 1 and text_size(t .. "…", font) > max_px do t = t:sub(1, -2) end
    return t .. "…"
end

-- 2.13: the pawn's order queue under the corner cells, as arrow-shaped bands (planche Q5 / V1): the running order
-- first, with its state and gauge, then the waiting ones. Drawn only while the wheel is open on a pawn.
local function draw_order_strip(cur, a)
    if a <= 0.01 then return end
    local left
    for _, it in ipairs(W.corner_items or {}) do if it.side == "left" then left = it end end
    if not left or not left.dx then return end
    local list = {}
    local run = AI.get_active_timer_for_pawn(cur.addr)
    if run and run.skill and run.skill > 0 then list[#list + 1] = run.skill end
    for _, q in ipairs(AI.get_pawn_queue(cur.addr) or {}) do list[#list + 1] = q.skill end
    if #list == 0 then return end

    local french = I18.t("ORDER QUEUE") ~= "ORDER QUEUE"
    local h = 52
    local x, cy = left.dx, left.dy + left.bh + 16 + h * 0.5
    local tip = h * 0.45
    local _, nh = text_size("X", F.font_small)
    for i, sk in ipairs(list) do
        local first = (i == 1) and run ~= nil
        local w = first and 300 or 255
        local top, bot = cy - h * 0.5, cy + h * 0.5
        local ax, bx, cx2, fx = PX(x), PX(x + w - tip), PX(x + w), PX(x + tip)
        local ty, my, by = PY(top), PY(cy), PY(bot)
        local fill = with_alpha(0xFF080B0D, a * 0.88)
        pcall(draw.filled_quad, ax, ty, bx, ty, cx2, my, fx, my, fill)
        pcall(draw.filled_quad, fx, my, cx2, my, bx, by, ax, by, fill)
        local rgb, la, t = first and SEL_RGB or GOLD_RGB, first and a or a * 0.5, (first and 2 or 1.2) * s
        seg(ax, ty, bx, ty, t, la, rgb); seg(bx, ty, cx2, my, t, la, rgb); seg(cx2, my, bx, by, t, la, rgb)
        seg(bx, by, ax, by, t, la, rgb); seg(ax, by, fx, my, t, la, rgb); seg(fx, my, ax, ty, t, la, rgb)

        local name = U.get_skill_display_name(sk) or "?"
        local sub
        if first then
            local ph = AI.run_phase(cur.addr, sk)
            sub = (ph == "sent" and "ORDER SENT") or (ph == "channel" and "CHANNELING") or "IN PROGRESS"
        else
            sub = string.format(french and "N° %d" or "#%d", i)
        end
        local mid = PX(x + w * 0.5)
        local nf = first and F.font_cell or F.font_small
        local name_fit = fit(I18.t(name), nf, (w - 2 * tip - 16) * s)
        local _, th = text_size(name_fit, nf)
        draw_aligned_text(name_fit, mid, my - th + 2 * s, first and 0xFFFFFFFF or COL.TEXT, a, nf, "center")
        draw_aligned_text(sub, mid, my + 3 * s, first and COL.GOLD_BRIGHT or COL.MUTED, 0.95 * a, F.font_small, "center")
        if first then
            local prog = AI.get_skill_progress(cur.addr, sk, F.g_now)
            if prog and prog > 0 then
                prog = smooth(cur.addr, sk, prog)
                local gx, gw = PX(x + tip + 6), (w - 2 * tip - 12) * s
                local ph = math.max(2, floor(3 * s + 0.5))
                local gy = by - ph - 5 * s
                draw.filled_rect(gx - 1, gy - 1, gw + 2, ph + 2, with_alpha(COL.GOLD, a * 0.45))    -- thin frame
                draw.filled_rect(gx, gy, gw, ph, with_alpha(0xFF000000, a * 0.75))
                soft_fill(gx, gy, gw * prog, ph, a)
                if prog < 0.999 then soft_light(gx + gw * prog, gy + ph * 0.5, s, a) end
            end
        end
        x = x + w - 12
    end
end


draw_atb_layer = function(cur, a)
    local soph = soph_style()
    local pts, mx, pps, segs = API.atb_gauge(cur.addr)
    -- 1.25: a long gauge under the wheel, above the name. Its left end is fixed; each segment has its own length, so
    -- the whole gauge grows to the right with every extra segment (left end, height, segment length and thickness
    -- are settings)
    local LK = UI.LOOK
    local SEG_W, ATB_H = LK.atb_seg or 246, LK.atb_h or 28
    local ATB_X, ATB_Y = LK.atb_x or 360, LK.atb_y or 815
    local n0 = 4
    if pts then n0 = math.max(1, math.floor((segs or ((pps and pps > 0) and (mx / pps) or 4)) + 0.5)) end
    -- 1.26: up to 6 segments the gauge grows with each one; from 7 (the ATB Combat System goes up to 9) the segments get
    -- shorter so that the gauge stays as long as 6 of them; and it never runs off the right of the screen
    local max_w = math.min(6 * SEG_W + 5 * ATB_GAP, 1920 - 40 - ATB_X)
    local ATB_W = math.min(n0 * SEG_W + (n0 - 1) * ATB_GAP, max_w)
    if W.layout == "fan" then
        -- 1.38: Cards style: the gauge is centred just above the (smaller) cards, never behind them
        max_w = math.min(6 * SEG_W + 5 * ATB_GAP, 1920 - 80)
        ATB_W = math.min(n0 * SEG_W + (n0 - 1) * ATB_GAP, max_w)
        ATB_X = L.cx - ATB_W * 0.5
        ATB_Y = (1020 - 320 * (W.fan_k or 1)) - 30 - 40 - ATB_H     -- card top, its rise, then a gap
    end
    -- a dark sheet behind the gauge and its queue, another behind the party list
    local sm = soph and (LK.soph_smoke or 1.0) or 1.0
    -- 1.33: size and darkness of this sheet are settings (look_atb_shade_size, look_atb_shade_op)
    -- 1.35: the ATB Combat System draws the gauge itself (its own renderer, colours, liquid and light) in the place given
    -- by API.wheel.atb_rect; the wheel then only draws the queue, the value and the party list around it
    local native = LK.atb_native ~= false and API.atb and API.atb.wheel_gauge == true
    API.wheel.atb_rect = native and {
        cx = PX(ATB_X + ATB_W * 0.5), cy = PY(ATB_Y + ATB_H * 0.5), w = ATB_W * s, h = ATB_H * s,
        gap = ATB_GAP * s, alpha = a,
    } or nil
    local zk, zo = LK.atb_shade_size or 1.0, LK.atb_shade_op or 1.0
    -- (the ATB Combat System draws before the wheel's pictures: the dark sheet would cover its gauge, so it is left out then)
    if zk > 0.01 and zo > 0.01 and not native then
        local zw, zh = (ATB_W + 220) * zk, 300 * zk
        image("soph_smoke_dark", ATB_X + ATB_W * 0.5 - zw * 0.5, ATB_Y + ATB_H * 0.5 - 14 - zh * 0.5, zw, zh,
            math.min(1, a * (soph and 0.75 or 0.6) * sm * zo))
    end
    -- 1.39: no more party list bottom right (the top row already picks the character), nor its dark sheet
    if pts then
        local n = math.max(1, math.floor((segs or ((pps and pps > 0) and (mx / pps) or 4)) + 0.5))
        local per = (pps and pps > 0) and pps or (mx / n)
        local sw = (ATB_W - (n - 1) * ATB_GAP) / n
        -- 1.27: slanted blades of scratched metal with gold edges (left end, stretched middle, right end, so the slant
        -- stays the same whatever the length), the blue filling the same shape, a light above the filling's front
        -- 1.30: straight segments as a choice (look_atb_shape); the middle piece now overlaps the two ends by 2 px and
        -- is drawn after them, which hides the thin seams the stretched pictures left at their joins
        local K = (UI.LOOK.atb_shape == "straight") and 0 or ATB_H * 0.5   -- horizontal shift of the slant
        -- 1.32: drawn as thin horizontal lines, each shifted along the slant: one solid shape, no joins at all (the
        -- stretched pictures of 1.27-1.31 left a thin line between the pointed ends and the middle). The filling
        -- keeps a light-to-deep blue shading from top to bottom.
        local ROWS = math.max(6, math.floor(ATB_H / 2 + 0.5))
        local rh = ATB_H / ROWS
        -- 1.33: colours from the menu (ABGR, as the colour pickers give them; their alpha is the opacity)
        local function rgb_of(c) return ((c & 0xFF) << 16) | (c & 0xFF00) | ((c >> 16) & 0xFF) end
        local function op_of(c) return ((c >> 24) & 0xFF) / 255 end
        local function mix(c1, c2, u)
            local r = ((c1 >> 16) & 0xFF) + (((c2 >> 16) & 0xFF) - ((c1 >> 16) & 0xFF)) * u
            local g = ((c1 >> 8) & 0xFF) + (((c2 >> 8) & 0xFF) - ((c1 >> 8) & 0xFF)) * u
            local b = (c1 & 0xFF) + ((c2 & 0xFF) - (c1 & 0xFF)) * u
            return (math.floor(r + 0.5) << 16) | (math.floor(g + 0.5) << 8) | math.floor(b + 0.5)
        end
        local C_FILL, C_PART = LK.atb_col_fill or 0xFFFF8D5C, LK.atb_col_part or 0xFFC76E48
        local C_EMPTY, C_EDGE = LK.atb_col_empty or 0xFF080C0F, LK.atb_col_edge or 0xFF58B3D9
        local C_TEXT = LK.atb_col_text or 0xFFFFC09C
        -- 1.34: by default the wheel's gauge takes the ATB Combat System's own colours (look_atb_col_link)
        if LK.atb_col_link ~= false then
            local ac = API.atb_colors()
            if ac then
                local function num(v, d) return (type(v) == "number") and v or d end
                C_FILL, C_PART = num(ac.full, C_FILL), num(ac.part, C_PART)
                C_EMPTY, C_EDGE = num(ac.empty, C_EMPTY), num(ac.edge, C_EDGE)
            end
        end
        local function shade(base, t)                            -- t 0 (top) .. 1 (bottom): lighter top, deeper bottom
            if t < 0.5 then return mix(mix(base, 0xFFFFFF, 0.4), base, t * 2) end
            return mix(base, mix(base, 0x000000, 0.45), (t - 0.5) * 2)
        end
        local function blade(x, w, kind, alpha)                  -- top edge from x+K to x+w+K, bottom from x-K to x+w-K
            if w <= 0 then return end
            for j = 0, ROWS - 1 do
                local t = (j + 0.5) / ROWS
                local sh = K * (1 - 2 * t)
                local c = (kind == "fill") and C_FILL or ((kind == "part") and C_PART or C_EMPTY)
                local rgb = (kind == "empty") and rgb_of(c) or shade(rgb_of(c), t)
                local op = op_of(c)
                -- see-through colours: rows touch without overlapping, else they would show as stripes
                seg(PX(x + sh), PY(ATB_Y + (j + 0.5) * rh), PX(x + w + sh), PY(ATB_Y + (j + 0.5) * rh),
                    rh * s + ((op < 0.99) and 0 or 0.8), alpha * op, rgb)
            end
        end
        local level = pts / per
        local front_x
        for i = 0, (native and -1 or (n - 1)) do
            local x = ATB_X + i * (sw + ATB_GAP)
            local f = math.max(0, math.min(1, level - i))
            blade(x, sw, "empty", a)          -- opaque: overlapping rows would otherwise show as stripes
            if f > 0 then
                local fw = sw * f
                blade(x, fw, (f >= 1) and "fill" or "part", a)
                if f < 1 then front_x = x + fw end
            end
            local t = 1.6 * s
            local tl, tr, bl, br = PX(x + K), PX(x + sw + K), PX(x - K), PX(x + sw - K)
            local yt, yb = PY(ATB_Y), PY(ATB_Y + ATB_H)
            local ec, ea = rgb_of(C_EDGE), a * op_of(C_EDGE)
            seg(tl, yt, tr, yt, t, ea, ec); seg(tr, yt, br, yb, t, ea, ec)
            seg(br, yb, bl, yb, t, ea, ec); seg(bl, yb, tl, yt, t, ea, ec)
        end
        if not front_x and level > 0 then
            local full = math.min(n, math.floor(level + 1e-6))
            if full > 0 then front_x = ATB_X + (full - 1) * (sw + ATB_GAP) + sw end
        end
        -- 1.29: no light on the filling (BardN): the plain blue front is enough
        local _, nh = text_size("0", F.font_cell)
        local value = string.format("%.1f / %d", pts / per, n)
        if I18.t("ORDER QUEUE") ~= "ORDER QUEUE" then value = value:gsub("%.", ",", 1) end   -- French: decimal comma
        -- 1.52: the ATB Combat System decides whether the value above the gauge is shown (its display drawer)
        local wv = API.atb and API.atb.wheel_value
        local show_value = true
        if type(wv) == "function" then
            local ok, r = pcall(wv)
            if ok and r == false then show_value = false end
        end
        if show_value then
            draw_aligned_text(value, PX(ATB_X + ATB_W), PY(ATB_Y - 6) - nh, C_TEXT, 0.95 * a, F.font_cell, "right")
        end

        -- the queue: the running order first, then the waiting ones, each over the segments it costs
        local list = {}
        -- 2.15: outside the Cards style the order strip under Cancel shows the queue: not twice
        if cur.kind ~= "arisen" and W.layout == "fan" then
            local run = AI.get_active_timer_for_pawn(cur.addr)
            if run and run.skill and run.skill > 0 then list[#list + 1] = { skill = run.skill, running = true } end
            for _, q in ipairs(AI.get_pawn_queue(cur.addr) or {}) do list[#list + 1] = { skill = q.skill } end
        end
        local at = 0
        for qi, q in ipairs(list) do
            local c = math.max(1, math.floor((API.atb_cost(cur.addr, q.skill) or 1) + 0.5))
            if at + c > n then break end
            local x, w, y = ATB_X + at * (sw + ATB_GAP), c * sw + (c - 1) * ATB_GAP, ATB_Y - 52
            local first = (qi == 1)
            -- 1.27: the queued orders stay upright, on metal plates (the first one gold-flecked)
            image(first and "soph_plate_sel" or "soph_plate", x - 10, y - 6, w + 20, 52, a)
            if q.running then fading_line(x + w, x, y + 40, 2 * s, a, SEL_RGB) end   -- 2.11: gold, like the cells
            local icon = U.get_skill_icon_no(q.skill)
            image("med", x + 4, y + 2, 36, 36, a)
            if icon then image("skill_" .. icon, x + 1, y - 1, 42, 42, a) end
            local name = fit(I18.t(U.upper(U.get_skill_display_name(q.skill) or "?")), F.font_small, (w - 52) * s)
            draw_aligned_text(name, PX(x + 46), PY(y + 12), first and 0xFFFFFFFF or COL.TEXT, a, F.font_small)
            if first then
                local pulse = 0.72 + 0.28 * math.sin((F.w_now or 0) * 2.4)
                image("flare", x + w - 35, y - 12, 70, 32, a * pulse)
            end
            at = at + c
        end

    end

end

------------------------------------------------------------------------------------------------
-- 1.21 open style: the ring (two arcs behind the skill columns, fading upwards and downwards) and the outer lines
-- (two thin arcs of a wide circle around the wheel, fading at both ends; brighter on the side being aimed at)
------------------------------------------------------------------------------------------------
local function arc_fading(cx, cy, r, mid_deg, half_deg, steps, t, alpha, rgb)
    local rad = math.pi / 180
    for k = 0, steps - 1 do
        local op = alpha * (1 - (k + 0.5) / steps)
        for _, sg in ipairs({ 1, -1 }) do
            local a0, a1 = (mid_deg + sg * half_deg * k / steps) * rad, (mid_deg + sg * half_deg * (k + 1) / steps) * rad
            seg(PX(cx + r * math.cos(a0)), PY(cy + r * math.sin(a0)), PX(cx + r * math.cos(a1)), PY(cy + r * math.sin(a1)), t, op, rgb)
        end
    end
end

draw_open_ring = function(a)
    local arc = W.arc
    if not arc then return end
    local r = arc.r - 15
    arc_fading(arc.cx, arc.cy, r, 180, 54, 18, 3 * s, a, GOLD_RGB)
    arc_fading(arc.cx, arc.cy, r, 0, 54, 18, 3 * s, a, GOLD_RGB)
end

draw_open_crescents = function(a_left, a_right)
    local cy = W.arc and W.arc.cy or 528
    arc_fading(L.cx, cy, 760, 180, 34, 24, 3 * s, a_left, GOLD_RGB)
    arc_fading(L.cx, cy, 760, 0, 34, 24, 3 * s, a_right, GOLD_RGB)
end

------------------------------------------------------------------------------------------------
-- Dark filter over the game (drawn first: furthest back, under every picture of the wheel)
------------------------------------------------------------------------------------------------
-- 1.39: when the ATB Combat System draws the wheel's gauge, it also draws the filter and the vignette (API.wheel.backdrop),
-- before its gauge: the ATB Combat System draws before the wheel, so a filter drawn here would cover the gauge. One table,
-- its entries reused from frame to frame (no new tables while the wheel is open).
local BD, bd_n, bd_hand = { t = 0 }, 0, false
local function bd_add(x, y, w, h, color)
    bd_n = bd_n + 1
    local q = BD[bd_n]
    if not q then q = {}; BD[bd_n] = q end
    q.x, q.y, q.w, q.h, q.color = x, y, w, h, color
end
local function bd_publish()
    for i = bd_n + 1, #BD do BD[i] = nil end
    BD.t = os.clock()
    API.wheel.backdrop = (bd_n > 0) and BD or nil
end
local function queue_filter(sw, sh, a)
    local f = UI.FILTER
    if not f.enabled or a <= 0.01 then return end
    local col = f.color or 0x59000000                     -- ABGR, like every imgui colour of the mod
    local alpha = ((col >> 24) & 0xFF) / 255 * a
    if alpha <= 0.004 then return end
    if X.d2d_available and X.d2d_ready and not X.d2d_rect_failed then
        -- d2d wants ARGB: swap red and blue
        local r, b = col & 0xFF, (col >> 16) & 0xFF
        local argb = (math.floor(alpha * 255 + 0.5) << 24) | (r << 16) | (col & 0x00FF00) | b
        if bd_hand then bd_add(0, 0, math.floor(sw + 1), math.floor(sh + 1), argb); return end
        iconSlots[#iconSlots + 1] = { rect = true, x = 0, y = 0, w = math.floor(sw + 1), h = math.floor(sh + 1), color = argb }
    else
        draw.filled_rect(0, 0, sw, sh, with_alpha(col, a))
    end
end

-- vignette = 10 nested frames, each thinner and adding a little darkness: the edges get darker step by step
local VIG_N = 10
local function queue_vignette(sw, sh, a)
    local f = UI.FILTER
    if not f.enabled or (f.vig or 0) <= 0.01 or a <= 0.01 then return end
    local per = (f.vig * a) / VIG_N
    if per <= 0.002 then return end
    local col = f.vig_color or 0xFF000000
    local size = math.min(sw, sh) * (f.vig_size or 0.28)
    local use_d2d = X.d2d_available and X.d2d_ready and not X.d2d_rect_failed
    local r, g, b = col & 0xFF, (col >> 8) & 0xFF, (col >> 16) & 0xFF
    local A = math.floor(per * 255 + 0.5)
    local argb = (A << 24) | (r << 16) | (g << 8) | b
    local abgr = (A << 24) | (b << 16) | (g << 8) | r
    for k = 1, VIG_N do
        local t = math.floor(size * (VIG_N - k + 1) / VIG_N + 0.5)
        local rects = { { 0, 0, sw, t }, { 0, sh - t, sw, t }, { 0, t, t, sh - 2 * t }, { sw - t, t, t, sh - 2 * t } }
        for _, q in ipairs(rects) do
            if use_d2d and bd_hand then
                bd_add(math.floor(q[1]), math.floor(q[2]), math.floor(q[3] + 1), math.floor(q[4] + 1), argb)
            elseif use_d2d then
                iconSlots[#iconSlots + 1] = { rect = true, x = math.floor(q[1]), y = math.floor(q[2]),
                    w = math.floor(q[3] + 1), h = math.floor(q[4] + 1), color = argb }
            else
                draw.filled_rect(q[1], q[2], q[3], q[4], abgr)
            end
        end
    end
end

------------------------------------------------------------------------------------------------
-- Targeting step: markers on the enemies, a curved line from the character to the chosen enemy, a small panel
------------------------------------------------------------------------------------------------
local function thick_line(x1, y1, x2, y2, w, col)
    local dx, dy = x2 - x1, y2 - y1
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 1 then return end
    local nx, ny = -dy / len, dx / len
    local half = (w - 1) * 0.5
    local k = -half
    while k <= half + 1e-6 do
        draw.line(x1 + nx * k, y1 + ny * k, x2 + nx * k, y2 + ny * k, col)
        k = k + 1
    end
end

-- polyline (x1,y1,x2,y2,...) plain or dashed
local function stroke(pts, w, col, dash, gap)
    local on, left = true, dash
    for i = 1, #pts - 3, 2 do
        local ax, ay, bx, by = pts[i], pts[i + 1], pts[i + 2], pts[i + 3]
        if not dash then
            thick_line(ax, ay, bx, by, w, col)
        else
            local dx, dy = bx - ax, by - ay
            local Lg = math.sqrt(dx * dx + dy * dy)
            local t = 0
            while Lg - t > 1e-3 do
                local stp = math.min(left, Lg - t)
                if on then
                    local t2 = t + stp
                    thick_line(ax + dx * t / Lg, ay + dy * t / Lg, ax + dx * t2 / Lg, ay + dy * t2 / Lg, w, col)
                end
                t = t + stp
                left = left - stp
                if left <= 1e-3 then
                    on = not on
                    left = on and dash or gap
                end
            end
        end
    end
end

-- quadratic Bezier curve; curve > 0 bends towards the top of the screen
local function curve_points(x1, y1, x2, y2, curve, N)
    local dx, dy = x2 - x1, y2 - y1
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 1 then return nil end
    -- 1.45: a straight line is cut into points too (the comet, the wave and the arrow need several)
    local nx, ny = -dy / len, dx / len
    if ny > 0 then nx, ny = -nx, -ny end
    local off = (math.abs(curve) < 0.01) and 0 or curve * len * 0.5
    local qx, qy = (x1 + x2) * 0.5 + nx * off, (y1 + y2) * 0.5 + ny * off
    local pts = {}
    N = N or 18
    for k = 0, N do
        local t = k / N
        local u = 1 - t
        pts[#pts + 1] = u * u * x1 + 2 * u * t * qx + t * t * x2
        pts[#pts + 1] = u * u * y1 + 2 * u * t * qy + t * t * y2
    end
    return pts
end

-- 1.38: a thin line and a comet running along it, from the character to the enemy, again and again
local COMET_CORE = 0xFFD8F6FF                    -- warm white (ABGR)
local function point_at(pts, cum, total, d)      -- the point at distance d along the polyline
    for i = 2, #cum do
        if cum[i] >= d then
            local seg_l = cum[i] - cum[i - 1]
            local f = (seg_l > 0) and (d - cum[i - 1]) / seg_l or 0
            local j = (i - 2) * 2 + 1
            return pts[j] + (pts[j + 2] - pts[j]) * f, pts[j + 1] + (pts[j + 3] - pts[j + 1]) * f
        end
    end
    return pts[#pts - 1], pts[#pts]
end

local function draw_aim_line(from_chara, cur, scale, a, now)
    local ln = UI.LINE
    if not ln.enabled or cur == nil or not U.is_valid_obj(from_chara) then return end
    local tx, ty = U.screen_pos(cur.chara, 1.3)
    local px, py = U.screen_pos(from_chara, 1.0)
    if not tx or not px then return end
    local w = math.max(1, math.floor((ln.width or 3) * scale + 0.5))
    local style = ln.style or "comet"
    local pts = curve_points(px, py, tx, ty, ln.curve or 0.2, (style == "breath") and 48 or 18)
    if pts == nil then return end
    local col_a = ((ln.color >> 24) & 0xFF) / 255 * (ln.opacity or 1.0)     -- 1.45: opacity setting
    local thin = math.max(1, math.floor(w * 0.5 + 0.5))
    local col = ln.color | 0xFF000000
    local t_now = now or os.clock()
    if style == "arrow" then
        -- 1.38 (C6): an archer's shot: a clean line, fletching at the start, a point on the enemy that pulses gently
        w = math.max(1, math.floor((ln.arrow_width or 3) * scale + 0.5))      -- 1.45: its own thickness
        if ln.outline then stroke(pts, w + 2, with_alpha(0xFF000000, a * 0.45 * col_a)) end
        stroke(pts, w, with_alpha(col, a * col_a))
        local n = #pts
        local ex, ey, bx, by = pts[n - 1], pts[n], pts[n - 5] or pts[1], pts[n - 4] or pts[2]
        local dx, dy = ex - bx, ey - by
        local l = math.sqrt(dx * dx + dy * dy)
        if l > 0.5 then
            dx, dy = dx / l, dy / l
            local k = (1 + 0.12 * math.sin(t_now * 4)) * scale * (ln.arrow_head or 1.0) * (0.7 + 0.1 * w / scale)
            local L, Wd = 15 * k, 7.5 * k
            local cxp, cyp = ex - dx * L, ey - dy * L
            local nx, ny = ex - dx * L * 0.7, ey - dy * L * 0.7
            local hc = with_alpha(col, a * col_a)       -- the point as two triangles (a notched shape is not convex)
            pcall(draw.filled_quad, ex, ey, cxp - dy * Wd, cyp + dx * Wd, nx, ny, nx, ny, hc)
            pcall(draw.filled_quad, ex, ey, nx, ny, cxp + dy * Wd, cyp - dx * Wd, cxp + dy * Wd, cyp - dx * Wd, hc)
        end
        local fx, fy, gx, gy = pts[5], pts[6], pts[1], pts[2]
        local fdx, fdy = fx - gx, fy - gy
        local fl = math.sqrt(fdx * fdx + fdy * fdy)
        if fl > 0.5 then
            fdx, fdy = fdx / fl, fdy / fl
            for _, off in ipairs({ 0, 6 * scale }) do
                local ox, oy = fx - fdx * off, fy - fdy * off
                for _, sg in ipairs({ -1, 1 }) do
                    thick_line(ox, oy, ox - fdx * 9 * scale - sg * fdy * 6 * scale, oy - fdy * 9 * scale + sg * fdx * 6 * scale,
                        math.max(1, thin), with_alpha(col, a * col_a))
                end
            end
        end
        return
    end
    if ln.outline then stroke(pts, thin + 2, with_alpha(0xFF000000, a * 0.45 * col_a)) end
    if style == "breath" then
        -- 1.38 (C2): the thread breathes: a broad wave of light rolls from the character to the enemy, again and again
        -- 1.45: 48 short pieces, the wave mostly in light (opacity) and only a little in thickness: no staircase
        local segs = (#pts - 2) / 2
        local wave = ln.breath_wave or 0.18
        local glow = ln.breath_glow or 0.5
        local c = -wave * 2 + (1 + wave * 4) * ((t_now * (ln.comet_speed or 1.0) / 1.6) % 1.0)
        local base = with_alpha(col, a * col_a * 0.45)
        stroke(pts, thin, base)
        for j = 0, segs - 1 do
            local tt = (j + 0.5) / segs
            local g = math.exp(-((tt - c) / wave) ^ 2)
            if g > 0.03 then
                local i = j * 2 + 1
                local wd = thin + ((g > 0.55) and 1 or 0)
                thick_line(pts[i], pts[i + 1], pts[i + 2], pts[i + 3], wd, with_alpha(COMET_CORE, a * col_a * glow * g))
            end
        end
        pcall(draw.filled_circle, px, py, thin + 2, with_alpha(col, a * col_a), 16)
        return
    end
    stroke(pts, thin, with_alpha(col, a * 0.6 * col_a))
    pcall(draw.filled_circle, px, py, thin + 2, with_alpha(col, a * col_a), 16)
    -- the comet: one run every 1.1 s at speed x1, its tail 18 % of the line
    local cum, total = { 0 }, 0
    for i = 3, #pts - 1, 2 do
        total = total + math.sqrt((pts[i] - pts[i - 2]) ^ 2 + (pts[i + 1] - pts[i - 1]) ^ 2)
        cum[#cum + 1] = total
    end
    if total < 4 then return end
    local u = (t_now * (ln.comet_speed or 1.0) / 1.1) % 1.0
    local head = total * u
    local tail = total * 0.18
    local n = 10
    local ax, ay = point_at(pts, cum, total, math.max(0, head - tail))
    for k = 1, n do
        local f = k / n
        local bx, by = point_at(pts, cum, total, math.max(0, head - tail * (1 - f)))
        thick_line(ax, ay, bx, by, math.max(1, math.floor(thin + (w + 1 - thin) * f + 0.5)), with_alpha(COMET_CORE, a * col_a * f))
        ax, ay = bx, by
    end
    local hx, hy = point_at(pts, cum, total, head)
    for r = 11, 4, -1 do        -- soft halo: thin discs piled up, brighter towards the middle
        pcall(draw.filled_circle, hx, hy, r * scale, with_alpha(col, a * col_a * 0.07), 20)
    end
    pcall(draw.filled_circle, hx, hy, math.max(2, (w * 0.5 + 1.5)), with_alpha(COMET_CORE, a * col_a), 16)
end

-- "solo" targeting. Only the chosen skill stays on screen: its own cell glides from its place in the wheel down to
-- the bottom middle, every other cell has faded out with the wheel, and the target line sits right under it. The middle
-- of the screen is left to the camera, the character and the enemy being aimed at.
-- 1.19: an empty list says why (realistic targeting)
local draw_target_band, band_gap        -- 1.38: defined just below
local EMPTY = { behind = "ENEMY OUT OF VIEW", dark = "TOO DARK: NO ENEMY ENGAGED", hidden = "NO ENEMY IN SIGHT" }
local function target_line(tg, cur)
    if cur then
        if (cur.name or "") == "" then          -- 1.38: unknown name (a monster from a mod): left out
            return string.format("TARGET: %dm  (%d/%d)", math.floor(cur.dist + 0.5), W.tgt_idx, #W.targets)
        end
        return string.format("TARGET: %s  %dm  (%d/%d)", cur.name, math.floor(cur.dist + 0.5), W.tgt_idx, #W.targets)
    end
    local ok, why = pcall(function() return require("TacticalCommandSystem.lib.vision").empty_reason() end)
    local base = (ok and EMPTY[why]) or "NO ENEMIES IN RANGE"
    if tg.entry.kind == "arisen" then return base .. ": LAUNCH WITHOUT TARGET" end
    return base
end

-- 1.38: under the chosen skill, a sober band in the game's spirit (U6): a dark veil between two gold lines that fade
-- away, the target in the middle, who acts on its left, the distance on its right; small diamonds count the targets
local draw_diamond = X.draw_diamond
local function band_veil(cx, y, half, h, a)                  -- design px
    -- 1.40: the same smooth dark wash pictures as the cells (no more stepped rectangles)
    image("cell_fade_l", cx - half, y, half, h, a * 0.9)
    image("cell_fade_r", cx, y, half, h, a * 0.9)
    fading_line(cx - half, cx, y, 1.2 * s, a, GOLD_RGB); fading_line(cx + half, cx, y, 1.2 * s, a, GOLD_RGB)
    fading_line(cx - half, cx, y + h, 1.2 * s, a, GOLD_RGB); fading_line(cx + half, cx, y + h, 1.2 * s, a, GOLD_RGB)
end
local function target_count(cx, y, a)
    local n = #W.targets
    if n < 2 then return end
    n = math.min(n, 9)
    local gold = with_alpha(COL.GOLD_BRIGHT, a)
    for i = 1, n do
        local x, yy, r = PX(cx + (i - (n + 1) * 0.5) * 16), PY(y), 4.5 * s
        if i == W.tgt_idx then
            draw_diamond(x, yy, r, r, gold)
        else
            local c = with_alpha(COL.GOLD_BRIGHT, a * 0.6)
            draw.line(x, yy - r, x + r, yy, c); draw.line(x + r, yy, x, yy + r, c)
            draw.line(x, yy + r, x - r, yy, c); draw.line(x - r, yy, x, yy - r, c)
        end
    end
end
draw_target_band = function(tg, cur, y, a)
    if a <= 0.01 then return end
    local cx, h = L.cx, 40
    band_veil(cx, y, 230, h, a)
    local fc, fs = F.font_cell, F.font_small
    if cur then
        local dist = string.format("%d m", math.floor(cur.dist + 0.5))
        local name = cur.name or ""
        local centre = (name ~= "") and name or dist                  -- unknown name: the distance takes its place
        local cw, ch = text_size(centre, fc)
        draw_aligned_text(centre, PX(cx), PY(y + h * 0.5) - ch * 0.5, 0xFFFFFFFF, a, fc, "center")
        local _, sh2 = text_size("X", fs)
        local ty = PY(y + h * 0.5) - sh2 * 0.5
        draw_aligned_text(I18.t(tg.entry.name or ""), PX(cx) - cw * 0.5 - 22 * s, ty, COL.GOLD, a, fs, "right")
        if name ~= "" then draw_aligned_text(dist, PX(cx) + cw * 0.5 + 22 * s, ty, COL.GOLD, a, fs, "left") end
        target_count(cx, y + h + 16, a)
    else
        local msg = I18.t(target_line(tg, nil))
        local _, mh = text_size(msg, fs)
        draw_aligned_text(msg, PX(cx), PY(y + h * 0.5) - mh * 0.5, COL.TEXT, a, fs, "center")
    end
end

-- gap between the solo cell and the target band: clear of the banner's lower line (Moderne, +16) and of the
-- metal plate (Sophistiquée, +14 and its line at +12)
band_gap = function()
    if soph_style() then return 28 end
    if open_style() then return 30 end
    return 14
end

local function draw_solo_cell(tg, cur, a_full)
    local it = tg.slice
    local k = 1 - (F.wheel_vis or 0)                 -- 0 = still in the wheel, 1 = arrived at the bottom
    k = k * k * (3 - 2 * k)
    -- 1.37: each style has its own solo look and size (Éventail: a card lying down, 300 x 110)
    local tw, th = it.bw, it.bh
    if fan_style() then tw, th = 300, 110 elseif open_style() then tw = math.max(it.bw, 560) end
    local gx = L.cx - tw * 0.5
    local gy = 1080 * (UI.LOOK.tgt_solo_y or 0.70) - th * 0.5
    -- 1.38: with the big ATB gauge (ATB Combat System style, not Cards), the whole targeting stack (cell, band, diamonds)
    -- stays above the gauge and its order queue
    if F.atb_style and W.layout ~= "fan" then
        local bottom = gy + th + band_gap() + 40 + 24
        local limit = (UI.LOOK.atb_y or 815) - 64
        if bottom > limit then gy = gy - (bottom - limit) end
    elseif F.atb_style then
        -- Cards: the gauge sits above the cards, so the lying card (and its flare) stays under it
        local gauge_bottom = (1020 - 320 * (W.fan_k or 1)) - 30 - 40
        gy = math.max(gy, gauge_bottom + 50)
    end
    -- a stand-in of the cell, moved: everything else (name, icon, lamp, ATB cost, tag) is read from the real one
    local solo = setmetatable({ dx = it.dx + (gx - it.dx) * k, dy = it.dy + (gy - it.dy) * k, side = "solo",
        bw = it.bw + (tw - it.bw) * k, bh = it.bh + (th - it.bh) * k }, { __index = it })
    local keep = F.open_anim
    F.open_anim = a_full
    draw_button(solo)
    F.open_anim = keep
    draw_target_band(tg, cur, solo.dy + solo.bh + band_gap(), a_full * k)
end

local function draw_target_step(sw, sh, scale, a, w_now, a_full)
    local tg = W.tg
    if not tg then return end
    local cur = IN.current_target()
    draw_aim_line(tg.entry.chara, cur, scale, a, w_now)
    draw_target_markers(cur, scale, a, 0.65 + 0.35 * math.sin(w_now * 6.0), F.font_small)

    if UI.LOOK.tgt_solo ~= false and tg.slice and tg.slice.bw then
        draw_solo_cell(tg, cur, a_full or a)
        return
    end

    -- the panel: skill, then target (or "no enemy in range")
    local pw, ph = 620, 92
    local px, py = L.cx - pw * 0.5, 826
    local frame = "frame_" .. (UI.LOOK.cell_shape or "hex")
    local kx, ky = pw / L.btn_w, ph / L.btn_h
    if not image(frame .. "_idle", px - L.btn_pad * kx, py - L.btn_pad * ky, (L.btn_w + 2 * L.btn_pad) * kx, (L.btn_h + 2 * L.btn_pad) * ky, a) then
        draw_panel(PX(px), PY(py), pw * s, ph * s, COL.PANEL, COL.GOLD_BRIGHT, a)
    end
    local cx = PX(L.cx)
    -- 1.38: the skill in the panel, the target in the same band as the solo targeting
    local _, nh = text_size("X", F.font_cell)
    draw_aligned_text(tg.slice.name, cx, PY(py + ph * 0.5) - nh * 0.5, COL.GOLD_BRIGHT, a, F.font_cell, "center")
    draw_target_band(tg, cur, py + ph + 14, a)
end

------------------------------------------------------------------------------------------------
-- Prompt bar entries for the current stage and character
------------------------------------------------------------------------------------------------
-- 2.08: the skill being aimed can be charged (data "full"): A sends it charged (2.23), X / middle button the quick one
local function aiming_chargeable()
    local sid = W.tg and W.tg.slice and W.tg.slice.skill_id
    local ord = sid and D.ORDERS[sid]
    return ord ~= nil and ord.full ~= nil
end

local function prompt_entries(entry)
    local B = IN.BINDS
    if W.stage == 2 then
        if aiming_chargeable() then
            return {
                { binds = { B.pad_prev_pawn, B.pad_next_pawn_2 }, dpad = true, t = "TARGET LEFT / RIGHT" },
                { binds = { B.pad_confirm_close },                t = "CHARGED" },   -- 2.23
                { binds = { B.pad_quick },                        t = "QUICK" },
                { binds = { B.pad_cancel },                       t = "BACK" },
            }
        end
        return {
            { binds = { B.pad_prev_pawn, B.pad_next_pawn_2 }, dpad = true, t = "TARGET LEFT / RIGHT" },
            { binds = { B.pad_confirm_close },                t = "GO" },
            { binds = { B.pad_cancel },                       t = "BACK" },
        }
    end
    local list = {
        { binds = { B.pad_prev_pawn, B.pad_next_pawn_2 }, dpad = true, t = "CHARACTER" },
        { binds = { B.pad_confirm_close },                t = "ORDER & CLOSE" },
    }
    if (B.pad_confirm_stay or 0) ~= 0 then list[#list + 1] = { binds = { B.pad_confirm_stay }, t = "ORDER & STAY" } end
    if entry and entry.kind ~= "arisen" then
        list[#list + 1] = { binds = { B.pad_queue_toggle }, t = "QUEUE ONLY" }
        list[#list + 1] = { binds = { B.pad_lock_skill },   t = "TOGGLE ON / OFF" }   -- 1.07: was "MANUAL ONLY"
        list[#list + 1] = { binds = { B.pad_cancel_orders }, t = "CLEAR QUEUE" }
    else
        list[#list + 1] = { binds = { B.pad_cancel_orders }, t = "CANCEL" }
    end
    if Poss.available() then
        list[#list + 1] = { binds = { B.pad_lock_char },                  -- 1.09: was "LOCK" / "UNLOCK"
            t = Poss.is_locked(entry) and "UNLOCK PLAYED CHARACTER" or "LOCK PLAYED CHARACTER" }
    end
    list[#list + 1] = { binds = { B.pad_cancel, B.pad_close_open }, t = "CLOSE" }
    return list
end

-- the same bar for the keyboard and mouse (the keys bound in the mod; "mouse" = moving the mouse)
local function prompt_entries_kbm(entry)
    local B = IN.BINDS
    if W.stage == 2 then
        if aiming_chargeable() then
            return {
                { kb = { B.kb_target_left, B.kb_target_right, "mouse_lr" }, t = "TARGET LEFT / RIGHT" },
                { kb = { B.kb_confirm },                             t = "CHARGED" },   -- 2.23
                { kb = { B.kb_quick },                               t = "QUICK" },
                { kb = { B.kb_cancel },                              t = "BACK" },
            }
        end
        return {
            { kb = { B.kb_target_left, B.kb_target_right, "mouse_lr" }, t = "TARGET LEFT / RIGHT" },
            { kb = { B.kb_confirm },                             t = "GO" },
            { kb = { B.kb_cancel },                              t = "BACK" },
        }
    end
    local list = {
        { kb = { B.kb_prev_pawn, B.kb_next_pawn }, t = "CHARACTER" },
        { kb = { B.kb_confirm },                   t = "ORDER & CLOSE" },
        { kb = { B.kb_stay },                      t = "ORDER & STAY" },
    }
    if entry and entry.kind ~= "arisen" then
        list[#list + 1] = { kb = { B.kb_queue_toggle }, t = "QUEUE ONLY" }
        if (B.kb_lock_skill or 0) > 0 then list[#list + 1] = { kb = { B.kb_lock_skill }, t = "TOGGLE ON / OFF" } end   -- 2.05
    end
    list[#list + 1] = { kb = { B.kb_cancel, B.kb_open }, t = "CLOSE" }
    return list
end

------------------------------------------------------------------------------------------------
-- Entry point
------------------------------------------------------------------------------------------------

function UI.draw_wheel(w_now, stick_x, stick_y)
    X.clear_icons()
    glow_dt = glow_last_t and math.max(0, math.min(0.1, w_now - glow_last_t)) or 0.05
    glow_last_t = w_now
    local dt = glow_dt

    local sw, sh = get_screen_size()
    local old_scale = (sh / 1080) * X.hud_scale        -- scale of the prompt bar and the target markers
    s = old_scale / 1.26                               -- the mock-up is the size of the default HUD scale (1.26)
    ox, oy = sw * 0.5 - L.cx * s, sh * 0.5 - 540 * s

    place_cells()
    W.view = { ox = ox, oy = oy, s = s, sw = sw, sh = sh }      -- for the mouse cursor (in/steer.lua)
    -- the stick is ignored for a moment after a click of the Left Stick (L3 = lock): the click must not move the selection
    if W.stage ~= 2 and not (W.steer_hold_until and w_now < W.steer_hold_until) then IN.update_steering(stick_x, stick_y) end

    local a = math.min(1.0, math.max(0.05, (w_now - W.open_time) / 0.12))
    local cur = W.pawns[W.pawn_idx]
    local is_arisen = cur ~= nil and cur.kind == "arisen"
    local sel_item = W.sel and W.slices[W.sel] or nil

    -- the wheel fades out during the targeting step, the centre fades out on the Arisen
    local fade_k = math.min(1, dt * 1000 / math.max(10, UI.LOOK.center_fade_ms or 150) * 3)
    F.wheel_vis = F.wheel_vis or 1
    F.wheel_vis = F.wheel_vis + (((W.stage == 2) and 0 or 1) - F.wheel_vis) * math.min(1, dt * 18)
    if (w_now - W.open_time) < 0.05 then F.wheel_vis = (W.stage == 2) and 0 or 1 end
    local center_goal = is_arisen and (UI.LOOK.center_arisen or 0) or 1
    F.center_vis = F.center_vis or center_goal
    if (w_now - W.open_time) < 0.05 then F.center_vis = center_goal end
    F.center_vis = F.center_vis + (center_goal - F.center_vis) * fade_k
    local wa = a * F.wheel_vis

    F.open_anim, F.g_now, F.w_now = wa, U.game_now(), w_now
    F.glyph_px = 27 * (sh / 1080) * (UI.LOOK.glyph_scale or 1.26)   -- the key pictures do not follow the wheel size
    F.font_title, F.font_cell = UI.get_scaled_font(30), UI.get_scaled_font(18)
    F.font_class, F.font_small = UI.get_scaled_font(15), UI.get_scaled_font(13)
    F.font_plate_name, F.font_plate_sub = UI.get_scaled_font(24), UI.get_scaled_font(11)   -- 1.20: 80 % of 30 and 13
    F.font_card = UI.get_scaled_font(22)                                                       -- 1.22: Éventail cards
    F.plate_bottom = nil
    F.cur_pawn = cur
    F.cur_ord = (cur and not is_arisen) and AI.get_active_timer_for_pawn(cur.addr) or nil
    F.cur_stance = (cur and not is_arisen) and AI.get_pawn_stance(cur.addr) or "free"
    F.team_stance = is_arisen and IN.team_stance() or nil
    F.low_stam = (cur and not is_arisen and cur.stam_ratio and cur.stam_ratio < 0.12) or false
    F.tint = tint_key(cur and cur.job or nil)
    F.atb = API.atb_on()
    local aw = API.wheel
    aw.open, aw.stage, aw.kind, aw.addr = true, W.stage, cur and cur.kind or nil, cur and cur.addr or nil
    -- 1.22: with the ATB Combat System on, the wheel draws its own big gauge, queue and party list (style ATB Combat System) and
    -- tells the ATB Combat System to hide its gauges while the wheel is open
    F.atb_style = F.atb and UI.LOOK.atb_style ~= false
    aw.atb_style = F.atb_style
    aw.atb_rect = nil                     -- set again by draw_atb_layer when the ATB Combat System draws the gauge
    aw.center_x, aw.center_y, aw.scale, aw.alpha = PX(L.cx), PY(918), s * 1.26, a
    local cur_queue = (cur and not is_arisen) and AI.get_pawn_queue(cur.addr) or {}

    -- 1.39: same test as draw_atb_layer for the native gauge, plus the ATB Combat System saying it can draw the filter
    local atb = API.atb
    bd_hand = (F.atb_style and cur and UI.LOOK.atb_native ~= false and atb and atb.wheel_gauge == true
        and atb.wheel_backdrop == true) and true or false
    bd_n = 0
    queue_filter(sw, sh, a)
    queue_vignette(sw, sh, a)
    if bd_hand then bd_publish() else aw.backdrop = nil end

    if wa > 0.01 then
        -- back to front: crescents, circle, columns
        if UI.LOOK.crescents and not fan_style() then
            local left_on = (sel_item and sel_item.side == "left") or (W.sx < -8)
            local right_on = (sel_item and sel_item.side == "right") or (W.sx > 8)
            if open_style() then
                draw_open_crescents(wa * (left_on and 1.0 or 0.65), wa * (right_on and 1.0 or 0.65))
            else
                image("cres_l", L.cres_left, L.cres_top, L.cres_w, L.cres_h, wa * (left_on and 1.0 or 0.65))
                image("cres_r", L.cres_right, L.cres_top, L.cres_w, L.cres_h, wa * (right_on and 1.0 or 0.65))
            end
        end
        -- by default the circle is gone, its information sits at the bottom middle
        local in_circle = (UI.LOOK.center_mode == "circle")
        if open_style() and not in_circle then draw_open_ring(wa) end
        if cur and F.center_vis > 0.01 then
            if in_circle then
                draw_center(cur, sel_item, cur_queue, wa * F.center_vis)
            elseif fan_style() then
                draw_fan_header(cur, sel_item, cur_queue, wa * F.center_vis)
            else
                draw_center_plate(cur, sel_item, cur_queue, wa * F.center_vis)
            end
        end
        if W.layout == "fan" then
            -- 1.22: the far cards first, the chosen one last (on top)
            local sel_item = W.sel and W.slices[W.sel]
            local sp = (sel_item and sel_item.fan_pos) or ((W.fan_n or 1) + 1) * 0.5
            local list = {}
            for _, item in ipairs(W.slices) do if item.bw then list[#list + 1] = item end end
            table.sort(list, function(p, q)
                local dp = p.fan_pos and math.abs(p.fan_pos - sp) or 99
                local dq = q.fan_pos and math.abs(q.fan_pos - sp) or 99
                return dp > dq
            end)
            for _, item in ipairs(list) do draw_button(item) end
        else
            for _, item in ipairs(W.slices) do if item.bw then draw_button(item) end end
        end
    end

    -- the top row can leave with the wheel during the targeting step
    local row_a = a
    if W.stage == 2 and UI.LOOK.tgt_hide_row ~= false then row_a = a * F.wheel_vis end
    if row_a > 0.01 then draw_pawn_row(cur, row_a, dt) end

    if W.stage == 2 then
        draw_target_step(sw, sh, old_scale, a * (1 - F.wheel_vis), w_now, a)
    end

    if F.atb_style and cur then draw_atb_layer(cur, a) end
    -- 2.13: the pawn's orders, in the order they will go out, under Cancel (the ATB "Large" style has its own queue)
    if cur and cur.kind ~= "arisen" and W.layout ~= "fan" then
        draw_order_strip(cur, a * (F.wheel_vis or 1))
    end

    -- 1.20: the key bar moves down when the name plate (look_plate_offset) reaches it
    local prompt_y = (W.layout == "fan") and 1052 or L.prompt_top
    if F.plate_bottom and W.layout ~= "fan" then prompt_y = math.min(1050, math.max(prompt_y, F.plate_bottom + 12)) end
    draw_prompt_bar(sw, sh, old_scale, a, F.font_cell, sw * 0.5, PY(prompt_y),
        (W.kbm or W.mode == "mouse") and prompt_entries_kbm(cur) or prompt_entries(cur))

    -- mouse mode: the cursor, drawn last (above everything)
    if W.mode == "mouse" and W.stage ~= 2 and W.mx and W.kbm and IN.mouse_show ~= false then   -- never on the pad: the cursor only serves the mouse
        local r = math.max(5, 9 * s)
        local col = UI.CURSOR_COLOR or 0xFFFFFFFF
        local ca = a * (UI.CURSOR_OPACITY or 1.0)        -- the cursor's own opacity setting, on top of the wheel's fade
        pcall(draw.filled_circle, W.mx, W.my, r + 2, with_alpha(0x99000000, ca), 24)
        pcall(draw.filled_circle, W.mx, W.my, r, with_alpha(col, ca), 24)
        pcall(draw.filled_circle, W.mx, W.my, r * 0.45, with_alpha(0xCC000000, ca), 16)
    end

    -- order messages stay visible while the wheel is open (R3 = order and stay)
    UI.draw_flash(sw, sh, old_scale, w_now, PY(262), UI.get_scaled_font(16))
end
