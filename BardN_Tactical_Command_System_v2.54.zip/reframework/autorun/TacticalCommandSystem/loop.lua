-- TacticalCommandSystem/loop.lua
-- The wheel module required by Tactical_Command_System.lua: update() runs every frame
-- (clock, Arisen launcher, AI timers, slow motion, inputs, drawing).

local U  = require("TacticalCommandSystem.utils")
local AI = require("TacticalCommandSystem.cmd.init")
local IN = require("TacticalCommandSystem.input")
local UI = require("TacticalCommandSystem.ui")
local AR = require("TacticalCommandSystem.arisen")
local API = require("TacticalCommandSystem.api")
local Focus = require("TacticalCommandSystem.camera")

local M = {}

local W    = IN.W
local Slow = U.Slow

-- the ATB Combat System's regeneration follows the slow motion of the wheel
API.time_scale = function() return math.max(0.0, math.min(1.0, Slow.cur or 1.0)) end

-- Called by Tactical_Command_System.lua when HUD is hidden (pause, menu, fade, cutscene)
function M.on_hud_hidden()
    U.safe_call(function()
        U.tick_clock()
        local g_now = U.game_now()
        if W.open then
            W.open = false
            W.swallowing = false
            W.stage, W.tg = 1, nil
        end
        API.wheel.open, API.wheel.backdrop = false, nil
        -- 2.50: the pictures are drawn by d2d from the last list filled: empty it, or the wheel stays on screen
        -- behind the pause menu
        require("TacticalCommandSystem.ui.shared").clear_icons()
        Focus.release()
        if Slow.active then
            IN.stop_slowmo_now()
        end
        AI.update_pawn_timers(g_now)
    end, "M.on_hud_hidden")
end

function M.update(w_now)
    U.safe_call(function()
        w_now = w_now or U.wall_time()
        W.last_update_wall = w_now
        U.tick_clock()
        local g_now = U.game_now()

        AR.frame(os.clock())
        AI.update_pawn_timers(g_now)
        IN.update_slowmo()

        local stick_x, stick_y = IN.handle_inputs(w_now, g_now)
        Focus.follow()          -- the camera looks at whichever pawn the wheel is on, and comes home otherwise

        if W.open then
            W.previewing = false
            UI.draw_wheel(w_now, stick_x, stick_y)
        elseif API.preview then
            IN.preview_frame(w_now)
            if W.pawns[1] then UI.draw_wheel(w_now, nil, nil) else API.wheel.open, API.wheel.backdrop = false, nil end
        else
            W.previewing = false
            if W.tg and W.tg.preview then W.stage, W.tg = 1, nil end     -- 1.38: leave the targeting preview
            API.wheel.open, API.wheel.backdrop = false, nil
            UI.draw_status_banner(w_now)
        end
    end, "M.update")
end

function M.reset()
    U.safe_call(function()
        W.open = false
        W.swallowing = false
        W.stage, W.tg = 1, nil
        AR.queue = nil
        IN.stop_slowmo_now()
        Focus.forget()
        AI.reset_all()
    end, "M.reset")
end

return M