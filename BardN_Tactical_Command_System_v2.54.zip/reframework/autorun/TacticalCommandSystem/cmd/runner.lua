-- TacticalCommandSystem/cmd/runner.lua
-- Watching an order through, from the moment it goes out to the moment the pawn is free again.
--
-- An ordered skill is not a function call: the order goes out, and then the pawn may be knocked down before it starts,
-- may walk into a wall trying to reach the enemy, may decide the enemy is dead and wander off, may hold a charge for
-- two seconds, may finish in four frames. Nothing reports back, so the only way to know is to watch the pawn's actions
-- and read what is happening from them.
--
-- An order goes through two phases:
--
--   winding   -- the order is out, the skill has not started. Watching for the skill's own action to appear, and for
--                the reasons it never will: a hit, a wall, a pawn that quietly went back to fighting its own way.
--   underway  -- the skill is running. Watching for it to charge, to come to the ready, to cast, and for the ways it
--                can hang: a charge that never releases, a cast that never ends, a skill that ran past its welcome.
--
-- An order that cannot start is not dropped: it goes back on the shelf as `soon` and is tried again once the pawn is on
-- its feet. Four reasons to wait, four ways to come back from it, written out at the bottom.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local P = require("TacticalCommandSystem.cmd.posture")
local Brain = require("TacticalCommandSystem.cmd.brain")
local Obj = require("TacticalCommandSystem.cmd.pawnobj")
local Aim = require("TacticalCommandSystem.cmd.aim")
local Roster = require("TacticalCommandSystem.cmd.roster")
local Issue = require("TacticalCommandSystem.cmd.issue")
local Queue = require("TacticalCommandSystem.cmd.queue")
local Stance = require("TacticalCommandSystem.cmd.stance")
local Auto = require("TacticalCommandSystem.cmd.auto")     -- 2.30: Bloodied Pact phase 2

local Run = {}

----------------------------------------------------------------------------------------------------
-- small moves
----------------------------------------------------------------------------------------------------
local function cancel_action(chara)
    pcall(function()
        chara[S.F.actions]:requestActionCore(10, "DefaultCancelAction", 0)
    end)
end

-- Gives the pawn its own thinking back part-way through an order, so it can aim the rest of the skill itself.
local function resume_thinking(rec, run)
    if run.thinking then return end
    local held_still = (rec.stance == "wait")
    if not held_still and U.is_valid_obj(run.chara) then
        Brain.of(run.chara):set_thinking(true)
    end
    run.thinking = true
    if run.mode ~= "brain" then Obj.give_ration(run, true) end
end

-- the set of action names the pawn had last frame, lowercased
local function previous_names(run)
    local was = {}
    for name in (run.stack or ""):lower():gmatch("[^|]+") do was[name] = true end
    return was
end

local function wait_for(rec, kind, skill_id, pick, now, extra)
    local soon = { kind = kind, skill = skill_id, chara = rec.chara, since = now, pick = pick }
    if extra then
        for k, v in pairs(extra) do soon[k] = v end
    end
    rec.soon = soon
end

----------------------------------------------------------------------------------------------------
-- the archer's two-part shot, which the engine drives by hand
----------------------------------------------------------------------------------------------------
local function draw_bow(rec, run, ord, stack, since_fire, now)
    if run.charge_sent or since_fire < 0.6 then return end
    if stack.hurt or stack.blocked or stack.aerial then return end

    local gap
    if U.is_valid_obj(run.target) and run.target ~= run.chara then
        local ok, d = pcall(U.distance, run.chara, run.target)
        gap = ok and d or nil
    end
    if gap and gap > (ord.direct.range or D.ARCHER_RANGE) then return end
    if not gap and since_fire < 3.0 then return end

    run.charge_sent = now
    Issue.request_action(run.chara, 10, ord.direct.prepare, 1)
end

----------------------------------------------------------------------------------------------------
-- is the pawn getting anywhere
----------------------------------------------------------------------------------------------------
-- True when the pawn has stopped making progress towards the skill and the order should be pushed through instead.
local function going_nowhere(run, stack, now)
    local gap
    if U.is_valid_obj(run.target) and run.target ~= run.chara then
        local ok, d = pcall(U.distance, run.chara, run.target)
        gap = ok and d or nil
    end

    local why = P.obstacle(stack, run.chara, U.is_dead(run.chara))
    local its_own_doing = why and why:find("^layer ") and not stack.aerial

    if its_own_doing then
        local stuck = run.stuck
        local closing = (stuck and stuck.gap and gap) and (stuck.gap - gap) or nil
        if not stuck or why ~= stuck.why or (closing and closing >= D.UNSTUCK_CLOSER) then
            run.stuck = { why = why, since = now, gap = gap }
            stuck = run.stuck
        end
        if now - stuck.since >= D.LAYER_STUCK and now - run.at_fire >= D.UNSTUCK_AFTER then
            return true
        end
    else
        run.stuck = nil
    end

    -- walking towards the enemy counts as progress even with no action to show for it
    local closing = (run.dist_ref and gap) and (run.dist_ref - gap) or nil
    if not why and closing and closing >= D.UNSTUCK_CLOSER then why = "walking" end

    if why then
        run.still_since, run.dist_ref = nil, nil
        return false
    end
    if not run.still_since then
        run.still_since, run.dist_ref = now, gap
        return false
    end
    return (now - run.still_since >= D.UNSTUCK_STILL) and (now - run.at_fire >= D.UNSTUCK_AFTER)
end

----------------------------------------------------------------------------------------------------
-- cut short by a hit
----------------------------------------------------------------------------------------------------
-- A pawn knocked out of its skill gets the order again, up to twice, once it has its feet back. A caster that was
-- already casting is left alone -- the spell is gone, repeating it would be a second cast the player did not ask for.
local function knocked_out(rec, run, now)
    local pick = run.target_pick
    local skill_id = run.skill
    local was_casting = run.casting
    Roster.stop(rec)

    local ord = D.ORDERS[skill_id]
    if not ord or ord.stance then return end
    if was_casting and not D.MELEE_JOBS[ord.job] then return end

    local tally = rec.retry
    local nth = (tally and tally.skill == skill_id) and (tally.n + 1) or 1
    if nth > D.RETRY_MAX then return end
    rec.retry = { skill = skill_id, n = nth }

    wait_for(rec, "after_hit", skill_id, pick, now, { nth = nth })
end

----------------------------------------------------------------------------------------------------
-- phase: the skill has not started yet
----------------------------------------------------------------------------------------------------
-- Returns true when the phase has dealt with the order (started it, dropped it, shelved it).
local function phase_winding(rec, run, ord, stack, started, hurt, now)
    local since_fire = now - run.at_fire

    -- some skills never announce themselves by a keyword: a job action that was not running before, and is not a
    -- restart of one that was, is taken as the skill and its name learnt for next time
    local guessed, stem
    if not started and not D.KEYS_SEEN[run.skill] and not D.MELEE_JOBS[ord.job] and run.mode ~= "brain" then
        guessed, stem = P.fresh_skill(stack, run.stack_at_fire)
    end

    if started or guessed then
        if guessed then run.keys[#run.keys + 1] = stem end
        run.at_begin = now
        Obj.give_ration(run, false)
        Obj.blinker_off(run.blinker)
        run.blinker = nil
        return true
    end

    if hurt then
        knocked_out(rec, run, now)
        return true
    end

    if run.mode == "brain" then
        -- the pawn has its head: either it is running one of the skill's decisions, or it has quietly gone back to
        -- fighting its own way, in which case the order is pushed through instead
        local ours = Brain.of(run.chara):running_ours(run.mine)
        if ours or stack.skill then
            run.idle_since = nil
        else
            run.idle_since = run.idle_since or now
        end

        if run.idle_since and (now - run.idle_since >= D.FREE_WAIT) and (not ord.wait_ai or run.skill == 69) then
            local chara, skill_id, pick = run.chara, run.skill, run.target_pick
            Roster.stop(rec)
            Issue.order(rec, skill_id, now, true, pick)
            return true
        end
        if since_fire >= D.START_MAX then
            Roster.stop(rec)
            return true
        end
        return false
    end

    if stack.low:find("outofstamina", 1, true) then
        Roster.stop(rec)
        return true
    end

    if going_nowhere(run, stack, now) then
        if run.nudged then
            Roster.stop(rec)
        else
            local chara, skill_id, pick = run.chara, run.skill, run.target_pick
            Roster.stop(rec)
            cancel_action(chara)
            wait_for(rec, "unstuck", skill_id, pick, now, { chara = chara })
        end
        return true
    end

    if since_fire >= D.START_MAX then
        Roster.stop(rec)
        return true
    end
    return false
end

----------------------------------------------------------------------------------------------------
-- phase: the skill is running
----------------------------------------------------------------------------------------------------
-- Each of these ends the order when it answers true, in this order.
local HANGING = {
    -- a charge that should have released by now, at the slowest rate the game ever charges
    function(run, ord, now)
        if run.mode == "brain" or not ord.charge or run.at_ready or run.casting then return false end
        local allowed = (run.prep or ord.charge) / D.SLOWEST_RATE + D.CHARGE_SLACK
        return (now - run.at_begin) >= allowed
    end,
    -- held at the ready, never let go
    function(run, ord, now)
        if run.mode == "brain" or not run.at_ready or run.casting then return false end
        local allowed = ord.ready_max or (ord.release_ai and D.READY_MAX_AI or D.READY_MAX)
        return (now - run.at_ready) >= allowed
    end,
    -- casting with no end in sight
    function(run, _, now)
        return run.at_cast ~= nil and (now - run.at_cast) >= D.CAST_STUCK
    end,
    -- out of patience altogether
    function(run, _, now)
        return (now - run.at_fire) >= D.ORDER_MAX
    end,
}

local function phase_underway(rec, run, ord, stack, in_skill, hurt, now)
    if hurt then
        knocked_out(rec, run, now)
        return true
    end

    -- the skill's action is gone: it finished, or something took it away
    if not in_skill then
        Roster.stop(rec)
        return true
    end

    -- the enemy died before the skill got going
    if ord.target == "enemy" and U.is_valid_obj(run.target) and run.target ~= run.chara
        and U.is_dead(run.target) and not run.at_ready and not run.casting then
        Roster.stop(rec)
        return true
    end

    for _, hangs in ipairs(HANGING) do
        if hangs(run, ord, now) then
            Roster.stop(rec)
            return true
        end
    end
    return false
end

----------------------------------------------------------------------------------------------------
-- reading the stages of the skill off the pawn's actions
----------------------------------------------------------------------------------------------------
local function follow_stages(rec, run, ord, stack, in_skill, was, now)
    if not in_skill or run.casting or ord.stance then return end

    for name in stack.low:gmatch("[^|]+") do
        local appeared = not was[name]
        -- 2.08: the charge of a chargeable skill is not the skill going off: the pawn is held in it until the full one
        if appeared and run.full and name == ord.full.stage then appeared = false end     -- 2.25
        if appeared and P.mentions(name, run.keys) then
            if name:find("ready", 1, true) and not run.at_ready then
                run.at_ready = now
                if ord.release_ai then resume_thinking(rec, run) end
                if ord.direct and run.charge_sent then
                    Issue.request_action(run.chara, 10, ord.direct.shoot, 1)
                end
            end
            if not name:find("prepare", 1, true) and not name:find("ready", 1, true) then
                run.casting = true
                run.at_cast = now
                -- a heal, or a caster holding its spell, keeps its own aim for a moment longer
                if D.RANGE_HEAL[run.skill] or run.hold then
                    run.thinking_back_at = now + D.HEAL_AI_MAX
                else
                    resume_thinking(rec, run)
                end
                break
            end
        end
    end
end

----------------------------------------------------------------------------------------------------
-- one order, one frame
----------------------------------------------------------------------------------------------------
local function step_order(rec, now)
    local run = rec.run
    if not run then return end

    if not U.is_valid_obj(run.chara) or U.is_dead(run.chara) then
        Roster.stop(rec)
        rec.soon = nil
        Queue.clear(rec)
        return
    end

    -- the pawn's decision table is rebuilt as it fights, handing flags back: mute them again
    if run.mode == "brain" and (now - (run.refocus_at or 0)) >= D.REAPPLY_DT then
        run.refocus_at = now
        Brain.of(run.chara):refocus(run.token)
    end

    local ord = D.ORDERS[run.skill]
    if not ord then
        Roster.stop(rec)
        return
    end

    local was = previous_names(run)
    local stack = P.read(run.chara)
    run.stack = stack.raw

    local in_skill = P.mentions(stack.low, run.keys)
    local started = (run.seen_request and in_skill) or false
    if not started then
        for _, name in ipairs(stack.names) do
            if not run.stack_at_fire[name] and P.mentions(name:lower(), run.keys) then
                started = true
                break
            end
        end
    end

    -- a pawn already reeling when the order went out would read as "knocked out of it" on the first frame
    local hurt = P.shaken(stack, run.chara)
    if run.shaken_at_fire then
        if not hurt then run.shaken_at_fire = false end
        hurt = nil
    end

    follow_stages(rec, run, ord, stack, in_skill, was, now)

    if run.thinking_back_at and now >= run.thinking_back_at then
        run.thinking_back_at = nil
        resume_thinking(rec, run)
    end

    -- the archer's shot, released a set time after the draw began
    if ord.direct and ord.direct.shoot_after and run.charge_sent and run.at_begin
        and not run.casting and not run.shot_sent
        and (now - run.at_begin >= ord.direct.shoot_after) then
        run.shot_sent = now
        Issue.request_action(run.chara, 10, ord.direct.shoot, 1)
    end

    -- 2.13: is the pawn in the charge of a chargeable skill (for the wheel: "channeling")
    if ord.full then
        local st, hit = ord.full.stage, false
        for name in stack.low:gmatch("[^|]+") do
            if name == st then hit = true; break end     -- 2.21: the charge action itself, not …Normal / …Full / …ExComboFull
        end
        run.charging = (hit and run.at_begin ~= nil) or nil
        if hit then run.stage_seen = true end            -- 2.29: the variant really started (an EX skill, say)
        -- 2.29: another variant of the skill took over (Arc of Might in Bloodied Pact phase 2): hands off
        if run.full and ord.full.skip and stack.low:find(ord.full.skip, 1, true) then run.full = nil end
    end

    -- 2.13: ordered quick (X): the quick release is asked for as soon as the charge starts
    if run.quick and run.at_begin and run.stage_seen and not run.quick_sent then     -- 2.29: stage_seen
        run.quick_sent = now
        Issue.request_action(run.chara, 10, ord.full.normal, 0)
    end

    -- 2.25: a chargeable skill ordered charged. The exact moment the charge is complete is not readable, and a fixed
    -- delay released it well after it (the pawn kept missing), so the charged release is asked for from "from" on and
    -- asked for again every 0.12 s: the first request the game accepts goes off at the earliest possible moment.
    if run.full and run.at_begin and not run.casting then
        local t = now - run.at_begin
        local lowfull = ord.full.low_full
        if not lowfull then lowfull = ord.full.full:lower(); ord.full.low_full = lowfull end
        if stack.low:find(lowfull, 1, true) then
            run.full_got = run.full_got or now     -- 2.33: out; its own early finish may still have to be fenced
            run.full = nil                   -- taken: the charge is released, nothing more to ask for
        elseif t > (ord.full.give_up or (ord.full.after + 2.0)) then     -- 2.33: give_up per skill
            run.full = nil                   -- never taken: let the quick one through rather than stall
        elseif ord.full.no_request then
            -- 2.34: nothing is asked for. Plenilune Slash EX: asking for the spin loop pre-empted the start-up and
            -- the loop died at once. Its short end is turned away instead, and the pawn's own head takes the loop.
        elseif run.stage_seen and t >= ((Auto.in_blood(run.actions_addr) and ord.full.from_blood)
                                         or ord.full.from or (ord.full.after * 0.6)) then     -- 2.30: phase 2
            -- 2.29: only once the variant's own first action was seen: never ask an EX action of a pawn without it
            if not run.full_try or (now - run.full_try) >= 0.05 then     -- 2.30: was 0.12 (up to 0.12 s late)
                run.full_try  = now
                run.full_sent = run.full_sent or now
                Issue.request_action(run.chara, 10, ord.full.full, 0)
            end
        end
    end

    if not run.at_begin and ord.direct and run.mode ~= "brain" and not started then
        draw_bow(rec, run, ord, stack, now - run.at_fire, now)
    end

    if not run.at_begin then
        phase_winding(rec, run, ord, stack, started, hurt, now)
    else
        phase_underway(rec, run, ord, stack, in_skill, hurt, now)
    end
end

----------------------------------------------------------------------------------------------------
-- coming back from a wait
----------------------------------------------------------------------------------------------------
local function pawn_is_busy(stack)
    return stack.hurt ~= nil or stack.blocked ~= nil or stack.aerial ~= nil
end

local RESUME = {}

-- knocked out of the skill: wait for the pawn to stop reeling, then order it again
RESUME.after_hit = function(rec, soon, stack, waited, now)
    local why = P.shaken(stack, soon.chara)
    if why == "IsDamage" then
        soon.flag_since = soon.flag_since or now
        if now - soon.flag_since >= D.ISDMG_MAX then why = nil end   -- the flag sometimes sticks; do not wait on it
    else
        soon.flag_since = nil
    end

    if why then
        soon.clear_since = nil
        if waited > D.RETRY_WAIT then rec.soon = nil end
        return
    end
    soon.clear_since = soon.clear_since or now
    if now - soon.clear_since >= D.RETRY_CLEAR then
        rec.soon = nil
        Issue.order(rec, soon.skill, now, false, soon.pick)
    end
end

-- the next skill in the queue, given a beat so it does not run into the one before it
RESUME.from_queue = function(rec, soon, stack, waited, now)
    if not pawn_is_busy(stack) and waited >= D.QUEUE_CHAIN_DT then
        rec.soon = nil
        Issue.order(rec, soon.skill, now, false, soon.pick)
    elseif waited > 8.0 then
        rec.soon = nil
    end
end

-- the pawn was getting nowhere: cancel, then push the order through rather than asking nicely again
RESUME.unstuck = function(rec, soon, stack, waited, now)
    if pawn_is_busy(stack) then
        if waited > 15.0 then rec.soon = nil end
        return
    end
    if waited >= D.UNSTUCK_REFIRE then
        rec.soon = nil
        Issue.order(rec, soon.skill, now, soon.cut and false or "unstuck", soon.pick)
    end
end

-- the pawn was in the middle of something: wait for it to come back to rest
RESUME.when_free = function(rec, soon, stack, waited, now)
    if pawn_is_busy(stack) then
        if waited > 20.0 then rec.soon = nil end
        return
    end
    if P.at_rest(stack) or D.IDLE_LAYERS[stack.top] or waited > 3.0 then
        rec.soon = nil
        Issue.order(rec, soon.skill, now, false, soon.pick)
    end
end

local function step_wait(rec, now)
    local soon = rec.soon
    if not soon or rec.run then return end
    if not U.is_valid_obj(soon.chara) or U.is_dead(soon.chara) then
        rec.soon = nil
        return
    end
    local stack = P.read(soon.chara)
    local handler = RESUME[soon.kind] or RESUME.when_free
    handler(rec, soon, stack, now - soon.since, now)
end

----------------------------------------------------------------------------------------------------
-- pulling the next skill off the queue
----------------------------------------------------------------------------------------------------
local function step_queue(rec, now)
    if rec.run or rec.soon or Queue.length(rec) == 0 then return end
    if not U.is_valid_obj(rec.chara) or U.is_dead(rec.chara) then
        Queue.clear(rec)
        return
    end

    while Queue.length(rec) > 0 do
        if not Queue.ready_head(rec) then break end              -- the gauge cannot pay for it yet: hold the queue
        local item = Queue.take(rec)
        local pick = Aim.settle(item.skill, item.pick, rec.chara)
        if not Aim.must_have_enemy(item.skill) or pick then
            wait_for(rec, "from_queue", item.skill, pick, now)
            break
        end
    end
end

----------------------------------------------------------------------------------------------------
-- the whole roster, once a frame
----------------------------------------------------------------------------------------------------
-- 2.48: a skill done in two steps (Powder Charge: plant, then detonate). 2.46 asked for the detonation itself and the
-- pawn went off twice in a row: now the detonation is left to the pawn or to a second order, and only the pawn's own
-- detonation is turned away for STEP2_GAP seconds (menu) after the planting ends (after it starts when clinging, as the cling
-- planting lasts until the next action). Kept on rec, not on the run: the run is over once the planting ends.
local function step_detonate(rec, now)
    local run = rec.run
    if run and not rec.det then
        local ord = D.ORDERS[run.skill]
        local det = ord and ord.detonate
        if det and U.is_valid_obj(run.chara) then
            local st = P.read(run.chara)
            if st.low:find(det.plant, 1, true) then
                local h = U.safe_call(function() return run.chara:get_field(S.F.human):get_address() end)
                rec.det = { t = now, chara = run.chara, cfg = det, addr = rec.actions_addr, human = h, skill = run.skill }
                -- 2.49: the order is done once the charge is going down. Kept running, it left the pawn standing
                -- still with its AI off, then set the skill off again; stopped here, the pawn gets its own head back.
                Roster.stop(rec)
            end
        end
    end
    local d = rec.det
    if not d then return end
    local c = d.cfg
    local alive = U.is_valid_obj(d.chara) and not U.is_dead(d.chara)
    local st = alive and P.read(d.chara) or nil
    local planting = st and st.low:find(c.plant, 1, true) and not st.low:find("cling", 1, true)
    local wall = os.clock()
    local gap = D.STEP2_GAP or c.min_gap         -- 2.49: set in the menu
    if planting then d.till = wall + gap
    elseif not d.till then d.till = wall + gap end
    if not alive or wall >= d.till or (now - d.t) > c.keep then
        if d.addr and d.addr ~= 0 then D.STEP2_FENCE[d.addr] = nil end
        if d.human then D.STEP2_VETO[d.human] = nil end
        rec.det = nil
        return
    end
    if d.addr and d.addr ~= 0 then D.STEP2_FENCE[d.addr] = { till = d.till, word = c.done } end
    -- 2.49: and the pawn's head is told the skill is unavailable, so it does not keep trying (and freezing) meanwhile
    if d.human then D.STEP2_VETO[d.human] = { till = d.till, skill = d.skill } end
end

function Run.step(rec, now)
    step_detonate(rec, now)
    step_order(rec, now)
    step_queue(rec, now)
    step_wait(rec, now)
    Stance.keep(rec, now)
end

function Run.tick(now, step_locks)
    if step_locks then pcall(step_locks, U.wall_time()) end

    for addr, rec in pairs(Roster.all()) do
        local ok, err = pcall(Run.step, rec, now)
        if not ok then
            U.log_err_once("order step", err)
            Roster.stop(rec)
            rec.soon = nil
        end
        Roster.tidy(rec)
    end
end

Run.wait_for = wait_for

return Run
