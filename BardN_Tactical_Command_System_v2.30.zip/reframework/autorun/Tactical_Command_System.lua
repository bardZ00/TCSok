-- Tactical_Command_System.lua
-- Tactical Command System: one wheel for the Arisen and the pawns.
-- Entry point: loads the configuration, runs the wheel module every frame and draws the menu.
--
-- Where things are, under TacticalCommandSystem/:
--   loop.lua        the frame: inputs -> orders -> camera -> drawing
--   input.lua  in/  inputs: pad, keyboard, mouse, the wheel's state machine, slow motion
--   ui.lua     ui/  drawing: the wheel, the targeting step, prompts, markers, pictures and fonts
--   cmd/            the pawn orders engine (brain, queue, stances, manual-only locks, game hooks)
--   arisen.lua      the Arisen's skills launched from the wheel
--   camera.lua      the camera that changes character with the wheel, and frames the enemy being aimed at
--   possess.lua     taking control of the character the wheel is on (driven through Direct Pawn Control)
--   config.lua conf/  the settings (list, values, saved file)
--   menu.lua   menu/  the REFramework menu (drawers, key assignment)
--   lib/ utils.lua  shared helpers;  data.lua  skills and vocations;  i18n.lua  French / English;  api.lua  for the ATB module
-- Choices are saved to reframework/data/Tactical_Command_System/config.json.

log.info("[Tactical_Command_System] Starting initialization.")

local VERSION = "2.30"

local I18  = require("TacticalCommandSystem.i18n")
local S    = require("TacticalCommandSystem.conf.settings")
local C    = require("TacticalCommandSystem.config")
local B    = require("TacticalCommandSystem.menu.binds")
local Menu = require("TacticalCommandSystem.menu")

local T = I18.pick   -- T("English", "Français")

local MODULE_ID      = "pawn_commands"   -- the key of the on / off switch in the saved settings: kept as it is
local PROFILE_WINDOW = 1.0      -- profiler averaging window (seconds)

----------------------------------------------------------------------
-- The wheel module
----------------------------------------------------------------------
local mod, load_error
do
    local ok, res = pcall(require, "TacticalCommandSystem.loop")
    if ok then mod = res else
        load_error = tostring(res)
        log.error("[Tactical_Command_System] Failed to load the wheel module: " .. load_error)
    end
end

local active = false           -- the module runs only while enabled
local last_error = nil

local function sync_active()
    local want = mod ~= nil and C.is_enabled(MODULE_ID)
    if want == active then return end
    active = want
    if not want and mod and mod.reset then
        local ok, err = pcall(mod.reset)
        if not ok then log.error("[Tactical_Command_System] reset failed: " .. tostring(err)) end
    end
end

----------------------------------------------------------------------
-- Profiler (time spent in the module's update, averaged over one second)
----------------------------------------------------------------------
local prof = { on = false, sum = 0, avg_ms = 0, peak_ms = 0, window_start = 0, frames = 0 }

local function profiler_switch(on)
    prof.on = on == true
    prof.sum, prof.avg_ms, prof.window_start, prof.frames = 0, 0, 0, 0
end
S.hooks.profiler = profiler_switch

local function roll_profile_window(now)
    if prof.window_start == 0 then prof.window_start = now end
    prof.frames = prof.frames + 1
    if now - prof.window_start < PROFILE_WINDOW then return end
    prof.avg_ms = prof.sum / prof.frames * 1000
    prof.sum, prof.window_start, prof.frames = 0, now, 0
end

----------------------------------------------------------------------
-- Frame loop
----------------------------------------------------------------------
-- True while the game hides its HUD (pause, menu, fade, photo mode, cutscene)
local function hud_hidden(gm)
    if gm:call("isPausedGUI") == true then return true end
    if gm:call("isDispMenuUI") == true then return true end
    if gm:call("isFadeDispAny()") == true then return true end
    if gm:get_field("<IsDispPhotoModeAll>k__BackingField") == true then return true end
    if gm:call("get_IsHideHud") == true then return true end
    local pm = sdk.get_managed_singleton("app.PauseManager")
    return pm ~= nil and pm:call("isPausedAny") == true
end

local function run_module(now)
    local t0 = prof.on and os.clock() or nil
    local ok, err = pcall(mod.update, now)
    if t0 then
        local dt = os.clock() - t0
        prof.sum = prof.sum + dt
        if dt * 1000 > prof.peak_ms then prof.peak_ms = dt * 1000 end
    end
    if ok then
        last_error = nil
    else
        err = tostring(err)
        if last_error ~= err then       -- logged once per distinct error
            last_error = err
            log.error("[Tactical_Command_System] update failed: " .. err)
        end
    end
end

re.on_frame(function()
    local now = os.clock()
    C.tick(now)
    if prof.on then roll_profile_window(now) end
    if not active then return end

    local gm = sdk.get_managed_singleton("app.GuiManager")
    local hidden = true
    if gm then
        local ok, h = pcall(hud_hidden, gm)
        hidden = ok and h == true
    end

    if hidden or B.capturing() then
        if mod.on_hud_hidden then pcall(mod.on_hud_hidden, now) end
        return
    end
    run_module(now)
end)

----------------------------------------------------------------------
-- Menu parts that belong to the host (module switch, profiler)
----------------------------------------------------------------------
Menu.install({
    title = "BardN Tactical Command System v" .. VERSION,

    draw_module = function()
        local label = T("Mod Active", "Mod actif")
        if not mod then
            imgui.text(label .. T("  [failed to load - see REFramework log]", "  [échec du chargement - voir le journal REFramework]"))
            return
        end
        local on_now = C.is_enabled(MODULE_ID)
        -- off is the state worth seeing at a glance: the whole line goes red
        if not on_now then imgui.push_style_color(0, 0xFF4040FF) end
        local changed, on = imgui.checkbox(label .. "##tc_module", on_now)
        if not on_now then imgui.pop_style_color(1) end
        if changed then
            C.set_enabled(MODULE_ID, on)
            sync_active()
        end
        if not on_now then
            imgui.same_line()
            imgui.text_colored(T("-- the wheel, the orders and the camera are off.",
                "-- la roue, les ordres et la caméra sont coupés."), 0xFF4040FF)
        end
        if last_error then
            imgui.same_line()
            imgui.text(T("(error - see log)", "(erreur - voir le journal)"))
        end
        if imgui.is_item_hovered() then
            imgui.set_tooltip(T("The whole mod: skills of the Arisen and tactical orders for the pawns.\nOn by default; off, the game behaves as if the mod were not installed.",
                "Tout le mod : compétences de l'Insurgé et ordres tactiques des pions.\nCoché par défaut ; décoché, le jeu se comporte comme si le mod n'était pas installé."))
        end
    end,

    draw_profiler = function()
        local def = S.BY_KEY.profiler
        local changed, on = imgui.checkbox(T(def.label[1], def.label[2]) .. "##tc_profiler", C.values.profiler)
        if changed then C.set("profiler", on) end
        if imgui.is_item_hovered() then imgui.set_tooltip(T(def.tip[1], def.tip[2])) end
        if not C.values.profiler then return end
        imgui.same_line()
        if imgui.button(T("Reset peaks", "Remettre les pics à zéro") .. "##tc_prof_reset") then prof.peak_ms = 0 end
        imgui.text(string.format(T("%-20s avg %.3f ms   peak %.1f ms", "%-20s moy %.3f ms   pic %.1f ms"),
            "Tactical Command System", prof.avg_ms, prof.peak_ms))
    end,
})

re.on_draw_ui(Menu.draw)

re.on_script_reset(function()
    if mod and mod.reset then pcall(mod.reset) end
    C.flush()
end)

----------------------------------------------------------------------
-- Start
----------------------------------------------------------------------
C.load()
sync_active()

log.info("[Tactical_Command_System] Loaded successfully.")
