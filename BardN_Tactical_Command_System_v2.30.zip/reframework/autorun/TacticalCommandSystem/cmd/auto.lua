-- TacticalCommandSystem/cmd/auto.lua
-- 2.30: what the mod does for a pawn that was given no order.
--
--   * Warrior pawns (setting "auto_charge"): a chargeable skill the pawn starts on its own is held to the full charge,
--     with the same release times as an order. In Bloodied Pact phase 2 the charge is near instant, so the release is
--     asked for almost at once and the pawn's own charged release is let through.
--   * Fighter pawns (setting "auto_shield_off"): Shield Precision is switched off once the fight is over.
--   * Warrior pawns, always: whether they are in Bloodied Pact phase 2, so an order uses the short release time too.
--
-- The pawns are known by the address of their action manager, the key the action hook reports: for every other
-- character the hook does one table lookup and leaves. The pawn being played (Direct Pawn Control) is never touched,
-- nor a pawn running an order (the order engine looks after it).

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local P = require("TacticalCommandSystem.cmd.posture")
local Roster = require("TacticalCommandSystem.cmd.roster")
local Issue = require("TacticalCommandSystem.cmd.issue")
local Vision = require("TacticalCommandSystem.lib.vision")

local A = {
    charge = false,        -- setting auto_charge
    shield_off = false,    -- setting auto_shield_off
    any = false,           -- at least one pawn is looked after (read by the action hook)
    by_actions = {},       -- action-manager address -> pawn record
}

local SKIP = sdk.PreHookResult and sdk.PreHookResult.SKIP_ORIGINAL or nil

local BLOOD_ON, BLOOD_OFF = "Job05_ScarletVowBloodMode", "Job05_ScarletVowBloodModeEnd"
local SHIELD_ON, SHIELD_OFF = "Job01_Ascertain", "Job01_AscertainEnd"
local SHIELD_IDLE = 20.0   -- seconds without a blow between the party and an enemy: the fight is over
local POLL = 0.10          -- how often a looked-after pawn's actions are read
local RETRY = 0.05         -- how often the charged release is asked for again

-- the Warrior's chargeable skills, by the exact name of their charge action
local STAGES = nil
local function stages()
    if STAGES then return STAGES end
    STAGES = {}
    for id, o in pairs(D.ORDERS) do
        if o.job == 5 and o.full and o.full.normal then
            local stage = o.full.normal:gsub("Normal$", "")
            STAGES[stage] = id
        end
    end
    return STAGES
end

local recs = {}            -- chara address -> record (kept across refreshes: phase 2 and shield state survive)

local function played_addr()
    local Poss = package.loaded["TacticalCommandSystem.possess"]
    return Poss and Poss.active_addr and Poss.active_addr() or nil
end

----------------------------------------------------------------------------------------------------
-- who is looked after (every 2 s)
----------------------------------------------------------------------------------------------------
local refresh_t = -10
local function refresh(now)
    if now - refresh_t < 2.0 then return end
    refresh_t = now
    local list = U.safe_call(function() return U.get_commandable_pawns() end) or {}
    local keep, by = {}, {}
    for _, e in ipairs(list) do
        local want = (e.job == 5) or (e.job == 1 and A.shield_off)
        if want and e.addr then
            local rec = recs[e.addr] or { addr = e.addr }
            rec.chara, rec.job = e.chara, e.job
            local a = U.safe_call(function()
                local act = e.chara[S.F.actions]
                return act and act:get_address()
            end)
            if a and a ~= 0 then
                rec.actions_addr = a
                by[a] = rec
                keep[e.addr] = rec
            end
        end
    end
    recs, A.by_actions = keep, by
    A.any = next(by) ~= nil
end

----------------------------------------------------------------------------------------------------
-- the action hook (called from guards.lua, inside its pcall)
----------------------------------------------------------------------------------------------------
-- Returns SKIP to turn the request away, nil to let it through.
function A.on_request(rec, name)
    if not A.charge or rec.job ~= 5 then return nil end
    local st = rec.st
    if not st or rec.addr == played_addr() then return nil end
    if Roster.run_by_actions(rec.actions_addr) then return nil end     -- an order: the engine decides
    local o = D.ORDERS[st.id]
    if not (o and o.full) then return nil end
    local t = U.game_now() - st.t0
    if name == o.full.normal then
        if t < o.full.after + 2.0 then return SKIP end                   -- the quick release, while we hold the charge
    elseif name == o.full.full then
        local from = (rec.blood and o.full.from_blood) or o.full.from
        if not rec.blood and t < from then return SKIP end               -- the pawn's own release, too early
    end
    return nil
end

----------------------------------------------------------------------------------------------------
-- the frame
----------------------------------------------------------------------------------------------------
local function poll(rec, now)
    local stack = P.read(rec.chara)
    local set = stack.set or {}

    -- Bloodied Pact phase 2 starts and ends with these two actions
    if set[BLOOD_OFF] then rec.blood = false
    elseif set[BLOOD_ON] then rec.blood = true end

    -- Shield Precision: on with its own action, off with its end
    if set[SHIELD_OFF] then rec.shield = nil
    elseif set[SHIELD_ON] and not rec.shield then rec.shield = os.clock() end

    if rec.job ~= 5 or not A.charge then rec.st = nil; return end
    if Roster.run_by_actions(rec.actions_addr) or rec.addr == played_addr() then rec.st = nil; return end

    local st = rec.st
    if not st then
        for stage, id in pairs(stages()) do
            if set[stage] then rec.st = { id = id, t0 = now, stage = stage }; break end
        end
        return
    end

    local o = D.ORDERS[st.id]
    local t = now - st.t0
    if set[o.full.full] or t > o.full.after + 2.0 or not set[st.stage] then
        rec.st = nil                                                     -- released, given up, or knocked out of it
        return
    end
    local from = (rec.blood and o.full.from_blood) or o.full.from
    if t >= from and (not st.try or now - st.try >= RETRY) then
        st.try = now
        Issue.request_action(rec.chara, 10, o.full.full, 0)
    end
end

function A.tick(now)
    refresh(now)
    if not A.any then return end
    for _, rec in pairs(recs) do
        -- a pawn in a charge is read every frame (the release time matters), the others every POLL seconds
        if rec.st or not rec.poll_t or now - rec.poll_t >= POLL then
            rec.poll_t = now
            U.safe_call(function() poll(rec, now) end)
        end
        -- the fight is over: Shield Precision is put away
        if A.shield_off and rec.job == 1 and rec.shield and rec.addr ~= played_addr() then
            local quiet = os.clock() - math.max(Vision.last_blow or 0, rec.shield)
            if quiet > SHIELD_IDLE then
                rec.shield = nil
                Issue.request_action(rec.chara, 10, SHIELD_OFF, 0)
            end
        end
    end
end

-- for an order: is this pawn in Bloodied Pact phase 2?
function A.in_blood(actions_addr)
    local rec = actions_addr and A.by_actions[actions_addr]
    return rec and rec.blood or false
end

return A
