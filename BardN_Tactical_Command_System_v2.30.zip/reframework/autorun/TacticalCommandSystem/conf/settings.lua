-- TacticalCommandSystem/conf/settings.lua
-- The list of user settings: ONE entry per setting. Each entry says what the setting is (default value, valid range),
-- where it takes effect (apply) and how it looks in the menu (label, tooltip, visibility).
-- config.lua loads / saves from this list, and the menu draws from it. Adding a setting = adding one entry here.
--
-- Entry fields:
--   key      name saved in config.json
--   kind     "bool" | "float" | "choice"
--   default  recommended value (the "Default" preset restores it)
--   min,max,fmt,round   float settings: slider range, display format, round to an integer
--   choices  choice settings: { { value = "...", en = "...", fr = "..." }, ... }
--   label    { english, french }          tip   { english, french }  (optional tooltip)
--   apply    function(value) putting the value to work (called at startup and on every change)
--   show     function(values) -> boolean, hides the entry in the menu when false
--   preset   false = left alone by the "Default" preset (language)
--   delay    seconds of quiet before apply() runs (a slider being dragged)
--   alias    old key names still read from config.json (migration)

local IN  = require("TacticalCommandSystem.input")
local AI  = require("TacticalCommandSystem.cmd.init")
local UI  = require("TacticalCommandSystem.ui")
local WLOOK = require("TacticalCommandSystem.api").wheel_look    -- 1.36
local I18 = require("TacticalCommandSystem.i18n")
local AR  = require("TacticalCommandSystem.arisen")      -- weapon sheathed settings
local Focus = require("TacticalCommandSystem.camera")
local Poss  = require("TacticalCommandSystem.possess")
local Vision = require("TacticalCommandSystem.lib.vision")   -- 1.13: realistic targeting

local S = {}

-- Hooks the host fills in later (the profiler state lives in the main file)
S.hooks = {}

local TGT, LAMP, LOCKCFG = IN.TGT, IN.LAMP, IN.LOCKCFG

S.LIST = {
    ------------------------------------------------------------------ language
    { key = "language", kind = "choice", default = "en", preset = false,   -- 1.50: English by default
      choices = { { value = "auto", en = "Auto (game language)", fr = "Auto (langue du jeu)" },
                  { value = "en", en = "English", fr = "English" },
                  { value = "fr", en = "Français", fr = "Français" },
                  { value = "zh", en = "Chinese - 简体中文", fr = "Chinois - 简体中文" } },
      label = { "Language / Langue", "Language / Langue" },
      tip = { "Language of the mod's own texts. Auto follows the game language.\n"
                  .. "Skill, item, enemy and pawn names always come from the game itself, in the game's language.",
              "Langue des textes propres au mod. Auto suit la langue du jeu.\n"
                  .. "Les noms des sorts, objets, ennemis et pions viennent toujours du jeu, dans la langue du jeu." },
      apply = function(v) I18.set_mode(v) end },

    ------------------------------------------------------------------ taking control of a pawn
    { key = "possess_on_close", kind = "bool", default = true,
      label = { "Switch body by closing the wheel", "Changer de corps en fermant la roue" },
      tip = { "Closing the wheel lands you in the character the top row is on: scroll to a pawn and close, you play that\n"
                  .. "pawn; scroll to the Arisen and close, you are yourself again. LT locks the highlighted character as a\n"
                  .. "permanent return (a golden frame marks it): while someone is locked, closing always brings you back to\n"
                  .. "them, so you can order every pawn from the wheel without changing body. The Arisen is locked by default.\n"
                  .. "The body-switch itself is done by Direct Pawn Control, which must be installed and running; without it\n"
                  .. "closing just closes. While you play a pawn, the wheel also opens on that pawn rather than on the Arisen.",
              "Fermer la roue vous met dans le personnage sur lequel est la rangée du haut : défilez sur un pion et fermez,\n"
                  .. "vous jouez ce pion ; défilez sur l'Insurgé et fermez, vous vous retrouvez. LT verrouille le personnage\n"
                  .. "surligné comme retour permanent (un cadre doré le marque) : tant que quelqu'un est verrouillé, fermer\n"
                  .. "vous y ramène toujours, donc vous ordonnez à tous vos pions sans changer de corps. L'Insurgé est\n"
                  .. "verrouillé par défaut. La bascule elle-même est faite par Direct Pawn Control, qui doit être installé et\n"
                  .. "actif ; sans lui, fermer ne fait que fermer. Quand vous jouez un pion, la roue s'ouvre sur ce pion." },
      apply = function(v) Poss.enabled = v end },

    ------------------------------------------------------------------ opening the wheel
    -- 1.11: hold mode, LB, 0.3 s by default
    { key = "open_mode", kind = "choice", default = "toggle",       -- 2.19 (BardN): a tap on LB opens, holding LB stays the game's
      choices = { { value = "hold", en = "Hold to keep it open, release to confirm", fr = "Maintenir pour garder ouverte, relâcher valide" },
                  { value = "toggle", en = "Click to open, click to close (default)", fr = "Clic pour ouvrir, clic pour fermer (défaut)" } },
      label = { "Wheel Opening", "Ouverture de la roue" },
      tip = { "Hold: the wheel stays open only while the button is held; releasing it confirms the highlighted order\n"
                  .. "(a very quick tap keeps it open instead, the next press closes it).\n"
                  .. "Click (default): a short tap on the opening button opens the wheel (held longer than the hold time, it does not open),\n"
                  .. "tap it again to close it without any order (A orders and closes, RB adds to the queue, B closes).",
              "Maintenir : la roue reste ouverte seulement tant que le bouton est tenu ; le relâcher valide l'ordre surligné\n"
                  .. "(un appui très bref la laisse ouverte, l'appui suivant la ferme).\n"
                  .. "Clic (défaut) : un appui bref sur le bouton d'ouverture ouvre la roue (maintenu plus longtemps que la durée de maintien,\n"
                  .. "elle ne s'ouvre pas) ; un second appui la ferme sans ordre (A ordonne et ferme, RB ajoute à la file, B ferme)." },
      apply = function(v) IN.open_mode = v end },

    { key = "open_delay", kind = "float", default = 300, min = 0, max = 800, fmt = "%.0f ms", round = true,
      label = { "Single button: hold time before opening", "Bouton seul : durée de maintien avant l'ouverture" },
      tip = { "When the opening shortcut is a single button (LB by default), it must be held this long to open the wheel.\n"
                  .. "Moving or pressing other buttons meanwhile does not matter. 0 = opens at once. Default 300 ms.",
              "Quand le raccourci d'ouverture est un seul bouton (LB par défaut), il faut le tenir ce temps-là pour ouvrir la roue.\n"
                  .. "Se déplacer ou appuyer sur d'autres boutons en même temps n'empêche rien. 0 = ouverture immédiate. Défaut 300 ms." },
      apply = function(v) IN.open_delay = v / 1000 end },

    { key = "close_release", kind = "bool", default = true, alias = { "close_l1" },
      label = { "Releasing the opening shortcut closes the wheel", "Relâcher le raccourci d'ouverture ferme la roue" },
      tip = { "Keep the opening shortcut held after opening the wheel: letting go of it closes the wheel.\n"
                  .. "Works with the key / button you mapped (controller, keyboard or a Steam Input key).\n"
                  .. "A quick tap that opens the wheel does not close it. In \"hold\" mode, releasing already closes the wheel.",
              "Garde le raccourci d'ouverture enfoncé après l'ouverture : le relâcher ferme la roue.\n"
                  .. "Marche avec la touche / le bouton que tu as mappé (manette, clavier ou touche Steam Input).\n"
                  .. "Un appui bref qui ouvre la roue ne la ferme pas. En mode « maintenir », relâcher ferme déjà la roue." },
      apply = function(v) IN.close_on_release = v end },

    { key = "release_confirm", kind = "bool", default = false, alias = { "l1_confirm" },
      label = { "... and validate the highlighted order", "... et valider l'ordre surligné" },
      show = function(v) return v.close_release == true end,
      apply = function(v) IN.release_confirm = v end },

    { key = "kb_latch", kind = "float", default = 70, min = 0, max = 300, fmt = "%.0f ms", round = true,
      label = { "Key pulse hold (Steam Input)", "Maintien minimal des touches (Steam Input)" },
      tip = { "Steam Input can send a key for only a few milliseconds, too short for the mod to see it.\n"
                  .. "A key seen pressed stays counted as pressed for this long. 0 = off. Default 70 ms.",
              "Steam Input peut envoyer une touche pendant quelques millisecondes seulement, trop court pour que le mod la voie.\n"
                  .. "Une touche vue enfoncée reste comptée enfoncée pendant cette durée. 0 = désactivé. Défaut 70 ms." },
      apply = function(v) IN.KB_LATCH = v / 1000 end },

    { key = "tap_keep", kind = "float", default = 250, min = 0, max = 600, fmt = "%.0f ms", round = true,
      label = { "Quick tap keeps the wheel open (hold mode)", "Appui bref garde la roue ouverte (mode maintien)" },
      tip = { "In hold mode, if the shortcut is released sooner than this after opening, the wheel stays open\n"
                  .. "and the next press closes it (like click mode). 0 = off. Default 250 ms.",
              "En mode maintien, si le raccourci est relâché avant ce délai après l'ouverture, la roue reste ouverte\n"
                  .. "et l'appui suivant la ferme (comme le mode clic). 0 = désactivé. Défaut 250 ms." },
      apply = function(v) IN.TAP_KEEP = v / 1000 end },

    ------------------------------------------------------------------ wheel and display
    { key = "skill_icons", kind = "bool", default = true,
      label = { "Show skill icons next to skill names", "Afficher les icônes de compétences à côté des noms" },
      apply = function(v) IN.show_skill_icons = v end },

    { key = "sounds", kind = "bool", default = true,
      label = { "Wheel sounds (cell change, character switch, orders)", "Bruitages de la roue (cellule, personnage, ordres)" },
      apply = function(v) IN.sounds = v end },

    { key = "slowmo", kind = "bool", default = true,
      label = { "Slow-motion while the wheel is open", "Ralenti pendant que la roue est ouverte" },
      apply = function(v) IN.slowmo_enabled = v end },

    { key = "slowmo_factor", kind = "float", default = 0.1, min = 0.05, max = 1.0, fmt = "x%.2f",
      label = { "Game speed while open", "Vitesse du jeu pendant l'ouverture" },
      show = function(v) return v.slowmo ~= false end,
      apply = function(v) IN.slowmo_factor = v end },

    { key = "cam_tilt", kind = "bool", default = true,
      label = { "Light camera tilt while the wheel is open (Right Stick)", "Inclinaison légère de la caméra roue ouverte (stick droit)" },
      tip = { "The Right Stick still moves the camera while the wheel is open. The Left Stick picks.",
              "Le stick droit bouge encore la caméra pendant que la roue est ouverte. Le stick gauche choisit." },
      apply = function(v) IN.cam_tilt = v end },

    { key = "cam_speed", kind = "float", default = 1.06, min = 0.1, max = 2.0, fmt = "x%.2f",
      label = { "Camera tilt: speed", "Inclinaison de la caméra : vitesse" },
      show = function(v) return v.cam_tilt ~= false end,
      apply = function(v) IN.cam_speed = v end },

    { key = "cam_realtime", kind = "bool", default = true,
      label = { "Camera tilt: normal speed despite the slow-motion", "Inclinaison de la caméra : vitesse normale malgré le ralenti" },
      tip = { "On: the camera turns as fast as usual while time is slowed. Off: it is slowed down with the game.",
              "Coché : la caméra tourne aussi vite que d'habitude pendant le ralenti. Décoché : elle ralentit avec le jeu." },
      show = function(v) return v.cam_tilt ~= false end,
      apply = function(v) IN.cam_realtime = v end },

    { key = "cam_focus", kind = "bool", default = true,
      label = { "Camera looks at the pawn you scroll onto", "La caméra regarde le pion sur lequel on défile" },
      tip = { "Scroll onto a pawn and the camera turns to it; back on the Arisen, or wheel closed, it comes home.",
              "Défile sur un pion et la caméra se tourne vers lui ; de retour sur l'Insurgé, ou roue fermée, elle revient." },
      apply = function(v) Focus.enabled = v end },

    { key = "cam_engine", kind = "choice", default = "native",
      choices = { { value = "native", en = "The game's own camera, moved onto the pawn (default)",
                                      fr = "La caméra du jeu, déplacée sur le pion (défaut)" },
                  { value = "gaze",   en = "Aim the camera at the pawn by hand",
                                      fr = "Viser le pion à la main" } },
      label = { "Camera focus: how the camera changes character", "Focus caméra : comment la caméra change de personnage" },
      tip = { "The game's own camera: the pawn becomes the camera's subject, so the game itself handles the distance,\n"
                  .. "the height, the collision with walls and the easing. Cleanest result, and it needs no settings.\n"
                  .. "By hand: the camera stays the Arisen's and only its aim point is moved onto the pawn. The engine\n"
                  .. "of versions 0.1 to 0.3, kept as a fallback; it is the one that uses the height setting below.",
              "La caméra du jeu : le pion devient le sujet de la caméra, donc le jeu gère lui-même la distance,\n"
                  .. "la hauteur, la collision avec les murs et le lissage. Résultat le plus propre, et aucun réglage.\n"
                  .. "À la main : la caméra reste celle de l'Insurgé et seul son point visé est déplacé sur le pion.\n"
                  .. "C'est le moteur des versions 0.1 à 0.3, gardé en repli ; c'est lui qui utilise la hauteur ci-dessous." },
      show = function(v) return v.cam_focus ~= false end,
      apply = function(v) Focus.engine = (v == "gaze") and 2 or 1 end },

    { key = "cam_snap", kind = "bool", default = false,
      label = { "Camera focus: cut to the pawn instead of gliding", "Focus caméra : couper sur le pion au lieu de glisser" },
      tip = { "Off: the camera travels from one character to the next. On: it cuts, which is instant but abrupt.",
              "Décoché : la caméra voyage d'un personnage à l'autre. Coché : elle coupe, c'est instantané mais sec." },
      show = function(v) return v.cam_focus ~= false and v.cam_engine ~= "gaze" end,
      apply = function(v) Focus.snap = v end },

    { key = "cam_snap_switch", kind = "bool", default = false,
      label = { "Camera focus: cut between characters under slow motion", "Focus caméra : couper entre personnages en ralenti" },
      tip = { "Time is slowed while the wheel is open, so the game's camera glides to the next pawn slowly. On: cut\n"
                  .. "straight to the pawn the moment you select it -- instant, and abrupt. Off (default): keep the\n"
                  .. "game's own travel, even though it is slowed with the world.",
              "Le temps est ralenti quand la roue est ouverte, donc la caméra du jeu glisse lentement vers le pion\n"
                  .. "suivant. Coché : couper directement sur le pion dès qu'on le sélectionne -- instantané, et sec.\n"
                  .. "Décoché (défaut) : garder le voyage de la caméra du jeu, même ralenti avec le monde." },
      show = function(v) return v.cam_focus ~= false and v.cam_engine ~= "gaze" and v.cam_snap ~= true end,
      apply = function(v) Focus.snap_switch = v end },

    { key = "cam_switch_time", kind = "float", default = 0.3, min = 0.10, max = 1.00, fmt = "%.2f s",
      label = { "Camera focus: travel time between characters", "Focus caméra : durée du trajet entre personnages" },
      tip = { "Under slow motion the game's own glide crawls, so the camera's travel to the newly selected character is\n"
                  .. "timed on the real clock instead. Lower = faster. Unaffected by the slow motion.",
              "En ralenti, le glissement natif du jeu se traîne : le trajet vers le personnage sélectionné est donc\n"
                  .. "chronométré en temps réel. Plus bas = plus rapide. Non affecté par le ralenti." },
      show = function(v) return v.cam_focus ~= false and v.cam_engine ~= "gaze" and v.cam_snap ~= true
                                and v.cam_snap_switch ~= true end,
      apply = function(v) Focus.switch_time = v end },

    { key = "cam_dpc_coexist", kind = "bool", default = true,
      label = { "Camera focus: share the camera while playing a pawn",
                "Focus caméra : partager la caméra quand on joue un pion" },
      tip = { "Direct Pawn Control puts the camera on the pawn it plays every frame, and cuts to it whenever anything\n"
                  .. "else moves it. Recent builds can lend the camera out, and then nothing is contested: the game's own\n"
                  .. "camera follows the wheel as usual. On an older build there is no way to ask, so the wheel aims the\n"
                  .. "camera by hand for as long as a pawn is played, which leaves Direct Pawn Control alone. Off: take\n"
                  .. "the camera anyway (expect it to fight back: the view stops following and jumps).",
              "Direct Pawn Control place la caméra sur le pion qu'il joue à chaque image, et coupe dessus dès que\n"
                  .. "quelque chose la déplace. Les versions récentes savent prêter la caméra : plus rien n'est disputé,\n"
                  .. "la caméra du jeu suit la roue normalement. Sur une version plus ancienne, impossible de demander :\n"
                  .. "la roue vise alors la caméra à la main tant qu'un pion est joué, pour laisser DPC tranquille.\n"
                  .. "Décoché : prendre la caméra quand même (elle résistera : le suivi lâche et saute)." },
      show = function(v) return v.cam_focus ~= false and v.cam_engine ~= "gaze" end,
      apply = function(v) Focus.dpc_coexist = v end },

    { key = "cam_focus_height", kind = "float", default = 1.0, min = 0.0, max = 2.5, fmt = "%.2f m",
      label = { "Camera focus: aim height on the pawn", "Focus caméra : hauteur visée sur le pion" },
      tip = { "How high above the pawn's feet the camera aims. 1 m is roughly the chest.\n"
                  .. "Only used when the camera is aimed by hand: the game's own camera knows where its character is.",
              "À quelle hauteur au-dessus des pieds du pion la caméra vise. 1 m, c'est à peu près la poitrine.\n"
                  .. "Utilisé seulement quand la caméra est visée à la main : la caméra du jeu sait où est son personnage." },
      show = function(v) return v.cam_focus ~= false and (v.cam_engine == "gaze" or v.cam_dpc_coexist ~= false) end,
      apply = function(v) Focus.height = v end },

    { key = "cam_focus_dist", kind = "float", default = 0.0, min = 0.0, max = 12.0, fmt = "%.1f m",
      label = { "Camera focus: distance", "Focus caméra : distance" },
      tip = { "How far back the camera is held while looking at a pawn. 0 keeps whatever the game is using.",
              "À quelle distance la caméra se tient quand elle regarde un pion. 0 garde celle du jeu." },
      show = function(v) return v.cam_focus ~= false end,
      apply = function(v) Focus.distance = v end },

    { key = "cam_focus_lift", kind = "float", default = 0.0, min = -2.0, max = 3.0, fmt = "%.2f m",
      label = { "Camera focus: raise the camera", "Focus caméra : élever la caméra" },
      tip = { "Raises the camera itself, which is not the same as aiming higher: this looks down at the pawn.",
              "Élève la caméra elle-même, ce qui n'est pas viser plus haut : là, on regarde le pion de haut." },
      show = function(v) return v.cam_focus ~= false end,
      apply = function(v) Focus.lift = v end },

    { key = "cam_centre", kind = "bool", default = true,
      label = { "Targeting: bring the enemy into frame", "Ciblage : ramener l'ennemi dans le cadre" },
      tip = { "During the targeting step the camera brings the enemy it is on into view. How, see the next setting.",
              "Pendant l'étape de ciblage, la caméra ramène l'ennemi visé dans le champ. Comment : réglage suivant." },
      show = function(v) return v.cam_focus ~= false end,
      apply = function(v) Focus.centre = v end },

    { key = "cam_centre_mode", kind = "choice", default = "aim",
      choices = { { value = "aim", en = "Enemy dead centre, the camera stays on the character (default)",
                    fr = "Ennemi au centre de l'écran, la caméra reste sur le personnage (défaut)" },
                  { value = "between", en = "Between the character and the enemy (experimental)",
                    fr = "Entre le personnage et l'ennemi (expérimental)" } },
      label = { "Targeting: framing the enemy", "Ciblage : cadrage de l'ennemi" },
      tip = { "Between: the camera moves towards a point between the character and the enemy, so both are in frame.\n"
                  .. "Enemy dead centre: the camera does not move off the character; it turns until the enemy sits in\n"
                  .. "the middle of the screen, the character in the foreground. When the targeting step closes, the\n"
                  .. "camera stays turned and is yours again.",
              "Entre les deux : la caméra se déplace vers un point entre le personnage et l'ennemi, pour garder les deux.\n"
                  .. "Ennemi au centre : la caméra ne quitte pas le personnage ; elle tourne jusqu'à ce que l'ennemi soit\n"
                  .. "au milieu de l'écran, le personnage au premier plan. À la fin du ciblage, elle reste tournée et te\n"
                  .. "revient." },
      show = function(v) return v.cam_focus ~= false and v.cam_centre ~= false end,
      apply = function(v) Focus.centre_mode = v end },

    { key = "cam_centre_force", kind = "float", default = 0.45, min = 0.0, max = 1.0, fmt = "%.2f",
      label = { "Targeting: centring strength", "Ciblage : force de centrage" },
      tip = { "0 stays on the character, 1 puts the enemy dead centre. In between, both stay in frame.",
              "0 reste sur le personnage, 1 met l'ennemi pile au centre. Entre les deux, les deux restent dans le cadre." },
      show = function(v) return v.cam_focus ~= false and v.cam_centre ~= false and v.cam_centre_mode ~= "aim" end,
      apply = function(v) Focus.centre_force = v end },

    { key = "filter_enabled", kind = "bool", default = true,
      label = { "Dark filter over the game while the wheel is open", "Filtre sombre sur le jeu pendant que la roue est ouverte" },
      apply = function(v) UI.FILTER.enabled = v end },

    { key = "filter_color", kind = "color", default = 0xFF000000,
      label = { "Filter: colour", "Filtre : couleur" },
      show = function(v) return v.filter_enabled ~= false end,
      apply = function(v) UI.FILTER.rgb = v; UI.FILTER.color = ((UI.FILTER.alpha or 0x59) << 24) | (v & 0x00FFFFFF) end },

    { key = "filter_opacity", kind = "float", default = 0.35, min = 0.0, max = 0.9, fmt = "%.2f",
      label = { "Filter: opacity", "Filtre : opacité" },
      show = function(v) return v.filter_enabled ~= false end,
      apply = function(v)
          UI.FILTER.alpha = math.floor(v * 255 + 0.5)
          UI.FILTER.color = (UI.FILTER.alpha << 24) | ((UI.FILTER.rgb or 0) & 0x00FFFFFF)
      end },

    { key = "filter_vignette", kind = "float", default = 0.55, min = 0.0, max = 1.0, fmt = "%.2f",
      label = { "Filter: darker edges (vignette)", "Filtre : bords assombris (vignette)" },
      tip = { "0 = none. The edges of the screen get darker step by step while the wheel is open.",
              "0 = aucun. Les bords de l'écran s'assombrissent progressivement pendant que la roue est ouverte." },
      show = function(v) return v.filter_enabled ~= false end,
      apply = function(v) UI.FILTER.vig = v end },
    { key = "filter_vignette_size", kind = "float", default = 0.28, min = 0.05, max = 0.5, fmt = "%.2f",
      label = { "Filter: vignette width", "Filtre : largeur de la vignette" },
      show = function(v) return v.filter_enabled ~= false and (v.filter_vignette or 0) > 0 end,
      apply = function(v) UI.FILTER.vig_size = v end },
    { key = "filter_vignette_color", kind = "color", default = 0xFF000000,
      label = { "Filter: vignette colour", "Filtre : couleur de la vignette" },
      show = function(v) return v.filter_enabled ~= false and (v.filter_vignette or 0) > 0 end,
      apply = function(v) UI.FILTER.vig_color = v end },

    ------------------------------------------------------------------ sizes and text
    { key = "hud_scale", kind = "float", default = 1.20, min = 0.5, max = 2.5, fmt = "%.2fx", delay = 0.3,
      label = { "Size of the whole wheel", "Taille globale de la roue" }, reset_label = { "Reset", "Défaut" },
      tip = { "Scales everything on the wheel at once (circle, buttons, texts, pawn row).\nThe key pictures have their own size below.",
              "Agrandit ou réduit toute la roue d'un coup (cercle, boutons, textes, rangée des pions).\nLes touches ont leur propre taille, juste en dessous." },
      apply = function(v) UI.set_scale(v) end },

    { key = "glyph_scale", kind = "float", default = 1.38, min = 0.6, max = 2.5, fmt = "%.2fx", delay = 0.3,
      label = { "Size of the key pictures", "Taille des touches" }, reset_label = { "Reset", "Défaut" },
      tip = { "The pad buttons of the prompt bar and the D-pad of the pawn row. Independent of the size of the wheel.",
              "Les boutons de la manette dans la barre du bas et la croix de la rangée des pions. Indépendante de la taille de la roue." },
      apply = function(v) UI.LOOK.glyph_scale = v end },

    { key = "text_scale", kind = "float", default = 1.0, min = 0.7, max = 1.5, fmt = "x%.2f", delay = 0.3,
      label = { "Size of the texts", "Taille des textes" }, reset_label = { "Reset", "Défaut" },
      tip = { "On top of the size of the wheel: only the texts grow or shrink.", "En plus de la taille de la roue : seuls les textes grossissent ou rétrécissent." },
      apply = function(v) UI.FONT.scale = v end },

    -- same fonts as the user's other mods (0.15: Pagella, the Palatino style; 1.05: the real Palatino Linotype when the
    -- player has copied it, Pagella otherwise -- the Windows font is never shipped)
    { key = "font_face2", kind = "choice", default = "pala.ttf",
      choices = { { value = "auto", en = "Automatic (the game's font if installed, else Pagella)",
                                    fr = "Automatique (police du jeu si installée, sinon Pagella)" },
                  { value = "quadraat", en = "Quadraat, the game's font (personal zip of RPG Level Up)",
                                        fr = "Quadraat, police du jeu (zip PERSO de RPG Level Up)" },
                  { value = "pala.ttf", en = "Palatino Linotype (if copied into reframework/fonts, else Pagella)",
                                        fr = "Palatino Linotype (si copiée dans reframework/fonts, sinon Pagella)" },
                  { value = "TCS_Pagella.ttf", en = "Pagella (Palatino style)",  fr = "Pagella (style Palatino)" },
                  { value = "TCS_Bonum.ttf",   en = "Bonum (Bookman style)",     fr = "Bonum (style Bookman)" },
                  { value = "TCS_Schola.ttf",  en = "Schola (Century style)",    fr = "Schola (style Century)" },
                  { value = "TCS_Caladea.ttf", en = "Caladea",                   fr = "Caladea" },
                  { value = "default",                      en = "GoNoto (REFramework default)",       fr = "GoNoto (défaut de REFramework)" },
                  { value = "TCS_NotoSans.ttf",        en = "Noto Sans (Item Wheel HUD)",         fr = "Noto Sans (Item Wheel HUD)" },
                  { value = "TCS_ZH_Serif.ttf", en = "Chinese serif - 中文衬线 (Noto Serif CJK)",
                                                fr = "Chinois serif - 中文衬线 (Noto Serif CJK)" },        -- 2.22
                  { value = "TCS_ZH_Sans.ttf",  en = "Chinese sans - 中文黑体 (Noto Sans CJK)",
                                                fr = "Chinois sans - 中文黑体 (Noto Sans CJK)" },
                  { value = "TCS_Garamond-SemiBold.ttf",        en = "EB Garamond SemiBold (Item Wheel HUD)", fr = "EB Garamond SemiBold (Item Wheel HUD)" },
                  { value = "D2DX-NotoSansJP.ttf",          en = "Noto Sans JP (D2DX)",                fr = "Noto Sans JP (D2DX)" },
                  { value = "TCS_Inter-SemiBold.otf", en = "Inter SemiBold",                     fr = "Inter SemiBold" },
                  { value = "TCS_Lora-Medium.ttf",    en = "Lora Medium (serif)",                fr = "Lora Medium (serif)" } },
      label = { "Font", "Police d'écriture" },
      tip = { "Font of every text drawn by the wheel. Palatino Linotype is the default: it is a Windows font and cannot be\n"
                  .. "shipped, so copy C:\\Windows\\Fonts\\pala.ttf into reframework\\fonts; until then Pagella (the same style)\n"
                  .. "is used. Quadraat (the font\n"
                  .. "installed in the game by Better UI - Font) is not shipped: on \"Automatic\" it is used when the personal\n"
                  .. "font zip of RPG Level Up is installed, otherwise Pagella. The change shows at the next frame.\n"
                  .. "In a Russian game, Pagella, Bonum, Schola and Caladea (no Cyrillic letters) give way to EB Garamond.",
              "Police de tous les textes de la roue. Palatino Linotype est la police par défaut : c'est une police de Windows,\n"
                  .. "qui ne peut pas être livrée ; copie C:\\Windows\\Fonts\\pala.ttf dans reframework\\fonts. En attendant,\n"
                  .. "Pagella (le même style) est utilisée. Quadraat (la police\n"
                  .. "installée dans le jeu par Better UI - Font) n'est pas livrée : sur « Automatique », elle sert quand le zip\n"
                  .. "PERSO de police de RPG Level Up est installé, sinon Pagella. Le changement apparaît à l'image suivante.\n"
                  .. "Dans un jeu en russe, Pagella, Bonum, Schola et Caladea (sans lettres cyrilliques) laissent la place à EB Garamond." },
      apply = function(v) UI.set_font(v) end },

    ------------------------------------------------------------------ look of the wheel
    { key = "look_tint", kind = "bool", default = true,
      label = { "Tint the wheel with the class colour of the pawn", "Teinter la roue avec la couleur de classe du pion" },
      tip = { "Circle, crescents, highlighted button and pawn bands take the colour of the class.\nOff: neutral bronze for everyone.",
              "Le cercle, les croissants, le bouton survolé et les bandes des pions prennent la couleur de la classe.\nDécoché : bronze neutre pour tout le monde." },
      apply = function(v) UI.LOOK.tint = v end },

    { key = "look_top_row", kind = "bool", default = true,
      label = { "Show the row of characters at the top", "Afficher la rangée des personnages en haut" },
      apply = function(v) UI.LOOK.top_row = v end },

    { key = "look_crescents", kind = "bool", default = true,
      label = { "Show the two side curves", "Afficher les deux courbes latérales" },
      tip = { "One thin gold curve on each side of the wheel.", "Une fine courbe dorée de chaque côté de la roue." },
      apply = function(v) UI.LOOK.crescents = v end },

    { key = "look_center_mode", kind = "choice", default = "bottom",
      choices = { { value = "bottom", en = "Bottom middle: the screen centre stays clear", fr = "En bas au centre : le milieu de l'écran reste libre" },
                  { value = "circle", en = "Big circle in the middle (previous look)", fr = "Grand cercle au milieu (ancien affichage)" } },
      label = { "Name, class and stance: where", "Nom, vocation et posture : où" },
      tip = { "The camera now looks at the pawn, right in the middle of the screen. At the bottom middle, the information sits on a plate between Cancel and Stance, and nothing hides the pawn.",
              "La caméra regarde maintenant le pion, en plein milieu de l'écran. En bas au centre, les infos sont sur une plaque entre Annuler et Posture, et rien ne cache le pion." },
      apply = function(v) UI.LOOK.center_mode = v end },







    { key = "look_plate_offset", kind = "float", default = 100, min = -60, max = 140, fmt = "%.0f px",
      label = { "Name of the character (bottom): height (+ = lower)", "Nom du personnage (en bas) : hauteur (+ = plus bas)" },
      tip = { "Moves the name, the vocation and the hint up or down. The key bar under them moves down with them when needed.",
              "Monte ou descend le nom, la vocation et l'aide. La barre des touches descend avec eux si nécessaire." },
      show = function(v) return v.look_center_mode ~= "circle" end,
      apply = function(v) UI.LOOK.plate_offset = v end },
    { key = "look_center_arisen", kind = "float", default = 0.0, min = 0.0, max = 1.0, fmt = "%.2f",
      label = { "Centre circle on the Arisen: opacity (0 = hidden)", "Cercle central sur l'Insurgé : opacité (0 = masqué)" },
      tip = { "The centre shows information about the pawns; on the Arisen it is hidden by default so you can see your character.",
              "Le centre donne des informations sur les pions ; sur l'Insurgé il est masqué par défaut pour bien voir ton personnage." },
      apply = function(v) UI.LOOK.center_arisen = v end },

    { key = "tgt_solo", kind = "bool", default = true,
      label = { "Targeting: show only the chosen skill", "Ciblage : n'afficher que la compétence choisie" },
      tip = { "During the targeting step every other cell is hidden and the chosen skill glides to the bottom middle of the screen, so the view is clear to aim.",
              "Pendant l'étape de ciblage, toutes les autres cellules sont masquées et la compétence choisie glisse en bas au centre de l'écran : la vue est dégagée pour viser." },
      apply = function(v) UI.LOOK.tgt_solo = v end },

    { key = "tgt_solo_y", kind = "float", default = 0.6, min = 0.40, max = 0.95, fmt = "%.2f",
      label = { "Targeting: height of the chosen skill", "Ciblage : hauteur de la compétence choisie" },
      tip = { "Its place on the screen, from top (0) to bottom (1). 0.70 = 30 % above the bottom edge.",
              "Sa place à l'écran, du haut (0) au bas (1). 0,70 = 30 % au-dessus du bord bas." },
      show = function(v) return v.tgt_solo ~= false end,
      apply = function(v) UI.LOOK.tgt_solo_y = v end },


    { key = "tgt_hide_row", kind = "bool", default = true,
      label = { "Targeting: hide the top row of characters", "Ciblage : masquer la rangée des personnages" },
      tip = { "The row of characters at the top fades out with the wheel while you aim, and comes back when you go back.",
              "La rangée des personnages en haut s'efface avec la roue pendant que tu vises, et revient quand tu fais retour." },
      apply = function(v) UI.LOOK.tgt_hide_row = v end },

    { key = "look_center_fade_ms", kind = "float", default = 150, min = 0, max = 600, fmt = "%.0f ms", round = true,
      label = { "Centre circle: fade when switching character", "Cercle central : fondu au changement de personnage" },
      apply = function(v) UI.LOOK.center_fade_ms = v end },

    { key = "look_carousel_ms", kind = "float", default = 150, min = 0, max = 600, fmt = "%.0f ms", round = true,
      label = { "Top row: slide duration", "Rangée du haut : durée du glissement" },
      tip = { "The shown character is always in the middle of the top row; the bands slide by one place when you switch.",
              "Le personnage affiché est toujours au milieu de la rangée du haut ; les bandes glissent d'un cran quand tu changes." },
      show = function(v) return v.look_top_row ~= false end,
      apply = function(v) UI.LOOK.carousel_ms = v end },

    { key = "look_row_icon_size", kind = "float", default = 0.55, min = 0.4, max = 2.0, fmt = "x%.2f",
      label = { "Top row: size of the character icons", "Rangée du haut : taille des icônes de personnage" },
      show = function(v) return v.look_top_row ~= false end,
      apply = function(v) UI.LOOK.row_icon_size = v end },

    { key = "look_row_sel_scale", kind = "float", default = 2.43, min = 1.0, max = 2.5, fmt = "x%.2f",
      label = { "Top row: enlargement of the selected character", "Rangée du haut : agrandissement du personnage sélectionné" },
      tip = { "1.00 = the selected character's icon is as big as the others.",
              "1,00 = l'icône du personnage sélectionné a la même taille que les autres." },
      show = function(v) return v.look_top_row ~= false end,
      apply = function(v) UI.LOOK.row_sel_scale = v end },

    { key = "look_row_arisen_size", kind = "float", default = 1.0, min = 0.4, max = 2.0, fmt = "x%.2f",
      label = { "Top row: size of the Arisen's icon (heart)", "Rangée du haut : taille de l'icône de l'Insurgé (cœur)" },
      tip = { "On top of the size of all the icons.", "En plus de la taille de toutes les icônes." },
      show = function(v) return v.look_top_row ~= false end,
      apply = function(v) UI.LOOK.row_arisen_size = v end },

    -- hidden by default (they made the confirm button unclear: it is always A); new key, so the old saved
    -- value is not taken over and the wheel starts with them hidden
    { key = "look_slot_keys_shown", kind = "bool", default = true,
      label = { "Arisen: show the game's button of each skill", "Insurgé : afficher le bouton du jeu de chaque compétence" },
      tip = { "X, Y, A, B, X+A, Y+B on the cells: where the skill sits in the game's own shortcuts (information only).",
              "X, Y, A, B, X+A, Y+B sur les cellules : l'emplacement de la compétence dans les raccourcis du jeu (information seulement)." },
      apply = function(v) UI.LOOK.slot_keys = v end },

    { key = "look_slot_keys_size", kind = "float", default = 0.8, min = 0.4, max = 1.6, fmt = "x%.2f",
      label = { "Arisen: size of those buttons", "Insurgé : taille de ces boutons" },
      show = function(v) return v.look_slot_keys_shown == true end,
      apply = function(v) UI.LOOK.slot_keys_size = v end },

    -- stance icons (Stance cell of a pawn and Team Stance cell of the Arisen)
    { key = "look_stance_icons", kind = "bool", default = true,
      label = { "Stance: picture of the stance on the cell", "Posture : image de la posture sur la cellule" },
      tip = { "A gold diamond in the medallion of the Stance cell and of the Team Stance cell, one per stance.",
              "Un losange doré dans le médaillon de la cellule Posture et de la cellule Posture d'équipe, un par posture." },
      apply = function(v) UI.LOOK.stance_icons = v end },
    { key = "look_stance_icon_size", kind = "float", default = 1.0, min = 0.5, max = 1.6, fmt = "x%.2f",
      label = { "Stance: size of that picture", "Posture : taille de cette image" },
      show = function(v) return v.look_stance_icons ~= false end,
      apply = function(v) UI.LOOK.stance_icon_size = v end },
    { key = "look_stance_close_art", kind = "choice", default = "close",
      choices = { { value = "free",  en = "A figure inside a ring", fr = "Une silhouette dans un anneau" },
                  { value = "close", en = "Three figures together", fr = "Trois silhouettes groupées" } },
      label = { "Stance: picture of Escort", "Posture : image d'Escorte" },
      tip = { "Free has no picture at all: nothing was asked of the pawn, so nothing is shown.",
              "Libre n'a aucune image : on n'a rien demandé au pion, donc on n'affiche rien." },
      show = function(v) return v.look_stance_icons ~= false end,
      apply = function(v) UI.LOOK.stance_close_art = v end },

    { key = "look_ring_thin", kind = "bool", default = true,
      label = { "Thin vocation line around the circle", "Fine ligne de vocation autour du cercle" },
      tip = { "A thin line in the class colour instead of the old ring gauge. Off: no line at all.",
              "Une fine ligne de la couleur de classe au lieu de l'ancien anneau-jauge. Décoché : aucune ligne." },
      apply = function(v) UI.LOOK.ring_thin = v end },

    { key = "look_cell_style", kind = "choice", default = "soph",
      choices = { { value = "open",    en = "Modern (gold lines that fade away from the centre)", fr = "Moderne (liserés dorés qui s'estompent vers l'extérieur)" },
                  { value = "soph",    en = "Minimalist (metal plates, soft smoke)",             fr = "Minimaliste (plaques de métal, fumée légère)" },
                  { value = "fan",     en = "Cards (skill cards along the bottom)",              fr = "Cartes (cartes de compétences en bas de l'écran)" },
                  { value = "classic", en = "Framed cells (previous look)",                      fr = "Cellules encadrées (ancien affichage)" } },
      label = { "Style of the wheel", "Style de la roue" },
      tip = { "Modern: cells, ring, outer lines and character cards drawn with gold lines that fade away. Framed: the previous look, with the shape below.",
              "Moderne : cellules, anneau, lignes externes et cartes des personnages en liserés dorés qui s'estompent. Encadré : l'ancien affichage, avec la forme ci-dessous." },
      apply = function(v) UI.LOOK.cell_style = v end },
    { key = "look_soph_smoke", kind = "float", default = 1.0, min = 0, max = 1.5, fmt = "%.2f",
      label = { "Minimalist: smoke intensity (0 = none)", "Minimaliste : intensité de la fumée (0 = aucune)" },
      show = function(v) return v.look_cell_style == "soph" end,
      apply = function(v) UI.LOOK.soph_smoke = v end },
    { key = "look_atb_style", kind = "bool", default = true,
      label = { "ATB Combat System style when the ATB Combat System is on (big gauge, queue)", "Style ATB Combat System quand l'ATB Combat System est actif (grande jauge, file)" },
      tip = { "The wheel shows a big ATB gauge with the order queue sitting on its segments. The ATB Combat System hides its own gauges while the wheel is open.",
              "La roue affiche une grande jauge ATB, avec la file d'ordres posée sur ses segments. L'ATB Combat System masque ses propres jauges pendant que la roue est ouverte." },
      apply = function(v) UI.LOOK.atb_style = v; WLOOK.style = (v ~= false) end },
    { key = "look_atb_x", kind = "float", default = 272, min = 0, max = 1500, fmt = "%.0f px",
      label = { "ATB Combat System style: left end of the gauge", "Style ATB Combat System : bout gauche de la jauge" },
      tip = { "The gauge grows to the right with every extra segment.", "La jauge s'allonge vers la droite à chaque segment en plus." },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_x = v end },
    { key = "look_atb_y", kind = "float", default = 785, min = 300, max = 1040, fmt = "%.0f px",
      label = { "ATB Combat System style: gauge height on screen (+ = lower)", "Style ATB Combat System : hauteur de la jauge à l'écran (+ = plus bas)" },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_y = v end },
    { key = "look_atb_seg", kind = "float", default = 223, min = 80, max = 500, fmt = "%.0f px",
      label = { "ATB Combat System style: length of one segment", "Style ATB Combat System : longueur d'un segment" },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_seg = v end },
    { key = "look_atb_shape", kind = "choice", default = "slant",          -- 1.51: kept after all
      choices = { { value = "slant",    en = "Slanted blades", fr = "Lames inclinées" },
                  { value = "straight", en = "Straight",       fr = "Droits" } },
      label = { "ATB Combat System style: shape of the segments", "Style ATB Combat System : forme des segments" },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_shape = v end },
    { key = "look_atb_h", kind = "float", default = 24, min = 4, max = 60, fmt = "%.0f px",
      label = { "ATB Combat System style: gauge thickness", "Style ATB Combat System : épaisseur de la jauge" },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_h = v end },
    { key = "look_atb_shade_size", kind = "float", default = 1.0, min = 0, max = 2.5, fmt = "%.2f",
      label = { "ATB Combat System style: size of the dark area behind the gauge (0 = none)", "Style ATB Combat System : taille de la zone assombrie derrière la jauge (0 = aucune)" },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_shade_size = v end },
    { key = "look_atb_shade_op", kind = "float", default = 0.72, min = 0, max = 1.6, fmt = "%.2f",
      label = { "ATB Combat System style: darkness of that area", "Style ATB Combat System : intensité de cette zone assombrie" },
      show = function(v) return v.look_atb_style ~= false and (v.look_atb_shade_size or 1) > 0 end, apply = function(v) UI.LOOK.atb_shade_op = v end },
    { key = "look_atb_native", kind = "bool", default = false,
      label = { "ATB Combat System style: gauge drawn by the ATB Combat System (the very same as at the bottom of the screen)", "Style ATB Combat System : jauge dessinée par l'ATB Combat System (exactement la même qu'en bas de l'écran)" },
      tip = { "Same renderer, colours, liquid, reflections and light as the ATB Combat System's gauge (ATB Combat System 0.39 or later). The segments are then straight, and the dark area behind the gauge is not drawn. Untick for the wheel's own gauge (slanted blades, colours below).",
              "Même rendu, couleurs, liquide, reflets et lumière que la jauge de l'ATB Combat System (ATB Combat System 0.39 ou plus). Les segments sont alors droits, et la zone assombrie derrière la jauge n'est pas dessinée. Décocher pour la jauge propre à la roue (lames inclinées, couleurs ci-dessous)." },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_native = v; WLOOK.native = (v ~= false) end },
    { key = "look_atb_col_link", kind = "bool", default = true,
      label = { "ATB Combat System style: same colours as the ATB Combat System gauge", "Style ATB Combat System : mêmes couleurs que la jauge de l'ATB Combat System" },
      tip = { "The wheel's gauge follows the colours chosen in the ATB Combat System (its colour presets included). Untick to choose them below.",
              "La jauge de la roue suit les couleurs choisies dans l'ATB Combat System (ses presets de couleurs compris). Décocher pour les choisir ci-dessous." },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_col_link = v; WLOOK.col_link = (v ~= false) end },
    { key = "look_atb_col_fill", kind = "color", default = 0xFFFF8D5C,
      label = { "ATB Combat System style: colour of the full segments", "Style ATB Combat System : couleur des segments pleins" },
      show = function(v) return v.look_atb_style ~= false and v.look_atb_col_link == false end, apply = function(v) UI.LOOK.atb_col_fill = v end },
    { key = "look_atb_col_part", kind = "color", default = 0xFFC76E48,
      label = { "ATB Combat System style: colour of the segment being filled", "Style ATB Combat System : couleur du segment en cours de remplissage" },
      show = function(v) return v.look_atb_style ~= false and v.look_atb_col_link == false end, apply = function(v) UI.LOOK.atb_col_part = v end },
    { key = "look_atb_col_empty", kind = "color", default = 0xFF080C0F,
      label = { "ATB Combat System style: colour of the empty segments", "Style ATB Combat System : couleur des segments vides" },
      show = function(v) return v.look_atb_style ~= false and v.look_atb_col_link == false end, apply = function(v) UI.LOOK.atb_col_empty = v end },
    { key = "look_atb_col_edge", kind = "color", default = 0xFF58B3D9,
      label = { "ATB Combat System style: colour of the outline", "Style ATB Combat System : couleur du contour" },
      show = function(v) return v.look_atb_style ~= false and v.look_atb_col_link == false end, apply = function(v) UI.LOOK.atb_col_edge = v end },
    { key = "look_atb_col_text", kind = "color", default = 0xFF897463,
      label = { "ATB Combat System style: colour of the value (x / n)", "Style ATB Combat System : couleur de la valeur (x / n)" },
      show = function(v) return v.look_atb_style ~= false end, apply = function(v) UI.LOOK.atb_col_text = v end },
    { key = "look_sel_tint", kind = "bool", default = true,
      label = { "Tint the chosen cell and card with the vocation's colour", "Teinter la cellule et la carte choisies à la couleur de la vocation" },
      show = function(v) return v.look_cell_style ~= "classic" end,
      apply = function(v) UI.LOOK.sel_tint = v end },
    { key = "look_cell_shape", kind = "choice", default = "hex",
      choices = { { value = "hex",     en = "Hexagon (pointed ends)",      fr = "Hexagone (bouts pointus)" },
                  { value = "spear",   en = "Spear (long points)",         fr = "Lance (pointes longues)" },
                  { value = "chamfer", en = "Cut corners",                 fr = "Coins coupés" },
                  { value = "rect",    en = "Rectangle",                   fr = "Rectangle" },
                  { value = "pill",    en = "Rounded ends",                fr = "Bouts arrondis" } },
      label = { "Shape of the cells (framed style, and the order message)", "Forme des cellules (style encadré, et message d'ordre)" },
      tip = { "Also used by the message shown when an order is given.", "Utilisée aussi par le message affiché quand un ordre est donné." },
      apply = function(v) UI.LOOK.cell_shape = v end },

    { key = "look_dpad_hint", kind = "choice", default = "arrow",
      choices = { { value = "arrow",     en = "Small arrow beside the D-pad", fr = "Petite flèche à côté de la croix" },
                  { value = "highlight", en = "White highlight on the D-pad arm", fr = "Surbrillance blanche de la branche" },
                  { value = "both",      en = "Arrow and highlight",             fr = "Flèche et surbrillance" },
                  { value = "none",      en = "D-pad only",                      fr = "Croix seule" } },
      label = { "Pawn row: direction marker on the D-pad", "Rangée des pions : repère de direction sur la croix" },
      tip = { "Left and right of the pawn row, the D-pad picture (or the button really bound) shows how to switch pawn.",
              "À gauche et à droite de la rangée des pions, l'image de la croix (ou la touche réellement assignée) montre comment changer de pion." },
      show = function(v) return v.look_top_row ~= false end,
      apply = function(v) UI.LOOK.dpad_hint = v end },

    { key = "look_dpad_size", kind = "float", default = 1.0, min = 0.5, max = 2.0, fmt = "x%.2f",
      label = { "Pawn row: size of the D-pad", "Rangée des pions : taille de la croix" },
      tip = { "Relative to the size of the key pictures.", "Par rapport à la taille des touches." },
      show = function(v) return v.look_top_row ~= false end,
      apply = function(v) UI.LOOK.dpad_size = v end },

    ------------------------------------------------------------------ position of the cells (design pixels)
    { key = "pos_skill_gap", kind = "float", default = 36, min = 0, max = 90, fmt = "%.0f px", round = true, reset_label = { "Reset", "Défaut" },
      label = { "Skills: space between cells", "Compétences : écart entre les cellules" },
      tip = { "Vertical space between the 3 skills of each side.", "Espace vertical entre les 3 compétences de chaque côté." },
      apply = function(v) UI.POS.skill_gap = v end },

    { key = "pos_skill_dist", kind = "float", default = 12, min = -60, max = 250, fmt = "%.0f px", round = true, reset_label = { "Reset", "Défaut" },
      label = { "Skills: distance from the circle", "Compétences : distance au cercle" },
      tip = { "Moves both skill columns away from the circle (negative = closer).", "Écarte les deux colonnes de compétences du cercle (négatif = plus près)." },
      apply = function(v) UI.POS.skill_dist = v end },

    { key = "pos_skill_mid_dx", kind = "float", default = 0, min = -200, max = 200, fmt = "%.0f px", round = true, reset_label = { "Reset", "Défaut" },
      label = { "Skills: middle cells, sideways", "Compétences : cellules du milieu, horizontal" },
      tip = { "Moves the middle cell of each column sideways, both sides mirrored. Positive = out towards the screen edges, negative = in towards the centre.",
              "Décale la cellule du milieu de chaque colonne sur le côté, en miroir des deux côtés. Positif = vers les bords de l'écran, négatif = vers le centre." },
      apply = function(v) UI.POS.skill_mid_dx = v end },

    { key = "pos_skill_dy", kind = "float", default = 0, min = -200, max = 200, fmt = "%.0f px", round = true, reset_label = { "Reset", "Défaut" },
      label = { "Skills: height", "Compétences : hauteur" },
      tip = { "Negative = higher, positive = lower. Cancel and Stance follow.", "Négatif = plus haut, positif = plus bas. Annuler et Posture suivent." },
      apply = function(v) UI.POS.skill_dy = v end },

    { key = "pos_skill_w", kind = "float", default = 1.0, min = 0.7, max = 1.4, fmt = "x%.2f", reset_label = { "Reset", "Défaut" },
      label = { "Skills: width", "Compétences : largeur" },
      tip = { "The cells grow outwards; the side next to the circle stays put.", "Les cellules s'élargissent vers l'extérieur ; le côté près du cercle ne bouge pas." },
      apply = function(v) UI.POS.skill_w = v end },

    { key = "pos_corner_dx", kind = "float", default = 312, min = 150, max = 700, fmt = "%.0f px", round = true, reset_label = { "Reset", "Défaut" },
      label = { "Cancel / Stance: distance from the middle", "Annuler / Posture : écart depuis le milieu" },
      tip = { "Distance between the vertical axis of the wheel and the centre of each cell.",
              "Distance entre l'axe vertical de la roue et le centre de chaque cellule." },
      apply = function(v) UI.POS.corner_dx = v end },

    { key = "pos_corner_dy", kind = "float", default = 0, min = -150, max = 250, fmt = "%.0f px", round = true, reset_label = { "Reset", "Défaut" },
      label = { "Cancel / Stance: height", "Annuler / Posture : hauteur" },
      tip = { "From their place under the skills. Negative = higher, positive = lower.",
              "À partir de leur place sous les compétences. Négatif = plus haut, positif = plus bas." },
      apply = function(v) UI.POS.corner_dy = v end },

    { key = "pos_corner_w", kind = "float", default = 1.0, min = 0.6, max = 1.6, fmt = "x%.2f", reset_label = { "Reset", "Défaut" },
      label = { "Cancel / Stance: width", "Annuler / Posture : largeur" },
      apply = function(v) UI.POS.corner_w = v end },

    ------------------------------------------------------------------ vocation icon (centre of the wheel)
    { key = "vocation_icon", kind = "bool", default = true,
      label = { "Show the vocation icon of the pawn", "Afficher l'icône de vocation du pion" },
      tip = { "The class emblem in the medallion on top of the central circle. Needs D2DX / reframework-d2d.",
              "L'emblème de la classe dans le médaillon en haut du cercle central. Nécessite D2DX / reframework-d2d." },
      apply = function(v) UI.VOC.enabled = v end },

    { key = "vocation_name", kind = "bool", default = true,
      label = { "Show the class name above the pawn name", "Afficher le nom de la classe au-dessus du prénom" },
      apply = function(v) UI.VOC.show_name = v end },

    { key = "vocation_size", kind = "float", default = 1.0, min = 0.5, max = 1.6, fmt = "x%.2f",
      label = { "Vocation icon: size", "Icône de vocation : taille" },
      tip = { "The icon keeps its own proportions; this scales its height.", "L'icône garde ses proportions ; ceci règle sa hauteur." },
      show = function(v) return v.vocation_icon ~= false end,
      apply = function(v) UI.VOC.size = v end },

    { key = "vocation_dx", kind = "float", default = 0, min = -60, max = 60, fmt = "%.0f", round = true,
      label = { "Vocation icon: horizontal offset (px)", "Icône de vocation : décalage horizontal (px)" },
      show = function(v) return v.vocation_icon ~= false end,
      apply = function(v) UI.VOC.dx = v end },

    { key = "vocation_dy", kind = "float", default = 0, min = -40, max = 40, fmt = "%.0f", round = true,
      label = { "Vocation icon: vertical offset (px)", "Icône de vocation : décalage vertical (px)" },
      show = function(v) return v.vocation_icon ~= false end,
      apply = function(v) UI.VOC.dy = v end },

    { key = "vocation_opacity", kind = "float", default = 0.94, min = 0.1, max = 1.0, fmt = "%.2f",
      label = { "Vocation icon: opacity", "Icône de vocation : opacité" },
      show = function(v) return v.vocation_icon ~= false end,
      apply = function(v) UI.VOC.opacity = v end },

    ------------------------------------------------------------------ 2.30: pawns without an order
    { key = "auto_charge", kind = "bool", default = false,
      label = { "Warrior pawns charge their skills fully", "Les pions guerriers chargent leurs compétences à fond" },
      tip = { "Without any order, a Warrior pawn starting a chargeable skill on its own is held to the full charge\n"
                  .. "(silver glow) before releasing it, with the same timing as an order from the wheel.\n"
                  .. "In Bloodied Pact phase 2 the charge is almost instant, so it is released almost at once.\n"
                  .. "The pawn you play yourself is never affected.",
              "Sans aucun ordre, un pion guerrier qui lance de lui-même une compétence chargeable la garde jusqu'à la\n"
                  .. "charge complète (lueur argentée) avant de la libérer, au même moment qu'un ordre de la roue.\n"
                  .. "En phase 2 du Pacte de sang, la charge est presque instantanée : elle part presque tout de suite.\n"
                  .. "Le pion que vous jouez vous-même n'est jamais concerné." },
      apply = function(v) AI.auto.charge = v end },

    { key = "auto_shield_off", kind = "bool", default = false,
      label = { "Fighter pawns put Shield Precision away after the fight", "Les pions combattants coupent Shield Precision après le combat" },
      tip = { "A Fighter pawn keeps Shield Precision on once the fight is over. With this ticked, the mod switches it off\n"
                  .. "after 20 seconds without any blow exchanged between your party and an enemy.\n"
                  .. "The Cancel cell of the wheel switches it off at any time, ticked or not.",
              "Un pion combattant garde Shield Precision active une fois le combat fini. Coché, le mod la coupe après\n"
                  .. "20 secondes sans aucun coup échangé entre votre groupe et un ennemi.\n"
                  .. "La cellule Annuler de la roue la coupe à tout moment, coché ou non." },
      apply = function(v) AI.auto.shield_off = v; Vision.want_blows = v end },

    ------------------------------------------------------------------ targeting
    { key = "target_default", kind = "choice", default = "near",
      choices = { { value = "near",   en = "The closest in metres (default)", fr = "La plus proche en mètres (défaut)" },
                  { value = "centre", en = "The closest to the centre of the screen", fr = "La plus au centre de l'écran" } },
      label = { "Targeting: enemy offered first", "Ciblage : ennemi proposé en premier" },
      tip = { "Which enemy the targeting step highlights before you step left or right.\n"
                  .. "The closest in metres: the one physically nearest, wherever you happen to be looking.\n"
                  .. "The closest to the centre of the screen: the one you are aiming at, which suits picking a target\n"
                  .. "out of a group by turning the camera. Only enemies on screen can be judged that way, so when none\n"
                  .. "of them is on screen the closest in metres is offered instead.",
              "Quel ennemi l'étape de ciblage met en avant avant que tu ne passes à gauche ou à droite.\n"
                  .. "La plus proche en mètres : la cible physiquement la plus proche, où que tu regardes.\n"
                  .. "La plus au centre de l'écran : celle que tu vises, pratique pour choisir une cible dans un groupe\n"
                  .. "en tournant la caméra. Seuls les ennemis à l'écran peuvent être jugés ainsi : si aucun n'est à\n"
                  .. "l'écran, la plus proche en mètres est proposée à la place." },
      apply = function(v) TGT.default_pick = v end },

    { key = "target_range", kind = "float", default = 35.0, min = 5, max = 80, fmt = "%.0f m",
      label = { "Targeting: range (m)", "Ciblage : portée (m)" },
      tip = { "The targeting step offers the living enemies within this distance of the Arisen.\n"
                  .. "When the chosen enemy is gone before the order leaves, the nearest one within this range takes its place.",
              "L'étape de ciblage propose les ennemis vivants à cette distance de l'Insurgé au plus.\n"
                  .. "Si l'ennemi choisi disparaît avant que l'ordre parte, le plus proche dans cette portée le remplace." },
      apply = function(v) TGT.range = v end },

    ------------------------------------------------------------------ 1.13: realistic targeting
    { key = "vis_on", kind = "bool", default = true,
      label = { "Realistic targeting: only what the party can see", "Ciblage réaliste : seulement ce que le groupe voit" },
      tip = { "The targeting step only offers enemies in front of the camera that you or one of your pawns can see:\n"
                  .. "not through walls, and only a few metres away by night. Half hidden behind a tree is still fine.",
              "L'étape de ciblage ne propose que les ennemis devant la caméra que toi ou un de tes pions voyez :\n"
                  .. "pas à travers les murs, et à quelques mètres seulement la nuit. À moitié caché derrière un arbre, ça passe." },
      apply = function(v) Vision.on = v end },
    { key = "vis_front", kind = "bool", default = true,
      label = { "Realistic targeting: only in front of the camera", "Ciblage réaliste : seulement devant la caméra" },
      tip = { "Enemies behind you are not offered.", "Les ennemis dans ton dos ne sont pas proposés." },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.front = v end },
    { key = "vis_front_angle", kind = "float", default = 100, min = 45, max = 180, fmt = "%.0f°",
      label = { "Realistic targeting: field of view, each side (degrees)", "Ciblage réaliste : champ de vision, de chaque côté (degrés)" },
      tip = { "90 = an exact half circle in front of the camera; a little more gives some margin on the sides.",
              "90 = un demi-cercle exact devant la caméra ; un peu plus laisse de la marge sur les côtés." },
      show = function(v) return v.vis_on ~= false and v.vis_front ~= false end,
      apply = function(v) Vision.front_angle = v end },
    { key = "vis_walls", kind = "bool", default = true,
      label = { "Realistic targeting: walls hide enemies", "Ciblage réaliste : les murs cachent les ennemis" },
      tip = { "Five sight rays go to each enemy (feet, waist, head, both sides); one clear ray is enough to target it.",
              "Cinq rayons de vue partent vers chaque ennemi (pieds, taille, tête, deux côtés) ; un seul dégagé suffit pour le cibler." },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.walls = v end },
    { key = "vis_dark_range", kind = "float", default = 4.0, min = 1, max = 30, fmt = "%.1f m",
      label = { "Realistic targeting: sight by night, lantern off (m)", "Ciblage réaliste : vue la nuit, lanterne éteinte (m)" },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.dark_range = v end },
    { key = "vis_lamp_range", kind = "float", default = 8.0, min = 1, max = 40, fmt = "%.1f m",
      label = { "Realistic targeting: sight by night, lantern lit (m)", "Ciblage réaliste : vue la nuit, lanterne allumée (m)" },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.lamp_range = v end },
    { key = "vis_ceiling", kind = "bool", default = true,
      label = { "Realistic targeting: under a ceiling counts as night", "Ciblage réaliste : sous un plafond, comme la nuit" },
      tip = { "Caves, and buildings too: a roof above the Arisen's head brings the night sight.",
              "Les grottes, et aussi les bâtiments : un toit au-dessus de la tête de l'Insurgé donne la vue de nuit." },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.ceiling = v end },
    { key = "vis_pawns", kind = "bool", default = true,
      label = { "Realistic targeting: pawns see for you", "Ciblage réaliste : les pions voient pour toi" },
      tip = { "An enemy one of your pawns can see is targetable. A fallen pawn stops seeing 3 seconds after it falls.",
              "Un ennemi qu'un de tes pions voit est ciblable. Un pion tombé cesse de voir 3 secondes après sa chute." },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.pawns = v end },
    { key = "vis_close", kind = "float", default = 2.0, min = 0, max = 6, fmt = "%.1f m",
      label = { "Realistic targeting: always targetable this close (m)", "Ciblage réaliste : toujours ciblable à moins de (m)" },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.close = v end },
    { key = "vis_memory", kind = "float", default = 2.5, min = 0, max = 6, fmt = "%.1f s",
      label = { "Realistic targeting: an enemy seen stays targetable (s)", "Ciblage réaliste : un ennemi vu reste ciblable (s)" },
      tip = { "So the list does not flicker when a monster passes behind a pillar.",
              "Pour que la liste ne clignote pas quand un monstre passe derrière un pilier." },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.memory = v end },
    { key = "vis_engage", kind = "bool", default = true,
      label = { "Realistic targeting: engagement (blows traded or wheel pick)", "Ciblage réaliste : engagement (coups échangés ou choix dans la roue)" },
      tip = { "An enemy that struck the party, was struck by it, or was picked in the wheel can be targeted in the dark and stays targetable behind a wall until the delay below runs out. An enemy that only spotted you is not engaged.",
              "Un ennemi qui a frappé le groupe, a été frappé par lui, ou a été choisi dans la roue reste ciblable dans le noir, et derrière un mur jusqu'à la fin du délai ci-dessous. Un ennemi qui vous a seulement repéré n'est pas engagé." },
      show = function(v) return v.vis_on ~= false end,
      apply = function(v) Vision.engage = v end },
    { key = "vis_engage_lose", kind = "float", default = 5.0, min = 1, max = 15, fmt = "%.0f s",
      label = { "Realistic targeting: engagement lost after (s) without sight nor blow", "Ciblage réaliste : engagement perdu après (s) sans vue ni coup" },
      show = function(v) return v.vis_on ~= false and v.vis_engage ~= false end,
      apply = function(v) Vision.engage_lose = v end },

    ------------------------------------------------------------------ keyboard and mouse
    { key = "mouse_mode", kind = "bool", default = true,
      label = { "Keyboard and mouse: mouse mode (hover and click on the cells)", "Clavier-souris : mode souris (survol et clic sur les cellules)" },
      tip = { "Opened from the keyboard (or once the mouse moves), the wheel shows a cursor: the cell under it is selected,\n"
                  .. "a click gives the order, the camera stays still and the key bar shows the keyboard and mouse keys.\n"
                  .. "As soon as the pad is used, the wheel goes back to pad mode (stick, pad buttons).",
              "Ouverte au clavier (ou dès que la souris bouge), la roue affiche un curseur : la cellule survolée est choisie,\n"
                  .. "un clic donne l'ordre, la caméra ne bouge plus et la barre d'aide montre les touches clavier-souris.\n"
                  .. "Dès que la manette sert, la roue repasse en mode manette (stick, boutons de manette)." },
      apply = function(v) IN.mouse_mode = v end },
    { key = "mouse_speed", kind = "float", default = 1.0, min = 0.1, max = 6.0, fmt = "x%.2f",      -- 1.38: wider range
      label = { "Keyboard and mouse: cursor speed", "Clavier-souris : vitesse du curseur" },
      tip = { "How far the wheel's cursor moves for a given mouse movement.", "Distance parcourue par le curseur de la roue pour un même geste de la souris." },
      show = function(v) return v.mouse_mode ~= false end,
      apply = function(v) IN.mouse_speed = v end },
    { key = "mouse_margin", kind = "float", default = 6, min = 0, max = 30, fmt = "%.0f px",
      label = { "Keyboard and mouse: extra hover zone around each cell", "Clavier-souris : zone de survol en plus autour de chaque cellule" },
      show = function(v) return v.mouse_mode ~= false end,
      apply = function(v) IN.mouse_margin = v end },
    -- 1.15: new key, off by default (the 1.14 key "mouse_follow" was saved on in some configs and is left unread)
    { key = "mouse_follow_pointer", kind = "bool", default = false,
      label = { "Keyboard and mouse: put the cursor on the system pointer when it is free",
                "Clavier-souris : placer le curseur sur le pointeur du système quand il est libre" },
      tip = { "Off (default): the mod's cursor is independent, it moves with your mouse and never jumps.\n"
                  .. "On: when the system pointer is free (a menu has it), the cursor sits right on it.",
              "Décoché (défaut) : le curseur du mod est indépendant, il suit ta souris et ne saute jamais.\n"
                  .. "Coché : quand le pointeur du système est libre (un menu l'a), le curseur se place exactement dessus." },
      show = function(v) return v.mouse_mode ~= false end,
      apply = function(v) IN.mouse_follow = v end },
    { key = "mouse_cursor_show", kind = "bool", default = true,
      label = { "Keyboard and mouse: show the mod's cursor (a dot on the mouse)", "Clavier-souris : afficher le curseur du mod (un point sur la souris)" },
      tip = { "Off: nothing is drawn, the cells still react when the mouse is over them.",
              "Décoché : rien n'est dessiné, les cellules réagissent quand même au survol de la souris." },
      show = function(v) return v.mouse_mode ~= false end,
      apply = function(v) IN.mouse_show = v end },
    { key = "mouse_cursor_color", kind = "color", default = 0xFF090915,
      label = { "Keyboard and mouse: cursor colour", "Clavier-souris : couleur du curseur" },
      show = function(v) return v.mouse_mode ~= false and v.mouse_cursor_show ~= false end,
      apply = function(v) UI.CURSOR_COLOR = v end },
    { key = "mouse_cursor_opacity", kind = "float", default = 1.0, min = 0.0, max = 1.0, fmt = "%.2f",
      label = { "Keyboard and mouse: cursor opacity", "Clavier-souris : opacité du curseur" },
      tip = { "How see-through the mod's cursor is (1.00 = fully opaque). It applies to the whole dot: its colour, its outline and its centre.",
              "Transparence du curseur du mod (1.00 = totalement opaque). Elle s'applique à tout le point : sa couleur, son contour et son centre." },
      show = function(v) return v.mouse_mode ~= false and v.mouse_cursor_show ~= false end,
      apply = function(v) UI.CURSOR_OPACITY = v end },

    ------------------------------------------------------------------ Arisen: spell target
    { key = "arisen_magic_hold", kind = "bool", default = true,
      label = { "Mage / Sorcerer: the wheel's target is the spell's starting target",
                "Mage / Sorcier : la cible de la roue est la cible de départ du sort" },
      tip = { "The spell has its own targeting. With this on, the target picked in the wheel is held while the spell is cast,\n"
                  .. "then the game's own targeting is free again once the spell has left.",
              "Le sort a son propre ciblage. Coché, la cible choisie dans la roue est maintenue pendant l'incantation,\n"
                  .. "puis le ciblage du jeu redevient libre une fois le sort parti." },
      apply = function(v) AR.CFG.magic_hold = v end },
    { key = "arisen_magic_hold_max", kind = "float", default = 2.0, min = 1.0, max = 8.0, fmt = "%.1f s",
      label = { "Mage / Sorcerer: longest hold of the target", "Mage / Sorcier : maintien maximal de la cible" },
      show = function(v) return v.arisen_magic_hold ~= false end,
      apply = function(v) AR.CFG.magic_hold_max = v end },

    { key = "arisen_lock_mode", kind = "choice", default = 1,
      choices = { { value = 1, en = "Lock on, and give the game its own back", fr = "Verrouiller, puis rendre le sien au jeu" },
                  { value = 2, en = "Lock on and leave it",                    fr = "Verrouiller et laisser" },
                  { value = 3, en = "Point the target out only",               fr = "Signaler la cible seulement" },
                  { value = 4, en = "Do not lock on (just turn the Arisen)",   fr = "Ne pas verrouiller (juste orienter l'Insurgé)" } },
      label = { "Arisen: how the target is given to the game", "Insurgé : comment la cible est donnée au jeu" },
      tip = { "Locking on points the game's camera at the enemy, which can pull it away from a pawn you are looking at. Set it to the last choice if the camera fights you.",
              "Le verrouillage oriente la caméra du jeu vers l'ennemi, ce qui peut l'arracher au pion que tu regardes. Mets le dernier choix si la caméra se bat contre toi." },
      apply = function(v) AR.CFG.lock_mode = v end },

    ------------------------------------------------------------------ Arisen: weapon sheathed
    { key = "arisen_draw", kind = "bool", default = true,
      label = { "Weapon sheathed: draw it, then launch the skill", "Arme rengainée : dégainer puis lancer la compétence" },
      tip = { "With the weapon sheathed, the game often only draws it and the skill is lost.\n"
                  .. "With this on, the same skill is launched again as soon as the weapon is drawn (once per choice).",
              "Arme rengainée, le jeu se contente souvent de dégainer et la compétence est perdue.\n"
                  .. "Coché, la même compétence est relancée dès que l'arme est dégainée (une seule fois par choix)." },
      apply = function(v) AR.CFG.draw_relaunch = v end },
    { key = "arisen_draw_wait", kind = "float", default = 2.0, min = 0.5, max = 4.0, fmt = "%.1f s",
      label = { "Weapon sheathed: longest wait for the draw", "Arme rengainée : attente maximale du dégainage" },
      tip = { "Past this delay without a skill, nothing is launched again.",
              "Passé ce délai sans compétence, rien n'est relancé." },
      show = function(v) return v.arisen_draw ~= false end,
      apply = function(v) AR.CFG.draw_wait = v end },

    { key = "line_enabled", kind = "bool", default = true,
      label = { "Targeting: curved line to the enemy", "Ciblage : ligne courbe vers l'ennemi" },
      tip = { "From the character who receives the order (the Arisen or the pawn) to the chosen enemy.",
              "Du personnage qui reçoit l'ordre (l'Insurgé ou le pion) jusqu'à l'ennemi choisi." },
      apply = function(v) UI.LINE.enabled = v end },

    { key = "line_color", kind = "color", default = 0xE692CEF3,
      label = { "Line: colour", "Ligne : couleur" },
      show = function(v) return v.line_enabled ~= false end,
      apply = function(v) UI.LINE.color = v end },

    { key = "line_opacity", kind = "float", default = 1.0, min = 0.1, max = 1.0, fmt = "%.2f",    -- 1.45
      label = { "Line: opacity", "Ligne : opacité" },
      show = function(v) return v.line_enabled ~= false end,
      apply = function(v) UI.LINE.opacity = v end },

    -- 1.45: per-look settings of the aim line
    { key = "line_breath_wave", kind = "float", default = 0.18, min = 0.06, max = 0.40, fmt = "%.2f",
      label = { "Breathing thread: width of the wave", "Fil qui respire : largeur de la vague" },
      show = function(v) return v.line_enabled ~= false and v.line_style == "breath" end,
      apply = function(v) UI.LINE.breath_wave = v end },
    { key = "line_breath_glow", kind = "float", default = 0.5, min = 0.0, max = 1.0, fmt = "%.2f",
      label = { "Breathing thread: strength of the breath", "Fil qui respire : force de la respiration" },
      show = function(v) return v.line_enabled ~= false and v.line_style == "breath" end,
      apply = function(v) UI.LINE.breath_glow = v end },
    { key = "line_arrow_width", kind = "float", default = 3, min = 1, max = 12, fmt = "%.0f px", round = true,
      label = { "Archer's shot: thickness", "Trait d'archer : épaisseur" },
      show = function(v) return v.line_enabled ~= false and v.line_style == "arrow" end,
      apply = function(v) UI.LINE.arrow_width = v end },
    { key = "line_arrow_head", kind = "float", default = 1.0, min = 0.5, max = 2.5, fmt = "x%.2f",
      label = { "Archer's shot: size of the point", "Trait d'archer : taille de la pointe" },
      show = function(v) return v.line_enabled ~= false and v.line_style == "arrow" end,
      apply = function(v) UI.LINE.arrow_head = v end },

    { key = "line_width", kind = "float", default = 3, min = 1, max = 12, fmt = "%.0f px", round = true,
      label = { "Thickness (comet, breathing thread)", "Épaisseur (comète, fil qui respire)" },
      show = function(v) return v.line_enabled ~= false and v.line_style ~= "arrow" end,
      apply = function(v) UI.LINE.width = v end },

    { key = "line_curve", kind = "float", default = 0.2, min = -0.6, max = 0.6, fmt = "%.2f",
      label = { "Line: curve (0 = straight)", "Ligne : courbure (0 = droite)" },
      show = function(v) return v.line_enabled ~= false end,
      apply = function(v) UI.LINE.curve = v end },

    -- 1.38: the dashed line is replaced by a thin line and a comet running to the enemy
    { key = "line_style", kind = "choice", default = "comet",
      choices = { { value = "comet",  en = "Comet (a light runs to the enemy)",          fr = "Comète (une lumière court vers l'ennemi)" },
                  { value = "breath", en = "Breathing thread (waves of light)",          fr = "Fil qui respire (vagues de lumière)" },
                  { value = "arrow",  en = "Archer's shot (fletching and point)",        fr = "Trait d'archer (empennage et pointe)" } },
      label = { "Line: look", "Ligne : apparence" },
      show = function(v) return v.line_enabled ~= false end,
      apply = function(v) UI.LINE.style = v end },

    { key = "line_comet_speed", kind = "float", default = 1.0, min = 0.3, max = 3.0, fmt = "x%.2f",
      label = { "Rhythm (speed of the light)", "Rythme (vitesse de la lumière)" },
      show = function(v) return v.line_enabled ~= false and v.line_style ~= "arrow" end,
      apply = function(v) UI.LINE.comet_speed = v end },

    { key = "line_outline", kind = "bool", default = true,
      label = { "Line: dark outline", "Ligne : contour sombre" },
      show = function(v) return v.line_enabled ~= false end,
      apply = function(v) UI.LINE.outline = v end },

    { key = "marker_closed", kind = "bool", default = false,
      label = { "Keep the target marker when the wheel is closed", "Garder le marqueur de cible roue fermée" },
      apply = function(v) TGT.marker_closed = v end },

    { key = "marker_seconds", kind = "float", default = 3.0, min = 0, max = 30, fmt = "%.1f s",
      label = { "Marker: seconds shown after the wheel closes", "Marqueur : secondes affichées après la fermeture" },
      show = function(v) return not v.marker_closed end,
      apply = function(v) TGT.marker_seconds = v end },

    -- 1.38: three looks for the chosen enemy's marker
    { key = "marker_style", kind = "choice", default = "life",       -- 2.14: Line + HP by default (BardN's settings)
      choices = { { value = "arcs",  en = "Target",    fr = "Cible" },          -- 1.50: same names as the buttons
                  { value = "glow",  en = "Diamond",   fr = "Losange" },
                  { value = "line",  en = "Line",      fr = "Liseré" },
                  { value = "life",  en = "Line + HP", fr = "Liseré + PV" } },
      label = { "Marker: look", "Marqueur : apparence" },
      apply = function(v) TGT.marker_style = v end },

    { key = "marker_size", kind = "float", default = 1.0, min = 0.3, max = 3.0, fmt = "x%.2f",
      label = { "Marker: size", "Marqueur : taille" },
      apply = function(v) TGT.marker_size = v end },

    { key = "marker_opacity", kind = "float", default = 1.0, min = 0.1, max = 1.0, fmt = "%.2f",
      label = { "Marker: opacity", "Marqueur : opacité" },
      apply = function(v) TGT.marker_opacity = v end },

    -- 1.45: colour and rhythm of the marker, colours of the life bar (« Line + HP »)
    { key = "marker_color", kind = "color", default = 0xFF92CEF3,
      label = { "Marker: colour", "Marqueur : couleur" },
      apply = function(v) TGT.marker_color = v end },
    { key = "marker_speed", kind = "float", default = 1.0, min = 0.0, max = 3.0, fmt = "x%.2f",
      label = { "Marker: rhythm (turning arcs)", "Marqueur : rythme (arcs qui tournent)" },
      show = function(v) return (v.marker_style or "line") == "arcs" end,
      apply = function(v) TGT.marker_speed = v end },
    { key = "marker_hp_color", kind = "color", default = 0xFF763C8C,
      label = { "Line + HP: colour of the life bar", "Liseré + PV : couleur de la barre de vie" },
      tip = { "By default the game's own enemy life bar: magenta, with a pink band and a white core.",
              "Par défaut, la barre de vie des ennemis du jeu : magenta, avec une bande rose et un cœur blanc." },
      show = function(v) return v.marker_style == "life" end,
      apply = function(v) TGT.hp_color = v end },
    { key = "marker_hp_core", kind = "color", default = 0xFFF6F6F6,
      label = { "Line + HP: core of the life bar", "Liseré + PV : cœur de la barre de vie" },
      show = function(v) return v.marker_style == "life" end,
      apply = function(v) TGT.hp_core = v end },

    ------------------------------------------------------------------ status lamp (skill cells)
    { key = "lamp_enabled", kind = "bool", default = true,
      label = { "Status lamp on skill cells (green = may cast by itself, dark = manual only)",
                "Voyant sur les cellules de compétence (vert = peut la lancer seul, noir = manuel seul)" },
      apply = function(v) LAMP.enabled = v end },

    { key = "lamp_off", kind = "bool", default = true,
      label = { "Show the dark lamp when locked", "Afficher le voyant éteint quand c'est verrouillé" },
      show = function(v) return v.lamp_enabled ~= false end,
      apply = function(v) LAMP.show_off = v end },

    { key = "lamp_size", kind = "float", default = 1.0, min = 0.4, max = 3.0, fmt = "x%.2f",
      label = { "Lamp: size", "Voyant : taille" },
      show = function(v) return v.lamp_enabled ~= false end,
      apply = function(v) LAMP.size = v end },

    { key = "lamp_glow", kind = "float", default = 1.0, min = 0.0, max = 3.0, fmt = "%.2f",
      label = { "Lamp: glow", "Voyant : intensité du halo" },
      show = function(v) return v.lamp_enabled ~= false end,
      apply = function(v) LAMP.glow = v end },

    { key = "lamp_opacity", kind = "float", default = 1.0, min = 0.1, max = 1.0, fmt = "%.2f",
      label = { "Lamp: opacity", "Voyant : opacité" },
      show = function(v) return v.lamp_enabled ~= false end,
      apply = function(v) LAMP.opacity = v end },

    { key = "lamp_dx", kind = "float", default = 0.0, min = -60, max = 60, fmt = "%.0f",
      label = { "Lamp: horizontal offset (px)", "Voyant : décalage horizontal (px)" },
      show = function(v) return v.lamp_enabled ~= false end,
      apply = function(v) LAMP.dx = v end },

    { key = "lamp_dy", kind = "float", default = 0.0, min = -30, max = 30, fmt = "%.0f",
      label = { "Lamp: vertical offset (px)", "Voyant : décalage vertical (px)" },
      show = function(v) return v.lamp_enabled ~= false end,
      apply = function(v) LAMP.dy = v end },

    ------------------------------------------------------------------ manual-only lock (internals)
    { key = "lock_enforce", kind = "bool", default = true,
      label = { "Lock: write the AI flags", "Verrou : poser les drapeaux d'IA" },
      apply = function(v) LOCKCFG.enforce = v end },

    { key = "lock_hook", kind = "bool", default = true,
      label = { "Lock: also refuse the skill itself (second safety)", "Verrou : refuser aussi la compétence elle-même (double sécurité)" },
      apply = function(v) LOCKCFG.hook = v end },

    { key = "lock_log", kind = "bool", default = true,
      label = { "Lock: trace what locked pawns run", "Verrou : tracer ce que les pions verrouillés exécutent" },
      apply = function(v) LOCKCFG.log = v end },

    ------------------------------------------------------------------ advanced
    { key = "profiler", kind = "bool", default = false,
      label = { "Profiler", "Profileur" },
      tip = { "Time spent in each module's update(), averaged per frame over 1 second.\n"
                  .. "Peak is the slowest single run since the last reset. Timer resolution is about 1 ms.",
              "Temps passé dans update() de chaque module, moyenné par image sur 1 seconde.\n"
                  .. "Le pic est l'exécution la plus lente depuis la dernière remise à zéro. Résolution du chronomètre : environ 1 ms." },
      apply = function(v) if S.hooks.profiler then S.hooks.profiler(v) end end },
}

S.BY_KEY = {}
for _, def in ipairs(S.LIST) do S.BY_KEY[def.key] = def end

return S
