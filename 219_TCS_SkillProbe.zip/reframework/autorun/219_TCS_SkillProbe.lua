-- 219_TCS_SkillProbe - a logging script for Tactical Command System (BardN)
-- It only READS the game and writes a text file. It changes nothing in the game and it is safe to remove at any time.
-- What it records:
--   1) the actions of the Arisen and of your pawns (name + how long the previous one lasted + stamina),
--      so the mod can learn the charge / quick / full action names of the chargeable Warrior skills;
--   2) the values of the character that may hold the "enough blood to awaken" state of Blood Pact.
-- Log file: <game folder>\reframework\data\219_TCS_SkillProbe_log.txt

local VERSION = "219"
local LOG_FILE = "219_TCS_SkillProbe_log.txt"
local KEYS = { "blood", "scarlet", "vow", "awake", "awaken", "loss", "gore", "stain", "splat", "rage", "frenzy", "berserk" }
local NUM = { ["System.Single"] = true, ["System.Double"] = true, ["System.Int32"] = true, ["System.UInt32"] = true,
              ["System.Int16"] = true, ["System.Byte"] = true, ["System.Boolean"] = true }
local MAX_WATCH = 150

local cfg = { on = true, actions = true, values = true, skills_only = true }
local lines, buf, last_flush, t0 = {}, {}, 0, os.clock()
local prev_act, watch, scanned, found_total = {}, {}, {}, 0

local function stamp() return string.format("%8.2f", os.clock() - t0) end
local function push(s)
    lines[#lines + 1] = s
    if #lines > 40 then table.remove(lines, 1) end
    buf[#buf + 1] = s
end
local function flush()
    if #buf == 0 then return end
    local f = io.open(LOG_FILE, "a")
    if f then f:write(table.concat(buf, "\n"), "\n"); f:close() end
    buf = {}
end
local function matches(name)
    local low = tostring(name):lower()
    for _, k in ipairs(KEYS) do if low:find(k, 1, true) then return true end end
    return false
end

local function characters()
    local out = {}
    pcall(function()
        local p = sdk.get_managed_singleton("app.CharacterManager"):call("get_ManualPlayer")
        if p then out[#out + 1] = { key = "Arisen", chara = p } end
    end)
    pcall(function()
        local pm = sdk.get_managed_singleton("app.PawnManager")
        local list = pm:call("get_PartyPawnList")
        local n = tonumber(list:call("get_Count")) or 0
        for i = 0, math.min(n, 3) - 1 do
            local h = list:call("get_Item", i)
            local c = h and h:call("get_CachedCharacter")
            if c then out[#out + 1] = { key = "Pawn" .. (i + 1), chara = c } end
        end
    end)
    return out
end

----------------------------------------------------------------------------------------------------
-- 1) actions
----------------------------------------------------------------------------------------------------
local function job_of(chara)
    local ok, j = pcall(function() return chara:get_field("WeaponJob") end)
    return ok and tonumber(j) or nil
end
local function stamina_of(chara)
    local ok, v = pcall(function()
        local sc = chara:call("get_StaminaManager")
        return string.format("%.0f/%.0f", sc:call("get_RemainingAmount"), sc:call("get_MaxValue"))
    end)
    return ok and v or "?"
end
local function stack_of(chara)
    local names = {}
    pcall(function()
        local list = chara["<ActionManager>k__BackingField"].CurrentActionList
        local n = math.min(list:call("get_Count"), 4)
        for i = 0, n - 1 do
            local ok, a = pcall(function() return list[i].Name end)
            names[#names + 1] = ok and a and tostring(a) or "nil"
        end
    end)
    return names
end
local function interesting(names)
    if not cfg.skills_only then return true end
    for _, a in ipairs(names) do
        if a:find("Job", 1, true) or a:find("Skill", 1, true) or a:find("Charge", 1, true) then return true end
    end
    return false
end
local function step_actions(c, now)
    local names = stack_of(c.chara)
    local sig = table.concat(names, " | ")
    local p = prev_act[c.key]
    if not p or p.sig ~= sig then
        local is = interesting(names)
        if is or (p and p.interesting) then
            push(string.format("%s  %-7s job%s  stam %s  (prev %s s)  %s", stamp(), c.key,
                tostring(job_of(c.chara) or "?"), stamina_of(c.chara),
                p and string.format("%.2f", now - p.t) or "-", sig))
        end
        prev_act[c.key] = { sig = sig, t = now, interesting = is }
    end
end

----------------------------------------------------------------------------------------------------
-- 2) values that may hold the Blood Pact state
----------------------------------------------------------------------------------------------------
local function add_fields(list, obj, td, prefix, depth)
    local seen = 0
    while td and seen < 6 and #list < MAX_WATCH do
        seen = seen + 1
        local tname = td:get_full_name() or "?"
        local type_hit = matches(tname)
        for _, f in ipairs(td:get_fields() or {}) do
            if #list >= MAX_WATCH then break end
            pcall(function()
                if f:is_static() then return end
                local fname = f:get_name() or "?"
                local ftype = f:get_type()
                local ftn = ftype and ftype:get_full_name() or "?"
                if NUM[ftn] and (type_hit or matches(fname)) then
                    list[#list + 1] = { label = prefix .. tname .. "." .. fname, read = function() return f:get_data(obj) end }
                elseif depth > 0 and not NUM[ftn] and (matches(fname) or matches(ftn)) then
                    local sub = f:get_data(obj)
                    if sub and type(sub) == "userdata" and sub.get_type_definition then
                        add_fields(list, sub, sub:get_type_definition(), prefix .. fname .. " > ", depth - 1)
                    end
                end
            end)
        end
        if type_hit then
            for _, m in ipairs(td:get_methods() or {}) do
                if #list >= MAX_WATCH then break end
                pcall(function()
                    local mn = m:get_name() or ""
                    if mn:sub(1, 4) == "get_" and m:get_num_params() == 0 then
                        local rt = m:get_return_type()
                        if rt and NUM[rt:get_full_name()] then
                            list[#list + 1] = { label = prefix .. tname .. "." .. mn .. "()", read = function() return m:call(obj) end }
                        end
                    end
                end)
            end
        end
        td = td:get_parent_type()
    end
end

local function scan(c)
    local list, chara = {}, c.chara
    pcall(function() add_fields(list, chara, chara:get_type_definition(), "Chara: ", 2) end)
    pcall(function()
        local human = chara:call("get_Human")
        if human then add_fields(list, human, human:get_type_definition(), "Human: ", 2) end
    end)
    -- the job (vocation) side: this is where a Warrior-only gauge would live
    for _, getter in ipairs({ "get_JobContext", "get_HumanJobContext", "get_JobController", "get_SkillController" }) do
        pcall(function()
            local o = chara:call(getter)
            if o then add_fields(list, o, o:get_type_definition(), getter:sub(5) .. ": ", 2) end
        end)
    end
    pcall(function()
        local go = chara:call("get_GameObject")
        local comps = go:call("get_Components")
        local n
        pcall(function() n = comps:get_size() end)
        for i = 0, (n or 0) - 1 do
            if #list >= MAX_WATCH then break end
            local comp
            pcall(function() comp = comps:get_element(i) end)
            if comp then
                local td = comp:get_type_definition()
                local tn = td and td:get_full_name() or ""
                if matches(tn) or tn:find("Job05", 1, true) then add_fields(list, comp, td, "Comp: ", 2)
                else add_fields(list, comp, td, "Comp: ", 0) end
            end
        end
    end)
    watch[c.key] = list
    found_total = found_total + #list
    push(string.format("%s  ===== %s: %d values to watch =====", stamp(), c.key, #list))
    for _, w in ipairs(list) do push("            . " .. w.label) end
end

local function fmt(v)
    if type(v) == "number" then return string.format("%.3f", v) end
    return tostring(v)
end
local function step_values(c)
    local addr = c.chara:get_address()
    if scanned[c.key] ~= addr then scanned[c.key] = addr; scan(c) end
    for _, w in ipairs(watch[c.key] or {}) do
        local ok, v = pcall(w.read)
        if ok then
            local changed
            if type(v) == "number" and type(w.last) == "number" then changed = math.abs(v - w.last) >= 0.01
            else changed = (v ~= w.last) end
            if changed then
                if w.last ~= nil then
                    push(string.format("%s  %-7s VALUE  %s = %s (was %s)", stamp(), c.key, w.label, fmt(v), fmt(w.last)))
                end
                w.last = v
            end
        end
    end
end

local next_a, next_b = 0, 0
re.on_frame(function()
    if not cfg.on then return end
    local now = os.clock()
    local do_a = cfg.actions and now >= next_a
    local do_b = cfg.values and now >= next_b
    if not (do_a or do_b) then return end
    if do_a then next_a = now + 0.05 end
    if do_b then next_b = now + 0.25 end
    for _, c in ipairs(characters()) do
        if do_a then pcall(step_actions, c, now) end
        if do_b then pcall(step_values, c) end
    end
    if now - last_flush > 1.0 then flush(); last_flush = now end
end)

local function mark(txt) push(stamp() .. "  ##### " .. txt .. " #####") end

re.on_draw_ui(function()
    if not imgui.tree_node("219_TCS_SkillProbe v" .. VERSION) then return end
    local _, v = imgui.checkbox("Recording", cfg.on); cfg.on = v
    _, v = imgui.checkbox("Record actions", cfg.actions); cfg.actions = v
    _, v = imgui.checkbox("Record values (Blood Pact)", cfg.values); cfg.values = v
    imgui.text("Values watched: " .. found_total)
    imgui.separator()
    imgui.text("Press a button below just BEFORE you do the matching step:")
    if imgui.button("1 - Charged Warrior skill") then mark("1 - charged Warrior skill") end
    if imgui.button("2 - Shield Precision ON") then mark("2 - Shield Precision ON") end
    imgui.same_line()
    if imgui.button("3 - Stamina ran out") then mark("3 - stamina ran out") end
    if imgui.button("4 - Blood Pact ON") then mark("4 - Blood Pact ON") end
    imgui.same_line()
    if imgui.button("5 - Awakening looks possible") then mark("5 - awakening looks possible") end
    imgui.same_line()
    if imgui.button("6 - Awakening done") then mark("6 - awakening done") end
    imgui.separator()
    if imgui.button("Save log now") then flush() end
    imgui.same_line()
    if imgui.button("Clear log") then
        lines, buf, prev_act, watch, scanned, found_total = {}, {}, {}, {}, {}, 0
        local f = io.open(LOG_FILE, "w"); if f then f:close() end
        t0 = os.clock()
        push(stamp() .. "  ##### log cleared #####")
    end
    imgui.text("File: reframework/data/" .. LOG_FILE)
    imgui.separator()
    for i = #lines, 1, -1 do imgui.text(lines[i]) end
    imgui.tree_pop()
end)

re.on_script_reset(flush)
push(stamp() .. "  ##### session start, probe v" .. VERSION .. " #####")
