-- TacticalCommandSystem/cmd/guards.lua
-- The fence around a running order.
--
-- Nothing in the game knows an order is running, so everything carries on as if the pawn were free: its AI asks for a
-- different action, the blackboard is handed another pack, a skill is refused because the pawn would not normally use
-- it there. Left alone, an ordered skill is interrupted a frame after it starts.
--
-- So the engine sits on four of the game's own calls and, only while an order is running and only for the pawn running
-- it, turns a few of them away:
--
--   action requests  -- the ones that would cut the skill short, and everything at all for a pawn told to hold still
--   pack requests    -- another pack pushed at a pawn that has its own thinking back mid-skill
--   charge time      -- read, not blocked: it is how the engine learns how long a spell really takes
--   skill allowed    -- forced through for a launch stance, refused for a skill locked to manual only
--   target filters   -- the pawn's AI is allowed to consider the enemy the player picked, and no other
--
-- Everything here must be cheap: the action hook fires for every character on screen, hundreds of times a second. The
-- first thing each one does is a single table lookup, and a pawn the engine is not looking after costs nothing more.
-- Each hook body also runs inside a pcall: a hook that raises inside the game's own call stack is a crash.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local API = require("TacticalCommandSystem.api")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local P = require("TacticalCommandSystem.cmd.posture")
local Roster = require("TacticalCommandSystem.cmd.roster")
local Issue = require("TacticalCommandSystem.cmd.issue")
local Manual = require("TacticalCommandSystem.cmd.manual")

local G = {}

local SKIP = sdk.PreHookResult and sdk.PreHookResult.SKIP_ORIGINAL or nil

local function action_name(arg)
    local str = U.safe_managed_arg(arg)
    local name = str and U.safe_call(function() return str:call("ToString") end)
    return name and tostring(name) or "?"
end

----------------------------------------------------------------------------------------------------
-- action requests
----------------------------------------------------------------------------------------------------
-- A pawn told to hold still: everything but resting and reacting to a hit is turned away.
local function fence_waiter(name)
    if D.IDLE_LAYERS[name] or name:find("Idle", 1, true) then return nil end
    if P.hurt_name(name:lower()) then return nil end
    return SKIP
end

-- A pawn running an order of its own accord (its AI is doing the aiming).
local function fence_thinking_order(run, name, prio)
    local low = name:lower()
    local ours = P.mentions(low, run.keys)

    -- a stocked spell is a different skill with a similar name: never the one that was ordered
    if name:find("SpellStock", 1, true) and not ours then return SKIP end

    -- between the skill starting and it reaching the ready, the pawn's own AI will happily cancel it
    if run.at_begin and not run.at_ready and not run.casting and D.CANCEL_NODES[name]
        and (prio == 10 or D.CANCEL_ANY_PRIO[name]) then
        return SKIP
    end
    return nil
end

-- A pawn running an order that was pushed onto it.
local function fence_pushed_order(run, name, prio)
    local low = name:lower()
    local ours = P.mentions(low, run.keys)

    -- a spell already leaving the pawn's hands is held for as long as the skill says
    if run.casting then
        local ord = D.ORDERS[run.skill]
        local hold = ord and ord.hold_cast
        if hold and (U.game_now() - run.at_cast < hold) and D.CANCEL_NODES[name] then return SKIP end
        return nil
    end

    -- once the skill is under way, no other skill may start in front of it
    if run.at_begin and name:find("Prepare", 1, true) and P.is_skill_name(name) and not ours then return SKIP end
    if name:find("SpellStock", 1, true) and not ours then return SKIP end

    local cuts = D.CANCEL_NODES[name]
    if prio ~= 10 and not D.CANCEL_ANY_PRIO[name] then cuts = nil end
    if cuts == nil then return nil end

    -- `true` means it cuts the skill at any point; anything else only before the skill has started
    if cuts == true or not run.at_begin then return SKIP end
    return nil
end

-- These hooks run for every character, often several times a frame. Most of the time no order is running: that case
-- leaves straight away, before any closure or pcall is made.
local function on_action_request(args)
    if Issue.ours or not Roster.anyone_engaged() then return end
    local ok, verdict = pcall(function()
        if not args or not args[2] then return nil end
        local actions_addr = sdk.to_int64(args[2])

        local waiter = Roster.waiter_by_actions(actions_addr)
        if waiter then return fence_waiter(action_name(args[4])) end

        local run = Roster.run_by_actions(actions_addr)
        if not run then return nil end

        local prio = args[3] and (sdk.to_int64(args[3]) & 0xFFFFFFFF) or 0
        local name = action_name(args[4])

        -- the pawn asking for the skill itself is how the engine knows the order was heard
        if not run.seen_request and P.mentions(name:lower(), run.keys) then
            run.seen_request = true
        end

        -- 2.13: ordered quick: the charged release is turned away
        if run.quick then
            local ord = D.ORDERS[run.skill]
            if ord and ord.full and name == ord.full.full then return SKIP end
        end

        -- 2.25: ordered charged: the quick release is turned away for as long as the charge is being forced
        if run.full then
            local ord = D.ORDERS[run.skill]
            if ord and ord.full and name == ord.full.normal then return SKIP end
        end

        if run.mode == "brain" then return fence_thinking_order(run, name, prio) end
        return fence_pushed_order(run, name, prio)
    end)
    if ok and verdict then return verdict end
end

----------------------------------------------------------------------------------------------------
-- pack requests
----------------------------------------------------------------------------------------------------
local function on_pack_request(args)
    if Issue.ours or not Roster.anyone_engaged() then return end
    local ok, verdict = pcall(function()
        if not args or not args[2] then return nil end

        local run = Roster.run_by_board(sdk.to_int64(args[2]))
        -- only matters for a pushed order that has its thinking back and has not started casting yet
        if not run or run.casting or run.mode == "brain" or not run.thinking then return nil end

        local pack = args[3] and sdk.to_int64(args[3]) or 0
        if pack == 0 or pack == run.pack_addr then return nil end
        return SKIP
    end)
    if ok and verdict then return verdict end
end

----------------------------------------------------------------------------------------------------
-- how long a spell takes to charge
----------------------------------------------------------------------------------------------------
-- the hook storage lives as long as the thread: it is cleared on every call, or the after-hook would read a stale one
local function before_prepare_time(args)
    local ok, store = pcall(thread.get_hook_storage)
    if ok and store then store.tc_prepare_this = Roster.anyone_engaged() and args[2] or nil end
end

local function after_prepare_time(retval)
    local ok, store = pcall(thread.get_hook_storage)
    local this = ok and store and store.tc_prepare_this
    if not this then return retval end
    pcall(function()
        local obj = U.safe_managed_arg(this)
        local human = obj and obj:get_field("Human")
        if not U.is_valid_obj(human) then return end
        local run = Roster.run_by_human(human:get_address())
        if run and not run.casting and not run.at_ready then
            run.prep = sdk.to_float(retval)
        end
    end)
    return retval
end

----------------------------------------------------------------------------------------------------
-- may this pawn use this skill
----------------------------------------------------------------------------------------------------
local function before_skill_allowed(args)
    local okst, store = pcall(thread.get_hook_storage)
    if not okst or not store then return end
    store.tc_force_yes = nil
    store.tc_force_no = nil
    -- nothing locked and nothing ordered: the game decides alone
    if not next(U.LOCKS) and not Roster.anyone_engaged() then return end
    pcall(function()
        if not args or not args[3] then return end

        local skill_id = sdk.to_int64(args[3]) & 0xFFFFFFFF
        if next(U.LOCKS) and D.ORDERS[skill_id] and Manual.vetoes(args[2], skill_id) then
            store.tc_force_no = true
            return
        end

        if not Roster.anyone_engaged() then return end
        local ord = D.ORDERS[skill_id]
        local run = ord and ord.stance and Roster.run_by_skill(skill_id)
        if not run then return end

        -- forced through only if the ATB module, when installed, agrees the pawn can pay for it
        local pawn = run.chara
        if pawn == nil or API.atb_affordable(pawn, skill_id) then
            store.tc_force_yes = sdk.to_ptr(true)
        end
    end)
end

local function after_skill_allowed(retval)
    local ok, store = pcall(thread.get_hook_storage)
    if not ok or not store then return retval end
    if store.tc_force_no then return sdk.to_ptr(false) end
    return store.tc_force_yes or retval
end

----------------------------------------------------------------------------------------------------
-- the enemy the pawn's AI is allowed to consider
----------------------------------------------------------------------------------------------------
-- The pawn's AI weighs each candidate target in turn. While an order is running through the pawn's own head, every
-- candidate but the one the player picked is answered "no", so the AI aims where it was told without the engine having
-- to aim for it.
local function is_the_chosen_one(run, node_ptr)
    if not run or run.mode ~= "brain" then return true end
    if not run.target_addr or run.target_addr == 0 then return true end

    local node = U.safe_managed_arg(node_ptr)
    if not node then return true end

    local owner = U.safe_call(function() return node:get_field(S.F.at_owner_ch) end)
        or U.safe_call(function() return node:get_field(S.F.at_chara) end)
    if U.is_valid_obj(owner) then
        return owner:get_address() == run.target_addr
    end

    if run.target_go_addr and run.target_go_addr ~= 0 then
        local go = U.safe_call(function() return node:get_field(S.F.at_owner) end)
            or U.safe_call(function() return node:get_field(S.F.at_go) end)
        if U.is_valid_obj(go) then
            return go:get_address() == run.target_go_addr
        end
    end
    return true
end

local function before_target_filter(args)
    if not Roster.anyone_engaged() then return end
    local ok, turn_away = pcall(function()
        if not args or not args[3] or not args[4] then return false end

        local run = Roster.run_by_board(sdk.to_int64(args[3]))
        if run and run.mode == "brain" and not is_the_chosen_one(run, args[4]) then
            thread.get_hook_storage().tc_refuse_target = true
            return true
        end
        return false
    end)
    if ok and turn_away then return SKIP end
end

local function after_target_filter(retval)
    local ok, store = pcall(thread.get_hook_storage)
    if ok and store and store.tc_refuse_target then
        store.tc_refuse_target = nil
        return sdk.to_ptr(false)
    end
    return retval
end

----------------------------------------------------------------------------------------------------
-- putting them on
----------------------------------------------------------------------------------------------------
local function keep(ret) return ret end

function G.install()
    pcall(function()
        if S.M.request_action then
            sdk.hook(S.M.request_action, on_action_request, keep)
        end
        if S.M.request_pack then
            sdk.hook(S.M.request_pack, on_pack_request, keep)
        end
        if S.M.prepare_secs then
            sdk.hook(S.M.prepare_secs, before_prepare_time, after_prepare_time)
        end
        if S.M.skill_allowed then
            sdk.hook(S.M.skill_allowed, before_skill_allowed, after_skill_allowed)
        end
        for _, m in ipairs(S.M.target_filters) do
            sdk.hook(m, before_target_filter, after_target_filter)
        end
    end)
end

return G
