-- TacticalCommandSystem/cmd/aim.lua
-- Who an order is aimed at, and how that enemy is handed to the pawn's AI.
--
-- The wheel picks the enemy itself, in its own targeting step, so there is no standing "current target" the engine has
-- to keep in step with the fight: each order carries the enemy it was given. What is kept here is the last one aimed at,
-- which the wheel draws a marker on, and the fallback when the chosen enemy dies before the order leaves.
--
-- Handing the enemy over is the fiddly part. A pawn's AI aims at an "AI target" node, and a large enemy has several:
-- its feet, which is where the root sits, and the body parts worth hitting. The pawn's own blackboard already holds
-- those nodes, so the highest one it knows about is preferred, and a plain node built from the character is only the
-- fallback for enemies it holds nothing for.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")

local A = {}

-- the game's own signature for "the AI target nodes you hold, of this kind"; 8 = the hostile ones
local NODES_OF_KIND =
    "getTargetsOfType(app.AIDecisionDefine.AITargetFlag, app.ActionTargetUniqueTypeFlag, app.AIDecisionDefine.AIPositionFlag)"
local HOSTILE_NODES = 8

local last_aimed = nil            -- { chara, addr, name, dist, auto } : only for the marker the wheel draws

----------------------------------------------------------------------------------------------------
-- choosing an enemy
----------------------------------------------------------------------------------------------------
-- The living enemy closest to `from` that is still inside the wheel's targeting range of the player.
function A.nearest(from)
    local player = U.get_player()
    local eye = (U.is_valid_obj(from) and from) or player
    if not U.is_valid_obj(eye) then return nil end

    local reach = U.TGT.range or 45.0
    local pick, pick_dist
    for _, enemy in ipairs(U.alive_enemies()) do
        local ok_near, near = pcall(U.distance, eye, enemy)
        local ok_far, from_player = pcall(U.distance, player, enemy)
        if ok_near and near and ok_far and from_player and from_player <= reach then
            if not pick_dist or near < pick_dist then pick, pick_dist = enemy, near end
        end
    end
    if not pick then return nil end

    return {
        chara = pick,
        addr  = U.safe_call(function() return pick:get_address() end),
        name  = U.upper(U.enemy_name(pick)),
        dist  = pick_dist,
        auto  = true,
    }
end

-- The enemy an order should go out on: the one chosen in the targeting step while it is still alive, else the nearest.
function A.settle(skill_id, chosen, pawn)
    if not A.needs_enemy(skill_id) then return nil end
    if chosen and U.is_valid_obj(chosen.chara) and not U.is_dead(chosen.chara) then return chosen end
    return A.nearest(pawn)
end

function A.needs_enemy(skill_id)
    local ord = D.ORDERS[skill_id]
    return ord ~= nil and ord.target == "enemy" and not ord.stance
end

-- 1.06: an order is refused for want of an enemy only if the player has not marked the skill "without targeting".
-- Marked, it still goes out on the nearest enemy when there is one (A.settle), and on the pawn itself when there is
-- none: so it can be ordered anytime, outside combat too.
local SH = require("TacticalCommandSystem.in.shared")
function A.must_have_enemy(skill_id)
    if not A.needs_enemy(skill_id) then return false end
    local IN = SH.IN
    if IN and IN.is_no_target and IN.is_no_target(skill_id) then return false end
    return true
end

-- the targeting step always finds something to aim at, so no cell is ever greyed out for want of a target
function A.always_available()
    return true
end

----------------------------------------------------------------------------------------------------
-- the marker the wheel draws
----------------------------------------------------------------------------------------------------
function A.remember(entry)
    last_aimed = entry
end

function A.recall()
    if not last_aimed then return nil end
    if not U.is_valid_obj(last_aimed.chara) or U.is_dead(last_aimed.chara) then
        last_aimed = nil
        return nil
    end
    return last_aimed
end

function A.clear()
    last_aimed = nil
end

----------------------------------------------------------------------------------------------------
-- handing the enemy to a pawn's AI
----------------------------------------------------------------------------------------------------
-- the highest node this pawn's blackboard holds for `target`, which is a body part rather than the ground
local function known_node(pawn, target)
    local best, best_height
    pcall(function()
        local board = pawn:get_AIBlackBoardController()
        if not board then return end
        local wanted = target:get_address()
        local nodes = board:call(NODES_OF_KIND, HOSTILE_NODES, 0, 0)
        if not nodes then return end
        local count = tonumber(nodes:call("get_Count")) or 0
        for i = 0, count - 1 do
            local node = nodes:call("get_Item", i)
            if node then
                local owner = U.safe_call(function() return node:get_field(S.F.at_owner_ch) end)
                    or U.safe_call(function() return node:get_field(S.F.at_chara) end)
                if U.is_valid_obj(owner) and owner:get_address() == wanted then
                    local height = 0
                    pcall(function()
                        local where = node:get_field(S.F.at_transform)
                        local pos = where and where:call("get_Position")
                        if pos and type(pos.y) == "number" then height = pos.y end
                    end)
                    if not best or height > best_height then best, best_height = node, height end
                end
            end
        end
    end)
    return best
end

-- a node of our own, for an enemy the pawn holds nothing for
local function built_node(target)
    local node = sdk.create_instance(S.T.ai_target, true)
    if not node then return nil end
    node[S.F.at_go]       = target:get_GameObject()
    node[S.F.at_chara]    = target
    node[S.F.at_owner]    = target:get_GameObject()
    node[S.F.at_owner_ch] = target
    node[S.F.at_context]  = target:get_Context()
    node[S.F.at_transform] = target:get_Transform()
    return node
end

function A.node_for(target, pawn)
    if not U.is_valid_obj(target) then return nil end
    if U.is_valid_obj(pawn) then
        local known = known_node(pawn, target)
        if known then return known end
    end
    return built_node(target)
end

return A
