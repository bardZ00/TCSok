-- TacticalCommandSystem/cmd/init.lua
-- The command engine, assembled. This is the only file the rest of the mod talks to.
--
-- Giving a pawn a skill, a stance or a lock goes through here; everything else -- which route the order takes, how it is
-- watched through, what is muted and given back, how the queue holds -- is the engine's own business and stays behind
-- this file.
--
-- The pieces, in the order they load:
--
--   sdkmap    every raw reflection lookup, and the game's own names for things
--   posture   what a character's body is doing, read once per frame into one record
--   matcher   which of a pawn's AI decisions belong to a given skill
--   brain     a pawn's decision table: mute, give back, read what it is running
--   pawnobj   the game's Pawn object: standing order, skill ration, ignore list
--   aim       who an order is aimed at, and how that enemy is handed to the pawn's AI
--   reach     how close the pawn walks before it uses the skill
--   roster    one record per pawn in hand, and the index the hooks look pawns up in
--   issue     putting an order out, by one of two routes
--   stance    the standing posture a pawn keeps until told otherwise
--   queue     what the pawn is to do after this
--   runner    watching an order through, frame by frame
--   manual    skills kept for the player to order
--   guards    the fence around a running order
--
-- A pawn the engine has nothing for has no record, so an idle party costs a table lookup a frame and no more.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local P = require("TacticalCommandSystem.cmd.posture")
local Brain = require("TacticalCommandSystem.cmd.brain")
local Obj = require("TacticalCommandSystem.cmd.pawnobj")
local Aim = require("TacticalCommandSystem.cmd.aim")
local Roster = require("TacticalCommandSystem.cmd.roster")
local Issue = require("TacticalCommandSystem.cmd.issue")
local Stance = require("TacticalCommandSystem.cmd.stance")
local Queue = require("TacticalCommandSystem.cmd.queue")
local Runner = require("TacticalCommandSystem.cmd.runner")
local Manual = require("TacticalCommandSystem.cmd.manual")
local Guards = require("TacticalCommandSystem.cmd.guards")

local AI = {}

Guards.install()

local function cancel_action(chara)
    pcall(function()
        chara[S.F.actions]:requestActionCore(10, "DefaultCancelAction", 0)
    end)
end

local function address_of(entry)
    if entry.addr then return entry.addr end
    return U.safe_call(function() return entry.chara:get_address() end)
end

----------------------------------------------------------------------------------------------------
-- ordering a skill
----------------------------------------------------------------------------------------------------
-- Returns one of:
--   "ordered"     the pawn has it (or is about to, once it is back on its feet)
--   "queued", n   waiting its turn, n deep
--   "queue_full"  three already waiting
--   "no_target"   nothing left alive to aim at
--   "stance_off"  a launch stance that was already up, now put away
--   "failed"      the pawn cannot take an order at all
function AI.execute_pawn_skill(entry, skill_id, now, force_queue, target_entry)
    if not entry or not U.is_valid_obj(entry.chara) then return "failed" end

    local pick = Aim.settle(skill_id, target_entry, entry.chara)
    if Aim.must_have_enemy(skill_id) and not pick then return "no_target" end

    local addr = address_of(entry)
    if not addr then return "failed" end
    local rec = Roster.ensure(addr, entry.chara, entry.pawn_obj)

    local stack = P.read(entry.chara)
    if stack.blocked then
        Roster.tidy(rec)
        return "failed"
    end

    local ord = D.ORDERS[skill_id]
    if not ord then
        Roster.tidy(rec)
        return "failed"
    end

    -- 1.06: a skill marked "without targeting" that the pawn is holding right now is put away when it is ordered
    -- again, instead of being launched a second time (a held guard the pawn's own head does not always let go of).
    -- Skills with targeting keep queueing as before.
    -- 2.06: a toggle skill (data.lua "toggle") is put away the same way, whether "without targeting" is ticked or not.
    local put_away = ord.toggle or (not Aim.must_have_enemy(skill_id) and Aim.needs_enemy(skill_id))
    if stack.skill and not ord.stance and put_away then
        local low = stack.low or ""
        for _, key in ipairs(ord.keys or {}) do
            if low:find(key, 1, true) then
                if rec.run then Roster.stop(rec) end
                rec.soon = nil
                cancel_action(entry.chara)
                Roster.tidy(rec)
                return "stance_off"
            end
        end
    end

    -- something is already running, or the player asked for this one to wait its turn
    if not ord.stance and (force_queue or rec.run or rec.soon) then
        if Queue.full(rec) then return "queue_full", Queue.length(rec) end
        local depth = Queue.add(rec, skill_id, pick)

        -- nothing actually running: start the head of the queue now, if the gauge can pay for it
        if not rec.run and not rec.soon and Queue.ready_head(rec) then
            local item = Queue.take(rec)
            return Issue.order(rec, item.skill, now, false, item.pick)
        end
        return "queued", depth
    end

    rec.retry = nil

    -- climbing an enemy or falling: hold the order until the pawn has the ground back
    if stack.aerial and not rec.run then
        Runner.wait_for(rec, "when_free", skill_id, pick, now)
        return "ordered"
    end

    -- in the middle of something else: cut it, then order once the pawn is free
    if not rec.run and (stack.skill or not (P.at_rest(stack) or D.IDLE_LAYERS[stack.top])) then
        cancel_action(entry.chara)
        Runner.wait_for(rec, "unstuck", skill_id, pick, now, { cut = true })
        return "ordered"
    end

    return Issue.order(rec, skill_id, now, false, pick)
end

----------------------------------------------------------------------------------------------------
-- calling a pawn off
----------------------------------------------------------------------------------------------------
function AI.cancel_pawn_action(entry)
    if not entry or not U.is_valid_obj(entry.chara) then return end
    U.safe_call(function()
        local chara = entry.chara
        local addr = address_of(entry)
        local rec = addr and Roster.get(addr)

        if rec then
            Roster.stop(rec)
            rec.soon = nil
            Queue.clear(rec)
            Stance.release(rec)
            rec.stance = "free"
            Roster.reindex_wait(rec)
        end

        Obj.set_order(entry.pawn_obj, chara, Obj.ORDER.NONE)
        Brain.of(chara):set_thinking(true)
        cancel_action(chara)

        -- 2.27: a toggle skill stays on as a state, not as a running action, so the cancel above never reaches it
        -- (Shield Precision). Its own "off" action is asked for, only for a toggle skill the pawn has equipped.
        local _, skills = U.read_pawn_equipped_skills(chara, entry.pawn_obj)
        for _, sid in ipairs(skills or {}) do
            local o = D.ORDERS[sid]
            if o and o.toggle and o.off then Issue.request_action(chara, 10, o.off, 0) end
        end

        if rec then Roster.tidy(rec) end
    end, "cancel_pawn_action")
end

function AI.cancel_all_pawns(list)
    for _, entry in ipairs(list or {}) do
        AI.cancel_pawn_action(entry)
    end
end

function AI.reset_all()
    Aim.clear()
    Roster.clear(Stance.release)
end

----------------------------------------------------------------------------------------------------
-- stances
----------------------------------------------------------------------------------------------------
function AI.get_pawn_stance(addr) return Stance.of(addr) end
function AI.set_pawn_stance(entry, mode, now, keep) return Stance.set(entry, mode, now, keep) end

----------------------------------------------------------------------------------------------------
-- the queue
----------------------------------------------------------------------------------------------------
function AI.get_pawn_queue(addr)
    return Queue.list(Roster.get(addr))
end

function AI.get_skill_queue_pos(addr, skill_id)
    return Queue.place(Roster.get(addr), skill_id)
end

function AI.remove_from_queue(entry, skill_id)
    if not entry then return "empty" end
    local addr = entry.addr or (U.is_valid_obj(entry.chara) and entry.chara:get_address()) or nil
    local rec = addr and Roster.get(addr)
    if not rec then return "empty" end
    local what, gone, left = Queue.drop(rec, skill_id)
    if what == "removed" then Roster.tidy(rec) end
    return what, gone, left
end

----------------------------------------------------------------------------------------------------
-- what the wheel asks about
----------------------------------------------------------------------------------------------------
-- the order the pawn is on, whether it is running or waiting for its feet
function AI.get_active_timer_for_pawn(addr)
    local rec = Roster.get(addr)
    if not rec then return nil end
    return rec.run or rec.soon or nil
end

-- 0..1 along the skill, for the ring the wheel draws on a cell
-- 2.10: where the running order stands: "sent" (not started yet), "channel" (charging), "active" (going off)
function AI.run_phase(addr, skill_id)
    local rec = Roster.get(addr)
    local run = rec and rec.run
    if not run or run.skill ~= skill_id then return nil end
    if not run.at_begin then return "sent" end
    if run.charging or (run.full and not run.at_cast) then return "channel" end     -- 2.25
    return "active"
end

-- 2.10: true while a chargeable skill ordered charged is still in its charge
function AI.is_channeling(addr, skill_id)
    local rec = Roster.get(addr)
    local run = rec and rec.run
    return run ~= nil and run.skill == skill_id and (run.charging ~= nil
        or (run.full ~= nil and run.at_begin ~= nil and not run.at_cast))     -- 2.25
end

function AI.get_skill_progress(addr, skill_id, now)
    local rec = Roster.get(addr)
    local run = rec and rec.run
    if not run or run.skill ~= skill_id then return nil end

    now = now or U.game_now()
    local ord = D.ORDERS[skill_id]

    if run.at_cast then
        local hold = (ord and ord.hold_cast) or 2.2
        return math.min(1.0, math.max(0.15, (now - run.at_cast) / hold))
    end
    -- 2.13: the pawn charging (its own choice): the bar fills over the full charge time
    if run.charging and ord and ord.full then
        return math.min(0.97, math.max(0.08, (now - run.at_begin) / ord.full.after))
    end
    -- 2.25: ordered charged: the bar fills over the charge; run.full is cleared the moment the release is taken
    if run.full and run.at_begin and not run.at_cast and ord and ord.full then
        return math.min(0.97, math.max(0.08, (now - run.at_begin) / ord.full.after))
    end
    if run.at_begin then
        local total = run.prep or (ord and ord.charge) or 2.0
        return math.min(0.95, math.max(0.08, (now - run.at_begin) / math.max(0.2, total)))
    end
    return math.min(0.35, math.max(0.05, (now - run.at_fire) / 3.0))
end

----------------------------------------------------------------------------------------------------
-- targets
----------------------------------------------------------------------------------------------------
function AI.nearest_target(from) return Aim.nearest(from) end
function AI.get_target() return Aim.recall() end
function AI.set_target(entry) Aim.remember(entry) end
function AI.skill_needs_target(skill_id) return Aim.needs_enemy(skill_id) end
function AI.skill_available(skill_id) return Aim.always_available(skill_id) end


----------------------------------------------------------------------------------------------------
-- manual-only locks
----------------------------------------------------------------------------------------------------
function AI.is_locked(pawn_name, skill_id) return Manual.is_locked(pawn_name, skill_id) end
function AI.toggle_lock(entry, skill_id) return Manual.toggle(entry, skill_id) end
function AI.clear_all_locks() return Manual.clear_all() end
function AI.lock_diag() return Manual.report() end

----------------------------------------------------------------------------------------------------
-- the frame
----------------------------------------------------------------------------------------------------
function AI.update_pawn_timers(now)
    Runner.tick(now, Manual.step)
end

return AI
