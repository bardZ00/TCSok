-- TacticalCommandSystem/in/wheel.lua
-- The characters of the wheel (the Arisen + the pawns), building the wheel (slices), giving an order (with the targeting
-- step), opening / closing the wheel, switching character.
-- Part of the input system (see input.lua); the public table is IN (in/shared.lua).

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local AI = require("TacticalCommandSystem.cmd.init")
local AR = require("TacticalCommandSystem.arisen")
local SND = require("TacticalCommandSystem.sound")
local API = require("TacticalCommandSystem.api")
local Poss = require("TacticalCommandSystem.possess")
local X = require("TacticalCommandSystem.in.shared")
local IN = X.IN
local W = IN.W
local Slow = U.Slow


local function flash(msg, w_now, secs)
    W.flash_msg = msg
    W.flash_icon = nil                         -- 1.52: set just after, for the orders that launch a skill
    W.flash_until = (w_now or U.wall_time()) + (secs or 2.0)
end

------------------------------------------------------------------------------------------------
-- Skills that skip the targeting step: the player's choices (menu) over the default list (data.lua)
------------------------------------------------------------------------------------------------
IN.NOTARGET = {}          -- tostring(skill id) -> true (no targeting) / false (targeting), saved in config.json

function IN.is_no_target(id)
    local v = IN.NOTARGET[tostring(id)]
    if v ~= nil then return v == true end
    return D.default_no_target(id)
end

function IN.set_no_target(id, on)
    if on == D.default_no_target(id) then IN.NOTARGET[tostring(id)] = nil else IN.NOTARGET[tostring(id)] = on and true or false end
    if IN.on_notarget_changed then pcall(IN.on_notarget_changed) end
end

-- Does this order go through the targeting step?
function IN.needs_target(entry, id)
    if not entry or not id or id <= 0 then return false end
    if IN.is_no_target(id) then return false end
    if entry.kind == "arisen" then return true end
    return AI.skill_needs_target(id)
end

------------------------------------------------------------------------------------------------
-- The characters: the Arisen first, then the pawns
------------------------------------------------------------------------------------------------
local arisen_cache = { t = -10, entry = nil }

local function arisen_entry(now)
    local player = U.get_player()
    if not U.is_valid_obj(player) or U.is_dead(player) then return nil end
    local addr = U.safe_call(function() return player:get_address() end)
    if not addr then return nil end
    local e = arisen_cache.entry
    if e and e.addr == addr and (now - arisen_cache.t) < 0.25 then
        e.hp_ratio, e.stam_ratio = U.get_vitals(player, nil)
        return e
    end
    AR.locate(player, now)
    local job = U.read_pawn_equipped_skills(player, nil)
    local hp, st = U.get_vitals(player, nil)
    e = {
        kind = "arisen",
        chara = player,
        addr = addr,
        name = U.pawn_name(player, nil, "ARISEN"),
        job = job,
        job_info = D.JOB_INFO[job] or D.DEFAULT_JOB_INFO,
        skills = AR.read_skills(player, job),      -- slot -> id (0 = empty slot)
        hp_ratio = hp,
        stam_ratio = st,
    }
    arisen_cache.entry, arisen_cache.t = e, now
    return e
end

function IN.get_party(w_now)
    local out = {}
    local a = arisen_entry(w_now or U.wall_time())
    if a then out[1] = a end
    for _, p in ipairs(U.get_commandable_pawns()) do
        p.kind = "pawn"
        out[#out + 1] = p
    end
    return out
end

-- Only the pawns of the wheel's list (stance / cancel for "all pawns")
function IN.pawns_only()
    local out = {}
    for _, p in ipairs(W.pawns) do if p.kind ~= "arisen" then out[#out + 1] = p end end
    return out
end

function IN.current()
    return W.pawns[W.pawn_idx]
end

------------------------------------------------------------------------------------------------
-- Slices
------------------------------------------------------------------------------------------------
local function skill_name(entry, sid)
    if entry.kind == "arisen" then
        local n = AR.sc_label(entry.chara, sid)
        if n then return U.upper(n) end
    end
    return U.upper(U.get_skill_display_name(sid))
end

function IN.build_wheel_slices()
    W.slices = {}
    W.skill_items = {}
    W.corner_items = {}
    local p = IN.current()
    if not p then return end
    local function add(list, item)
        W.slices[#W.slices + 1] = item
        item.idx = #W.slices
        list[#list + 1] = item
    end
    local arisen = (p.kind == "arisen")

    -- the 6 skill slots: 1..3 on the left of the circle, 4..6 on the right
    for slot = 1, 6 do
        local sid = p.skills[slot]
        local side = (slot <= 3) and "left" or "right"
        if sid and sid > 0 then
            local ord = D.ORDERS[sid]
            local sub
            if arisen then
                sub = ""
            else
                sub = ord and (ord.stance and "LAUNCH STANCE" or (ord.target == "player" and "SUPPORT / ALLY" or (ord.target == "self" and "SELF / AREA BUFF" or "ASSAULT / TARGET"))) or "SKILL"
            end
            add(W.skill_items, {
                side = side, slot = slot, kind = "skill", skill_id = sid, arisen = arisen,
                name = skill_name(p, sid),
                icon = U.get_skill_icon_no(sid),
                sub = sub,
                keys = arisen and AR.SLOT_KEYS[slot] or nil,
            })
        else
            add(W.skill_items, { side = side, slot = slot, kind = "empty", skill_id = 0, arisen = arisen,
                name = "EMPTY SLOT", sub = "NO SKILL EQUIPPED", keys = arisen and AR.SLOT_KEYS[slot] or nil })
        end
    end

    -- the small cells under the skills: Cancel (bottom-left); Stance (bottom-right) for the pawns only
    if arisen then
        add(W.corner_items, { side = "left", kind = "cancel", skill_id = 0, arisen = true, name = "CANCEL", sub = "PENDING SKILL" })
        -- the team's stance: one press sets the next stance on every pawn at once
        add(W.corner_items, { side = "right", kind = "team", skill_id = 0, arisen = true, name = "TEAM STANCE", sub = "ALL PAWNS" })
    else
        add(W.corner_items, { side = "left",  kind = "cancel", skill_id = 0, name = "CANCEL", sub = "CLEAR QUEUE & RESET" })
        add(W.corner_items, { side = "right", kind = "stance", skill_id = 0, name = "STANCE", sub = "" })
    end
end

-- The stance that follows the current one when the Stance cell is confirmed: free -> close -> wait -> ranged -> free
function IN.next_stance(cur)
    local list = D.STANCE_LIST
    for i, id in ipairs(list) do
        if id == cur then return list[i % #list + 1] end
    end
    return list[2]
end

------------------------------------------------------------------------------------------------
-- Orders
------------------------------------------------------------------------------------------------
-- the stance shared by every pawn, "mixed" when they differ, nil without pawns
function IN.team_stance()
    local common = nil
    for _, p in ipairs(IN.pawns_only()) do
        local st = AI.get_pawn_stance(p.addr) or "free"
        if common == nil then common = st elseif common ~= st then return "mixed" end
    end
    return common
end

-- Stance and Cancel cells (no target). all = the queue button was used (all pawns).
local function trigger_corner(slice, entry, g_now, w_now, all)
    if slice.kind == "team" then
        -- every pawn takes the next stance after the team's one (a different stance of one pawn is replaced too)
        local pawns = IN.pawns_only()
        if #pawns == 0 then flash("[ NO PAWN IN THE PARTY ]", w_now, 1.8); return end
        local cur = IN.team_stance()
        local new_mode = (cur == "mixed") and D.STANCE_LIST[1] or IN.next_stance(cur)
        for _, p in ipairs(pawns) do AI.set_pawn_stance(p, new_mode, g_now, true) end
        flash(string.format("[ ALL PAWNS >> %s ]", D.STANCE_LABELS[new_mode] or U.upper(new_mode)), w_now, 2.2)
        return
    end
    if slice.kind == "stance" then
        local new_mode = IN.next_stance(AI.get_pawn_stance(entry.addr))
        local label = D.STANCE_LABELS[new_mode] or ("STANCE: " .. U.upper(new_mode))
        local pawns = IN.pawns_only()
        if all and #pawns > 1 then
            for _, p in ipairs(pawns) do AI.set_pawn_stance(p, new_mode, g_now, true) end
            flash(string.format("[ ALL PAWNS >> %s ]", label), w_now, 2.2)
        else
            AI.set_pawn_stance(entry, new_mode, g_now, true)
            flash(string.format("[ %s >> %s ]", entry.name, label), w_now, 2.2)
        end
    elseif slice.kind == "cancel" then
        if entry.kind == "arisen" then
            AR.queue = nil
            flash(string.format("[ %s : PENDING SKILL CANCELLED ]", entry.name), w_now, 1.8)
            return
        end
        local pawns = IN.pawns_only()
        if all and #pawns > 1 then
            AI.cancel_all_pawns(pawns)
            flash("[ ALL PAWNS : QUEUES CLEARED & FREE ]", w_now, 1.8)
        else
            AI.cancel_pawn_action(entry)
            flash(string.format("[ %s : QUEUE CLEARED & FREE ]", entry.name), w_now, 1.8)
        end
    end
end

-- Gives the order now. tgt = target entry or nil. mode = "close" | "stay" | "queue".
function IN.execute_order(slice, entry, tgt, mode, g_now, w_now)
    if tgt then AI.set_target(tgt) end           -- remembered only for the marker shown after the wheel closes
    if entry.kind == "arisen" then
        AR.request({ slot = slice.slot, id = slice.skill_id, name = slice.name, job = entry.job }, tgt)
        flash(string.format("[ %s >> %s ]", entry.name, slice.name), w_now, 2.2)
        W.flash_icon = slice.icon                -- 1.52: the skill's medallion in the announcement
        SND.play("decide")
        return true
    end
    -- 2.08: a chargeable skill says which version goes out (read before the order uses the choice up)
    local ordc = D.ORDERS[slice.skill_id]
    local what = slice.name
    if ordc and ordc.full then
        if D.charge_quick_once == slice.skill_id then what = what .. " · QUICK"
        else what = what .. " · CHARGED" end     -- 2.23: A = charged, X = quick
    end
    local status, qpos = AI.execute_pawn_skill(entry, slice.skill_id, g_now, mode == "queue", tgt)
    if status == "ordered" then
        flash(string.format("[ %s >> %s ]", entry.name, what), w_now, 2.2)
        W.flash_icon = slice.icon
    elseif status == "queued" then
        flash(string.format("[ %s : QUEUED #%d >> %s ]", entry.name, qpos or 1, what), w_now, 2.2)
        W.flash_icon = slice.icon
    elseif status == "queue_full" then
        flash(string.format("[ %s : QUEUE FULL (MAX %d) ]", entry.name, D.MAX_QUEUE), w_now, 1.8)
        SND.play("disable")
        return false
    elseif status == "no_target" then
        flash("[ NO ENEMIES IN RANGE ]", w_now, 1.8)
        SND.play("disable")
        return false
    elseif status == "stance_off" then
        flash(string.format("[ %s : STANCE ENDED ]", entry.name), w_now, 1.8)
    else
        flash(string.format("[ %s : ORDER FAILED ]", entry.name), w_now, 1.8)
        SND.play("disable")
        return false
    end
    SND.play("decide")
    return true
end

-- What the Arisen's launch gave (called from UpdateBehavior)
AR.on_result = function(ok, cell, msg)
    if not ok and msg then
        flash(msg, U.wall_time(), 2.2)
        SND.play("disable")
    end
end

-- A skill / Stance / Cancel cell was confirmed. mode = "close" (A), "stay" (R3) or "queue" (X).
-- Returns "target" when the targeting step opened, "done" when the order went out, nil when nothing happened.
function IN.begin_order(slice, entry, mode, g_now, w_now)
    if not slice or not entry or slice.kind == "empty" then return nil end
    if slice.kind ~= "skill" then
        trigger_corner(slice, entry, g_now, w_now, mode == "queue")
        SND.play("decide")
        return "done"
    end
    if entry.kind == "arisen" and mode == "queue" then return nil end      -- no queue for the Arisen (for now)
    -- ATB Combat System: not enough full segments -> refused (greyed cell); a pawn may still queue it (it waits for the gauge)
    if mode ~= "queue" and not API.atb_affordable(entry.addr, slice.skill_id) then
        SND.play("disable")
        return nil
    end
    if not IN.needs_target(entry, slice.skill_id) then
        return IN.execute_order(slice, entry, nil, mode, g_now, w_now) and "done" or nil
    end
    -- targeting step: the wheel fades out, the enemies are offered left / right
    W.stage = 2
    W.tg = { slice = slice, entry = entry, mode = mode, t0 = w_now }
    W.stage_t = w_now
    W.tgt_idx = 0
    W.stick_armed = false
    IN.build_targets(w_now, nil)
    -- 2.08: nothing the party can target: say why, longer, and stay on the skills instead of an empty targeting step
    if #W.targets == 0 and entry.kind ~= "arisen" then
        W.stage, W.tg = 1, nil
        local EMPTY = { behind = "[ ENEMY OUT OF VIEW ]", dark = "[ TOO DARK: NO ENEMY ENGAGED ]", hidden = "[ NO ENEMY IN SIGHT ]" }
        local okR, why = pcall(function() return require("TacticalCommandSystem.lib.vision").empty_reason() end)
        flash((okR and EMPTY[why]) or "[ NO ENEMIES IN RANGE ]", w_now, 3.0)
        SND.play("disable")
        return nil
    end
    SND.play("decide")
    return "target"
end

------------------------------------------------------------------------------------------------
-- Targeting step
------------------------------------------------------------------------------------------------
-- Living enemies within range; keep_addr stays selected if it is still there, else the default one is offered first.
--
-- Which one is "default" is the player's choice: the enemy nearest the crosshair -- what you are looking at -- or the
-- one nearest in metres. Only enemies actually on screen can be judged against the crosshair, so when none of them is
-- on screen the centred rule has nothing to measure and the nearest one is offered instead.
local function default_target(list)
    if #list == 0 then return 0 end
    local idx = 0
    if (U.TGT.default_pick or "near") == "centre" then
        for k, t in ipairs(list) do
            if t.centre and (idx == 0 or t.centre < list[idx].centre) then idx = k end
        end
    end
    if idx == 0 then
        idx = 1
        for k = 2, #list do if list[k].dist < list[idx].dist then idx = k end end
    end
    return idx
end

function IN.build_targets(w_now, keep_addr)
    W.targets_t = w_now
    local list = U.list_target_candidates(U.get_player(), U.TGT.range or 45.0, D.TARGET_MAX)
    local idx = 0
    if keep_addr then
        for k, t in ipairs(list) do if t.addr == keep_addr then idx = k; break end end
    end
    if idx == 0 then idx = default_target(list) end
    W.targets, W.tgt_idx = list, idx
end

function IN.refresh_targets(w_now)
    if W.stage ~= 2 then return end
    if (w_now - (W.targets_t or -10)) < D.TARGET_REFRESH then return end
    local cur = W.targets[W.tgt_idx]
    IN.build_targets(w_now, cur and cur.addr or nil)
end

function IN.current_target()
    return (W.stage == 2) and W.targets[W.tgt_idx] or nil
end

-- dir = -1 (left) / 1 (right): the enemy really on that side; at the edge nothing moves
function IN.target_step(dir)
    local n = #W.targets
    if n < 2 then return end
    local k = U.pick_direction(W.targets, W.tgt_idx, dir)
    if k and k ~= W.tgt_idx then
        W.tgt_idx = k
        SND.play("cursor")
    end
end

function IN.target_back(w_now)
    W.stage = 1
    W.tg = nil
    W.stage_t = w_now
    SND.play("cancel")
end

-- Validates the targeting step. With no enemy in range: the Arisen launches without a target, a pawn order is refused.
function IN.target_confirm(g_now, w_now)
    local tg = W.tg
    if not tg then W.stage = 1; return end
    local tgt = W.targets[W.tgt_idx]
    if tgt and (not U.is_valid_obj(tgt.chara) or U.is_dead(tgt.chara)) then
        tgt = AI.nearest_target(tg.entry.chara)          -- the chosen enemy died meanwhile: the nearest one
    end
    -- 2.08: the list emptied while aiming (enemy slipped out of view): the nearest one rather than nothing
    if not tgt and tg.entry.kind ~= "arisen" then tgt = AI.nearest_target(tg.entry.chara) end
    if not tgt and tg.entry.kind ~= "arisen" then
        local EMPTY = { behind = "[ ENEMY OUT OF VIEW ]", dark = "[ TOO DARK: NO ENEMY ENGAGED ]", hidden = "[ NO ENEMY IN SIGHT ]" }
        local okR, why = pcall(function() return require("TacticalCommandSystem.lib.vision").empty_reason() end)
        flash((okR and EMPTY[why]) or "[ NO ENEMIES IN RANGE ]", w_now, 3.0)
        SND.play("disable")
        IN.target_back(w_now)
        return
    end
    local entry = (tgt and { chara = tgt.chara, addr = tgt.addr, name = tgt.name, dist = tgt.dist }) or nil
    -- 1.16: an enemy picked in the wheel is engaged (realistic targeting)
    if tgt then pcall(function() require("TacticalCommandSystem.lib.vision").engage_chara(tgt.chara) end) end
    local ok = IN.execute_order(tg.slice, tg.entry, entry, tg.mode, g_now, w_now)
    W.stage = 1
    W.tg = nil
    W.stage_t = w_now
    if ok and tg.mode == "close" then IN.close_wheel(false, g_now, w_now) end
end

------------------------------------------------------------------------------------------------
-- Opening, closing, switching character
------------------------------------------------------------------------------------------------
-- 2.24: another mod is holding a full-screen menu, so its own buttons must not reach the wheel. The convention is
-- the one already used for the HUD (_G.BardN_HideHUD): a table keyed by mod name, each mod setting its own key
-- while its menu is up. Second line: RPG Level Up Overhaul 1.10 and under, which only announces the HUD hiding.
function IN.modal_mod_open()
    local t = rawget(_G, "BardN_MenuOpen")
    if type(t) == "table" then
        for _, v in pairs(t) do if v then return true end end
    end
    local h = rawget(_G, "BardN_HideHUD")
    if type(h) == "table" and h["RPG Level Up"] then return true end
    return false
end

function IN.open_wheel(w_now)
    if IN.modal_mod_open() then return false end     -- 2.24
    W.opened_t = w_now
    local pl = U.get_player()
    if not U.is_valid_obj(pl) or U.is_dead(pl) then return false end

    arisen_cache.t = -10
    W.pawns = IN.get_party(w_now)
    if #W.pawns == 0 then return false end
    -- Opens on the character actually being played: on the Arisen normally, and on the possessed pawn while Direct
    -- Pawn Control is driving one, so the wheel starts on "you" rather than on the Arisen you have stepped out of.
    W.pawn_idx = 1
    local played = Poss.active_addr()
    if played then
        for i, p in ipairs(W.pawns) do if p.addr == played then W.pawn_idx = i; break end end
    end
    W.car_pos = W.pawn_idx              -- carousel of the top row, no slide at opening
    U.clear_skill_names()   -- re-read the skill names from the game each time the wheel opens
    IN.build_wheel_slices()

    W.open = true
    W.swallowing = true
    W.open_time = w_now
    W.last_update_wall = w_now
    W.stage, W.tg, W.stage_t = 1, nil, w_now
    W.sel = nil
    W.sx, W.sy = 0, 0
    W.angle = nil
    W.last_mouse = nil
    W.disp_angle = nil
    W.last_steer_t = nil
    W.mouse_reset = true
    W.stick_was_active = false
    W.mode, W.mx, W.my, W.tg_acc, W.abs_ok, W.abs_prev = "pad", nil, nil, 0, false, nil
    W.abs_home = nil                   -- 1.14: where the system pointer sits when the wheel opens
    W.kbm = false     -- keys shown = keyboard and mouse (last device used), whatever the mouse mode   -- pad mode / mouse mode (set by who opened the wheel)
    W.nav_delta = 0
    W.back_req, W.close_req = false, false
    W.queue_req, W.quick_req = false, false
    W.confirm_req, W.stay_req = false, false
    W.lock_char_req = false
    W.lock_req = false
    W.rel_armed = false
    W.sticky = false
    W.used_multi_queue = false
    W.targets, W.tgt_idx = {}, 0
    W.targets_t = -10
    Slow.active, Slow.releasing = true, false
    return true
end

-- commit = validate the highlighted cell while closing (hold mode); a skill that needs a target is not launched that way
function IN.close_wheel(commit, g_now, w_now)
    if not W.open then return end
    if commit and W.stage == 1 and not W.used_multi_queue and W.sel and W.slices[W.sel] then
        local slice, entry = W.slices[W.sel], IN.current()
        if slice.kind ~= "skill" or not IN.needs_target(entry, slice.skill_id) then
            IN.begin_order(slice, entry, "close", g_now, w_now)
        end
    end
    -- Closing the wheel lands you in the character it was on -- or in the locked one, when a lock overrides it. This
    -- is the whole "switch body" gesture now: no dedicated button, every close does it. On the character you already
    -- play, switch_to finds nothing to do and returns quietly.
    if Poss.enabled then
        pcall(function() Poss.switch_to(Poss.close_target(W.pawns, IN.current())) end)
    end
    W.open = false
    W.stage, W.tg = 1, nil
    W.closed_t = w_now
    Slow.releasing = true
end

function IN.cycle_pawn(delta)
    local latest = IN.get_party(U.wall_time())
    if #latest > 0 then
        -- keep the same character selected when the list changes under us
        local cur = IN.current()
        W.pawns = latest
        if cur then
            for i, p in ipairs(latest) do if p.addr == cur.addr then W.pawn_idx = i; break end end
        end
    end
    local n = #W.pawns
    if n <= 1 then return end
    W.pawn_idx = ((W.pawn_idx - 1 + delta) % n) + 1
    SND.play("decide")
    IN.build_wheel_slices()
    W.sel = nil
    W.used_multi_queue = false
end

-- Preview (menu): the wheel stays drawn, closed, on the character chosen in the menu
function IN.preview_frame(w_now)
    if not W.previewing or (w_now - (W.preview_t or -10)) > 0.5 then
        local keep = W.previewing and W.pawns[W.pawn_idx] and W.pawns[W.pawn_idx].addr or nil
        W.pawns = IN.get_party(w_now)
        W.pawn_idx = 1
        if keep then for i, p in ipairs(W.pawns) do if p.addr == keep then W.pawn_idx = i end end end
        if not W.previewing then
            W.open_time = w_now - 1
            W.car_pos = W.pawn_idx
            W.stage, W.tg, W.sel = 1, nil, nil
        end
        W.previewing, W.preview_t = true, w_now
        IN.build_wheel_slices()
        if API.preview_target then IN.preview_targeting(w_now) end
    end
    if not API.preview_target and W.stage == 2 then W.stage, W.tg = 1, nil end
end

-- 1.38: the targeting step's preview: the first skill of the character shown, aimed at the enemies in range;
-- with no enemy around, a party member stands in for one, so the marker can be tuned anywhere
function IN.preview_targeting(w_now)
    local entry = W.pawns[W.pawn_idx]
    local slice = nil
    for _, it in ipairs(W.skill_items or {}) do if it.kind == "skill" and it.skill_id and it.skill_id > 0 then slice = it; break end end
    if not entry or not slice then W.stage, W.tg = 1, nil; return end
    local keep = W.tg and W.targets and W.targets[W.tgt_idx] and W.targets[W.tgt_idx].addr or nil
    if W.stage ~= 2 then W.stage_t = w_now end
    W.stage = 2
    W.tg = { slice = slice, entry = entry, mode = "close", t0 = (W.tg and W.tg.t0) or w_now, preview = true }
    IN.build_targets(w_now, keep)
    if #W.targets == 0 then
        local me = U.get_player()
        for _, p in ipairs(W.pawns) do
            if p.addr ~= entry.addr and p.chara then
                local ok, d = pcall(U.distance, me, p.chara)
                W.targets[#W.targets + 1] = { chara = p.chara, addr = p.addr, name = U.upper(p.name or ""), dist = (ok and d) or 0 }
            end
        end
        W.tgt_idx = (#W.targets > 0) and 1 or 0
    end
end

function IN.preview_cycle(delta)
    local n = #W.pawns
    if not W.previewing or n == 0 then return end
    W.pawn_idx = ((W.pawn_idx - 1 + delta) % n) + 1
    IN.build_wheel_slices()
    if API.preview_target then IN.preview_targeting(os.clock()) end
end

