-- Tactical Command System / lib / vision.lua  (1.13)
--
-- Realistic targeting: the targeting step only offers what the party can actually see.
--
--   * In front: an enemy behind the camera's half-plane (wider by a margin) is never offered.
--   * Walls: a few sight rays go from a seer's eyes to the enemy's feet, waist, head and both flanks; ONE clear ray is
--     enough, so an enemy half hidden behind a tree stays targetable and only a real wall hides it.
--   * Night: by night (the game's own TimeManager.isNight) or under a ceiling (cave, building), sight shrinks to a few
--     metres, a little more with the lantern lit.
--   * The party shares its eyes: the Arisen sees, and so does every pawn alive -- and a pawn that just fell, for
--     3 seconds more.
--   * Close: an enemy right next to the Arisen is always targetable (heard, felt).
--   * Short memory: an enemy seen stays targetable a moment after it slipped out of sight, so the list does not
--     flicker when a monster passes behind a pillar.
--   * Engagement (1.16): once blows have been traded with the party (either way), or the enemy was picked in the wheel,
--     both sides know where the other is. The dark no longer matters, and the enemy stays targetable -- walls
--     included -- until it has been out of sight AND out of blows for a few seconds (V.engage_lose). An enemy that
--     spotted you first but has not struck yet is not engaged: it has the advantage of surprise.
--
-- The ray itself is the one BardN's Enemy Variant Size uses for ceilings (same author): the one-parameter overload
-- via.physics.System.castRay(CastRayQuery) -> CastRayResult, static, on the static-scenery layer.
-- Nothing runs outside the targeting step: Vision.allows() is only called while it builds its list, and each enemy's
-- answer is kept for a fraction of a second.

local Safe = require("TacticalCommandSystem.lib.safe")

local V = {}

-- settings (conf/settings.lua writes them)
V.on          = true
V.front       = true
V.front_angle = 100     -- degrees each side of the camera's facing; 90 = an exact half circle
V.walls       = true
V.dark_range  = 4.0     -- m, by night with no lantern
V.lamp_range  = 8.0     -- m, by night with the lantern lit
V.ceiling     = true    -- under a ceiling counts as night
V.close       = 2.0     -- m: always targetable this close to the Arisen
V.memory      = 2.5     -- s: an enemy seen stays targetable this long
V.pawns       = true    -- pawns see for the Arisen
V.engage      = true    -- 1.16: an enemy engaged with the party ignores the dark
V.engage_lose = 5.0     -- s: engagement ends after this long without sight AND without a blow

local PAWN_AFTER_DEATH = 3.0   -- s: a fallen pawn still counts as a seer this long
local EYE = 1.55               -- m above a seer's feet
local POINTS = { 0.4, 1.2, 2.2 }   -- m above an enemy's feet
local FLANK = 0.7              -- m sideways, at the middle height
local MARGIN = 0.6             -- m: a hit this close to the enemy point is the enemy itself, not a wall
local CACHE = 0.2              -- s an enemy's answer is reused
local ENV_EVERY = 1.0          -- s between two readings of night / lantern / ceiling
local RAY_LAYER, RAY_MASK = 2, 0
local CEILING_UP = 8.0         -- m: a roof lower than this above the Arisen's head counts as "under a ceiling"

local R = { checked = false, native = false, castM = nil, query = nil, filter = nil, contactTd = nil, err = nil }

local function ray_init()
    if R.checked then return end
    R.checked = true
    pcall(function()
        local td = sdk.find_type_definition("via.physics.System")
        R.castM = td and td:get_method("castRay")
        R.contactTd = sdk.find_type_definition("via.physics.ContactPoint")
        R.query = sdk.create_instance("via.physics.CastRayQuery"):add_ref()
        R.query:clearOptions()
        R.query:enableAllHits()
        R.query:enableNearSort()
        R.filter = R.query:get_FilterInfo()
        R.filter:set_Group(0)
    end)
    R.native = R.castM ~= nil and R.query ~= nil and R.filter ~= nil and R.contactTd ~= nil
end

-- first static hit between a and b, as x, y, z; nil when the way is clear (or rays do not work)
local function ray_hit(ax, ay, az, bx, by, bz)
    if not R.native then return nil end
    local ok, pos = pcall(function()
        R.filter:set_Layer(RAY_LAYER)
        R.filter:set_MaskBits(RAY_MASK)
        R.query:call("setRay(via.vec3, via.vec3)", Vector3f.new(ax, ay, az), Vector3f.new(bx, by, bz))
        local result = R.castM:call(nil, R.query)
        if result == nil then return nil end
        local count = result:call("get_NumContactPoints")
        if type(count) ~= "number" or count < 1 then return nil end
        local point = result:call("getContactPoint(System.UInt32)", 0)
        if point == nil then return nil end
        return sdk.get_native_field(point, R.contactTd, "Position")
    end)
    if ok then return pos end
    R.err = tostring(pos)
    return nil
end

local function feet(chara)
    local ok, p = pcall(function() return chara:call("get_Transform"):call("get_Position") end)
    if ok and p and type(p.x) == "number" then return p end
    return nil
end

----------------------------------------------------------------------------------------------------
-- light: night, lantern, ceiling (read once a second)
----------------------------------------------------------------------------------------------------
local ENV = { t = -10, night = false, lamp = nil, roof = false, lamp_how = nil, lamp_tried = false }
V.env = ENV

-- The lantern's state: the first boolean getter without parameters, on the Arisen's Human then Character, whose name
-- speaks of a lit lantern. Looked up once; the probe shows what was found. Unknown = treated as lit (the kinder way).
local LAMP_WORDS = { "lanternon", "lanternlight", "lightlantern", "islantern", "lantern" }
local function lamp_find(player)
    ENV.lamp_tried = true
    ENV.lamp_found = {}
    local best, best_rank = nil, 99
    local human = Safe.call(function() return player:call("get_Human") end)
    for _, holder in ipairs({ { obj = human, src = "Human" }, { obj = player, src = "Character" } }) do
        if holder.obj then
            pcall(function()
                for _, m in ipairs(holder.obj:get_type_definition():get_methods()) do
                    local name = m:get_name()
                    local low = name:lower()
                    if low:find("lantern", 1, true) and not low:find("set_", 1, true) then
                        local np, rt = 9, ""
                        pcall(function() np = m:get_num_params() end)
                        pcall(function() rt = m:get_return_type():get_full_name() end)
                        if np == 0 and rt == "System.Boolean" then
                            ENV.lamp_found[#ENV.lamp_found + 1] = holder.src .. ":" .. name
                            for rank, w in ipairs(LAMP_WORDS) do
                                if low:find(w, 1, true) and rank < best_rank then
                                    best, best_rank = { obj = holder.obj, src = holder.src, name = name }, rank
                                end
                            end
                        end
                    end
                end
            end)
        end
    end
    ENV.lamp_how = best
end

local function env_read(player, now)
    if now - ENV.t < ENV_EVERY then return end
    ENV.t = now
    -- the game's own isNight first; else the hour, night from 20:00 to 04:00 (the split used by Simple Time Scaler)
    local tm = sdk.get_managed_singleton("app.TimeManager")
    local night = tm and Safe.call(function() return tm:call("isNight") end)
    if type(night) ~= "boolean" then
        local h = tm and tonumber(Safe.call(function() return tm:call("get_InGameHour") end))
        night = h ~= nil and (h >= 20 or h < 4) or false
        ENV.night_how = "hour"
    else
        ENV.night_how = "isNight"
    end
    ENV.night = night
    if not ENV.lamp_tried then lamp_find(player) end
    ENV.lamp = nil
    if ENV.lamp_how then
        local ok, v = pcall(function() return ENV.lamp_how.obj:call(ENV.lamp_how.name) end)
        if ok and type(v) == "boolean" then ENV.lamp = v end
    end
    ENV.roof = false
    if V.ceiling then
        local p = feet(player)
        if p then ENV.roof = ray_hit(p.x, p.y + EYE, p.z, p.x, p.y + EYE + CEILING_UP, p.z) ~= nil end
    end
end

-- how far a seer sees right now (nil = no limit)
local function sight_range()
    if not (ENV.night or ENV.roof) then return nil end
    if ENV.lamp == false then return V.dark_range end
    return V.lamp_range
end

----------------------------------------------------------------------------------------------------
-- seers: the Arisen, the pawns alive, a pawn fallen less than 3 s ago
----------------------------------------------------------------------------------------------------
local died_at = {}

local function seers(player, now)
    local out = { player }
    if not V.pawns then return out end
    pcall(function()
        local list = sdk.get_managed_singleton("app.PawnManager"):call("get_PawnCharacterList")
        local n = tonumber(list:call("get_Count")) or 0
        for i = 0, math.min(n, 6) - 1 do
            local chara = list[i]
            local addr = chara and Safe.address(chara)
            if addr then
                local dead = Safe.call(function() return chara:call("get_IsDead") end) == true
                if dead then
                    died_at[addr] = died_at[addr] or now
                    if now - died_at[addr] <= PAWN_AFTER_DEATH then out[#out + 1] = chara end
                else
                    died_at[addr] = nil
                    out[#out + 1] = chara
                end
            end
        end
    end)
    return out
end

-- can this seer see that enemy (range first, then rays)
local function sees(seer, e, range)
    local s = feet(seer)
    if not s then return false end
    local dx, dz = e.x - s.x, e.z - s.z
    local flat = math.sqrt(dx * dx + dz * dz)
    if range and flat > range then return false end
    if not V.walls or not R.native then return true end
    local ex, ey, ez = s.x, s.y + EYE, s.z
    local sx, sz = 0, 0
    if flat > 0.01 then sx, sz = -dz / flat, dx / flat end
    local aims = {}
    for _, h in ipairs(POINTS) do aims[#aims + 1] = { e.x, e.y + h, e.z } end
    aims[#aims + 1] = { e.x + sx * FLANK, e.y + POINTS[2], e.z + sz * FLANK }
    aims[#aims + 1] = { e.x - sx * FLANK, e.y + POINTS[2], e.z - sz * FLANK }
    for _, a in ipairs(aims) do
        local hit = ray_hit(ex, ey, ez, a[1], a[2], a[3])
        if hit == nil then return true end
        local hx, hy, hz = hit.x - a[1], hit.y - a[2], hit.z - a[3]
        if hx * hx + hy * hy + hz * hz <= MARGIN * MARGIN then return true end
    end
    return false
end

----------------------------------------------------------------------------------------------------
-- the question the targeting step asks
----------------------------------------------------------------------------------------------------
local cache, seen_at = {}, {}
V.last = {}            -- addr -> why, for the probe (last list built)

----------------------------------------------------------------------------------------------------
-- 1.16: engagement, keyed by the enemy's GameObject address (what a blow reports)
----------------------------------------------------------------------------------------------------
local engaged = {}     -- go addr -> { hit = last blow, seen = last sight }
V.engaged = engaged

function V.engage_go(go_addr, now)
    if not (V.on and V.engage and go_addr) then return end
    local e = engaged[go_addr]
    if e then e.hit = now else engaged[go_addr] = { hit = now, seen = now } end
    if now - (V.pruned or 0) > 10 then                -- forget long-gone fights (dead or fled enemies)
        V.pruned = now
        for k, x in pairs(engaged) do
            if now - x.hit > 60 and now - x.seen > 60 then engaged[k] = nil end
        end
    end
    cache = {}                                  -- answers change at once
end

local function go_address(chara)
    local ok, go = pcall(function() return chara:call("get_GameObject") end)
    return ok and go and Safe.address(go) or nil
end

-- picked in the wheel: engaged
function V.engage_chara(chara, now)
    if chara then V.engage_go(go_address(chara), now or os.clock()) end
end

-- the party's GameObjects, refreshed once a second, for the blow hook
local party_go, party_t = {}, -10
local function party_set(now)
    if now - party_t < 1.0 then return party_go end
    party_t, party_go = now, {}
    pcall(function()
        local player = sdk.get_managed_singleton("app.CharacterManager"):call("get_ManualPlayer")
        local a = player and go_address(player)
        if a then party_go[a] = true end
        local list = sdk.get_managed_singleton("app.PawnManager"):call("get_PawnCharacterList")
        local n = tonumber(list:call("get_Count")) or 0
        for i = 0, math.min(n, 6) - 1 do
            local g = list[i] and go_address(list[i])
            if g then party_go[g] = true end
        end
    end)
    return party_go
end

-- a blow between the party and anyone else engages that other one
local function on_blow(info)
    local now = os.clock()
    local att = info:get_field("<AttackOwnerObject>k__BackingField")
    local vic = info:get_field("<DamageGameObject>k__BackingField")
    local a, v = att and Safe.address(att), vic and Safe.address(vic)
    if not (a and v) or a == v then return end
    local party = party_set(now)
    if party[a] and not party[v] then V.engage_go(v, now)
    elseif party[v] and not party[a] then V.engage_go(a, now) end
end

pcall(function()
    local td = sdk.find_type_definition("app.HitController")
    local m = td and (td:get_method("damageProc(app.HitController.DamageInfo)") or td:get_method("damageProc"))
    if not m then return end
    sdk.hook(m, function(args)
        if not (V.on and V.engage) then return end
        pcall(function()
            local info = sdk.to_managed_object(args[3])
            if info then on_blow(info) end
        end)
    end, function(retval) return retval end)
    V.blow_hooked = true
end)

-- basis = W.camera_basis() (may be nil); returns true / false and a short reason
function V.allows(player, enemy, addr, dist, basis, now)
    if not V.on then return true, "off" end
    local c = cache[addr]
    if c and now - c.t < CACHE then
        V.last[addr] = { ok = c.ok, why = c.why, dist = dist }
        return c.ok, c.why
    end
    ray_init()
    env_read(player, now)

    local ok, why = true, "seen"
    local e, p = feet(enemy), feet(player)
    if not (e and p) then ok, why = true, "unreadable" end

    if e and p and V.front and basis then
        local dx, dz = e.x - p.x, e.z - p.z
        local len = math.sqrt(dx * dx + dz * dz)
        if len > 0.5 then
            local cosine = (dx * basis.fx + dz * basis.fz) / len
            if cosine < math.cos(math.rad(V.front_angle)) then
                ok, why = false, "behind"
                -- 2.08: behind the camera only hides what nobody fights: an engaged enemy, or one a pawn sees, stays
                local g = V.engage and go_address(enemy)
                if g and engaged[g] then
                    ok, why = true, "seen"
                else
                    local list = seers(player, now)
                    for i = 2, #list do
                        if sees(list[i], e, sight_range()) then ok, why = true, "seen by a pawn"; break end
                    end
                end
            end
        end
    end

    if ok and e and p and why == "seen" then
        local eng, g = nil, nil
        if V.engage then
            g = go_address(enemy)
            eng = g and engaged[g]
        end
        if dist <= V.close then
            why = "close"
        else
            local range = (not eng) and sight_range() or nil    -- engaged: the dark no longer matters
            local any = false
            for _, s in ipairs(seers(player, now)) do
                if sees(s, e, range) then any = true; break end
            end
            if any then
                seen_at[addr] = now
                if eng then eng.seen = now; why = "engaged" end
            elseif eng and (now - eng.seen <= V.engage_lose or now - eng.hit <= V.engage_lose) then
                why = "engaged, hidden"                       -- still engaged: walls do not drop it yet
            elseif eng then
                engaged[g] = nil                              -- out of sight and out of blows long enough: forgotten
                ok, why = false, "engagement lost"
            elseif seen_at[addr] and now - seen_at[addr] <= V.memory then
                why = "remembered"
            else
                ok, why = false, (range and dist > range) and "dark" or "hidden"
            end
        end
    end

    cache[addr] = { t = now, ok = ok, why = why }
    V.last[addr] = { ok = ok, why = why, dist = dist }
    return ok, why
end

-- 1.19: why the last list came out empty, for the message under the skill:
-- nil (someone is targetable, or realistic targeting is off), "range" (no enemy in range at all),
-- "behind" (one at least behind the camera -- checked first, the one the player can act on), "dark", "hidden"
function V.empty_reason()
    if not V.on then return nil end
    local any, behind, dark = false, false, false
    for _, e in pairs(V.last) do
        if e.ok then return nil end
        any = true
        if e.why == "behind" then behind = true elseif e.why == "dark" then dark = true end
    end
    if not any then return "range" end
    return behind and "behind" or (dark and "dark" or "hidden")
end

-- for the menu
function V.report()
    ray_init()
    return {
        rays = R.native, err = R.err, blow_hooked = V.blow_hooked,
        night = ENV.night, night_how = ENV.night_how, roof = ENV.roof, lamp = ENV.lamp,
        lamp_how = ENV.lamp_how and (ENV.lamp_how.src .. ":" .. ENV.lamp_how.name) or nil,
        lamp_found = ENV.lamp_found or {},
        range = sight_range(),
    }
end

return V
