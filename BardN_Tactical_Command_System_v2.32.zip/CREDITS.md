# Tactical Command System — Crédits / Credits

Auteur / Author : **BardN**

---

## Français

### Code réutilisé avec autorisation

**Direct Pawn Control** — par **Hazzer**
Le « moteur 1 » de la caméra de ce mod (l'attache de la caméra sur un personnage, sa réaffirmation à chaque image, et le refus des types de contrôle de caméra 6 et 10) vient de Direct Pawn Control, **réutilisé avec l'autorisation expresse de son auteur** (19/11/2026). C'est là que cette méthode a été trouvée et éprouvée en jeu.

Les deux mods sont développés en compatibilité mutuelle : Direct Pawn Control peut prêter la caméra à la roue tactique pendant qu'un pion est joué, au lieu que les deux mods se la disputent.

**RPG Level Up**
Le « moteur 2 » de la caméra (déplacer le *point de visée* écrit par `updatePog`, plutôt que de changer le sujet de la caméra) vient de la caméra de RPG Level Up : la méthode, les noms et les trois pièges à éviter y ont été trouvés et éprouvés en jeu.

La police Quadraat (celle du jeu) **n'est pas livrée ici** : elle est utilisée si le zip de polices personnel de RPG Level Up est installé, sinon TeX Gyre Pagella (style Palatino) prend le relais.

Palatino Linotype (police de Windows, Linotype / Microsoft) **n'est pas livrée non plus** : c'est la police par défaut si le joueur copie `C:\Windows\Fonts\pala.ttf` dans `reframework\fonts`, sinon Pagella prend le relais.

### Images

Les icônes de vocation (`reframework/images/Tactical_Command_System/job_*.png`) proviennent de **Honest Vocation Icons** — par **Synmachus** (Nexus Mods, Dragon's Dogma 2, n° 1428, https://www.nexusmods.com/dragonsdogma2/users/8440111), utilisées avec l'accord de son auteur.

### Mods liés

- **Direct Pawn Control** (Hazzer) — facultatif. Tactical Command System fonctionne seul ; sans Direct Pawn Control, seule la prise de contrôle d'un pion est indisponible (le reste de la roue, les ordres, les postures, le ciblage et la caméra fonctionnent normalement).

### Polices

Les polices livrées dans `reframework/fonts/` sont sous **SIL Open Font License 1.1** ou **GUST Font License**. Le détail des copyrights et le texte complet des licences se trouvent dans `reframework/fonts/TCS_FONTS_LICENSE.txt` :
Noto Sans, EB Garamond, Inter, Lora, Caladea (OFL 1.1) ; TeX Gyre Pagella, Bonum et Schola (GUST Font License).

### Plateforme

Ce mod s'exécute sous **REFramework** (praydog).

---

## English

### Code reused with permission

**Direct Pawn Control** — by **Hazzer**
This mod's camera "engine 1" (attaching the camera to a character, re-asserting it every frame, and refusing camera control types 6 and 10) comes from Direct Pawn Control, **reused with the author's express permission** (2026-11-19). That is where the method was found and proven in game.

Both mods are developed for mutual compatibility: Direct Pawn Control can lend the camera to the tactical wheel while a pawn is being played, instead of the two mods fighting over it.

**RPG Level Up**
The camera "engine 2" (moving the *point of gaze* written by `updatePog`, rather than changing the camera's subject) comes from the RPG Level Up camera: the method, the names and the three traps to avoid were found and proven in game there.

The Quadraat font (the game's own) is **not shipped here**: it is used when RPG Level Up's personal font zip is installed, otherwise TeX Gyre Pagella (Palatino style) is used instead.

Palatino Linotype (a Windows font, Linotype / Microsoft) is **not shipped either**: it is the default font when the player copies `C:\Windows\Fonts\pala.ttf` into `reframework\fonts`, otherwise Pagella is used instead.

### Images

The vocation icons (`reframework/images/Tactical_Command_System/job_*.png`) come from **Honest Vocation Icons** — by **Synmachus** (Nexus Mods, Dragon's Dogma 2, no. 1428, https://www.nexusmods.com/dragonsdogma2/users/8440111), used with the author's agreement.

### Related mods

- **Direct Pawn Control** (Hazzer) — optional. Tactical Command System works on its own; without Direct Pawn Control only taking control of a pawn is unavailable (the rest of the wheel, orders, stances, targeting and the camera all work normally).

### Fonts

The fonts shipped in `reframework/fonts/` are under the **SIL Open Font License 1.1** or the **GUST Font License**. Full copyright statements and licence texts are in `reframework/fonts/TCS_FONTS_LICENSE.txt`:
Noto Sans, EB Garamond, Inter, Lora, Caladea (OFL 1.1); TeX Gyre Pagella, Bonum and Schola (GUST Font License).

### Platform

This mod runs under **REFramework** (praydog).
