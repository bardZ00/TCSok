-- TacticalCommandSystem/camera.lua
-- Looking at the pawn you are giving orders to.
--
-- Scroll onto a pawn in the wheel's top row and the camera turns to it; back on the Arisen, or wheel closed, it comes
-- home. The Arisen does not move and the game still thinks he is the one being played.
--
-- There are two ways to do that, and both are here. The menu picks one.
--
-- ============================================================================================
-- ENGINE 1 -- "the game's own camera, moved onto the pawn" (default)
-- ============================================================================================
-- The camera the player already has is simply told that the pawn is its subject:
--
--     MainCameraController.registerTargetObject(pawn's GameObject)
--
-- Everything else then happens by itself and happens properly, because the game is doing it: the distance, the height
-- over the shoulder, the collision with walls, the easing, the right stick panning. Nothing is computed here, so
-- nothing here can get it wrong.
--
-- Three things make it hold:
--
--   * **Re-assert every frame.** The game writes its own target object whenever it feels like it. Asking again each
--     frame costs one read (and a write only when the two have actually drifted apart), and the player never sees it.
--   * **Refuse the two cameras that would steal the view.** The game switches the camera's *control type* for its own
--     reasons, and two of those follow the player character rather than the camera's subject: type 6 (clinging to a
--     monster) and type 10 (the cinematic action camera). While a pawn is held, a pre-hook on `switchCamera` refuses
--     those two. Type 7 (bow aim) is deliberately left alone: if the Arisen aims, he should get his aim camera.
--   * **Never take a camera that is not ours.** Before the first attach, the camera's current subject must be the
--     Arisen. If it is anybody else, another mod is driving the camera -- Direct Pawn Control playing a pawn, say --
--     and this mod stays out of it entirely, because pulling the view off the character someone is actually playing is
--     the worst thing it could do. For the same reason the camera is handed back to whoever held it, not "to the
--     Arisen", and only if it is still on our pawn when we let go.
--
-- The attach, the per-frame re-assert and the refusal of control types 6 and 10 come from **Direct Pawn Control** by
-- Hazzer (reused with the author's express permission, 2026-11-19), where they were found and proven in game.
--
-- ============================================================================================
-- ENGINE 2 -- "the gaze point, written by hand" (the 0.1 - 0.3 engine, kept as a fallback)
-- ============================================================================================
-- Not by telling the camera to follow someone else, but by moving its *point of gaze*: the spot in the world it is
-- aimed at, written into `_Pog` by `updatePog`. That call is hooked and the point is moved onto the pawn just after
-- the game has set it. The game keeps doing everything else -- distance, collision, the player's own panning --
-- around a point that has quietly moved. Coming home needs no work: stop writing, and the next frame the game's own
-- point stands.
--
-- The method, the names and the three traps below are from the RPG Level Up camera, where they were found and proven
-- in game rather than guessed:
--
--   * **Smooth over time, not per call.** `updatePog` is not called at a steady rate, so moving a fixed fraction each
--     call lurches whenever the rate changes.
--   * **Aim in front of the pawn, not inside it.** The camera's own collision starts at the point of gaze; put that
--     inside the pawn's chest and the camera collides with the pawn and sticks to it. The point is pulled toward the
--     camera, out of the body.
--   * **Freeze the written point once it settles.** The computed point jitters by millimetres forever; writing every
--     one of those is a camera that never stops twitching.
--
-- Engine 1 needs none of those three: the game is placing the camera, and the game knows where its own character is.

local U = require("TacticalCommandSystem.utils")
local X = require("TacticalCommandSystem.in.shared")

local Focus = {}

local IN = X.IN

Focus.enabled = true             -- the player's settings, from the menu
Focus.engine = 1                 -- 1 = the game's camera moved onto the pawn, 2 = the gaze point written by hand
Focus.snap = false               -- engine 1: cut to the pawn instead of letting the game glide there
Focus.snap_switch = false        -- engine 1: while time is slowed, cut straight to a newly selected pawn (instant, abrupt)
Focus.switch_time = 0.30         -- s, real time: engine 1 travel between characters under slow motion
Focus.dpc_coexist = true         -- while Direct Pawn Control plays a pawn, aim by hand instead of fighting it for the camera
Focus.height = 1.0               -- engine 2 only: m above the pawn's feet that the camera aims at
Focus.distance = 0.0             -- m the camera is held back; 0 keeps the game's own
Focus.lift = 0.0                 -- m the camera itself is raised (not what it aims at)
Focus.centre = true              -- during the targeting step, bring the enemy into frame too
Focus.centre_force = 0.45        -- 0 = all on the character, 1 = all on the enemy
Focus.centre_mode = "aim"        -- "aim" (default since 1.04): the camera stays on the character and turns to put the
                                 -- enemy dead centre; "between": aim between the character and the enemy (experimental)

local PULL        = 0.7          -- m : the aim point sits this far in front of the pawn, out of its body
local TAU_TARGET  = 0.07         -- s : how fast the aim point chases the pawn
local TAU_WRITTEN = 0.06         -- s : how fast what is written chases the aim point
local TAU_HEADING = 0.05         -- s : how fast the pull direction follows the camera
local SPEED_MAX   = 10.0         -- m/s : the written point never moves faster, whatever the target does
local WAKE        = 0.03         -- m : a frozen point starts moving again once the aim is this far off
local SETTLED     = 0.006        -- m : below this the point counts as arrived
local SETTLE_TIME = 0.4          -- s : and is frozen after this long arrived
local STEP_MAX    = 0.1          -- s : the longest gap counted between two calls, so a stall does not jump the camera

local CENTRE_TAU = 0.18          -- s : engine 1, how fast the enemy is brought into frame and let go of again

-- "aim" framing (1.02). The yaw convention is measured, not guessed: 900 samples of the user's own RPG Level Up probe
-- 008, over the whole turn, give world heading = yaw + pi (spread 0.00004 rad). The pitch direction is not on record,
-- so it is read in game (see aim_pitch_sign) and the pitch is left alone until it is.
local AIM_TAU     = 0.15         -- s : how fast the camera turns onto the enemy
local AIM_HEIGHT  = 1.2          -- m : above the enemy's feet, when no spine joint is found
local AIM_JOINTS  = { "Spine_2", "Spine_1", "Spine_0", "Hip" }
local YAW_OFFSET  = math.pi      -- world heading = yaw + YAW_OFFSET
local PITCH_MAX   = 1.2          -- rad : never asked to look further up or down than this

local DIST_TAU = 0.25            -- s : how fast the camera slides to its new distance, and back
local WRITE_FLOOR = 0.002        -- below this the hand-over back to the game is done

local kept = nil                 -- the game's own distance and offset, held while they are overridden
local blend = 0                  -- 0 = the game's camera, 1 = ours; eased both ways
local blend_at = nil

local aim = nil                  -- engine 2: { x, y, z } the pawn's position, smoothed
local written = nil              -- engine 2: { x, y, z, frozen, still } what was last put in _Pog
local heading = nil              -- engine 2: the camera's own direction, smoothed
local last_call = nil
local target = nil               -- the character to look at, or nil for "leave the camera alone"
local mark = nil                 -- the enemy being targeted, to bring into frame alongside it

local pog_last = nil             -- engine 1: the point of gaze last shown, where a fast travel starts from
local glide = nil                -- engine 1: { x, y, z, t0 } a travel timed on the wall clock, under slow motion
local centre_blend = 0           -- engine 1: 0 = the game's own point, 1 = all the way onto the enemy
local centre_at = nil            -- engine 1: where that enemy was, kept so letting go can be eased

local AIM = {                    -- "aim" framing: the camera turned onto the enemy (1.02)
    last = nil,                  -- os.clock() of the last turn, so it is smoothed over time
    joint_of = nil,              -- the enemy the cached joint belongs to
    joint = nil,                 -- the name of its spine joint, or false when it has none
    pitch_sign = nil,            -- +1 / -1 once read in game; nil = the pitch is left alone
    pitch_votes = 0,             -- consistent readings so far (signed)
    turns = 0,                   -- frames the camera was turned
    failed = false,              -- setYaw could not be called on this camera
}
Focus.aim = AIM

Focus.report = { hooked = false, writes = 0, status = "idle" }

----------------------------------------------------------------------------------------------------
-- the camera the game is currently using
----------------------------------------------------------------------------------------------------
local function first_of(list)
    if not list then return nil end
    local one = U.safe_call(function() return list:call("get_Item", 0) end)
    if one then return one end
    return U.safe_call(function()
        local all = list:get_elements()
        return all and all[1]
    end)
end

local function controller()
    local manager = U.safe_call(function() return sdk.get_managed_singleton("app.CameraManager") end)
    if not manager then return nil end
    local mains = U.safe_call(function() return manager:call("get_MainCameraControllers") end)
        or U.safe_call(function() return manager:get_field("_MainCameraControllers") end)
    local main = first_of(mains)
    if not main then return nil end
    return U.safe_call(function() return main:call("get_CurrentCameraController") end)
        or U.safe_call(function() return main:get_field("_CurrentCameraController") end)
end

-- which way the camera is looking, from where it is to what it is aimed at
local function look_direction(ctrl)
    local from = U.safe_call(function() return ctrl:get_field("_Position") end)
    local at = U.safe_call(function() return ctrl:get_field("_Pog") end)
    if not (from and at) then return nil end
    local dx, dz = at.x - from.x, at.z - from.z
    if dx * dx + dz * dz < 1e-6 then return nil end
    return math.atan(dx, dz)
end

-- Where a character is, in the coordinates the camera itself works in.
--
-- Not the same as U.position(): that reads the universal position, which is what the rest of the mod measures
-- distances with, and in a world this size the two are far apart. Feeding the camera a universal position sends it to
-- the other side of the map, aimed at nothing.
local function render_position(chara)
    return U.safe_call(function()
        local p = chara:call("get_GameObject"):call("get_Transform"):call("get_Position")
        if type(p.x) ~= "number" then return nil end
        return { p.x, p.y, p.z }
    end)
end

local function shortest_turn(a)
    while a > math.pi do a = a - math.pi * 2 end
    while a < -math.pi do a = a + math.pi * 2 end
    return a
end

----------------------------------------------------------------------------------------------------
-- ENGINE 1 : the game's own camera, moved onto the pawn
--
-- Reused from Direct Pawn Control by Hazzer, with permission (2026-11-19).
----------------------------------------------------------------------------------------------------
local NAT = {
    home = nil,          -- the GameObject that held the camera when we engaged (normally the Arisen)
    held = nil,          -- the GameObject we have put the camera on
    hooked = false,
    no_guard = false,    -- switchCamera was not found: engine 1 runs without the two refusals
    refused = 0,
    refused_last = nil,
    reasserts = 0,
    stood_down = false,  -- another mod owns the camera; this one is staying out
}

Focus.native = NAT

local function game_object(chara)
    if not chara then return nil end
    return U.safe_call(function() return chara:call("get_GameObject") end)
end

local function same_obj(a, b)
    if not (a and b) then return false end
    local aa = U.safe_call(function() return a:get_address() end)
    local bb = U.safe_call(function() return b:get_address() end)
    return aa ~= nil and bb ~= nil and aa == bb
end

local function main_controller()
    local manager = U.safe_call(function() return sdk.get_managed_singleton("app.CameraManager") end)
    if not manager then return nil end
    return U.safe_call(function() return manager:call("getMainCameraController", 0) end)
end

local function camera_subject(mcc)
    return U.safe_call(function() return mcc:call("get_TargetObject") end)
end

-- the whole of engine 1, in five lines
local function attach_camera_to(go, snap)
    if not go then return false end
    local mcc = main_controller()
    if not mcc then return false end
    if not same_obj(camera_subject(mcc), go) then
        U.safe_call(function() mcc:call("registerTargetObject(via.GameObject)", go) end, "attach_camera_to")
        if snap then U.safe_call(function() mcc:call("onWarpTarget()") end) end
        NAT.reasserts = NAT.reasserts + 1
    end
    return true
end

-- The two control types that follow the player character instead of the camera's subject, and so would pull the view
-- off the pawn and back onto the Arisen. 7 (bow aim) is left alone on purpose.
local CT_CLING, CT_CINEMATIC = 6, 10
local SWITCH_SIG = "switchCamera(app.CameraDefine.ControlType, app.CameraSwitchInterpParam, "
    .. "app.PostEffectSetting, app.CameraDefine.ToPlayerCameraOption)"

-- Installed on the first attach, never removed, and inert unless a pawn is actually held -- so a stopped script can
-- never leave the Arisen without one of his own cameras.
local function install_switch_guard()
    if NAT.hooked then return end
    NAT.hooked = true
    local m = U.safe_call(function()
        local td = sdk.find_type_definition("app.MainCameraController")
        return td and td:get_method(SWITCH_SIG)
    end)
    if not m then NAT.no_guard = true; return end
    local ok = pcall(sdk.hook, m, function(args)
        local okh, res = pcall(function()
            if not NAT.held then return nil end
            local ct = sdk.to_int64(args[3]) & 0xFFFFFFFF
            if ct == CT_CLING or ct == CT_CINEMATIC then
                NAT.refused = NAT.refused + 1
                NAT.refused_last = ct
                return sdk.PreHookResult.SKIP_ORIGINAL
            end
            return nil
        end)
        if okh and res then return res end
    end, function(retval) return retval end)
    if not ok then NAT.no_guard = true end
end

-- Hand the camera back. Only if it is still on our pawn: if something else moved it in the meantime, that something
-- owns it now and must keep it. Nothing is touched when the scene is going away (the object we would write is gone).
local function nat_release()
    local held, home = NAT.held, NAT.home
    NAT.held, NAT.home, NAT.stood_down = nil, nil, false
    if not (held and home) then return end
    if not U.is_valid_obj(home) then return end
    local mcc = main_controller()
    if not mcc then return end
    local cur = camera_subject(mcc)
    if cur and not same_obj(cur, held) then return end
    attach_camera_to(home, Focus.snap)
end

-- A camera subject this mod may borrow from while the wheel is open: our own held pawn, the subject we started from,
-- the character the player is manually controlling, or the pawn Direct Pawn Control is currently playing. Anything
-- else is another mod looking at a third party, which this mod leaves alone. Reading DPC's played pawn by address
-- (from possess.lua's own handle) is what lets the player order other pawns, and have the camera follow them, while
-- a pawn is possessed -- without that, DPC re-asserting its pawn each frame reads as "someone took the camera".
-- The Arisen's own GameObject, remembered. `get_ManualPlayer` follows the body being played, so while Direct Pawn
-- Control has a pawn it no longer answers "the Arisen" -- and the camera can legitimately sit on the Arisen then
-- (DPC leaves him fighting on his own). So the handle is cached on every frame where nothing is possessed, which is
-- the one time the manual player and the Arisen are certainly the same character.
local arisen_cache = nil

-- Direct Pawn Control writes the camera's target object every frame for the pawn it plays, and cuts to it whenever
-- anything else moves it. From 0.9.170 its mod API can lend the camera out instead: claiming `camera.follow` asks
-- DPC to stop following the played pawn, and releasing the claim gives it back. That keeps engine 1 -- the game's
-- own camera, with its distance, framing and collisions -- usable while a pawn is played. 0.9.165 has no such
-- call; there, aiming by hand (engine 2) is the way to stay out of DPC's way (see Focus.effective_engine).
local function dpc_api()
    local a = rawget(_G, "DPC_API")
    if type(a) ~= "table" then return nil end
    if type(a.claim) ~= "function" or type(a.release) ~= "function" then return nil end
    return a
end

local function dpc_can_lend()
    return dpc_api() ~= nil
end

local lease_on = false
local lease_handle = nil

local function dpc_lend(on)
    on = on and true or false
    local a = dpc_api()
    if not a then lease_on, lease_handle = false, nil; return false end
    if on == lease_on then return lease_on end              -- already in the state asked for
    if on then
        local ok, h = pcall(a.claim, "camera.follow", { mod = "Tactical Command System" })
        if not (ok and h) then lease_on, lease_handle = false, nil; return false end
        lease_handle, lease_on = h, true
    else
        if lease_handle then pcall(a.release, lease_handle) end
        lease_handle, lease_on = nil, false
    end
    return true
end

Focus.dpc_lend_active = function() return lease_on end

local function possessing()
    local P = package.loaded["TacticalCommandSystem.possess"]
    if not (P and P.active) then return false end
    local ok, on = pcall(P.active)
    return ok and on == true
end

-- The address of the character Direct Pawn Control is currently playing, and whether a given wheel character is it.
local function is_played_pawn(chara)
    local P = package.loaded["TacticalCommandSystem.possess"]
    if not (P and P.active_addr) then return false end
    local ok, paddr = pcall(P.active_addr)
    if not (ok and paddr) then return false end
    local caddr = U.safe_call(function() return chara:get_address() end)
    return caddr ~= nil and caddr == paddr
end

local function known_arisen()
    if not possessing() then
        local go = game_object(U.get_player())
        if go then arisen_cache = go end
    end
    if arisen_cache and U.is_valid_obj(arisen_cache) then return arisen_cache end
    arisen_cache = nil
    return nil
end

-- Which engine is actually used this frame.
--
-- Engine 1 works by writing the camera's TargetObject. Direct Pawn Control writes the very same field, every frame,
-- for the pawn it is playing, and calls onWarpTarget() whenever the target is not that pawn -- read in DPC 0.9.165
-- (attach_camera_to, called from its per-frame possession tick while "Attach camera to pawn" is on, which is its
-- default). So while a pawn is possessed the two mods pull on one field sixty times a second: the wheel's view stops
-- following, and DPC's warp is what makes it jump. No amount of re-asserting wins that cleanly, and DPC's public
-- handle offers no way to ask it to let go of the camera.
--
-- Engine 2 never touches the target. It only moves the point of gaze, so DPC keeps its camera on the pawn it plays
-- and the wheel aims it, with nothing contested. It also eases on the wall clock, which the wheel's slow motion does
-- not reach -- so the travel stays quick and smooth instead of crawling. Hence: a possession switches the focus to
-- engine 2 for as long as it lasts, and engine 1 comes back by itself once the Arisen is played again.
function Focus.effective_engine()
    if Focus.engine == 1 and Focus.dpc_coexist ~= false and Focus.report.hooked
        and possessing() and not dpc_can_lend() then return 2 end
    return Focus.engine
end

local function borrowable_subject(cur)
    if not cur then return false end
    if same_obj(cur, NAT.held) or same_obj(cur, NAT.home) then return true end
    local pgo = game_object(U.get_player())
    if pgo and same_obj(cur, pgo) then return true end
    local ag = known_arisen()
    if ag and same_obj(cur, ag) then return true end
    local P = package.loaded["TacticalCommandSystem.possess"]
    if P and P.active_addr then
        local paddr = U.safe_call(function() return P.active_addr() end)
        local caddr = U.safe_call(function() return cur:get_address() end)
        if paddr and caddr and paddr == caddr then return true end
    end
    return false
end

-- Called once a frame while the wheel is on a pawn: engages on the first frame, re-asserts on the rest.
-- force_snap cuts to the pawn on a switch even when Focus.snap is off (used to keep switching quick under slow motion).
local function nat_engage(chara, force_snap)
    local go = game_object(chara)
    if not go then return false end
    local mcc = main_controller()
    if not mcc then return false end
    local cur = camera_subject(mcc)

    if not NAT.home then
        -- The camera has to be on someone the player legitimately is: the Arisen, or -- while Direct Pawn Control is
        -- playing a pawn -- that pawn. Anyone else means another mod is driving the camera onto a third party, and
        -- this mod does not take it away from them.
        if not borrowable_subject(cur) then
            NAT.stood_down = true
            return false
        end
        NAT.home = cur
        NAT.stood_down = false
        install_switch_guard()
    else
        if not U.is_valid_obj(NAT.home) then
            NAT.home, NAT.held = nil, nil
            return false
        end
        -- Once engaged, the wheel keeps the camera until it closes. Standing down here is what made the camera give
        -- up a second or two after a body switch: Direct Pawn Control settles its own camera shortly after possessing
        -- and that read as "somebody took the camera", so scrolling the wheel stopped moving the view. While the
        -- wheel is open the player is steering the camera on purpose, so the subject is simply re-asserted instead;
        -- closing the wheel hands it back (nat_release / Focus.handover).
    end

    if attach_camera_to(go, (Focus.snap or force_snap) and not same_obj(cur, go)) then
        NAT.held = go
        return true
    end
    return false
end

----------------------------------------------------------------------------------------------------
-- moving the point of gaze
----------------------------------------------------------------------------------------------------

-- Engine 1's only use for the gaze point. The camera is on the pawn and how it sits there is the game's business; the
-- one thing the game cannot know is which enemy the targeting step is on. So during that step the point it has just
-- computed is nudged towards that enemy -- from whatever the game decided, never from scratch, which is why none of
-- engine 2's three traps apply here. Letting go is eased the same way, over CENTRE_TAU, so the view does not jump
-- back when the targeting step closes.
local function engine1_centre()
    local ctrl = controller()
    if not ctrl then return end

    local now = os.clock()
    local step = math.max(0, math.min(STEP_MAX, now - (last_call or now)))
    last_call = now

    local on = (Focus.centre and mark and Focus.centre_mode ~= "aim") and true or false
    if on then
        local to = render_position(mark)
        if to then centre_at = to end
    end

    local goal = (on and centre_at) and math.max(0, math.min(1, Focus.centre_force or 0.45)) or 0
    centre_blend = centre_blend + (goal - centre_blend) * (1 - math.exp(-step / CENTRE_TAU))

    if centre_blend < WRITE_FLOOR or not centre_at then
        if goal == 0 then centre_blend, centre_at = 0, nil end
        return
    end

    local p = U.safe_call(function() return ctrl:get_field("_Pog") end)
    if not p or type(p.x) ~= "number" then return end

    local k = centre_blend
    ctrl:set_field("_Pog", Vector3f.new(
        p.x + (centre_at[1] - p.x) * k,
        p.y + (centre_at[2] - p.y) * k,
        p.z + (centre_at[3] - p.z) * k))
    Focus.report.writes = Focus.report.writes + 1
end

local function engine2_gaze()
    local ctrl = controller()
    if not ctrl then return end

    local at = render_position(target)
    if not at then return end
    local tx, ty, tz = at[1], at[2], at[3]

    -- During the targeting step the camera has two things to show, and showing one well means losing the other:
    -- aimed at the enemy, the character walks out of frame; aimed at the character, the enemy is a dot at the
    -- edge. So it aims between them, and how far along that line is the player's to set.
    if mark and Focus.centre_mode ~= "aim" then
        local to = render_position(mark)
        if to then
            local k = math.max(0, math.min(1, Focus.centre_force or 0.45))
            tx, ty, tz = tx + (to[1] - tx) * k, ty + (to[2] - ty) * k, tz + (to[3] - tz) * k
        end
    end

    local now = os.clock()
    local step = math.max(0, math.min(STEP_MAX, now - (last_call or now)))
    last_call = now

    -- the aim point follows the pawn
    if not aim then
        aim = { tx, ty, tz }
    else
        local k = 1 - math.exp(-step / TAU_TARGET)
        aim = { aim[1] + (tx - aim[1]) * k, aim[2] + (ty - aim[2]) * k, aim[3] + (tz - aim[3]) * k }
    end

    -- pulled out of the pawn's body, along the direction the camera is really looking
    local pull_x, pull_z = 0, 0
    local look = look_direction(ctrl)
    if look then
        heading = (heading == nil) and look
            or (heading + shortest_turn(look - heading) * (1 - math.exp(-step / TAU_HEADING)))
        pull_x = -math.sin(heading) * PULL
        pull_z = -math.cos(heading) * PULL
    end

    local wx = aim[1] + pull_x
    local wy = aim[2] + (Focus.height or 1.0)
    local wz = aim[3] + pull_z

    local w = written
    if not w then
        w = { x = wx, y = wy, z = wz }
        written = w
    end

    local gap2 = (wx - w.x) ^ 2 + (wy - w.y) ^ 2 + (wz - w.z) ^ 2
    if w.frozen and gap2 > WAKE * WAKE then
        w.frozen, w.still = false, nil
    end

    if not w.frozen then
        local k = 1 - math.exp(-step / TAU_WRITTEN)
        local sx, sy, sz = (wx - w.x) * k, (wy - w.y) * k, (wz - w.z) * k
        local travel = math.sqrt(sx * sx + sy * sy + sz * sz)
        local allowed = SPEED_MAX * math.max(step, 1 / 240)
        if travel > allowed then
            local r = allowed / travel
            sx, sy, sz = sx * r, sy * r, sz * r
        end
        w.x, w.y, w.z = w.x + sx, w.y + sy, w.z + sz

        if gap2 < SETTLED * SETTLED then
            w.still = w.still or now
            if now - w.still > SETTLE_TIME then w.frozen = true end
        else
            w.still = nil
        end
    end

    ctrl:set_field("_Pog", Vector3f.new(w.x, w.y, w.z))
    Focus.report.writes = Focus.report.writes + 1
end

-- Engine 1 under slow motion. The game's own glide runs in slowed time and crawls, and the rate behind it is not
-- known yet (probe 100_Camera). So on a switch the camera is warped onto the new character -- position, distance and
-- collision all the game's -- and the point of gaze alone is eased from where it was to the game's new one, on the
-- wall clock, over Focus.switch_time. The view travels quickly and smoothly whatever the slow motion.
local function engine1_glide()
    local ctrl = controller()
    if not ctrl then glide = nil; return end
    local p = U.safe_call(function() return ctrl:get_field("_Pog") end)
    if not p or type(p.x) ~= "number" then glide = nil; return end
    local t = (os.clock() - glide.t0) / math.max(0.05, Focus.switch_time or 0.30)
    if t >= 1 then glide = nil; return end
    local e = 1 - (1 - t) ^ 3                     -- ease out: leaves fast, lands softly
    ctrl:set_field("_Pog", Vector3f.new(
        glide.x + (p.x - glide.x) * e,
        glide.y + (p.y - glide.y) * e,
        glide.z + (p.z - glide.z) * e))
    Focus.report.writes = Focus.report.writes + 1
end

local function remember_pog()
    local ctrl = controller()
    local p = ctrl and U.safe_call(function() return ctrl:get_field("_Pog") end)
    if p and type(p.x) == "number" then
        pog_last = pog_last or {}
        pog_last.x, pog_last.y, pog_last.z = p.x, p.y, p.z
    end
end

local function after_update_pog(retval)
    if not target then
        pog_last, glide = nil, nil
        aim, written, heading, last_call = nil, nil, nil, nil
        centre_blend, centre_at = 0, nil
        return retval
    end

    if Focus.effective_engine() == 1 then
        -- nothing to write unless the targeting step has an enemy to bring in, and nothing at all on the Arisen
        if centre_blend > 0 or (Focus.centre and mark) then pcall(engine1_centre) end
        if glide then pcall(engine1_glide) end
        pcall(remember_pog)
    else
        pcall(engine2_gaze)
    end

    return retval
end

pcall(function()
    local td = sdk.find_type_definition("app.PlayerCameraControllerRoot")
    local m = td and td:get_method("updatePog")
    if m then
        sdk.hook(m, function() end, after_update_pog)
        Focus.report.hooked = true
    end
end)

----------------------------------------------------------------------------------------------------
-- "aim" framing (1.02): the enemy dead centre, the camera still on the character
--
-- Moving the point of gaze (the "between" framing) moves what the camera orbits, so the camera itself drifts towards
-- the enemy. Here the point of gaze is left where the game put it, on the character, and only the camera's angle is
-- turned. An orbit camera aimed from its pivot straight at the enemy has the enemy on its axis, wherever the camera
-- stands on that orbit: so the wanted direction is pivot -> enemy, and nothing depends on where the camera is now.
--
-- Written after updateManualCameraControl, where the user's RPG Level Up camera writes its angle (setYaw / setPitch)
-- and where the probe 008 showed the game applying it untouched, frame after frame. When the targeting step closes
-- nothing is written any more: the camera simply stays turned, and the player has it back.
----------------------------------------------------------------------------------------------------
local function wrap_angle(a) return shortest_turn(a) end

-- The point to centre: the enemy's spine when it has one, else a fixed height over its feet. Only the joint's *name*
-- is kept from one frame to the next, never the joint itself: it is looked up again each frame, so nothing is held on
-- an enemy that may be gone.
local function enemy_point(chara)
    local tf = U.safe_call(function() return chara:call("get_GameObject"):call("get_Transform") end)
    if not tf then return nil end
    if AIM.joint_of ~= chara then
        AIM.joint_of, AIM.joint = chara, false
        for _, name in ipairs(AIM_JOINTS) do
            if U.safe_call(function() return tf:call("getJointByName", name) end) then AIM.joint = name; break end
        end
    end
    if AIM.joint then
        local p = U.safe_call(function() return tf:call("getJointByName", AIM.joint):call("get_Position") end)
        if p and type(p.x) == "number" then return { p.x, p.y, p.z } end
    end
    local f = U.safe_call(function() return tf:call("get_Position") end)
    if f and type(f.x) == "number" then return { f.x, f.y + AIM_HEIGHT, f.z } end
    return nil
end

-- Which way the pitch turns is read from the camera itself: the slope of camera -> point of gaze against the pitch
-- the camera reports. Only a reading where the two agree in size counts (pitch 0 = level); five in a row decide.
local function aim_pitch_sign(ctrl, pitch)
    if AIM.pitch_sign or math.abs(pitch) < 0.05 then return end
    local from = U.safe_call(function() return ctrl:get_field("_Position") end)
    local at = U.safe_call(function() return ctrl:get_field("_Pog") end)
    if not (from and at) then return end
    local dx, dy, dz = at.x - from.x, at.y - from.y, at.z - from.z
    local flat = math.sqrt(dx * dx + dz * dz)
    if flat < 0.3 then return end
    local slope = math.atan(dy, flat)
    if math.abs(math.abs(slope) - math.abs(pitch)) > 0.06 then AIM.pitch_votes = 0; return end
    local vote = (slope * pitch > 0) and 1 or -1
    if AIM.pitch_votes * vote < 0 then AIM.pitch_votes = 0 end
    AIM.pitch_votes = AIM.pitch_votes + vote
    if math.abs(AIM.pitch_votes) >= 5 then AIM.pitch_sign = vote end
end

local function aim_turn()
    local ctrl = controller()
    if not ctrl then return end
    local pog = U.safe_call(function() return ctrl:get_field("_Pog") end)
    local ang = U.safe_call(function() return ctrl:call("get_Angle") end)
    local to = enemy_point(mark)
    if not (pog and ang and to and type(pog.x) == "number" and type(ang.y) == "number") then return end

    local now = os.clock()
    local step = math.max(0, math.min(STEP_MAX, now - (AIM.last or now)))
    AIM.last = now
    local k = 1 - math.exp(-step / AIM_TAU)

    local dx, dy, dz = to[1] - pog.x, to[2] - pog.y, to[3] - pog.z
    local flat = math.sqrt(dx * dx + dz * dz)
    if flat < 0.5 then return end                -- the enemy is on top of the character: no sensible direction

    local want_yaw = wrap_angle(math.atan(dx, dz) - YAW_OFFSET)
    local ok = pcall(function() ctrl:call("setYaw", ang.y + wrap_angle(want_yaw - ang.y) * k) end)
    if not ok then AIM.failed = true; return end
    AIM.turns = AIM.turns + 1

    if type(ang.x) == "number" then
        aim_pitch_sign(ctrl, ang.x)
        if AIM.pitch_sign then
            local want_pitch = AIM.pitch_sign * math.atan(dy, flat)
            want_pitch = math.max(-PITCH_MAX, math.min(PITCH_MAX, want_pitch))
            pcall(function() ctrl:call("setPitch", ang.x + (want_pitch - ang.x) * k) end)
        end
    end
end

local function after_manual_control(retval)
    if Focus.centre and Focus.centre_mode == "aim" and mark and target then
        pcall(aim_turn)
    else
        AIM.last = nil
    end
    return retval
end

pcall(function()
    local td = sdk.find_type_definition("app.RotateCameraControllerBase")
    local m = td and td:get_method("updateManualCameraControl")
    if m then
        sdk.hook(m, function() end, after_manual_control)
        AIM.hooked = true
    end
end)

----------------------------------------------------------------------------------------------------
-- how far back, and how high
--
-- Aiming is one thing; where the camera stands is another, and the game keeps that in its own camera settings --
-- a distance and an offset it reads afresh every frame. So they are written in the same place the game reads them,
-- and the values that were there are kept so they can be put back.
--
-- Nothing is written when both settings are left at zero, which is the default: then the camera keeps whatever
-- distance the player has set in the game's own options, and only what it looks at changes.
--
-- Both directions are eased. Snapping back the moment the wheel closes is as jarring as snapping out, and easing out
-- means still writing for a quarter second after the pawn is let go -- so the hand-over waits for the blend to reach
-- zero rather than happening the instant focus ends.
----------------------------------------------------------------------------------------------------
local function wants_placing()
    return target ~= nil and ((Focus.distance or 0) > 0 or (Focus.lift or 0) ~= 0)
end

local function place_camera()
    local now = os.clock()
    local step = math.max(0, math.min(STEP_MAX, now - (blend_at or now)))
    blend_at = now

    local goal = wants_placing() and 1 or 0
    blend = blend + (goal - blend) * (1 - math.exp(-step / DIST_TAU))
    if goal == 1 and blend > 1 - WRITE_FLOOR then blend = 1 end

    if blend < WRITE_FLOOR and goal == 0 then
        -- fully handed back: put the game's own values in one last time, then stop touching them
        if kept then
            local back = kept
            kept = nil
            pcall(function()
                local s = controller()._PlayerCameraSettings
                if back.dist then s._CameraDistance = back.dist end
                if back.off then s._PosOffset = Vector3f.new(back.off[1], back.off[2], back.off[3]) end
            end)
        end
        blend = 0
        return
    end

    pcall(function()
        local ctrl = controller()
        local set = ctrl and ctrl._PlayerCameraSettings
        if not set then return end

        if not kept then
            local off = set._PosOffset
            kept = {
                dist = tonumber(set._CameraDistance),
                off = off and { off.x, off.y, off.z } or nil,
            }
        end

        local base_dist = kept.dist
        if base_dist and (Focus.distance or 0) > 0 then
            set._CameraDistance = base_dist + (Focus.distance - base_dist) * blend
        end

        local o = kept.off
        if o and (Focus.lift or 0) ~= 0 then
            set._PosOffset = Vector3f.new(o[1], o[2] + Focus.lift * blend, o[3])
        end
    end)
end

pcall(function()
    re.on_application_entry("UpdateBehavior", function() pcall(place_camera) end)
end)

----------------------------------------------------------------------------------------------------
-- probe 100_Camera : find the rate the game eases its camera with
----------------------------------------------------------------------------------------------------
-- The wheel slows the whole game (via.Application GlobalSpeed), so the game's own camera travels to a newly selected
-- pawn in slowed time and crawls. The mod already undoes that for camera *rotation*, by scaling the return of
-- `app.RotateCameraControllerBase.getInputRotationSpeedRate` by 1 / Slow.cur (see in/slowmo.lua). The same trick would
-- give a fast *smooth* travel instead of the only other native option, an instant warp -- but it needs the name of the
-- method that carries the travel / interpolation rate, and that name cannot be guessed from outside the game.
--
-- So this is a probe, not a fix: run it from the Diagnostics panel and it lists every method on the camera classes
-- whose name looks like a rate and that takes no argument and returns a number. Report the list back and the right one
-- gets hooked in the next version.
local PROBE_TYPES = {
    "app.MainCameraController",
    "app.RotateCameraControllerBase",
    "app.CameraController",
    "app.PlayerCameraController",
    "app.CameraManager",
}
local PROBE_WORDS = { "speed", "rate", "interp", "lerp", "delta", "smooth", "follow", "blend", "ease", "damp" }

Focus.probe = { name = "100_Camera", ran = false, found = {}, scanned = 0 }

function Focus.run_probe()
    local out, scanned = {}, 0
    for _, type_name in ipairs(PROBE_TYPES) do
        local td = U.safe_call(function() return sdk.find_type_definition(type_name) end)
        if td then
            scanned = scanned + 1
            local methods = U.safe_call(function() return td:get_methods() end) or {}
            for _, m in ipairs(methods) do
                local mname = U.safe_call(function() return m:get_name() end)
                if mname then
                    local low = string.lower(mname)
                    local hit = false
                    for _, word in ipairs(PROBE_WORDS) do
                        if string.find(low, word, 1, true) then hit = true; break end
                    end
                    if hit then
                        local nparams = tonumber(U.safe_call(function() return m:get_num_params() end)) or -1
                        local rt = U.safe_call(function() return m:get_return_type() end)
                        local rtn = rt and U.safe_call(function() return rt:get_full_name() end) or "?"
                        if nparams == 0 and (rtn == "System.Single" or rtn == "System.Double") then
                            out[#out + 1] = type_name .. " : " .. mname .. "() -> " .. rtn
                        end
                    end
                end
            end
        end
    end
    table.sort(out)
    Focus.probe.ran = true
    Focus.probe.found = out
    Focus.probe.scanned = scanned
    log.info("[Tactical_Command_System] probe 100_Camera: " .. #out .. " candidate(s) on " .. scanned .. " type(s)")
    for _, line in ipairs(out) do log.info("[Tactical_Command_System] 100_Camera  " .. line) end
    return out
end

----------------------------------------------------------------------------------------------------
-- who to look at
----------------------------------------------------------------------------------------------------
-- Stops aiming. Engine 2 has nothing to put back: the game's own point of gaze stands again on the very next frame.
-- Engine 1 hands the camera back to whoever held it before.
function Focus.release()
    dpc_lend(false)
    target, mark = nil, nil
    aim, written, heading, last_call = nil, nil, nil, nil
    centre_blend, centre_at = 0, nil
    pog_last, glide = nil, nil
    if NAT.held or NAT.home then pcall(nat_release) end
    NAT.stood_down = false
    Focus.report.status = "idle"
    -- the distance and the offset are not put back here: place_camera eases them home over the next quarter second
    -- and hands them over itself, so the view slides back instead of jumping
end

Focus.forget = Focus.release

-- Steps out of the way without putting the camera back, for when another mod is about to take the very character we
-- are looking at (the wheel's take-control button, which hands the pawn to Direct Pawn Control). The camera is
-- already where it needs to be, so the quietest hand-over is to simply stop holding it: putting it back on the
-- Arisen first would show a flinch in the one or two frames before the other mod claims it.
function Focus.handover()
    dpc_lend(false)
    target, mark = nil, nil
    aim, written, heading, last_call = nil, nil, nil, nil
    centre_blend, centre_at = 0, nil
    NAT.held, NAT.home, NAT.stood_down = nil, nil, false
    Focus.report.status = "handed over"
end

-- Looks wherever the wheel is pointing: at the selected pawn while the wheel is open, and nowhere otherwise. Called
-- once a frame, so a pawn dismissed or killed under the wheel lets the camera go by itself.
function Focus.follow()
    if not Focus.enabled then
        if target or NAT.held then Focus.release() end
        return
    end

    local W = IN.W
    local entry = W.open and IN.current and IN.current() or nil
    local chara = entry and entry.chara or nil
    if not (chara and U.is_valid_obj(chara) and not U.is_dead(chara)) then
        if target or NAT.held then Focus.release() end
        return
    end

    -- the enemy being picked, while the targeting step is open
    local enemy = nil
    if Focus.centre and IN.current_target then
        local picked = IN.current_target()
        local who = picked and picked.chara
        if who and U.is_valid_obj(who) and not U.is_dead(who) then enemy = who end
    end

    -- The Arisen with nothing targeted used to end here, on the grounds that his camera is the one the player already
    -- has. But leaving that way let go of the hold -- and with it the guard that stops the game switching the camera
    -- type back -- so returning from a pawn to the Arisen reframed instantly while going out to a pawn glided: smooth
    -- one way, abrupt the other.
    --
    -- Under engine 1 the Arisen is now focused like anybody else: his game object is re-registered as the camera's
    -- subject, which the game glides to, and the hold stays until the wheel closes. When the camera is already on him
    -- that costs nothing -- attach_camera_to does nothing when the subject is already the right one. While a pawn is
    -- being played the Arisen really is somewhere else, so focusing him is a genuine move in that case.
    --
    -- Engine 2 keeps the early exit when the Arisen is the character being played: there the camera is his already and
    -- writing a point of gaze onto the player himself would only fight it.
    local is_pawn = (entry.kind ~= "arisen")
    if not is_pawn and not enemy and Focus.effective_engine() ~= 1 and not possessing() then
        if target or NAT.held then Focus.release() end
        return
    end

    local switched = false
    if chara ~= target then
        target = chara
        aim, written, heading, last_call = nil, nil, nil, nil   -- start the glide from where the camera is
        switched = true
    end
    mark = enemy                 -- changing enemy only moves the aim point, which glides there on its own

    -- Under slow motion the game's own camera glides to the new pawn in slowed time, which crawls. On the frame the
    -- focused character actually changes, cut straight to it instead, so switching between pawns stays quick.
    local slow_now = (U.Slow and U.Slow.cur or 1.0) < 0.999
    -- Without the cut, the switch is still warped, but eased by hand on the real clock (engine1_glide), so it is quick
    -- and never abrupt. That needs the updatePog hook; without it the game's own (slowed) glide is kept.
    local fast = switched and slow_now and not Focus.snap_switch and Focus.report.hooked and pog_last ~= nil
    local force_snap = switched and slow_now and (Focus.snap_switch or fast)

    if Focus.effective_engine() == 1 then
        -- The wheel is on the very pawn Direct Pawn Control is already playing and framing. Borrowing the camera here
        -- would stop DPC holding its player-follow framing, and the view would drift to the plainer target-object
        -- framing -- a small downward hop the instant the wheel opens. So the camera is left entirely to DPC on its
        -- own pawn; the lease is only taken once the player scrolls to someone else.
        if is_pawn and possessing() and is_played_pawn(chara) and not mark then
            dpc_lend(false)
            NAT.held, NAT.home, NAT.stood_down = nil, nil, false
            Focus.report.status = (entry.name or "pawn") .. " (DPC)"
            return
        end
        -- Everyone else -- pawn or Arisen -- is focused the same way, so the travel glides in both directions.
        if possessing() then dpc_lend(true) end          -- renewed every frame; lapses on its own if we stop
        local prev = camera_subject(main_controller())
        if not nat_engage(chara, force_snap) then
            Focus.report.status = NAT.stood_down
                and "stood down (another mod has the camera)"
                or "engine 1: no camera"
            return
        end
        -- start the timed travel only if the camera really moved to someone else
        if fast and not same_obj(prev, game_object(chara)) then
            glide = { x = pog_last.x, y = pog_last.y, z = pog_last.z, t0 = os.clock() }
        end
    elseif NAT.held then
        pcall(nat_release)       -- the engine was changed in the menu while a pawn was held
    end

    Focus.report.status = (entry.name or "pawn") .. (enemy and " + cible" or "")
end

return Focus
