-- TacticalCommandSystem/menu/binds.lua
-- Key / button assignment in the menu: the list of rebindable actions, the "press a key or a button" capture,
-- the opening-shortcut block and the full bindings list.

local IN  = require("TacticalCommandSystem.input")
local I18 = require("TacticalCommandSystem.i18n")
local C   = require("TacticalCommandSystem.config")
local P   = require("TacticalCommandSystem.possess")

local T = I18.pick   -- T("English", "Français")

local B = {}

local COLOR_OK, COLOR_WARN = 0xFF60E060, 0xFF5050FF   -- ABGR
local INFO = 0xFFC8C8C8                                -- neutral grey for information lines, same as menu.lua
local DPC_ONLY = { kb_lock_char = true, pad_lock_char = true }

----------------------------------------------------------------------
-- Rebindable actions (label in English, then French)
----------------------------------------------------------------------
local KB_ROWS = {
    { "kb_open",         "Open Wheel: key", "Ouvrir la roue : touche" },
    { "kb_open_mod",     "Open Wheel: 2nd key held first (optional, empty = single key)", "Ouvrir la roue : 2e touche à maintenir avant (facultative, vide = une seule touche)" },
    { "kb_next_pawn",    "Next character", "Personnage suivant" },
    { "kb_prev_pawn",    "Previous character", "Personnage précédent" },
    { "kb_confirm",      "Order and close (targeting: go)", "Ordonner et fermer (ciblage : valider)" },
    { "kb_stay",         "Order and stay in the wheel", "Ordonner et rester dans la roue" },
    { "kb_queue_toggle", "Add to the pawn's queue (on Stance / Cancel = all pawns)", "Ajouter à la file du pion (posture / annuler = tous les pions)" },
    { "kb_lock_skill",   "Lock / unlock the highlighted pawn skill to MANUAL ONLY (pawn never casts it by itself)", "Verrouiller / déverrouiller la compétence visée du pion en MANUEL SEUL (il ne la lance jamais seul)" },
    { "kb_lock_char",    "Lock / unlock the played character (the one closing the wheel returns to)", "Verrouiller / déverrouiller le personnage joué (celui vers qui la fermeture de la roue ramène)" },
    { "kb_cancel",       "Back / Close the wheel", "Retour / Fermer la roue" },
    { "kb_target_left",  "Targeting: enemy on the left (key or mouse button)", "Ciblage : ennemi à gauche (touche ou bouton de souris)" },
    { "kb_target_right", "Targeting: enemy on the right (key or mouse button)", "Ciblage : ennemi à droite (touche ou bouton de souris)" },
    { "kb_quick",        "Targeting a chargeable skill: quick version, forced", "Ciblage d'une compétence chargeable : version rapide forcée" },
}

local PAD_ROWS = {
    { "pad_open_trig",     "Open Wheel: button (held, see the hold time)", "Ouvrir la roue : bouton (maintenu, voir la durée de maintien)" },
    { "pad_open_hold",     "Open Wheel: 2nd button held first (optional, empty = single button)", "Ouvrir la roue : 2e bouton à maintenir avant (facultatif, vide = un seul bouton)" },
    { "pad_confirm_close", "Order (targeting, then launch) AND close the wheel", "Ordonner (ciblage, puis lancement) ET fermer la roue" },
    { "pad_queue_toggle",  "Add the order to the pawn's queue (wheel stays open; Stance / Cancel = all pawns)", "Ajouter l'ordre à la file du pion (la roue reste ouverte ; posture / annuler = tous les pions)" },
    { "pad_lock_skill",    "Lock / unlock the highlighted pawn skill to MANUAL ONLY (pawn never casts it by itself)", "Verrouiller / déverrouiller la compétence visée du pion en MANUEL SEUL (il ne la lance jamais seul)" },
    { "pad_quick",         "Targeting a chargeable skill: quick version, forced", "Ciblage d'une compétence chargeable : version rapide forcée" },
    { "pad_cancel_orders", "Cancel cell shortcut (Arisen: pending skill; pawn: queue, autonomous)", "Raccourci de la cellule Annuler (Insurgé : compétence en attente ; pion : file, autonome)" },
    { "pad_next_pawn_2",   "Next character (targeting: enemy on the right)", "Personnage suivant (ciblage : ennemi à droite)" },
    { "pad_prev_pawn",     "Previous character (targeting: enemy on the left)", "Personnage précédent (ciblage : ennemi à gauche)" },
    { "pad_cancel",        "Close the wheel (targeting: back to the wheel)", "Fermer la roue (ciblage : retour à la roue)" },
    { "pad_lock_char",     "Lock / unlock the played character (the one closing the wheel returns to)", "Verrouiller / déverrouiller le personnage joué (celui vers qui la fermeture de la roue ramène)" },
    { "pad_close_open",    "Extra button to close the wheel (optional)", "Bouton supplémentaire pour fermer la roue (facultatif)" },
}

local ROW = {}      -- key -> row, for both lists
for _, list in ipairs({ KB_ROWS, PAD_ROWS }) do
    for _, r in ipairs(list) do ROW[r[1]] = r end
end
local SAME_KIND = {}   -- key -> the list it belongs to (conflict detection stays inside one device)
for _, r in ipairs(KB_ROWS) do SAME_KIND[r[1]] = KB_ROWS end
for _, r in ipairs(PAD_ROWS) do SAME_KIND[r[1]] = PAD_ROWS end

-- "any" capture: where the first thing pressed goes
local ANY_TARGETS = {
    main = { kb = "kb_open",     pad = "pad_open_trig" },
    mod  = { kb = "kb_open_mod", pad = "pad_open_hold" },
}

----------------------------------------------------------------------
-- Capture. kind = "kb" (keyboard / mouse), "pad" (controller) or "any" (both: the first thing pressed wins).
-- Keys / buttons already held when the capture starts are ignored until released, so a stuck key cannot block it.
-- The 1..254 key scan only runs while a capture is open.
----------------------------------------------------------------------
local capture, flash = nil, nil

function B.capturing() return capture ~= nil end

local function start_capture(fields)
    fields.base_k = IN.keys_down_set()
    fields.base_p = IN.pad_mask_now()
    capture = fields
end

local function assign(key, val, what)
    C.binds[key] = val
    IN.BINDS[key] = val
    flash = { text = T("Assigned: ", "Assigné : ") .. what, t = os.clock() }
    capture = nil
    C.mark_dirty()
end

local function first_new_pad(mask, base)
    local fresh = mask & (~base)
    if fresh == 0 then return nil end
    for _, entry in ipairs(IN.PAD_BUTTON_LIST) do
        if entry.val ~= 0 and (fresh & entry.val) ~= 0 then return entry.val end
    end
end

-- Called from the menu every frame it is open
function B.update_capture()
    if not capture then return end
    local esc_ok, esc_down = pcall(function() return reframework:is_key_down(0x1B) end)
    if esc_ok and esc_down then capture = nil; return end

    local st = capture
    local keys, mask = IN.keys_down_set(), IN.pad_mask_now()
    for vk in pairs(st.base_k) do if not keys[vk] then st.base_k[vk] = nil end end   -- released: may be pressed again
    st.base_p = st.base_p & mask

    local new_vk
    for vk = 1, 254 do
        if keys[vk] and not st.base_k[vk] then new_vk = vk; break end
    end
    local new_pad = first_new_pad(mask, st.base_p)

    local kn, pn = IN.diag_scan(), IN.pad_names(mask)
    st.seen = T("Seen now - keyboard: ", "Vu en ce moment - clavier : ") .. (#kn > 0 and table.concat(kn, ", ") or "-")
        .. T("   controller: ", "   manette : ") .. (#pn > 0 and table.concat(pn, ", ") or "-")

    local any = ANY_TARGETS[st.target]
    if (st.kind == "kb" or st.kind == "any") and new_vk then
        local key = st.key or (any and any.kb)
        if key then assign(key, new_vk, T("keyboard ", "clavier ") .. I18.t(IN.get_vk_name(new_vk))) end
    elseif (st.kind == "pad" or st.kind == "any") and new_pad then
        local key = st.key or (any and any.pad)
        if key then assign(key, new_pad, T("controller ", "manette ") .. I18.t(IN.get_pad_name(new_pad))) end
    end
end

----------------------------------------------------------------------
-- Widgets
----------------------------------------------------------------------
local function in_conflict(key)
    local v = C.binds[key]
    if not v or v == 0 then return false end
    for _, r in ipairs(SAME_KIND[key]) do
        -- 2.20: "order and stay" (wheel) and "quick version" (targeting) never meet: they may share the middle button
        local pair = (key == "kb_stay" and r[1] == "kb_quick") or (key == "kb_quick" and r[1] == "kb_stay")
        if r[1] ~= key and not pair and C.binds[r[1]] == v then return true end
    end
    return false
end

local function bind_name(kind, v)
    return I18.t(kind == "kb" and IN.get_vk_name(v) or IN.get_pad_name(v))
end

local function draw_row(key, kind, idsuf)
    idsuf = idsuf or ""
    local listening = capture and capture.key == key
    local label
    if listening then
        label = (kind == "kb") and T("[ Press Key / Mouse (ESC Cancel) ]", "[ Appuie sur une touche / souris (ÉCHAP annule) ]")
                               or T("[ Press Pad Button (ESC Cancel) ]", "[ Appuie sur un bouton de manette (ÉCHAP annule) ]")
    else
        label = bind_name(kind, C.binds[key] or 0)
    end
    if imgui.button(label .. "##bind_" .. key .. idsuf) then start_capture({ key = key, kind = kind }) end
    imgui.same_line()
    if imgui.button(T("Clear", "Effacer") .. "##clr_" .. key .. idsuf) then
        C.binds[key] = 0
        IN.BINDS[key] = 0
        if listening then capture = nil end
        C.mark_dirty()
    end
    imgui.same_line()
    imgui.text(T(ROW[key][2], ROW[key][3]))
    if in_conflict(key) then
        imgui.same_line()
        imgui.text_colored(T("(also used by another action)", "(déjà utilisé par une autre action)"), COLOR_WARN)
    end
end

-- One-line summary of the opening shortcut for a device
local function shortcut_summary(kind)
    local ph, pt, km, kk = IN.open_binds()
    local a, b = ph, pt
    if kind == "kb" then a, b = km, kk end
    if b == 0 then return T("none", "aucun") end
    if a ~= 0 then return bind_name(kind, a) .. " + " .. bind_name(kind, b) .. T("   (two keys)", "   (deux touches)") end
    return bind_name(kind, b) .. T("   (single key)", "   (une seule touche)")
end

local function any_button(target, idle_label)
    local listening = capture and capture.kind == "any" and capture.target == target
    local txt = listening and T("[ Press a key OR a pad button (ESC cancels) ]", "[ Appuie sur une touche OU un bouton de manette (ÉCHAP annule) ]") or idle_label
    if imgui.button(txt .. "##tc_any_" .. target) then start_capture({ kind = "any", target = target }) end
end

-- Opening shortcut: ONE key / button alone, or a combination (a held key + a key); controller and keyboard at the same time.
function B.draw_opening_shortcut()
    imgui.text(T("Opening shortcut", "Raccourci d'ouverture") .. " :")
    imgui.text("   " .. T("Controller: ", "Manette : ") .. shortcut_summary("pad"))
    imgui.text("   " .. T("Keyboard: ", "Clavier : ") .. shortcut_summary("kb"))
    any_button("main", T("Assign the opening shortcut (key OR button)", "Assigner le raccourci d'ouverture (touche OU bouton)"))
    any_button("mod", T("Assign the optional 2nd key / button held first", "Assigner la 2e touche / le 2e bouton à maintenir avant (facultatif)"))
    if capture and capture.seen then imgui.text("   " .. capture.seen) end
    if flash and os.clock() - flash.t < 4 then imgui.text_colored("   " .. flash.text, COLOR_OK) end
    imgui.text(T("Or set each slot yourself:", "Ou règle chaque case toi-même :"))
    draw_row("pad_open_trig", "pad", "_o")
    draw_row("pad_open_hold", "pad", "_o")
    draw_row("kb_open", "kb", "_o")
    draw_row("kb_open_mod", "kb", "_o")
    if imgui.is_item_hovered() then
        imgui.set_tooltip(T("Single key: set only the first line (click Clear on the 2nd one).\n"
            .. "Two keys: hold the 2nd one, then press the first one.\n"
            .. "Click mode: the same shortcut closes the wheel without an order. Hold mode: see \"Wheel Opening\" above.\n"
            .. "A pad button converted into a key by Steam Input works as a keyboard key (it is read the same way).",
            "Une seule touche : ne règle que la première ligne (Effacer sur la 2e).\n"
            .. "Deux touches : maintiens la 2e, puis appuie sur la première.\n"
            .. "Mode clic : le même raccourci referme la roue sans ordre. Mode maintien : voir « Ouverture de la roue » plus haut.\n"
            .. "Un bouton de manette converti en touche par Steam Input marche comme une touche de clavier (lu de la même façon)."))
    end
end

-- What the mod sees right now (the scan runs only while this node is open)
function B.draw_key_diagnostic()
    if not imgui.tree_node(T("Key diagnostic (what the mod sees)", "Diagnostic des touches (ce que le mod voit)") .. "##tc_keydiag") then return end
    local names = IN.diag_scan()
    imgui.text(T("Keys seen down: ", "Touches vues enfoncées : ") .. (#names > 0 and table.concat(names, ", ") or T("none", "aucune")))
    imgui.text(T("Pad buttons mask: ", "Masque des boutons de manette : ") .. tostring(IN.diag_pad or 0))
    imgui.text(T("Last opening came from: ", "Dernière ouverture venue de : ") .. tostring(IN.last_open_src or "-"))
    imgui.tree_pop()
end

-- Full list of bindings
function B.draw_all_bindings()
    if imgui.button(T("Reset All Bindings to Default", "Remettre toutes les touches par défaut") .. "##tc_reset_binds") then
        IN.reset_binds()
        for k, v in pairs(IN.DEFAULT_BINDS) do C.binds[k] = v end
        capture = nil
        C.mark_dirty()
    end
    imgui.text(T("Click a binding, then press the new key / button. ESC cancels, Clear unbinds.",
        "Clique sur une touche, puis appuie sur la nouvelle touche / le nouveau bouton. ÉCHAP annule, Effacer retire l'assignation."))
    imgui.spacing()
    if imgui.tree_node(T("Keyboard & Mouse", "Clavier et souris") .. "##tc_kb_binds") then
        local dpc = P.available()
        for _, r in ipairs(KB_ROWS) do if dpc or not DPC_ONLY[r[1]] then draw_row(r[1], "kb") end end
        if not dpc then imgui.text_colored(T("Lock played character: requires Direct Pawn Control", "Verrouiller le personnage joué : nécessite Direct Pawn Control"), INFO) end
        imgui.tree_pop()
    end
    if imgui.tree_node(T("Controller / Gamepad", "Manette") .. "##tc_pad_binds") then
        local dpc = P.available()
        for _, r in ipairs(PAD_ROWS) do if dpc or not DPC_ONLY[r[1]] then draw_row(r[1], "pad") end end
        if not dpc then imgui.text_colored(T("Lock played character: requires Direct Pawn Control", "Verrouiller le personnage joué : nécessite Direct Pawn Control"), INFO) end
        imgui.tree_pop()
    end
end

return B
