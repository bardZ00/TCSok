-- TacticalCommandSystem/input.lua
-- Input system facade. The public table is IN; the work is split over several files, loaded in this order:
--   in/shared     the IN table and the wheel state (IN.W)
--   in/slowmo     slow motion while the wheel is open
--   in/binds      pad buttons, key names, default bindings, key reading
--   in/wheel      wheel slices, triggering a slice, targets, open / close / cycle
--   in/handle     per-frame state machine (shortcuts, opening, closing, confirming)
--   in/steer      mouse reader, stick / mouse steering, cursor sound

local U   = require("TacticalCommandSystem.utils")
local AI  = require("TacticalCommandSystem.cmd.init")
local SND = require("TacticalCommandSystem.sound")
local X   = require("TacticalCommandSystem.in.shared")

local IN = X.IN
local W  = IN.W

----------------------------------------------------------------------
-- Settings holders (written by config.lua, read by the input / drawing code)
----------------------------------------------------------------------
IN.open_mode = "toggle"          -- "toggle" (click / click, default since 2.19) or "hold"
IN.close_on_release = false      -- releasing the opening shortcut closes the wheel
IN.release_confirm = false       -- ... and validates the highlighted order
IN.TGT = U.TGT
IN.LOCKS = U.LOCKS
IN.LAMP = U.LAMP
IN.LOCKCFG = U.LOCKCFG
function IN.set_locks_callback(f) U.on_locks_changed = f end
function IN.lock_diag() return AI.lock_diag() end
function IN.clear_all_locks() AI.clear_all_locks() end

require("TacticalCommandSystem.in.slowmo")
require("TacticalCommandSystem.in.binds")
require("TacticalCommandSystem.in.wheel")
require("TacticalCommandSystem.in.handle")
require("TacticalCommandSystem.in.steer")

SND.enabled = function() return IN.sounds ~= false end
SND.install()

return IN
