-- TacticalCommandSystem/conf/vault.lua
-- Every setting's current value, and the one road a new value travels down.
--
-- A setting is not just a number in a table: changing one has to take effect on the wheel, and has to end up in the
-- file. So there is exactly one way in -- `put` -- and it does all four things in order: check the value is usable,
-- store it, make it take effect, and note that the file needs writing. Nothing writes into the values table directly,
-- because a value stored without being applied shows up as a setting that works after a restart and not before.
--
-- Two details the wheel needs:
--
--   * a value that cannot be used is dropped, not clamped into something else and not stored as nil. A colour read
--     back from a hand-edited file as the word "blue" leaves the setting at whatever it already was.
--   * a slider that costs something to apply -- one that rebuilds the wheel's artwork -- is applied once the player
--     stops dragging it, not sixty times a second on the way. `delay` is how long "stopped" is.

local S = require("TacticalCommandSystem.conf.settings")

local Vault = {}

Vault.values = {}                -- setting key -> its current value
Vault.preset = "default"         -- "default", "custom", or the name of one of Vault.presets
Vault.presets = {}               -- preset name -> { setting key -> value }: the player's own, saved from the menu

local pending = {}               -- setting key -> when a dragged slider's value should take effect

for _, def in ipairs(S.LIST) do
    Vault.values[def.key] = def.default
end

-- called whenever something changes, so the file gets written; set by conf/file.lua
Vault.on_change = nil

local function changed()
    if Vault.on_change then Vault.on_change() end
end

----------------------------------------------------------------------------------------------------
-- is this value usable
----------------------------------------------------------------------------------------------------
-- Returns the value fit to store, or nil when it is not one this setting can take. Values arrive from the menu, where
-- they are always the right shape, and from the saved file, where they are whatever is in the file.
local CHECK = {}

CHECK.bool = function(_, v)
    if type(v) == "boolean" then return v end
end

CHECK.float = function(def, v)
    if type(v) ~= "number" or v ~= v then return nil end       -- v ~= v catches not-a-number
    v = math.max(def.min, math.min(def.max, v))
    if def.round then v = math.floor(v + 0.5) end
    return v
end

CHECK.color = function(_, v)
    if type(v) ~= "number" or v ~= v then return nil end
    return math.floor(v) & 0xFFFFFFFF
end

CHECK.choice = function(def, v)
    for _, choice in ipairs(def.choices) do
        if choice.value == v then return v end
    end
end

function Vault.clean(def, v)
    local check = def and CHECK[def.kind]
    if not check then return nil end
    return check(def, v)        -- must not use `check(def,v) or nil`: a valid `false` would be turned into nil
end

----------------------------------------------------------------------------------------------------
-- making a value take effect
----------------------------------------------------------------------------------------------------
function Vault.apply(def)
    if not def or not def.apply then return end
    local ok, err = pcall(def.apply, Vault.values[def.key])
    if not ok then
        log.error("[Tactical_Command_System] setting " .. def.key .. " failed: " .. tostring(err))
    end
end

function Vault.apply_all()
    for _, def in ipairs(S.LIST) do Vault.apply(def) end
end

----------------------------------------------------------------------------------------------------
-- changing one
----------------------------------------------------------------------------------------------------
function Vault.put(key, v, now)
    local def = S.BY_KEY[key]
    v = Vault.clean(def, v)
    if v == nil or Vault.values[key] == v then return end

    Vault.values[key] = v
    if def.delay then
        pending[key] = (now or os.clock()) + def.delay
    else
        Vault.apply(def)
    end
    changed()
end

function Vault.reset(key)
    local def = S.BY_KEY[key]
    if not def then return end
    pending[key] = nil
    Vault.values[key] = def.default
    Vault.apply(def)
    changed()
end

-- Applies any slider the player has stopped dragging. Called once a frame.
function Vault.settle(now)
    if next(pending) == nil then return end
    for key, at in pairs(pending) do
        if now >= at then
            pending[key] = nil
            Vault.apply(S.BY_KEY[key])
        end
    end
end

----------------------------------------------------------------------------------------------------
-- presets
----------------------------------------------------------------------------------------------------
-- Settings marked `preset = false` are the player's own whatever happens -- the language, above all -- and never count
-- towards the preset or get restored by it.
function Vault.is_default()
    for _, def in ipairs(S.LIST) do
        if def.preset ~= false and Vault.values[def.key] ~= def.default then return false end
    end
    return true
end

-- True while every setting still holds what the named preset saved.
local function matches_saved(name)
    local saved = Vault.presets[name]
    if not saved then return false end
    for _, def in ipairs(S.LIST) do
        if def.preset ~= false and saved[def.key] ~= nil and Vault.values[def.key] ~= saved[def.key] then
            return false
        end
    end
    return true
end

-- The name to show at the top of the menu: one of the player's own presets while nothing has moved since it was
-- loaded, "default" on the recommended values, "custom" otherwise.
function Vault.named_preset()
    if Vault.presets[Vault.preset] then
        if matches_saved(Vault.preset) then return Vault.preset end
        return "custom"
    end
    if Vault.preset == "custom" or not Vault.is_default() then return "custom" end
    return "default"
end

-- The player's own presets, in alphabetical order (the menu shows them after Default and Custom)
function Vault.preset_names()
    local out = {}
    for name in pairs(Vault.presets) do out[#out + 1] = name end
    table.sort(out, function(a, b) return a:lower() < b:lower() end)
    return out
end

local function restore(key, value)
    local def = S.BY_KEY[key]
    local v = Vault.clean(def, value)
    if v == nil then return end
    Vault.values[key] = v
    pending[key] = nil
    Vault.apply(def)
end

function Vault.use_preset(name)
    Vault.preset = name
    if name == "default" then
        for _, def in ipairs(S.LIST) do
            if def.preset ~= false then restore(def.key, def.default) end
        end
    elseif Vault.presets[name] then
        -- a key the preset never saved (added since, or left to the player) keeps the value it has
        for key, value in pairs(Vault.presets[name]) do
            local def = S.BY_KEY[key]
            if def and def.preset ~= false then restore(key, value) end
        end
    end
    changed()
end

-- Saves the settings as they are now under `name` (an existing name is overwritten). Returns the name kept, or nil
-- when the name is unusable or the two reserved names were asked for.
function Vault.save_preset(name)
    name = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 32)
    if name == "" then return nil end
    local low = name:lower()
    if low == "default" or low == "custom" or low == "défaut" or low == "personnalisé" then return nil end
    local snap = {}
    for _, def in ipairs(S.LIST) do
        if def.preset ~= false then snap[def.key] = Vault.values[def.key] end
    end
    Vault.presets[name] = snap
    Vault.preset = name
    changed()
    return name
end

function Vault.delete_preset(name)
    if not Vault.presets[name] then return end
    Vault.presets[name] = nil
    if Vault.preset == name then Vault.preset = "custom" end
    changed()
end

return Vault
