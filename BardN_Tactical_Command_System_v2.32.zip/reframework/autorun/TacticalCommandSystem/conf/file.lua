-- TacticalCommandSystem/conf/file.lua
-- The saved file: where it is, what shape it has, and what to do about the names the mod used to go by.
--
-- One flat JSON file, every setting at the top level under its own key. Flat because the file has to survive being
-- read by a version of the mod that is older or newer than the one that wrote it: a key that has gone is skipped, and
-- one that has arrived takes its default. Nothing is ever read out of it without being checked first, since by the
-- time it comes back it may have been hand-edited, half-written by a crash, or left behind by another version.
--
-- Writing waits for quiet. A colour picker being dragged changes a setting on every frame, and saving on each one
-- would mean a hundred file writes for one colour; instead any change sets a time half a second out, and the file is
-- written once the player stops.
--
-- The mod has been renamed four times, and each name had its own file. A player coming from any of them is read from
-- their old file once, and from then on writes to this one -- so settings carry over without anything to do.

local IN = require("TacticalCommandSystem.input")
local S = require("TacticalCommandSystem.conf.settings")
local Vault = require("TacticalCommandSystem.conf.vault")

local File = {}

local HERE = "Tactical_Command_System/config.json"

-- older names of this mod, newest first; read only, and only when there is no file of our own
local FORMER = {
    "Modern_RPG_Combat_System/config.json",
    "BardN_Tactical_Command/config.json",
    "BardN_Battle_Orders/config.json",
    "BardN_Wheel_and_Orders/config.json",
}

local QUIET = 0.5                -- seconds of no changes before the file is written
local BIND_VER = 3               -- raised when the default bindings move, so saved ones for moved actions are dropped

local dirty, write_at = false, 0

----------------------------------------------------------------------------------------------------
-- writing
----------------------------------------------------------------------------------------------------
function File.touch()
    dirty = true
    write_at = os.clock() + QUIET
end

function File.write()
    dirty = false
    local out = {
        bind_ver = BIND_VER,
        preset = Vault.named_preset(),
        presets = Vault.presets,
        enabled = File.enabled,
        manual_locks = IN.LOCKS,
        binds = File.binds,
        no_target = IN.NOTARGET,
    }
    for key, value in pairs(Vault.values) do out[key] = value end

    local ok, err = pcall(json.dump_file, HERE, out)
    if not ok then
        log.error("[Tactical_Command_System] Could not save config: " .. tostring(err))
    end
end

-- on the way out (a script reset), write whatever was still waiting for quiet
function File.flush()
    if dirty then File.write() end
end

function File.tick(now)
    Vault.settle(now)
    if dirty and now >= write_at then File.write() end
end

Vault.on_change = File.touch

----------------------------------------------------------------------------------------------------
-- what else is in the file, beside the settings
----------------------------------------------------------------------------------------------------
File.binds = {}                  -- action name -> key or pad button
File.enabled = {}                -- module id -> on; absent means on

for name, key in pairs(IN.DEFAULT_BINDS) do File.binds[name] = key end

function File.is_enabled(id)
    local on = File.enabled[id]
    return on == nil or on == true
end

function File.set_enabled(id, on)
    File.enabled[id] = on and true or false
    File.touch()
end

----------------------------------------------------------------------------------------------------
-- reading
----------------------------------------------------------------------------------------------------
local function read_json()
    local ok, data = pcall(json.load_file, HERE)
    if ok and type(data) == "table" then return data end
    for _, path in ipairs(FORMER) do
        ok, data = pcall(json.load_file, path)
        if ok and type(data) == "table" then return data end
    end
    return nil
end

-- A setting, under its own key or under one of the names an earlier version saved it as.
local function value_from(data, def)
    local raw = data[def.key]
    -- fonts were shipped as BardN_TC_*.ttf, then as MRCS_*.ttf (Modern RPG Combat System), before the rename to Tactical Command System (TCS_*.ttf)
    if def.kind == "choice" and type(raw) == "string" then raw = (raw:gsub("^BardN_TC_", "TCS_"):gsub("^MRCS_", "TCS_")) end
    local v = Vault.clean(def, raw)
    if v ~= nil then return v end
    for _, former in ipairs(def.alias or {}) do
        v = Vault.clean(def, data[former])
        if v ~= nil then return v end
    end
    return nil
end

-- The player's own presets: name -> { setting key -> value }. Read one key at a time and checked like any other
-- value, since the file may have been hand-edited; a key that no longer exists is skipped.
local function read_presets(saved)
    for name, keys in pairs(saved) do
        if type(name) == "string" and type(keys) == "table" and name ~= "" then
            local snap = {}
            for key, value in pairs(keys) do
                local def = S.BY_KEY[key]
                if def and def.preset ~= false then
                    local v = Vault.clean(def, value)
                    if v ~= nil then snap[key] = v end
                end
            end
            if next(snap) then Vault.presets[name] = snap end
        end
    end
end

-- LOCKS[pawn name][skill id as a string] = true. The ids come back from JSON as strings or numbers depending on how
-- they were written, so they are made strings again on the way in.
local function read_locks(saved)
    for pawn, ids in pairs(saved) do
        if type(pawn) == "string" and type(ids) == "table" then
            for id, on in pairs(ids) do
                if on == true then
                    IN.LOCKS[pawn] = IN.LOCKS[pawn] or {}
                    IN.LOCKS[pawn][tostring(id)] = true
                end
            end
        end
    end
end

local function read_no_target(saved)
    for id, on in pairs(saved) do
        local number = tonumber(id)
        if type(on) == "boolean" and number then
            IN.NOTARGET[tostring(math.floor(number))] = on
        end
    end
end

-- Bindings are taken one by one from the defaults, so an action added since the file was written gets its default
-- rather than nothing, and anything in the file that is not a key number is ignored.
local function read_binds(saved, version)
    if (tonumber(version) or 0) < BIND_VER then
        -- nothing to move yet: this is the first version of the file under this name
        File.touch()
    end
    for name, default in pairs(IN.DEFAULT_BINDS) do
        File.binds[name] = (type(saved[name]) == "number") and saved[name] or default
    end
    -- 2.07: the keyboard "manual only" lock had no key in 2.05-2.06; a file from then that still has none gets F
    if (tonumber(version) or 0) < 2 and saved.kb_lock_skill == 0 then File.binds.kb_lock_skill = IN.DEFAULT_BINDS.kb_lock_skill end
    -- 2.14: the controller layout was redone; a button still on its old default moves to the new one (a button the
    -- player chose stays where it is)
    if (tonumber(version) or 0) < 3 then
        local OLD = { pad_confirm_stay = 512, pad_queue_toggle = IN.BTN.X, pad_lock_skill = 4096,
                      pad_lock_char = 8192, pad_cancel_orders = 2048 }
        for name, old in pairs(OLD) do
            if saved[name] == nil or saved[name] == old then File.binds[name] = IN.DEFAULT_BINDS[name] end
        end
        File.binds.pad_confirm_stay = 0                                       -- gone from the controller
        if saved.pad_lock_skill == 0 then File.binds.pad_lock_skill = IN.DEFAULT_BINDS.pad_lock_skill end
        -- no controller button at all to open the wheel: back to the default (LB held)
        if saved.pad_open_trig == 0 then File.binds.pad_open_trig = IN.DEFAULT_BINDS.pad_open_trig end
    end
end

function File.read()
    local data = read_json()
    if data then
        for _, def in ipairs(S.LIST) do
            local v = value_from(data, def)
            if v ~= nil then Vault.values[def.key] = v end
        end
        if type(data.enabled) == "table" then File.enabled = data.enabled end
        if type(data.presets) == "table" then read_presets(data.presets) end
        if data.preset == "custom" then Vault.preset = "custom"
        elseif type(data.preset) == "string" and Vault.presets[data.preset] then Vault.preset = data.preset end
        if type(data.manual_locks) == "table" then read_locks(data.manual_locks) end
        if type(data.no_target) == "table" then read_no_target(data.no_target) end
        if type(data.binds) == "table" then read_binds(data.binds, data.bind_ver) end
    end

    IN.set_binds(File.binds)
    Vault.apply_all()
    IN.set_locks_callback(File.touch)
    IN.on_notarget_changed = File.touch
end

return File
