-- TacticalCommandSystem/data.lua
-- What the mod knows about Dragon's Dogma 2, and the numbers it was tuned with.
--
-- Two different kinds of thing live here, and they are kept apart:
--
--   * the game's own facts -- skill numbers, the names of its action files, which vocation owns what. None of this is
--     a choice; it is what the game has, written down.
--   * the mod's own numbers -- how long to wait for a charge, how far an escorting pawn may drift, what colour a panel
--     is. Every one of these was settled by playing with it.
--
-- The skill table is built rather than listed. Left to itself the game is almost perfectly regular: skill "Guillotine"
-- of the thief lives in job04_theif\job04_guillotine.user and its actions are named after it. So a skill is one line --
-- its number and its name -- and only the two dozen that break the pattern say anything more. Listing all hundred in
-- full meant a hundred chances to mistype a path that fails silently in the middle of a fight.

local D = {}

D.TAU = math.pi * 2

----------------------------------------------------------------------------------------------------
-- vocations
----------------------------------------------------------------------------------------------------
D.JOB_INFO = {
    [1]  = { name = "FIGHTER",          code = "FTR-01", col = 0xFF505880 },
    [2]  = { name = "ARCHER",           code = "ARC-02", col = 0xFF68B870 },
    [3]  = { name = "MAGE",             code = "MGE-03", col = 0xFFFFC870 },
    [4]  = { name = "THIEF",            code = "THF-04", col = 0xFF40C840 },
    [5]  = { name = "WARRIOR",          code = "WAR-05", col = 0xFF4888E8 },
    [6]  = { name = "SORCERER",         code = "SOR-06", col = 0xFFD888F0 },
    [7]  = { name = "MYSTIC SPEARHAND", code = "MYS-07", col = 0xFFE0A860 },
    [8]  = { name = "MAGICK ARCHER",    code = "MAR-08", col = 0xFFC8B870 },
    [9]  = { name = "TRICKSTER",        code = "TRK-09", col = 0xFFD8A0E8 },
    [10] = { name = "WARFARER",         code = "WFR-10", col = 0xFFB0B8C0 },
}

D.DEFAULT_JOB_INFO = { name = "PAWN UNIT", code = "PWN-00", col = 0xFFA0B8C8 }

-- Width over height of each vocation emblem. The drawing keeps each picture's real shape; this is only used to centre
-- it in its medallion.
D.JOB_ICON_ASPECT = {
    [1] = 137 / 156, [2] = 137 / 156, [3] = 137 / 156, [4] = 137 / 156, [5] = 161 / 166,
    [6] = 161 / 166, [7] = 162 / 166, [8] = 162 / 166, [9] = 161 / 166, [10] = 162 / 166,
}

D.MELEE_JOBS  = { [1] = true, [4] = true, [5] = true }
D.CASTER_JOBS = { [3] = true, [6] = true }

----------------------------------------------------------------------------------------------------
-- colours
--
-- Written as ABGR (0xAABBGGRR), which is the order imgui wants them in, not the RGB of an image editor: the red and
-- blue of a hex colour read the other way round here. Only the parts drawn by imgui use these -- the wheel's own
-- artwork carries its colours in the pictures.
----------------------------------------------------------------------------------------------------
D.COL = {
    PANEL       = 0xE60D0E11,     -- the dark panel behind a cell, used when D2DX is not installed
    PANEL_HOV   = 0xF01C2430,
    GOLD        = 0xFF5B9AC9,     -- frames
    GOLD_BRIGHT = 0xFF92CEF3,     -- highlights, vocation names, the tag of an active stance
    AMBER       = 0xFF50B8F0,     -- warnings: low stamina, recovering
    GREEN       = 0xFF7ADB6F,     -- health, an order under way
    STAMINA     = 0xFF54B4E0,
    RING_STAM   = 0xFFD0E4ED,     -- the stamina half of the ring: ivory, so it is never a vocation colour
    RING_TRACK  = 0xFF1C1816,     -- the empty part of the ring
    BAR_HP_BG   = 0xE6233023,
    BAR_ST_BG   = 0xE61A2933,
    TEXT        = 0xFFDCE9F2,
    MUTED       = 0xFF78858D,
    SHADOW      = 0xF0000000,
}

-- Colour each vocation's tinted artwork is dyed with (0 = the neutral bronze), as ABGR
D.TINT_COL = {
    [0] = 0xFF558AB0, [1] = 0xFF4D45C2, [2] = 0xFF2BAED2, [3] = 0xFFC8A33F,
    [4] = 0xFF4AB06D, [5] = 0xFF3A32B4, [6] = 0xFFDC6A4A,
}

----------------------------------------------------------------------------------------------------
-- stances and the queue
----------------------------------------------------------------------------------------------------
D.MAX_QUEUE      = 3              -- orders a pawn may have waiting behind the one it is doing
D.QUEUE_CHAIN_DT = 0.25           -- s : beat left between one queued order and the next
D.LEASH_DIST     = 5.5            -- m : how far an escorting pawn may drift before being sent back
D.LEASH_REFIRE   = 1.2            -- s : and how often it may be sent
D.STANCE_TICK_DT = 0.35           -- s : how often a stance is pressed back onto a pawn

D.TARGET_MAX     = 8              -- enemies offered in the targeting step, nearest first
D.TARGET_REFRESH = 0.25           -- s : how often that list is read again while the wheel is open

-- Order the stance cell cycles through
D.STANCE_LIST = { "free", "close", "wait", "ranged" }

D.STANCE_LABELS = {
    free   = "STANCE: FREE",
    wait   = "STANCE: HOLD",
    close  = "STANCE: ESCORT",
    ranged = "STANCE: RANGED",
}

-- What a pawn holding its distance must not do: every one of these closes the gap it was told to keep
D.RANGED_BLOCK_STEMS = {
    "ch1_moveapproach",
    "move_straight_fixeddash",
    "common_clingcliff",
    "ch1_springboardjumping",
}

-- The game's own shared action packs, which the stances push onto a pawn directly
D.COMMON_PACKS = {
    IDLE       = "AppSystem\\AI\\ActionInterface\\ActInterPackData\\Common\\Idle.user",
    RUN_TARGET = "AppSystem\\AI\\ActionInterface\\ActInterPackData\\ch1\\ch1_Move_Run_Target.user",
    APPROACH   = "AppSystem\\AI\\ActionInterface\\ActInterPackData\\ch1\\ch1_MoveApproach.user",
}

----------------------------------------------------------------------------------------------------
-- how long the engine waits for things
--
-- All in game seconds, which run slowly while the wheel is open. Every one of these is a ceiling, not a schedule: an
-- order normally finishes long before any of them. They exist because a pawn can be knocked down, cornered, or quietly
-- decide to do something else, and nothing says so -- without a ceiling the pawn would be held by an order that is
-- never going to happen.
----------------------------------------------------------------------------------------------------
D.START_MAX      = 8.0            -- waiting for the skill's own action to appear at all
D.ORDER_MAX      = 20.0           -- the whole order, start to finish
D.CAST_STUCK     = 8.0            -- a cast that never ends
D.READY_MAX      = 3.3            -- held at the ready, never released
D.READY_MAX_AI   = 4.5            -- the same, for a skill whose aiming was handed back to the pawn
D.CHARGE_SLACK   = 0.3            -- grace on top of a charge time before calling it hung
D.SLOWEST_RATE   = 0.65           -- the slowest the game ever charges a spell, as a fraction of normal
D.HEAL_AI_MAX    = 5.0            -- how long a heal keeps its own aim before the pawn gets it back
D.FREE_WAIT      = 1.0            -- a pawn thinking its own thoughts this long has ignored the order
D.REAPPLY_DT     = 0.25           -- how often muted decisions are muted again

-- a pawn that is getting nowhere
D.UNSTUCK_AFTER  = 1.0            -- never call it stuck sooner than this after the order
D.UNSTUCK_STILL  = 0.7            -- standing still, doing nothing, for this long
D.UNSTUCK_CLOSER = 0.5            -- m : ground gained that counts as progress rather than being stuck
D.UNSTUCK_REFIRE = 0.3            -- pause after cutting its action before ordering again
D.LAYER_STUCK    = 1.5            -- stuck in the same action this long

-- a pawn knocked out of its skill
D.RETRY_CLEAR    = 0.3            -- steady on its feet this long before trying again
D.RETRY_WAIT     = 5.0            -- give up waiting for it to recover
D.RETRY_MAX      = 2              -- attempts, after which the order is dropped
D.ISDMG_MAX      = 1.0            -- the game's own damage flag sometimes sticks: stop believing it after this

----------------------------------------------------------------------------------------------------
-- the skills
----------------------------------------------------------------------------------------------------
local PACK_ROOT = "AppSystem\\ai\\actioninterface\\actinterpackdata\\"

-- Each vocation's own folder. The thief's is misspelled in the game; it has to be misspelled here too.
local JOB_FOLDER = {
    [1] = "job01_fighter",
    [2] = "job02_archer",
    [3] = "job03_mage",
    [4] = "job04_theif",
    [5] = "job05_warrior",
    [6] = "job06_sorcerer",
}

-- The skills, by vocation: skill number, name, and only what the pattern does not already give.
--
--   file     the pack file, when it is not jobNN_<name in lower case>
--   target   "enemy" unless said otherwise: "player" for anything cast on the party, "self" for a self-buff
--   keys     the words the skill's own actions are named after, when they are not just the name
--   charge   seconds the spell takes to charge, for the vocations that charge
--   stance   a launch pose, which is held until ordered again rather than performed
--   and the handful of one-off flags underneath them
local SKILLS = {
    [1] = {   -- fighter
        { 1,   "BlinkStrike" },
        { 2,   "RisingLunge",       file = "job01_risinglunge_standard" },
        { 3,   "CymbalAttack",      file = "pawn_job01_cymbalattack" },
        { 4,   "FullMoonSlash",     full = { stage = "job01_fullmoonslashlvexstart", normal = "Job01_FullMoonSlashLvExFinish",
                                    full = "Job01_FullMoonSlashLvExLoop", from = 0.20, after = 0.8 } },   -- 2.30: asked from 0.20 s (0.50 never took)
        { 5,   "FighterLaunch",     file = "job01_springboard_01", target = "player", keys = { "springboard" }, stance = true },
        { 6,   "ShieldSummons",     file = "pawn_job01_shieldsummons_targetmember", target = "player", ally = true },   -- 2.31
        { 7,   "ViolentStab" },
        { 8,   "HindsightSlash" },
        { 9,   "FullMoonGuard",     target = "player" },
        { 10,  "ShieldCounter" },
        { 11,  "DivineDefense",     target = "player" },
        { 12,  "BravesRaid" },
        { 102, "RushAttack" },
        { 103, "Ascertain",         toggle = true, off = "Job01_AscertainEnd" },   -- 2.27: off = the action that ends it   -- Shield Precision (confirmed 2.17): ordering it again puts it away
    },
    [2] = {   -- archer
        { 13,  "ThreefoldArrow" },
        { 14,  "TriadShot" },
        { 15,  "BodyBinder" },
        { 16,  "MeteorShot" },
        { 17,  "SpecialAllowBomb",   file = "job02_specialallowbomb_01" },
        { 18,  "SpecialAllowWater",  file = "job02_specialallowwater_01" },
        { 19,  "SpecialAllowOil",    file = "job02_specialallowoil_01" },
        { 20,  "SpecialAllowPoison", file = "job02_specialallowpoison_01" },
        { 21,  "RandomShot" },
        { 22,  "WhirlingArrow" },
        { 23,  "FullBlast" },
        { 104, "FlightShot" },
        { 105, "HeavyRain",          file = "job02_heavyrain_combo3" },
    },
    [3] = {   -- mage
        { 24,  "Firestorm",         charge = 2.5 },
        { 25,  "Levin",             file = "job03_thunderrain", charge = 2.5, keys = { "thunderrain", "levin" }, ready_max = 5.0 },
        { 26,  "Frigor",            charge = 3.0 },
        { 27,  "SpellStockRelease", target = "player", keys = { "spellstock" } },
        { 28,  "GuardBit",          file = "job03_guardbit_lv1", target = "player", charge = 3.0 },
        { 29,  "FireBoon",          target = "player", charge = 2.5, ally = true },   -- 2.31: aimed at an ally
        { 30,  "IceBoon",           target = "player", charge = 2.5, ally = true },
        { 31,  "ThunderBoon",       target = "player", charge = 2.5, ally = true },
        { 32,  "HolyShine",         file = "job03_holyshine_attack", charge = 3.0 },
        { 33,  "CureSpot",          target = "player", charge = 2.5 },
        { 34,  "HasteSpot",         target = "player", charge = 3.0 },
        { 35,  "FullRecover",       target = "player", charge = 3.5, ally = true },
        { 36,  "SpellBreak",        charge = 3.5 },
        { 37,  "HolyGlare",         target = "player", charge = 10.0, keys = { "holyglare", "magicbarrier" }, hold_cast = 0.5 },
        { 106, "DivineShot",        release_ai = true },
        { 107, "Reraise",           target = "player" },
    },
    [4] = {   -- thief
        { 38,  "CuttingWind" },
        { 39,  "Guillotine" },
        { 40,  "Attract",           file = "job04_attract_01" },
        { 41,  "ParryCounter" },
        { 42,  "AbsoluteAvoidance" },
        { 43,  "HollowOut",         file = "job04_hollowout_01" },
        { 44,  "FlameBlade",        target = "self" },
        { 45,  "SmokeScreen",       file = "job04_smoke" },
        { 46,  "RemoteBomb",        file = "job04_remotebomb_01" },
        { 47,  "WindWave" },
        { 48,  "Stealth",           target = "self" },
        { 49,  "Snatch" },
        { 101, "FakeMaster" },
        { 108, "AdvancedTrigger" },
        { 109, "CarpetBombing" },
    },
    [5] = {   -- warrior
        { 50,  "HeavyRunningThrust" },
        { 51,  "HorizontalSlash",   keys = { "horizontalslash", "horizonalslash" },  -- the game spells it both ways
                                    full = { stage = "job05_horizonalslash", normal = "Job05_HorizonalSlashNormal",
                                             full = "Job05_HorizonalSlashFull", from = 1.30, from_blood = 0.30, after = 1.8 } },   -- 2.30 (Arisen at the glow: 1.57 s)
        { 52,  "CrescentSlash",     full = { stage = "job05_crescentslash", normal = "Job05_CrescentSlashNormal",
                                             full = "Job05_CrescentSlashFull", from = 1.40, from_blood = 0.30, after = 1.9 } },    -- 2.30 (Arisen at the glow: 1.67 s)
        { 53,  "CycloneSlash" },
        { 54,  "GroundDrill" },
        { 55,  "CounterAttack",     file = "job05_counterattack_01" },
        { 56,  "WarCry",            file = "job05_warcry_targetmember", target = "player" },
        { 57,  "LandSlide",         full = { stage = "job05_landslide", normal = "Job05_LandSlideNormal",
                                             full = "Job05_LandSlideFull", from = 1.70, from_blood = 0.30, after = 2.2 } },        -- 2.30 (Arisen at the glow: 1.95 s)
        { 58,  "IndomitableLash",   full = { stage = "job05_indomitablelash", normal = "Job05_IndomitableLashNormal",
                                         full = "Job05_IndomitableLashFull", from = 1.85, from_blood = 0.30, after = 2.9 } },  -- 2.30 (Arisen at the glow: 2.14 s)
        { 59,  "Guts",              target = "player" },
        { 60,  "WarriorLaunch",     file = "job05_springboard_01", target = "player", keys = { "springboard" }, stance = true },
        { 61,  "ArcOfObliteration", full = { stage = "job05_arcofobliteration", normal = "Job05_ArcOfObliterationNormal",
                                    full = "Job05_ArcOfObliterationEnd", from = 4.20, after = 5.0,  -- 2.28 (2.26: 3.0 came out before the glow)
                                    skip = "job05_superarcofobliteration" } },   -- 2.29: phase 2 variant, left alone
        { 110, "DashSlashUp" },
        { 111, "ScarletVow",        target = "player" },
    },
    [6] = {   -- sorcerer
        { 62,  "Salamander" },
        { 63,  "Blizzard" },
        { 64,  "MineVolt" },
        { 65,  "SaintDrain" },
        { 66,  "RockBeat" },
        { 67,  "AddFlare" },
        { 68,  "MeteorFall",        hold_cast = 1.5, ready_max = 5.0, wait_ai = true },
        { 69,  "VortexRage",        wait_ai = true },
        { 112, "ThunderWhip" },
        { 113, "FrozenStorm" },
    },
}

-- the flags each entry may carry beyond the pattern, copied across as given
-- 2.08: chargeable skills (entry "full") are ordered charged unless the player asks for the quick one in the
-- targeting step (X / middle mouse button). That choice is handed to the next order only, then forgotten.
D.charge_quick_once = nil

local CARRIED = { "charge", "stance", "hold_cast", "ready_max", "wait_ai", "release_ai", "toggle", "full", "off", "ally" }

D.ORDERS = {}
for job, list in pairs(SKILLS) do
    for _, entry in ipairs(list) do
        local id, name = entry[1], entry[2]
        local target = entry.target or "enemy"
        local ord = {
            name   = name,
            job    = job,
            target = target,
            keys   = entry.keys or { name:lower() },
            pack   = PACK_ROOT .. JOB_FOLDER[job] .. "\\" .. (entry.file or (JOB_FOLDER[job]:sub(1, 5) .. "_" .. name:lower())) .. ".user",
        }
        -- The mage's decisions are named exactly after their packs, so the loose keyword match is never needed and
        -- would only let one spell answer for another. Every other vocation names some of them loosely.
        -- Anything cast on the party has one decision and no variants, so it does not need it either.
        if job ~= 3 and target ~= "player" then ord.ai_fuzzy = true end
        for _, flag in ipairs(CARRIED) do
            if entry[flag] ~= nil then ord[flag] = entry[flag] end
        end
        D.ORDERS[id] = ord
    end
end

----------------------------------------------------------------------------------------------------
-- the archer, who is driven by hand
--
-- An archer's shot is two actions, a draw and a release, and its AI will not do the second on command. So the engine
-- asks for both itself, which means knowing what they are called -- and the action names are what the engine then
-- watches for to know the shot is happening, so they double as the skill's keywords.
----------------------------------------------------------------------------------------------------
local DRAW_AND_SHOOT = {
    [13]  = "ThreefoldArrow",
    [14]  = "TriadShot",
    [15]  = "BodyBinder",
    [16]  = { "MeteorShot", shoot_after = 8.0, range = 40 },
    [17]  = "SpecialArrowBomb",
    [18]  = "SpecialArrowWater",
    [19]  = "SpecialArrowOil",
    [20]  = "SpecialArrowPoison",
    [21]  = "RandomShot",
    [22]  = { "WhirlingArrow", shoot_after = 2.8 },
    [23]  = "FullBlast",
    [105] = "HeavyRain",
}

for id, spec in pairs(DRAW_AND_SHOOT) do
    local action = type(spec) == "table" and spec[1] or spec
    local ord = D.ORDERS[id]
    ord.direct = {
        prepare = "Job02_Prepare" .. action,
        shoot   = "Job02_Shoot" .. action,
    }
    if type(spec) == "table" then
        ord.direct.shoot_after = spec.shoot_after
        ord.direct.range = spec.range
    end
    -- the three stages of the shot, which is what the engine follows the skill by
    local stem = action:lower()
    ord.keys = { "prepare" .. stem, "ready" .. stem, "shoot" .. stem }
end

----------------------------------------------------------------------------------------------------
-- distances
----------------------------------------------------------------------------------------------------
D.ARCHER_RANGE = 30              -- m : an archer will not be driven by hand further out than this
D.RANGE_FAR    = 20.0            -- m : default distance a caster holds

-- the spells that reach further than the default, in metres
D.RANGE_MAX = { [24] = 30, [25] = 30, [63] = 30, [65] = 20, [66] = 30, [67] = 30, [68] = 30, [69] = 30 }

-- spells that have to be cast close up, so the pawn is left to walk in
D.RANGE_CLOSE_SPELL = { [26] = true, [62] = true, [112] = true }

-- a heal is aimed at whoever needs it, from this far
D.RANGE_HEAL = { [35] = 30 }

-- Which of the game's own distance steps to borrow per vocation: { vocation number, a skill of that vocation that
-- uses the step }. The step needs a skill to read a distance for, and any skill of the vocation will do.
D.SAR_SKILL = { job02 = { 2, 18 }, job03 = { 3, 24 }, job06 = { 6, 69 } }

----------------------------------------------------------------------------------------------------
-- reading a character's actions
----------------------------------------------------------------------------------------------------
-- Skills whose own actions the engine already knows the names of, so it need not guess from a new action appearing
D.KEYS_SEEN = { [24] = true, [25] = true, [29] = true, [30] = true, [31] = true, [37] = true, [106] = true }

-- Actions that cut a skill short. true = they cut it at any point; false = only before it has started.
D.CANCEL_NODES = {
    DefaultCancelAction = true,
    UpperBodyDefault = true,
    SheatheWeapon = true,
    NormalLocomotion = false,
    AttackCancelSheatheWeaponFullBody = true,
    AttackCancelSheatheWeaponUpperBody = true,
    FastSheatheWeapon = true,
}

-- Of those, the ones that cut a skill whatever priority they are asked at
D.CANCEL_ANY_PRIO = {
    AttackCancelSheatheWeaponFullBody = true,
    AttackCancelSheatheWeaponUpperBody = true,
    FastSheatheWeapon = true,
}

-- Named like a vocation skill, but part of ordinary fighting: aiming, a plain shot, turning to face
D.NOT_SKILL = {
    "NormalShot", "RapidShot", "MagicTurn", "AimTurn", "StartAim",
    "AimCancel", "NormalArrow", "SyncUpperBody", "Cancel",
}

-- A pawn running only these is doing nothing, and is free to take an order
D.IDLE_LAYERS = {
    NormalLocomotion = true,
    Strafe = true,
    DefaultCancelAction = true,
    UpperBodyDefault = true,
}

-- Words in an action name that mean the pawn is reacting to a hit
D.HIT_WORDS = { "dmg", "damage", "blown", "tumble", "wince", "repelled", "caught" }

----------------------------------------------------------------------------------------------------
-- skills that skip the targeting step
--
-- Anything not aimed at an enemy: a buff, a heal, a launch pose. Skills added by other mods are not in the table
-- above, so they are listed here by hand. Whatever the player sets in the menu wins over all of this.
----------------------------------------------------------------------------------------------------
D.NO_TARGET_EXTRA = {
    [121] = true,     -- Skill Creator's Healing Dome, which is a mode rather than an attack
    [124] = true,     -- BardN Astral Beacon (Mystic Spearhand): laid at the feet or on the monster being climbed, never aimed
    [103] = true,     -- 2.17: Shield Precision (Fighter, confirmed by probe 216): a guard toggled on oneself, never aimed
}

-- 2.06: Skill Creator numbers its skills in the alphabetical order of their keys, so a new pack can shift them.
-- The numbers above are only the fallback: as soon as Skill Creator can be read, its own numbers replace them
-- (same lookup as ATB Combat System 0.72). Read every 5 s until every key is found, then never again.
local NO_TARGET_SC = {
    { key = "BardN_Healing_Sigil",    fallback = 121 },
    { key = "BardN_Z_Balise_Astrale", fallback = 124 },
}
local sc_read = { t = -10, done = false }
local function read_skill_creator()
    if sc_read.done or os.clock() - sc_read.t < 5.0 then return end
    sc_read.t = os.clock()
    local ok, sk = pcall(require, "SkillCreator/SkillHandler/Skills")
    if not (ok and type(sk) == "table" and type(sk.BardN) == "table") then return end
    local all, real = true, {}
    for _, e in ipairs(NO_TARGET_SC) do
        local d = sk.BardN[e.key]
        local id = d and d.params and d.params.skillID
        if type(id) == "number" then real[id] = true else all = false end
    end
    -- a fallback number that is not one of the real ones belongs to some other skill: drop it
    for _, e in ipairs(NO_TARGET_SC) do
        if not real[e.fallback] then D.NO_TARGET_EXTRA[e.fallback] = nil end
    end
    for id in pairs(real) do D.NO_TARGET_EXTRA[id] = true end
    sc_read.done = all
end

function D.default_no_target(id)
    read_skill_creator()
    if D.NO_TARGET_EXTRA[id] then return true end
    local ord = D.ORDERS[id]
    return ord ~= nil and (ord.target ~= "enemy" or ord.stance == true)
end

return D
