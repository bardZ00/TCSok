-- TacticalCommandSystem/arisen.lua
-- The Arisen in the wheel: reading the 6 equipped skills and launching one of them on a chosen target.
-- How the Arisen's skills are launched from the wheel:
--   * the skill is launched by the game's own function app.PlayerInputProcessorDetail.processCustomSkill, the variant with
--     7 parameters (Action, HumanCustomSkillID, UInt64, LockOnController.Option, Boolean x3): the same gate as a real
--     button press, so Skill Creator skills (e.g. Healing Dome, id 121) work too. Skills that are not equipped are refused
--     by the game through this path.
--   * the target is given to the game's lock-on (setTarget, then updateLockOn with a "nearest point of the enemy" option)
--     and put back for 0.6 s if findAndSetTarget picks another one; last resort: the Arisen is turned towards the target.
--   * the launch itself happens at the start of UpdateBehavior (AR.request queues it).
-- Public table: AR.

local U = require("TacticalCommandSystem.utils")

local AR = {
    proc = nil, proc_addr = nil, proc_src = nil,      -- app.PlayerInputProcessorDetail of the Arisen
    lock = nil, lock_addr = nil, lock_src = nil,      -- app.LockOnController of the Arisen
    pcs1 = nil, pcs2 = nil,                           -- processCustomSkill (7 / 8 parameters)
    actions = { 7, 8, 9, 10, 27, 61 },                -- app.CharacterInput.Action Skill1..Skill6 (read from the game)
    flags = {},                                       -- action -> flag value seen on a real button press
    locate_for = nil, locate_n = 0, locate_t = -10, lock_owner = {},
    aim = nil, in_aim = false, launching = false,
    queue = nil,                                      -- launch waiting for UpdateBehavior
    on_result = nil,                                  -- function(ok, cell, msg) set by the wheel (flash message)
    hooks = { launch = "waiting", lock = "waiting" }, hook_tries = 0, hook_next = 0,
    stats = { launches = 0, refused = 0, errors = 0, locks_ok = 0, locks_refused = 0, relocks = 0, turned = 0 },
    history = {},
}

-- Lock-on behaviour (defaults of the ATB wheel, validated in game)
AR.CFG = {
    lock_mode = 1,       -- 1 soft then full (+ put back), 2 full only, 3 soft only, 4 none (turn only)
    lock_ui = true,      -- keep the game's lock-on display on
    lock_restore = true, -- give the game its own lock-on option back after the launch
    lock_flags = 1,      -- the two booleans of setTarget (1 no/no, 2 yes/no, 3 no/yes, 4 yes/yes)
    aim_info = true,     -- pass the target on to the character (setAimTargetInfoToCharacter)
    face = 2,            -- turn the Arisen towards the target: 1 never, 2 if the lock-on refused it, 3 always
    draw_relaunch = true,-- weapon sheathed -> the launch only draws it; the skill is launched again once drawn
    draw_wait = 2.0,     -- longest wait for the draw to end (seconds)
    magic_hold = true,   -- Mage / Sorcerer: the wheel's target stays the spell's target until the spell leaves
    magic_hold_max = 4.0,-- longest hold (seconds)
}

-- The game's button for each slot, shown on the cells: X, Y, A, B, X+A, Y+B
-- (slots 3 and 4 are A then B -- BardN's check in game: Ice Charm on A, Empyrean on B)
AR.SLOT_KEYS = { { "X" }, { "Y" }, { "A" }, { "B" }, { "X", "A" }, { "Y", "B" } }

------------------------------------------------------------------------------------------------
-- Small helpers
------------------------------------------------------------------------------------------------
local function fget(o, name)
    local ok, v = pcall(function() return o:get_field(name) end)
    if ok and v ~= nil then return v end
    ok, v = pcall(function() return o[name] end)
    if ok then return v end
    return nil
end
local function fset(o, name, v)
    if pcall(function() o[name] = v end) then return true end
    return pcall(function() o:set_field(name, v) end)
end
local function pc0(o, n)
    local ok, v = pcall(function() return o:call(n) end)
    if ok then return v end
    return nil
end
local function obj_addr(o)
    if o == nil then return nil end
    local ok, a = pcall(function() return o:get_address() end)
    if ok and a and a ~= 0 then return a end
    return nil
end
local function type_name(o)
    local n = nil
    pcall(function() n = o:get_type_definition():get_full_name() end)
    return n
end
local function toint(v, d)
    v = tonumber(v)
    if v == nil or v ~= v then return d end
    return math.floor(v)
end

------------------------------------------------------------------------------------------------
-- Skill Creator (skills it adds get ids past the game's own, e.g. 121; it exposes its table in package.loaded)
------------------------------------------------------------------------------------------------
function AR.sc_skill(id)
    local ok, sk = pcall(function()
        local sh = package.loaded["SkillCreator/SkillHandler"]
        return sh and sh.skillInfo and sh.skillInfo.skillIDsToSkills and sh.skillInfo.skillIDsToSkills[id] or nil
    end)
    if ok then return sk end
    return nil
end
local function sc_props()
    local ok, P = pcall(function() return package.loaded["_NickCore/Properties"] end)
    return ok and P or nil
end

-- Display name of a Skill Creator skill (its uiName at the current level), nil otherwise
function AR.sc_label(chara, id)
    local sk = AR.sc_skill(id)
    if not sk then return nil end
    local prm = sk.params or {}
    local lv = 1
    pcall(function()
        local human = chara["<Human>k__BackingField"]
        local sc = human:call("get_SkillContext")
        lv = U.num_val(sc:call("getCustomSkillLevel", prm.skillID)) or 1
    end)
    local t = (lv == 2 and prm.lvl2) or prm.lvl1
    local n = t and t.uiName
    if type(n) == "table" then n = n.fr or n.French or n[1] end
    if type(n) == "string" and n ~= "" then return n end
    return prm.name
end

------------------------------------------------------------------------------------------------
-- Finding the Arisen's input processor and lock-on controller
------------------------------------------------------------------------------------------------
local SEARCH_WORDS = { "Input", "Processor", "Player", "LockOn", "Param", "Detail" }
local function find_typed(obj, want, depth, budget)
    local found, nexts = nil, {}
    pcall(function()
        local td, guard = obj:get_type_definition(), 0
        while td and guard < 6 and not found do
            for _, f in ipairs(td:get_fields()) do
                if budget.n <= 0 then break end
                local st = true
                pcall(function() st = f:is_static() == true end)
                if not st then
                    budget.n = budget.n - 1
                    local ftn = ""
                    pcall(function() ftn = f:get_type():get_full_name() end)
                    if ftn == want then
                        local v = fget(obj, f:get_name())
                        if v ~= nil then found = { obj = v, path = f:get_name() }; break end
                    elseif depth > 0 and ftn:find("^app%.") then
                        for _, w in ipairs(SEARCH_WORDS) do
                            if ftn:find(w, 1, true) then nexts[#nexts + 1] = f:get_name(); break end
                        end
                    end
                end
            end
            td = td:get_parent_type()
            guard = guard + 1
        end
    end)
    if found then return found end
    for _, name in ipairs(nexts) do
        local sub = fget(obj, name)
        if sub ~= nil and type(sub) ~= "number" and type(sub) ~= "boolean" and type(sub) ~= "string" then
            local r = find_typed(sub, want, depth - 1, budget)
            if r then r.path = name .. "." .. r.path; return r end
        end
    end
    return nil
end

function AR.locate(player, now)
    local addr = obj_addr(player)
    if not addr then return end
    if AR.locate_for ~= addr then
        if AR.locate_for ~= nil then
            AR.proc, AR.proc_addr, AR.proc_src = nil, nil, nil
            AR.lock, AR.lock_addr, AR.lock_src = nil, nil, nil
            AR.lock_owner = {}
        end
        AR.locate_for, AR.locate_n, AR.locate_t = addr, 0, -10
    end
    if (AR.proc and AR.lock) or AR.locate_n >= 3 or (now - AR.locate_t) < 2.0 then return end
    AR.locate_n, AR.locate_t = AR.locate_n + 1, now
    local ip = fget(player, "<InputProcessor>k__BackingField")
    if ip == nil then return end
    if AR.proc == nil then
        if type_name(ip) == "app.PlayerInputProcessorDetail" then
            AR.proc, AR.proc_addr, AR.proc_src = ip, obj_addr(ip), "Character.<InputProcessor>"
        else
            local r = find_typed(ip, "app.PlayerInputProcessorDetail", 2, { n = 160 })
            if r then AR.proc, AR.proc_addr, AR.proc_src = r.obj, obj_addr(r.obj), "Character.<InputProcessor>." .. r.path end
        end
    end
    if AR.lock == nil then
        local r = find_typed(ip, "app.LockOnController", 2, { n = 160 })
        if r == nil and AR.proc then
            r = find_typed(AR.proc, "app.LockOnController", 2, { n = 160 })
            if r then r.path = "(processor)." .. r.path end
        end
        if r then AR.lock, AR.lock_addr, AR.lock_src = r.obj, obj_addr(r.obj), "Character.<InputProcessor>." .. r.path end
    end
end

------------------------------------------------------------------------------------------------
-- The 6 equipped skills (slot -> id, 0 = empty)
------------------------------------------------------------------------------------------------
function AR.read_skills(player, job)
    local ids, n = {}, 0
    if AR.proc then
        for i, act in ipairs(AR.actions) do
            local v = nil
            pcall(function() v = U.num_val(AR.proc:call("getCustomSkillID(app.CharacterInput.Action)", act)) end)
            if type(v) == "number" then
                ids[i] = toint(v, 0)
                if ids[i] > 0 then n = n + 1 end
            end
        end
        if n == 0 then ids = {} end
    end
    if n == 0 and job then
        pcall(function()
            local human = player["<Human>k__BackingField"]
            local sc = human:call("get_SkillContext")
            if sc == nil then sc = human["<SkillContext>k__BackingField"] end
            local eq = sc.EquipedSkills[job].Skills
            for s = 0, 5 do
                local v = U.num_val(eq[s])
                ids[s + 1] = v and toint(v, 0) or 0
            end
        end)
    end
    for i = 1, 6 do ids[i] = ids[i] or 0 end
    return ids
end

------------------------------------------------------------------------------------------------
-- Lock-on
------------------------------------------------------------------------------------------------
local function target_char_addr()
    if AR.lock == nil then return nil end
    local t = pc0(AR.lock, "get_Target")
    if t == nil then return nil end
    return obj_addr(pc0(t, "get_Character"))
end

local function make_option(job, action_type, id)
    local opt = sdk.create_instance("app.LockOnController.Option"):add_ref()
    fset(opt, "MaxLockOnCount", 32)
    fset(opt, "RateRadiusScale", 1.0)
    fset(opt, "<IsUseLockOnUI>k__BackingField", AR.CFG.lock_ui and true or false)
    local prm = fget(opt, "<ParameterInfo>k__BackingField")
    if prm ~= nil then
        fset(prm, "<Job>k__BackingField", job)
        fset(prm, "<ActionType>k__BackingField", action_type)
        fset(prm, "<CustomSkillID>k__BackingField", id)
    end
    return opt
end

local function enemy_work(enemy)
    local lt = fget(enemy, "<LockOnTarget>k__BackingField")
    if lt == nil then return nil end
    local work = nil
    pcall(function()
        local td, guard = lt:get_type_definition(), 0
        while td and guard < 4 and not work do
            for _, f in ipairs(td:get_fields()) do
                local ftn = ""
                pcall(function() ftn = f:get_type():get_full_name() end)
                if ftn:find("LockOnTargetWork", 1, true) and not f:is_static() then
                    local v = fget(lt, f:get_name())
                    if v ~= nil then
                        if ftn == "app.LockOnTargetWork" then
                            work = v
                        else
                            local first = nil
                            pcall(function() first = v:call("get_Item", 0) end)
                            if first == nil then pcall(function() first = v[0] end) end
                            work = first
                        end
                        if work then break end
                    end
                end
            end
            td = td:get_parent_type()
            guard = guard + 1
        end
    end)
    return work
end

-- The game's own lock-on option: saved before ours replaces it, given back once the skill is out
local LOCKOPT = { field = nil, searched = false, saved = nil, dirty = false }
local function lock_option_field()
    if LOCKOPT.searched then return LOCKOPT.field end
    LOCKOPT.searched = true
    pcall(function()
        local td, guard = sdk.find_type_definition("app.LockOnController"), 0
        while td and guard < 4 and not LOCKOPT.field do
            for _, f in ipairs(td:get_fields() or {}) do
                local ftn = ""
                pcall(function() ftn = f:get_type():get_full_name() end)
                if ftn == "app.LockOnController.Option" and not f:is_static() then
                    LOCKOPT.field = f:get_name()
                    break
                end
            end
            td = td:get_parent_type()
            guard = guard + 1
        end
    end)
    return LOCKOPT.field
end
local function lock_option_save()
    if LOCKOPT.dirty or AR.lock == nil then return end
    local fn = lock_option_field()
    if fn ~= nil then
        pcall(function()
            local cur = fget(AR.lock, fn)
            if cur ~= nil then LOCKOPT.saved = cur:add_ref() end
        end)
    end
    LOCKOPT.dirty = true
end
local function lock_option_restore()
    if not LOCKOPT.dirty then return end
    LOCKOPT.dirty = false
    local fn, saved = LOCKOPT.field, LOCKOPT.saved
    LOCKOPT.saved = nil
    if fn == nil or saved == nil or AR.lock == nil then return end
    pcall(function() fset(AR.lock, fn, saved) end)
end

local LOCK_FLAGS = { { false, false }, { true, false }, { false, true }, { true, true } }

local function aim_info()
    if not AR.CFG.aim_info or AR.lock == nil then return end
    pcall(function() AR.lock:call("setAimTargetInfoToCharacter") end)
end

local function aim_soft(enemy, want)
    if AR.lock == nil then return false end
    local work = enemy_work(enemy)
    if work == nil then return false end
    pcall(function()
        local fl = LOCK_FLAGS[AR.CFG.lock_flags] or LOCK_FLAGS[1]
        AR.lock:call("setTarget(app.LockOnTargetWork, System.Boolean, System.Boolean)", work, fl[1], fl[2])
    end)
    local ok = target_char_addr() == want
    if ok then aim_info() end
    return ok
end

local function aim_at(enemy, job, id)
    local want = obj_addr(enemy)
    if want == nil then return false, "invalid enemy" end
    if AR.lock and target_char_addr() == want then aim_info(); return true, "already locked" end
    if AR.CFG.lock_mode == 4 then return false, "game lock-on off (turn only)" end
    AR.in_aim = true
    local res, how = false, "refused by the game"
    local okk = pcall(function()
        if AR.CFG.lock_mode ~= 2 then
            if aim_soft(enemy, want) then res, how = true, "setTarget"; return end
            if AR.CFG.lock_mode == 3 then how = "soft way refused"; return end
        end
        local go = enemy:call("get_GameObject")
        local opt = make_option(job, 3, id)
        local set_ok = pcall(function() opt:call("setToFindNearestPointOfObject(via.GameObject)", go) end)
        if set_ok and AR.lock then
            lock_option_save()
            pcall(function() AR.lock:call("updateLockOn(app.LockOnController.Option)", opt) end)
            if target_char_addr() == want then aim_info(); res, how = true, "updateLockOn"; return end
            pcall(function() AR.lock:call("findNearestPointOfObjectAndSetTarget(app.LockOnController.Option)", opt) end)
            if target_char_addr() == want then res, how = true, "findNearestPointOfObjectAndSetTarget"; return end
        elseif set_ok and AR.proc then
            lock_option_save()
            local okp = pcall(function() AR.proc:call("updateLockOn(app.LockOnController.Option)", opt) end)
            res, how = nil, okp and "updateLockOn (processor, not checkable)" or "call refused"
            return
        end
        if aim_soft(enemy, want) then res, how = true, "setTarget (enemy component)" end
    end)
    AR.in_aim = false
    if not okk then return false, "error" end
    return res, how
end

local function face_enemy(player, enemy)
    return pcall(function()
        local tr = player:call("get_Transform")
        local p, e = tr:call("get_Position"), enemy:call("get_Transform"):call("get_Position")
        local yaw = math.atan(e.x - p.x, e.z - p.z)
        local q = tr:call("get_Rotation")
        q.x, q.y, q.z, q.w = 0.0, math.sin(yaw * 0.5), 0.0, math.cos(yaw * 0.5)
        tr:call("set_Rotation", q)
    end)
end

------------------------------------------------------------------------------------------------
-- Hooks (tried every 2 s until they are in place)
------------------------------------------------------------------------------------------------
local function hook_launch()
    local td = sdk.find_type_definition("app.PlayerInputProcessorDetail")
    if not td then return "type app.PlayerInputProcessorDetail not found" end
    for _, m in ipairs(td:get_methods()) do
        if m:get_name() == "processCustomSkill" then
            local n = 0
            pcall(function() n = #m:get_param_types() end)
            if n == 7 then AR.pcs1 = m elseif n == 8 then AR.pcs2 = m end
        end
    end
    if not AR.pcs1 and not AR.pcs2 then return "processCustomSkill not found" end
    local a = {}
    for i, n in ipairs({ "Skill1", "Skill2", "Skill3", "Skill4", "Skill5", "Skill6" }) do
        a[i] = U.enum_val("app.CharacterInput.Action", n)
    end
    if a[1] and a[2] and a[3] and a[4] then
        AR.actions = { a[1], a[2], a[3], a[4], a[5] or 27, a[6] or 61 }
    end
    local function capture(args)
        local raw = sdk.to_int64(args[2])
        if raw ~= 0 and raw ~= AR.proc_addr then
            local o = sdk.to_managed_object(args[2])
            if o then AR.proc, AR.proc_addr, AR.proc_src = o, raw, "launch hook" end
        end
    end
    if AR.pcs1 then
        sdk.hook(AR.pcs1, function(args)
            pcall(function()
                capture(args)
                if AR.launching then return end
                local act = sdk.to_int64(args[3]) & 0xFFFFFFFF
                AR.flags[act] = sdk.to_int64(args[5])
            end)
        end, function(retval) return retval end)
    end
    if AR.pcs2 then
        sdk.hook(AR.pcs2, function(args) pcall(capture, args) end, function(retval) return retval end)
    end
    return "OK"
end

local function hook_lock()
    local td = sdk.find_type_definition("app.LockOnController")
    local m = td and td:get_method("findAndSetTarget(app.LockOnController.Option)")
    if not m then return "findAndSetTarget not found" end
    sdk.hook(m, function(args)
        local mine = false
        pcall(function()
            local player = U.get_player()
            local paddr = obj_addr(player)
            if not paddr then return end
            local raw = sdk.to_int64(args[2])
            local known = AR.lock_owner[raw]
            if known == nil then
                local o = sdk.to_managed_object(args[2])
                local ch = o and fget(o, "Chara")
                known = (ch ~= nil and obj_addr(ch) == paddr)
                AR.lock_owner[raw] = known
                if known and raw ~= AR.lock_addr then AR.lock, AR.lock_addr, AR.lock_src = o, raw, "lock-on hook" end
            end
            mine = known
        end)
        thread.get_hook_storage().tc_lk = mine
    end, function(retval)
        pcall(function()
            local st = thread.get_hook_storage()
            local mine = st.tc_lk
            st.tc_lk = nil
            local a = AR.aim
            if not mine or a == nil or AR.in_aim then return end
            if os.clock() > a.till then
                AR.aim = nil
                if AR.CFG.lock_restore then pcall(lock_option_restore) end
                return
            end
            if target_char_addr() ~= a.addr then
                local res = aim_at(a.chara, a.job, a.id)
                a.redo = a.redo + 1
                if res == true then AR.stats.relocks = AR.stats.relocks + 1 end
            end
        end)
        return retval
    end)
    return "OK"
end

function AR.try_hooks(now)
    if AR.hook_tries >= 30 or now < AR.hook_next then return end
    AR.hook_tries, AR.hook_next = AR.hook_tries + 1, now + 2.0
    local pending = false
    local function one(key, fn)
        if AR.hooks[key] == "OK" then return end
        local ok, res = pcall(fn)
        AR.hooks[key] = ok and res or ("error: " .. tostring(res))
        if AR.hooks[key] ~= "OK" then pending = true end
    end
    one("launch", hook_launch)
    one("lock", hook_lock)
    if not pending then AR.hook_tries = 30 end
end

-- The lock-on put back after 0.6 s even when findAndSetTarget is not called (no target in sight)
function AR.tick(now)
    local a = AR.aim
    if a and os.clock() > a.till + 0.5 then
        AR.aim = nil
        if AR.CFG.lock_restore then pcall(lock_option_restore) end
    end
end

------------------------------------------------------------------------------------------------
-- Launch
------------------------------------------------------------------------------------------------
-- cell = { slot, id, name }, tgt = { chara, addr, name, dist } or nil
function AR.request(cell, tgt)
    AR.queue = { cell = cell, tgt = tgt }
end

-- weapon sheathed. The first launch often only draws the weapon (the game's draw action plays instead of the
-- skill). The launch is watched: when a draw action shows up and no skill action follows, the same skill is launched
-- again once, as soon as the draw ends.
AR.redo = nil
AR.stats.relaunch = 0
AR.watch_seen = {}
local function act_names(player)
    local a0, a1
    pcall(function()
        local list = player["<ActionManager>k__BackingField"].CurrentActionList
        a0 = list[0] and list[0].Name or nil
        a1 = list[1] and list[1].Name or nil
    end)
    return a0, a1
end
local function is_draw(nm)
    if type(nm) ~= "string" then return false end
    local low = string.lower(nm)
    return low:find("draw", 1, true) ~= nil and low:find("weapon", 1, true) ~= nil
end
local function is_skill_act(nm)
    return type(nm) == "string" and nm:find("^Job") ~= nil
end
-- spell target held (Mage / Sorcerer): put back every 0.1 s while the cast plays, released when it ends
AR.stats.magic, AR.stats.magic_fix, AR.stats.magic_end = 0, 0, ""
local function watch_magic()
    local a = AR.aim
    if not (a and a.magic) or AR.in_aim then return end
    local c = os.clock()
    local player = U.get_player()
    if not U.is_valid_obj(player) or not U.is_valid_obj(a.chara) or U.is_dead(a.chara) then
        AR.aim = nil; AR.stats.magic_end = "target lost"
        if AR.CFG.lock_restore then pcall(lock_option_restore) end
        return
    end
    local a0, a1 = act_names(player)
    local casting = is_skill_act(a0) or is_skill_act(a1)
    if casting then a.started = true
    elseif a.started or c - a.t0 > 1.5 then                      -- the spell has left (or never started)
        AR.aim = nil; AR.stats.magic_end = a.started and "spell left" or "no spell"
        if AR.CFG.lock_restore then pcall(lock_option_restore) end
        return
    end
    if c - a.fix_t > 0.1 and target_char_addr() ~= a.addr then
        a.fix_t = c
        local res = aim_at(a.chara, a.job, a.id)
        if res == true then AR.stats.magic_fix = AR.stats.magic_fix + 1 end
    end
end

local function watch_redo(now)
    local w = AR.redo
    if not w then return end
    if now - w.t > (AR.CFG.draw_wait or 2.0) then AR.redo = nil; return end
    local player = U.get_player()
    if not U.is_valid_obj(player) or U.is_dead(player) then AR.redo = nil; return end
    local a0, a1 = act_names(player)
    local seen = tostring(a0) .. " | " .. tostring(a1)
    if AR.watch_seen[#AR.watch_seen] ~= seen then                              -- shown in the menu (diagnosis)
        AR.watch_seen[#AR.watch_seen + 1] = seen
        if #AR.watch_seen > 6 then table.remove(AR.watch_seen, 1) end
    end
    if is_skill_act(a0) or is_skill_act(a1) then AR.redo = nil; return end      -- the skill is playing
    if is_draw(a0) or is_draw(a1) then w.drawing = true; return end
    if w.drawing then                                                          -- draw over, no skill: launch again
        AR.redo = nil
        AR.stats.relaunch = AR.stats.relaunch + 1
        AR.queue = { cell = w.cell, tgt = w.tgt, again = true }
    end
end

local function finish(ok, cell, msg)
    if AR.on_result then pcall(AR.on_result, ok, cell, msg) end
end

local function run_queue(now)
    local q = AR.queue
    AR.queue = nil
    if q == nil then return end
    local player = U.get_player()
    if not U.is_valid_obj(player) or U.is_dead(player) then return end
    local cell, tgt = q.cell, q.tgt
    if q.again and tgt and not (U.is_valid_obj(tgt.chara) and not U.is_dead(tgt.chara)) then tgt = nil end
    local job = cell.job or 1
    local act = AR.actions[cell.slot]
    local flag = AR.flags[act] or (1 << act)
    local rec = { t = now, id = cell.id, slot = cell.slot, target = tgt and tgt.name or nil }
    AR.history[#AR.history + 1] = rec
    if #AR.history > 12 then table.remove(AR.history, 1) end
    AR.locate(player, now)
    if AR.proc == nil or (AR.pcs1 == nil and AR.pcs2 == nil) then
        rec.error = "input processor not found yet"
        finish(false, cell, "[ WHEEL NOT READY: USE A SKILL ONCE WITH ITS BUTTON ]")
        return
    end
    if tgt and U.is_valid_obj(tgt.chara) and not U.is_dead(tgt.chara) then
        local res, how = aim_at(tgt.chara, job, cell.id)
        rec.lock, rec.how = (res == nil) and "not checkable" or res, how
        if res == true then AR.stats.locks_ok = AR.stats.locks_ok + 1
        elseif res == false then AR.stats.locks_refused = AR.stats.locks_refused + 1 end
        -- Mage / Sorcerer: the spell picks its own target while it is cast; the wheel's target is held as the
        -- spell's starting target until the spell leaves (then the game's own targeting is free again)
        local magic = (job == 3 or job == 6) and AR.CFG.magic_hold
        AR.aim = { addr = tgt.addr, chara = tgt.chara, job = job, id = cell.id, redo = 0, magic = magic,
            till = os.clock() + (magic and (AR.CFG.magic_hold_max or 4.0) or 0.6), t0 = os.clock(), fix_t = 0 }
        if magic then AR.stats.magic = (AR.stats.magic or 0) + 1 end
        if AR.CFG.face == 3 or (AR.CFG.face == 2 and res ~= true) then
            face_enemy(player, tgt.chara)
            AR.stats.turned = AR.stats.turned + 1
        end
    end
    local okk, ret
    AR.launching = true
    local sk = AR.sc_skill(cell.id)
    if sk and AR.pcs1 then
        -- Skill Creator only listens to the 7-parameter variant (with the button's action)
        local opt = make_option(job, 0, 0)
        local P = sc_props()
        if P then P.inputSkill = nil end
        okk, ret = pcall(function() return AR.pcs1:call(AR.proc, act, cell.id, flag, opt, false, true, false) end)
        if okk then
            local active = false
            pcall(function() active = P and P.is_in_move and P.is_in_move(sk.params.name) or false end)
            local seen = P and P.inputSkill == cell.id
            ret = (active or seen) and true or false
        end
    elseif AR.pcs2 then
        local opt = make_option(job, 3, cell.id)
        okk, ret = pcall(function() return AR.pcs2:call(AR.proc, cell.id, flag, opt, false, true, false, 0, true) end)
    else
        local opt = make_option(job, 0, 0)
        okk, ret = pcall(function() return AR.pcs1:call(AR.proc, act, cell.id, flag, opt, false, true, false) end)
    end
    AR.launching = false
    -- watch for a draw of the weapon in place of the skill (once per wheel launch)
    if okk and AR.CFG.draw_relaunch and not q.again then
        AR.redo = { cell = cell, tgt = tgt, t = now }
        AR.watch_seen = {}
        rec.watch = true
    end
    if q.again then rec.again = true end
    if okk and ret ~= true and q.again == nil and AR.CFG.draw_relaunch then
        -- refused but maybe drawing: no message yet, the watcher decides
        local a0, a1 = act_names(player)
        if is_draw(a0) or is_draw(a1) then
            rec.ok = false
            rec.drawing = true
            return
        end
    end
    if not okk then
        rec.error = tostring(ret)
        AR.stats.errors = AR.stats.errors + 1
        finish(false, cell, "[ LAUNCH ERROR (SEE LOG) ]")
        log.error("[Tactical_Command_System] Arisen launch error: " .. tostring(ret))
    elseif ret == true then
        rec.ok = true
        AR.stats.launches = AR.stats.launches + 1
        finish(true, cell, nil)
    else
        rec.ok = false
        AR.stats.refused = AR.stats.refused + 1
        finish(false, cell, "[ " .. tostring(cell.name) .. " : REFUSED BY THE GAME ]")
    end
end

pcall(function()
    if re.on_pre_application_entry then
        re.on_pre_application_entry("UpdateBehavior", function()
            if AR.queue then pcall(run_queue, os.clock()) end
        end)
        AR.ub = true
    end
end)

-- Without the UpdateBehavior callback the launch runs from the frame loop
function AR.frame(now)
    AR.try_hooks(now)
    AR.tick(now)
    if AR.redo then pcall(watch_redo, now) end
    if AR.aim and AR.aim.magic then pcall(watch_magic) end
    if AR.queue and not AR.ub then pcall(run_queue, now) end
end

return AR
