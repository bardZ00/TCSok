-- TacticalCommandSystem/menu.lua
-- The mod's menu in the REFramework window (Script Generated UI > Tactical Command System).
--   * a preset at the top (Default / Custom), then the settings grouped in drawers (orange titles)
--   * every ordinary setting is drawn from conf/settings.lua by one generic function
--   * no "new in this version" marking: it was a testing aid, removed in 1.0

local IN  = require("TacticalCommandSystem.input")
local U   = require("TacticalCommandSystem.utils")
local AR  = require("TacticalCommandSystem.arisen")
local Focus = require("TacticalCommandSystem.camera")
local P   = require("TacticalCommandSystem.possess")
local API = require("TacticalCommandSystem.api")
local I18 = require("TacticalCommandSystem.i18n")
local S   = require("TacticalCommandSystem.conf.settings")
local C   = require("TacticalCommandSystem.config")
local Safe = require("TacticalCommandSystem.lib.safe")
local B   = require("TacticalCommandSystem.menu.binds")

local T = I18.pick   -- T("English", "Français")

local M = {}

local COL_TEXT   = 0                -- ImGuiCol_Text
local ORANGE     = 0xFF2090FF       -- drawer titles (ABGR)
local INFO       = 0xFFC8C8C8       -- neutral grey for information lines (ABGR)
local GOLD_HEAD  = 0xFF72CCF0       -- 1.37: light gold, the titles of the button rows (ABGR)

local host = nil     -- provided by the main file: title, draw_module(), draw_profiler()

----------------------------------------------------------------------
-- Generic widgets
----------------------------------------------------------------------
local function tip(en, fr)
    if imgui.is_item_hovered() then imgui.set_tooltip(T(en, fr)) end
end

local function colored(color, fn)
    imgui.push_style_color(COL_TEXT, color)
    fn()
    imgui.pop_style_color(1)
end

local items_cache = {}   -- choice settings: combo item lists, built once per language
local function choice_items(def)
    local c = items_cache[def]
    if not c then
        c = { en = {}, fr = {} }
        for i, ch in ipairs(def.choices) do c.en[i], c.fr[i] = ch.en, ch.fr end
        items_cache[def] = c
    end
    return T(c.en, c.fr)
end

local function draw_setting(def)
    if def.show and not def.show(C.values) then return end
    local label = T(def.label[1], def.label[2]) .. "##tc_" .. def.key
    local value = C.values[def.key]
    local function widget()
        if def.kind == "bool" then
            local changed, v = imgui.checkbox(label, value)
            if changed then C.set(def.key, v) end
        elseif def.kind == "float" then
            local changed, v = imgui.slider_float(label, value, def.min, def.max, def.fmt)
            if changed then C.set(def.key, v) end
        elseif def.kind == "color" then
            local fn = imgui.color_edit or imgui.color_picker
            if fn then
                local changed, v = fn(label, value)
                if changed and type(v) == "number" then C.set(def.key, v) end
            end
        else
            local idx = 1
            for i, ch in ipairs(def.choices) do if ch.value == value then idx = i end end
            local changed, new_idx = imgui.combo(label, idx, choice_items(def))
            if changed then C.set(def.key, def.choices[new_idx].value) end
        end
    end
    widget()
    if def.tip then tip(def.tip[1], def.tip[2]) end
    if def.reset_label then
        imgui.same_line()
        if imgui.button(T(def.reset_label[1], def.reset_label[2]) .. "##tc_reset_" .. def.key) then C.reset_value(def.key) end
    end
end

-- One button that puts every position setting back to its default
local POSITION_KEYS = { "pos_skill_gap", "pos_skill_dist", "pos_skill_mid_dx", "pos_skill_dy", "pos_skill_w", "pos_corner_dx", "pos_corner_dy", "pos_corner_w" }
local function draw_reset_positions()
    local function button()
        if imgui.button(T("Reset all positions", "Remettre toutes les positions par défaut") .. "##tc_reset_pos") then
            for _, k in ipairs(POSITION_KEYS) do C.reset_value(k) end
        end
    end
    button()
end

-- A drawer: orange title, content only while open
local function drawer(id, en, fr, body)
    imgui.push_style_color(COL_TEXT, ORANGE)
    local open = imgui.tree_node(T(en, fr) .. "##tc_dr_" .. id)
    imgui.pop_style_color(1)
    if open then
        body()
        imgui.tree_pop()
    end
end

----------------------------------------------------------------------
-- Locks panel (skills a pawn may only cast on order)
----------------------------------------------------------------------
local function draw_locks()
    imgui.text(T("Skills locked to MANUAL ONLY (pawn never casts them by itself):",
        "Compétences verrouillées en MANUEL SEUL (le pion ne les lance jamais seul) :"))
    local n_locks = 0
    for pname, ids_set in pairs(IN.LOCKS) do
        local ids = {}
        for sid in pairs(ids_set) do ids[#ids + 1] = sid end
        table.sort(ids)
        n_locks = n_locks + #ids
        imgui.text("  " .. tostring(pname) .. " : " .. table.concat(ids, ", "))
    end
    if n_locks == 0 then imgui.text(T("  none", "  aucune")) end

    local ok, dg = pcall(IN.lock_diag)
    if ok and dg then
        imgui.text(string.format(T("  check: %d pass, %d pawn(s), last pack found %d decision(s), %d flag(s) set, %d error(s)",
            "  contrôle : %d passes, %d pion(s), dernier pack : %d décision(s) trouvée(s), %d drapeau(x) posé(s), %d erreur(s)"),
            dg.ticks or 0, dg.pawns or 0, dg.matched or 0, dg.applied or 0, dg.errors or 0))
        if dg.last_err then imgui.text("  " .. tostring(dg.last_err)) end
        imgui.text(string.format(T("  skill refusals: %d   |   locked skills seen running: %d",
            "  refus de compétence : %d   |   compétences verrouillées vues en cours : %d"), dg.vetoed or 0, dg.leaks or 0))
    end

    draw_setting(S.BY_KEY.lock_enforce)
    draw_setting(S.BY_KEY.lock_hook)
    draw_setting(S.BY_KEY.lock_log)
    if C.values.lock_log and ok and dg and dg.recent then
        for _, line in ipairs(dg.recent) do imgui.text("    " .. tostring(line)) end
    end
    if n_locks > 0 and imgui.button(T("Unlock all skills", "Tout déverrouiller") .. "##tc_unlock_all") then
        pcall(IN.clear_all_locks)
    end
end

----------------------------------------------------------------------
-- Skills that skip the targeting step (ticked = no targeting)
----------------------------------------------------------------------
local draw_preview

local function draw_no_target()
    imgui.text(T("Ticked = the skill goes out at once, without the targeting step (support, buffs, \"mode\" skills...).",
        "Coché = la compétence part tout de suite, sans l'étape de ciblage (soutien, renforcements, compétences de « mode »...)."))
    imgui.text(T("The list is filled in advance; your ticks are kept. Skills currently equipped:",
        "La liste est préremplie ; tes choix sont gardés. Compétences équipées en ce moment :"))
    local ok, party = pcall(IN.get_party, os.clock())
    if not ok or type(party) ~= "table" or #party == 0 then
        imgui.text(T("  (load a save to see the equipped skills)", "  (charge une partie pour voir les compétences équipées)"))
    else
        for ci, p in ipairs(party) do
            imgui.text((p.kind == "arisen" and T("  Arisen: ", "  Insurgé : ") or "  ") .. tostring(p.name))
            local seen = {}
            for slot = 1, 6 do
                local id = p.skills[slot]
                if id and id > 0 and not seen[id] then
                    seen[id] = true
                    local name = (p.kind == "arisen" and AR.sc_label(p.chara, id)) or U.get_skill_display_name(id)
                    local on = IN.is_no_target(id)
                    local changed, v = imgui.checkbox("    " .. tostring(name) .. "  (id " .. id .. ")##tc_nt_" .. ci .. "_" .. id, on)
                    if changed then IN.set_no_target(id, v) end
                end
            end
        end
    end
    local n = 0
    for _ in pairs(IN.NOTARGET) do n = n + 1 end
    if n > 0 and imgui.button(T("Back to the default list", "Revenir à la liste par défaut") .. "##tc_nt_reset") then
        for k in pairs(IN.NOTARGET) do IN.NOTARGET[k] = nil end
        C.mark_dirty()
    end
end

-- What the Arisen's launcher found (for the tests)
-- Whether the other half of the feature is actually there, which is the first thing to look at when the
-- take-control button seems to do nothing.
-- headings inside the Extensions drawer
local function draw_ext_dpc_title()
    colored(ORANGE, function()
        imgui.text(T("Direct Pawn Control (Hazzer) -- optional", "Direct Pawn Control (Hazzer) -- facultatif"))
    end)
    imgui.text(T("  Not required: without it, only taking control of a pawn is unavailable.",
        "  Non nécessaire : sans lui, seule la prise de contrôle d'un pion est indisponible."))
end

local function draw_ext_atb_title()
    imgui.separator()
    colored(ORANGE, function()
        imgui.text(T("Tactical Command System with ATB Combat System -- optional", "Tactical Command System with ATB Combat System -- facultatif"))
    end)
end

local function draw_possess_diag()
    if C.values.possess_on_close == false then return end
    local kind = P.kind()
    if kind == nil then
        imgui.text_colored(T("Direct Pawn Control not found: the take-control button only closes the wheel.",
            "Direct Pawn Control introuvable : le bouton de prise de contrôle ferme simplement la roue."), INFO)
        return
    end
    if kind == "modern" then
        imgui.text_colored(string.format(T("Direct Pawn Control %s found, read-only: this build has no call that "
                .. "starts a possession, so closing the wheel cannot change who you play.",
            "Direct Pawn Control %s détecté, en lecture seule : cette version n'a aucun appel qui démarre une "
                .. "possession, donc fermer la roue ne peut pas changer de personnage."),
            tostring(P.report.version or "?")), INFO)
        imgui.text(T("  The wheel still points DPC's own possession key at the character you close on, "
                .. "and borrows the camera from it (camera.follow).",
            "  La roue vise quand même la touche de possession de DPC sur le personnage choisi, "
                .. "et lui emprunte la caméra (camera.follow)."))
        local on = P.active()
        imgui.text(T("  Playing: ", "  Personnage joué : ")
            .. (on and T("a pawn", "un pion") or T("the Arisen", "l'Insurgé")))
        return
    end
    local on, idx = P.active()
    imgui.text(string.format(T("Direct Pawn Control %s found. Playing: %s.",
        "Direct Pawn Control %s détecté. Personnage joué : %s."),
        tostring(P.report.version or "?"),
        on and (T("pawn #", "pion n°") .. tostring(idx)) or T("the Arisen", "l'Insurgé")))
    -- 1.10: through DPC's official calls (0.9.173+) or the patched local handle
    imgui.text(T("  Switching from the wheel: ", "  Changement depuis la roue : ")
        .. (kind == "control" and "DPC_API.possess / release_pawn" or T("local handle (patched copy)", "accès local (copie modifiée)")))
    if P.report.last then imgui.text(T("  Last switch: ", "  Dernier changement : ") .. tostring(P.report.last)) end
end

-- what the camera focus found, which is the first thing to look at when the camera does not move
local function draw_camera_diag()
    local r = Focus.report
    if not C.values.cam_focus then
        imgui.text(T("Camera focus: off.", "Focus caméra : désactivé."))
        return
    end
    local N = Focus.native

    -- 1.02: the "enemy dead centre" framing turns the camera's angle, through its own hook
    if C.values.cam_centre ~= false and C.values.cam_centre_mode == "aim" then
        local A = Focus.aim
        if not A.hooked or A.failed then
            imgui.text_colored(T("Enemy dead centre: the camera's angle cannot be set here (updateManualCameraControl / setYaw).",
                "Ennemi au centre : l'angle de la caméra n'est pas réglable ici (updateManualCameraControl / setYaw)."), INFO)
        else
            imgui.text(string.format(T("Enemy dead centre: %d turn(s). Pitch: %s.",
                "Ennemi au centre : %d rotation(s). Inclinaison : %s."), A.turns,
                A.pitch_sign and T("followed", "suivie")
                    or T("not read yet (horizontal only)", "pas encore lue (horizontal seulement)")))
        end
    end

    -- a played pawn means Direct Pawn Control is writing the camera too: either it lends it, or we aim by hand
    if C.values.cam_engine ~= "gaze" and Focus.effective_engine() == 2 then
        imgui.text_colored(T("A pawn is being played and this build of Direct Pawn Control cannot lend the camera: "
                .. "aiming by hand instead, so it is left alone.",
            "Un pion est joué et cette version de Direct Pawn Control ne peut pas prêter la caméra : "
                .. "visée à la main, pour le laisser tranquille."), INFO)
        imgui.text(string.format(T("Gaze engine: %d write(s), looking at: %s.",
            "Moteur de visée : %d écriture(s), vise : %s."), r.writes, tostring(r.status)))
        return
    end
    if Focus.dpc_lend_active and Focus.dpc_lend_active() then
        imgui.text_colored(T("Direct Pawn Control is lending the camera: the game's own camera follows the wheel.",
            "Direct Pawn Control prête la caméra : la caméra du jeu suit la roue."), INFO)
    end

    if C.values.cam_engine ~= "gaze" then
        imgui.text(string.format(T("Camera focus: the game's own camera. %d hand-over(s), looking at: %s.",
            "Focus caméra : caméra du jeu. %d passation(s), vise : %s."), N.reasserts, tostring(r.status)))
        if N.no_guard then
            imgui.text_colored(T("switchCamera not found: the cling and cinematic cameras cannot be refused.",
                "switchCamera introuvable : les caméras d'accrochage et cinématique ne peuvent pas être refusées."), INFO)
        elseif N.refused > 0 then
            imgui.text(string.format(T("%d camera(s) refused (last: control type %s).",
                "%d caméra(s) refusée(s) (dernière : type de contrôle %s)."), N.refused, tostring(N.refused_last)))
        end
        if N.stood_down then
            imgui.text_colored(T("Standing down: another mod is driving the camera.",
                "En retrait : un autre mod pilote la caméra."), INFO)
        end
        if not r.hooked then
            imgui.text(T("updatePog not found: the targeting step cannot bring the enemy into frame.",
                "updatePog introuvable : l'étape de ciblage ne peut pas ramener l'ennemi dans le cadre."))
        end
        return
    end

    if not r.hooked then
        imgui.text_colored(T("Camera focus: updatePog not found, the camera cannot be aimed.",
            "Focus caméra : updatePog introuvable, la caméra ne peut pas être visée."), INFO)
        return
    end
    imgui.text(string.format(T("Camera focus: hooked, %d write(s), looking at: %s.",
        "Focus caméra : accroché, %d écriture(s), vise : %s."), r.writes, tostring(r.status)))
end

-- Probe 100_Camera: lists the camera methods that could carry the travel rate, so the slow motion can be undone on
-- the game's own camera travel (see camera.lua). Results also go to the REFramework log.
local function draw_camera_probe()
    local p = Focus.probe
    if imgui.button(T("Run probe 100_Camera", "Lancer la sonde 100_Camera") .. "##tc_probe_cam") then
        pcall(Focus.run_probe)
    end
    tip("Lists the camera methods whose name looks like a speed / interpolation rate. Send me the list and the\n"
            .. "camera travel can be sped up smoothly under slow motion, instead of cutting.",
        "Liste les méthodes de caméra dont le nom ressemble à un taux de vitesse / interpolation. Envoie-moi la\n"
            .. "liste et le voyage de la caméra pourra être accéléré en douceur sous ralenti, au lieu de couper.")
    if not p.ran then return end
    if #p.found == 0 then
        imgui.text_colored(string.format(T("Probe 100_Camera: nothing found (%d type(s) scanned).",
            "Sonde 100_Camera : rien trouvé (%d type(s) scanné(s))."), p.scanned), INFO)
        return
    end
    imgui.text(string.format(T("Probe 100_Camera: %d candidate(s) on %d type(s) -- also in the log.",
        "Sonde 100_Camera : %d candidat(s) sur %d type(s) -- aussi dans le log."), #p.found, p.scanned))
    for _, line in ipairs(p.found) do imgui.text("  " .. line) end
end

-- Optional second layer: Tactical Command System with ATB Combat System (separate script, registers itself through API)
local function draw_atb_status()
    local on = API.atb_on()
    if API.atb == nil then return end            -- 1.37: nothing about the ATB Combat System until it is installed
    imgui.text(on
        and T("ATB Combat System: linked and on (gauges, costs, greyed cells).", "ATB Combat System : relié et activé (jauges, coûts, cellules grisées).")
        or T("ATB Combat System: linked but off (switched off in its own menu).", "ATB Combat System : relié mais désactivé (coupé dans son propre menu)."))
    imgui.text(T("  Its own settings live in its own menu entry.", "  Ses réglages se trouvent dans sa propre entrée de menu."))
end

local function draw_arisen_diag()
    imgui.text(string.format(T("Arisen launcher: hooks launch=%s lock=%s | processor %s | lock-on %s",
        "Lanceur de l'Insurgé : accroches lancement=%s ciblage=%s | processeur %s | verrouillage %s"),
        tostring(AR.hooks.launch), tostring(AR.hooks.lock),
        AR.proc and T("found", "trouvé") or T("not yet", "pas encore"), AR.lock and T("found", "trouvé") or T("not yet", "pas encore")))
    local st = AR.stats
    imgui.text(string.format(T("  launches %d, refused %d, errors %d, lock-on ok %d / refused %d, put back %d, turned %d",
        "  lancements %d, refus %d, erreurs %d, verrouillage ok %d / refusé %d, remis %d, orienté %d"),
        st.launches, st.refused, st.errors, st.locks_ok, st.locks_refused, st.relocks, st.turned))
    imgui.text(string.format(T("  relaunched after drawing the weapon: %d", "  relancées après le dégainage : %d"), st.relaunch or 0))
    imgui.text(string.format(T("  spell targets held: %d ; put back during the cast: %d ; last end: %s",
        "  cibles de sort maintenues : %d ; remises pendant l'incantation : %d ; dernière fin : %s"),
        st.magic or 0, st.magic_fix or 0, tostring(st.magic_end or "-")))
    if #AR.watch_seen > 0 then
        imgui.text(T("  actions seen after the last launch: ", "  actions vues après le dernier lancement : ")
            .. table.concat(AR.watch_seen, "  >  "))
    end
    for i = #AR.history, math.max(1, #AR.history - 4), -1 do
        local r = AR.history[i]
        imgui.text(string.format("    #%d id %s slot %s -> %s%s", i, tostring(r.id), tostring(r.slot),
            (r.again and T("[relaunch] ", "[relance] ") or "") .. (r.drawing and T("drawing the weapon", "dégainage")
                or (r.ok == true and "OK" or (r.ok == false and T("refused", "refusé") or tostring(r.error)))),
            r.target and ("  (" .. tostring(r.target) .. ", " .. tostring(r.how) .. ")") or ""))
    end
end

----------------------------------------------------------------------
-- Preview: the wheel drawn without being opened, to tune it from the menu
----------------------------------------------------------------------
-- 1.37: buttons right under the style buttons; 1.38: the wheel or the targeting step, side by side
local function preview_button(label_en, label_fr, target, tip_en, tip_fr)
    local on = API.preview == true and (API.preview_target == true) == target
    if on then
        imgui.push_style_color(21, 0xFF1E5A7A); imgui.push_style_color(22, 0xFF2A6E92); imgui.push_style_color(23, 0xFF2A6E92)
        imgui.push_style_color(COL_TEXT, 0xFFFFFFFF)
    end
    local label = T(label_en, label_fr) .. "##tc_preview" .. (target and "_t" or "_w")
    local sz = (Vector2f and Vector2f.new) and Vector2f.new(230, 32) or nil
    local okb, pressed = pcall(imgui.button, label, sz)
    if not okb then pressed = imgui.button(label) end
    if on then imgui.pop_style_color(4) end
    tip(tip_en, tip_fr)
    if pressed then API.set_preview(not on, target) end
end
draw_preview = function()
    colored(GOLD_HEAD, function() imgui.text(T("PREVIEW", "APERÇU")) end)
    preview_button("Wheel", "Roue", false,
        "The wheel is drawn as it is, without opening it, to tune its look from the menu. Click again to hide it.",
        "La roue est dessinée telle quelle, sans l'ouvrir, pour régler son allure depuis le menu. Recliquer pour la masquer.")
    imgui.same_line()
    preview_button("Targeting", "Ciblage", true,
        "The targeting step with the first skill: the enemies in range, or a party member when there is none. Click again to hide it.",
        "L'étape de ciblage avec la première compétence : les ennemis à portée, ou un membre du groupe s'il n'y en a aucun. Recliquer pour la masquer.")
    if API.preview then
        imgui.same_line()
        if imgui.button(T("< character", "< personnage") .. "##tc_prev_l") then IN.preview_cycle(-1) end
        imgui.same_line()
        if imgui.button(T("character >", "personnage >") .. "##tc_prev_r") then IN.preview_cycle(1) end
        imgui.text(T("  Drawn without slow motion; the game keeps the controls. Load a save first.",
            "  Dessinée sans ralenti ; le jeu garde les commandes. Charge une partie avant."))
    end
end

----------------------------------------------------------------------
-- Layout: drawers and what they hold (setting keys, or functions for custom blocks)
----------------------------------------------------------------------
local sub_drawer                          -- 1.45: defined after draw_items
local DRAWERS = {
    -- 1.11: the main feature, first at the root
    { id = "open", en = "Opening the wheel", fr = "Ouverture de la roue", items = {
        "open_mode", B.draw_opening_shortcut, "open_delay", "close_release", "release_confirm",
        "kb_latch", "tap_keep", B.draw_key_diagnostic } },
    { id = "toprow", en = "Top row: character icons", fr = "Rangée du haut : icônes des personnages", items = {
        "look_top_row", "look_row_icon_size", "look_row_sel_scale", "look_row_arisen_size", "look_carousel_ms",
        "look_dpad_hint", "look_dpad_size" } },
    { id = "extensions", en = "Extensions (optional mods)", fr = "Extensions (mods facultatifs)", items = {
        draw_ext_dpc_title, "possess_on_close", "cam_dpc_coexist", draw_possess_diag,
        draw_ext_atb_title, draw_atb_status } },
    { id = "wheels", en = "Wheel, camera & filter", fr = "Roue, caméra et filtre", items = {
        "skill_icons", "sounds", "slowmo", "slowmo_factor", "cam_tilt", "cam_speed", "cam_realtime",
        "cam_focus", "cam_engine", "cam_snap", "cam_snap_switch", "cam_switch_time", "cam_focus_height", "cam_focus_dist", "cam_focus_lift",
        "cam_centre", "cam_centre_mode", "cam_centre_force",
        "filter_enabled", "filter_color", "filter_opacity", "filter_vignette", "filter_vignette_size", "filter_vignette_color" } },
    { id = "look", en = "Look of the wheel", fr = "Apparence de la roue", items = {
        "hud_scale", "glyph_scale", "text_scale", "font_face2",
        "look_tint", "look_soph_smoke", "look_sel_tint", "look_cell_shape", "look_ring_thin",
        "look_crescents", "look_center_mode", "look_plate_offset",
        "look_center_arisen", "look_center_fade_ms", "look_slot_keys_shown", "look_slot_keys_size",
        "look_stance_icons", "look_stance_icon_size", "look_stance_close_art" } },
    { id = "position", en = "Position of the cells", fr = "Position des cellules", items = {
        "pos_skill_gap", "pos_skill_dist", "pos_skill_mid_dx", "pos_skill_dy", "pos_skill_w",
        "pos_corner_dx", "pos_corner_dy", "pos_corner_w", draw_reset_positions } },
    { id = "vocation", en = "Class emblem (wheel centre)", fr = "Emblème de classe (centre de la roue)", items = {
        "vocation_icon", "vocation_name", "vocation_size", "vocation_dx", "vocation_dy", "vocation_opacity" } },
    { id = "vision", en = "Realistic targeting", fr = "Ciblage réaliste", items = {
        "vis_on", "vis_front", "vis_front_angle", "vis_walls", "vis_dark_range", "vis_lamp_range", "vis_ceiling",
        "vis_pawns", "vis_close", "vis_memory", "vis_engage", "vis_engage_lose" } },
    { id = "target", en = "Targeting step", fr = "Étape de ciblage", items = {
        "tgt_solo", "tgt_solo_y", "tgt_hide_row", "target_default", "target_range" } },
    -- 1.45: everything about the look of the targeting, in one drawer with two sub-drawers
    { id = "tstyle", en = "Targeting and line style", fr = "Style ciblage et ligne", items = {
        function() sub_drawer("line", "Aim line", "Ligne de visée", {
            "line_enabled", "line_style", "line_color", "line_opacity", "line_width", "line_arrow_width", "line_arrow_head",
            "line_comet_speed", "line_breath_wave", "line_breath_glow", "line_curve", "line_outline" }) end,
        function() sub_drawer("marker", "Markers on the enemy", "Marqueurs sur l'ennemi", {
            "marker_style", "marker_color", "marker_size", "marker_opacity", "marker_speed", "marker_hp_color", "marker_hp_core",
            "marker_closed", "marker_seconds" }) end } },
    { id = "notarget", en = "Skills without targeting", fr = "Compétences sans ciblage", items = { draw_no_target } },
    { id = "auto", en = "Pawns without an order", fr = "Pions sans ordre", items = {         -- 2.30
        "auto_charge", "auto_shield_off", "auto_shield_delay" } },
    { id = "kbm", en = "Keyboard and mouse (experimental)", fr = "Clavier-souris (expérimental)", items = {
        "mouse_mode", "mouse_speed", "mouse_margin", "mouse_cursor_show", "mouse_cursor_color", "mouse_cursor_opacity",
        "mouse_follow_pointer" } },
    { id = "magic", en = "Arisen: spell target (Mage, Sorcerer)", fr = "Insurgé : cible des sorts (Mage, Sorcier)", items = {
        "arisen_magic_hold", "arisen_magic_hold_max", "arisen_lock_mode" } },
    { id = "draw", en = "Arisen: weapon sheathed", fr = "Insurgé : arme rengainée", items = {
        "arisen_draw", "arisen_draw_wait" } },
    { id = "lamp", en = "Status lamp on skill cells (pawns)", fr = "Voyant sur les cellules de compétence (pions)", items = {
        "lamp_enabled", "lamp_off", "lamp_size", "lamp_glow", "lamp_opacity", "lamp_dx", "lamp_dy" } },
    { id = "locks", en = "Manual-only skill locks (pawns)", fr = "Verrous de compétences des pions (manuel seul)", items = { draw_locks } },
    { id = "binds", en = "Key & Controller Bindings", fr = "Touches et manette", items = { B.draw_all_bindings } },
    { id = "advanced", en = "Diagnostics", fr = "Diagnostic", dev = true,
      items = { draw_arisen_diag, draw_camera_diag, draw_camera_probe, function() host.draw_profiler() end } },
}

local function draw_items(items)
    for _, it in ipairs(items) do
        if type(it) == "function" then it() else draw_setting(S.BY_KEY[it]) end
    end
end

sub_drawer = function(id, en, fr, items)
    drawer(id, en, fr, function() draw_items(items) end)
end


----------------------------------------------------------------------
-- Preset (Default / Custom)
----------------------------------------------------------------------
-- Default, Custom, then the player's own presets. Saving takes the settings as they are now under a name typed here;
-- loading one puts them back. The two first names are the mod's own and cannot be taken.
local preset_name_field = ""

local function draw_preset()
    local current = C.current_preset()
    local own = C.preset_names()

    local items_en = { "Default (recommended)", "Custom" }
    local items_fr = { "Défaut (recommandé)", "Personnalisé" }
    local idx = (current == "default") and 1 or 2
    for i, name in ipairs(own) do
        items_en[i + 2], items_fr[i + 2] = name, name
        if current == name then idx = i + 2 end
    end

    local changed, new_idx = imgui.combo(T("Preset", "Préréglage") .. "##tc_preset", idx, T(items_en, items_fr))
    if changed then
        C.apply_preset(new_idx == 1 and "default" or (new_idx == 2 and "custom" or own[new_idx - 2]))
    end
    tip("Default: the recommended settings (choosing it restores them all, except language, key bindings and locks).\n"
            .. "Custom: every setting is yours. Changing any setting switches to Custom by itself.\n"
            .. "Below that: the presets you saved yourself.",
        "Défaut : les réglages recommandés (le choisir les remet tous, sauf la langue, les touches et les verrous).\n"
            .. "Personnalisé : tous les réglages sont à toi. Modifier un réglage passe tout seul en Personnalisé.\n"
            .. "En dessous : les préréglages que tu as enregistrés toi-même.")

    -- name field + Save, then Delete for the one being shown
    local field = imgui.input_text
    if field then
        local edited, text = field(T("Name", "Nom") .. "##tc_preset_name", preset_name_field)
        if edited and type(text) == "string" then preset_name_field = (text:gsub("%z.*$", "")) end
        tip("Name of the preset to save: the settings as they are now, under this name.",
            "Nom du préréglage à enregistrer : les réglages tels qu'ils sont, sous ce nom.")
        imgui.same_line()
        if imgui.button(T("Save", "Enregistrer") .. "##tc_preset_save") then
            if C.save_preset(preset_name_field) then preset_name_field = "" end
        end
        tip("Saves the settings as they are now. An existing name is overwritten. Default and Custom cannot be used.",
            "Enregistre les réglages tels qu'ils sont. Un nom déjà pris est remplacé. Défaut et Personnalisé sont réservés.")
    end

    if C.preset_names()[1] and current ~= "default" and current ~= "custom" then
        imgui.same_line()
        if imgui.button(T("Delete this preset", "Supprimer ce préréglage") .. "##tc_preset_del") then
            C.delete_preset(current)
        end
        tip("Removes this preset. The settings themselves stay as they are.",
            "Retire ce préréglage. Les réglages en cours ne changent pas.")
    end
end

----------------------------------------------------------------------
-- Entry point, called from re.on_draw_ui
----------------------------------------------------------------------
function M.install(h) host = h end

-- 1.37: the wheel's styles at the root, as buttons side by side (the one in use in gold)
local BTN, BTN_HOV, BTN_ACT = 21, 22, 23            -- ImGuiCol_Button, ButtonHovered, ButtonActive
local function style_row(title_en, title_fr, key, list, w, h)
    colored(GOLD_HEAD, function() imgui.text(T(title_en, title_fr)) end)
    local cur = C.values[key]
    local size = (Vector2f and Vector2f.new) and Vector2f.new(w, h) or nil
    for i, b in ipairs(list) do
        if i > 1 then imgui.same_line() end
        local on = (cur == b.value)
        if on then
            imgui.push_style_color(BTN, 0xFF1E5A7A); imgui.push_style_color(BTN_HOV, 0xFF2A6E92); imgui.push_style_color(BTN_ACT, 0xFF2A6E92)
            imgui.push_style_color(COL_TEXT, 0xFFFFFFFF)
        end
        local label = T(b.en, b.fr) .. "##tc_style_" .. key .. i
        local ok, pressed = pcall(imgui.button, label, size)
        if not ok then pressed = imgui.button(label) end
        if on then imgui.pop_style_color(4) end
        if b.tip then tip(b.tip[1], b.tip[2]) end
        if pressed and not on then C.set(key, b.value) end
    end
end
local WHEEL_STYLES = {
    { value = "open",    en = "Modern",        fr = "Moderne" },
    { value = "soph",    en = "Minimalist",    fr = "Minimaliste" },
    { value = "fan",     en = "Cards",         fr = "Cartes" },
    { value = "classic", en = "Framed",        fr = "Encadrée" },
}
local ATB_STYLES = {
    { value = true,  en = "Large", fr = "Grand",
      tip = { "Big ATB gauge and order queue (with BardN ATB Combat System).", "Grande jauge ATB et file d'ordres (avec BardN ATB Combat System)." } },
    { value = false, en = "Above the head", fr = "Au-dessus de la tête",
      tip = { "The usual ATB gauges stay above the characters' heads while the wheel is open.", "Les jauges ATB habituelles restent au-dessus de la tête des personnages pendant que la roue est ouverte." } },
}
-- 1.38: the targeting step's look and the enemy marker's look, as rows of buttons too
local MARKERS = {
    { value = "arcs",  en = "Target",  fr = "Cible",    tip = { "Turning arcs around the enemy, a diamond above.", "Arcs qui tournent autour de l'ennemi, losange au-dessus." } },
    { value = "glow",  en = "Diamond", fr = "Losange", tip = { "Glowing diamond above the head.", "Losange lumineux au-dessus de la tête." } },
    { value = "line",  en = "Line",    fr = "Liseré",  tip = { "Name on a gold line, no backing.", "Nom sur un liseré doré, sans fond." } },
    { value = "life",  en = "Line + HP", fr = "Liseré + PV",     tip = { "Name and the target's life.", "Nom et vie de la cible." } },
}
-- 1.42: the aim line's look, back at the root
local LINES = {
    { value = "comet",  en = "Comet",            fr = "Comète",          tip = { "A light runs from the character to the enemy.", "Une lumière court du personnage jusqu'à l'ennemi." } },
    { value = "breath", en = "Breathing thread", fr = "Fil qui respire", tip = { "Broad waves of light roll towards the enemy.", "De larges vagues de lumière roulent vers l'ennemi." } },
    { value = "arrow",  en = "Archer's shot",    fr = "Trait d'archer",  tip = { "A clean line, fletching at the start, a point on the enemy.", "Un fil net, un empennage au départ, une pointe sur l'ennemi." } },
}
local function draw_style_buttons()
    style_row("WHEEL STYLE", "STYLE DE LA ROUE", "look_cell_style", WHEEL_STYLES, 150, 40)
    style_row("TARGET: ENEMY MARKER", "CIBLE : MARQUEUR DE L'ENNEMI", "marker_style", MARKERS, 150, 32)
    style_row("AIM LINE", "LIGNE DE VISÉE", "line_style", LINES, 150, 32)
    draw_preview()                               -- 1.37: the preview button sits with the style buttons
    -- 1.42: a small line saying whether the ATB Combat System is there, and where its gauge's look is set
    imgui.spacing(); imgui.separator()
    if API.atb == nil then
        colored(INFO, function() imgui.text(T("BardN ATB Combat System: not detected.", "BardN ATB Combat System : non détecté.")) end)
    else
        colored(0xFF7ACF6F, function() imgui.text(T("BardN ATB Combat System: detected.", "BardN ATB Combat System : détecté.")) end)
        if C.values.look_atb_native ~= false then
            colored(INFO, function() imgui.text(T("The big gauge's look (colours, liquid, light) is set in BardN ATB Combat System.",
                "L'apparence de la grande jauge (couleurs, liquide, lumière) se règle dans BardN ATB Combat System.")) end)
        end
    end
    -- 1.38: the ATB Combat System style apart, under the preview (only with the ATB Combat System installed)
    if API.atb ~= nil then
        imgui.spacing()
        style_row("ATB COMBAT SYSTEM STYLE (with BardN ATB Combat System)", "STYLE ATB COMBAT SYSTEM (avec BardN ATB Combat System)", "look_atb_style", ATB_STYLES, 200, 32)
        -- 1.42: the big gauge's settings, right under its row (they were lost in « Look of the wheel »)
        if C.values.look_atb_style ~= false then
            drawer("atbgauge", "Big ATB gauge: position, size, colours", "Grande jauge ATB : position, taille, couleurs", function()
                draw_items({ "look_atb_x", "look_atb_y", "look_atb_seg", "look_atb_h", "look_atb_shape", "look_atb_shade_size",
                    "look_atb_shade_op", "look_atb_native", "look_atb_col_link", "look_atb_col_fill", "look_atb_col_part",
                    "look_atb_col_empty", "look_atb_col_edge", "look_atb_col_text" })
                imgui.text(T("  Cards style: the gauge is centred above the cards (left end and height are not used).",
                    "  Style Cartes : la jauge est centrée au-dessus des cartes (bout gauche et hauteur ne servent pas)."))
            end)
        end
    end
end

function M.draw()
    if not imgui.tree_node(host.title .. "##tc_root") then return end
    B.update_capture()

    draw_preset()
    draw_setting(S.BY_KEY.language)
    host.draw_module()
    draw_style_buttons()
    imgui.separator()
    for _, d in ipairs(DRAWERS) do
        if d.dev ~= true or Safe.DEV then
            drawer(d.id, d.en, d.fr, function() draw_items(d.items) end)
        end
    end
    imgui.tree_pop()
end

return M
