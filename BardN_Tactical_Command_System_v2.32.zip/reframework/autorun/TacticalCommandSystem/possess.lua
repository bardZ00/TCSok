-- TacticalCommandSystem/possess.lua
-- Taking control of the character the wheel is on.
--
-- Scroll to a pawn in the wheel's top row, press the take-control button, and the wheel closes with that pawn as the
-- character being played. Scroll to the Arisen and press it again to come back. One gesture, both directions, and
-- no counting presses to reach the third pawn.
--
-- ============================================================================================
-- This mod does not do the possessing. Direct Pawn Control does.
-- ============================================================================================
-- Playing a pawn is far more than a camera: the player's input processor has to be moved across, the pawn's AI
-- suspended, the Arisen given a brain so he keeps fighting, the HUD rebound, and all of it undone cleanly on death,
-- on a warp, on a cutscene and on leaving to the title screen. Direct Pawn Control by Hazzer already does all of
-- that, and does it well. Writing a second engine for it here would mean maintaining the same hard work twice and,
-- worse, two mods fighting over the same character.
--
-- So this file is a remote control, nothing more. DPC keeps every bit of the machinery; this mod only says which
-- pawn, and when. Both mods stay installed, each doing the half it is good at.
--
-- This file knows three doors, best first:
--
--   * 0.9.173 and later (DPC_API "control" feature, added by DPC's author at this mod's request):
--         DPC_API.possess(chara, { mod = ... })     take control of that pawn (matched by address)
--         DPC_API.release_pawn({ mod = ... })        give the Arisen back
--     Both return true, or nil and a reason (loading, cutscene, coop, downed...), and never throw. The switch itself
--     runs on DPC's next game frame, like its own key; a "control_failed" event says why if it could not happen.
--
--   * a local handle, _G.DPC.possess / release / active, that a patched copy of 0.9.165 carried. It was never in
--     an official DPC release (DPC's author checked every build); it stays supported only so that copy keeps
--     working, and should not be passed around.
--
--   * 0.9.170 - 0.9.172: _G.DPC_API without "control": read-only (state, events, camera claims, overrides). The
--     wheel can only aim: DPC's own possession hotkey acts on the pawn in its `selected_pawn_idx` setting, which
--     the API can write. The player's own DPC key does the rest.
--
-- Every call is wrapped: no DPC, an unknown build, or an API that changed again all end up the same way -- the
-- feature reports what it can do, and the wheel behaves exactly as it did before.
--
-- ============================================================================================
-- The index is looked up, never guessed
-- ============================================================================================
-- DPC numbers the party by position in `app.PawnManager.get_PawnCharacterList()`. This mod's own wheel does not use
-- that order: it puts the main pawn first (read from its own field, the one place its pawn object is certain to be),
-- then merges in the character list and the party-pawn list, skipping duplicates by address. The two orders usually
-- agree, and "usually" is not good enough when being wrong means possessing the wrong pawn. So the index is read
-- from DPC's own source, by address, at the moment it is needed -- not derived from where the pawn sits in the wheel.

local U = require("TacticalCommandSystem.utils")
local Focus = require("TacticalCommandSystem.camera")

local P = {}

P.enabled = true

-- The locked character: the one closing the wheel always returns you to, whatever the top row happens to be on. It
-- blocks the body-switch that an unlocked wheel does on close. Locked on the Arisen by default, so that until the
-- player deliberately locks a pawn, closing the wheel never changes who they play -- they can order every pawn from
-- the wheel and stay themselves. { kind = "arisen" } or { kind = "pawn", addr = <address>, name = <label> }, or nil
-- for free travel (every close lands you in whoever the top row is on).
P.lock = { kind = "arisen" }

P.report = { found = false, version = nil, active = false, idx = nil, last = nil }

----------------------------------------------------------------------------------------------------
-- the lock
----------------------------------------------------------------------------------------------------
-- Is this wheel entry the one currently locked? Used by the top row to mark it, and to decide toggle vs move.
function P.is_locked(entry)
    if not (P.lock and entry) then return false end
    if P.lock.kind == "arisen" then return entry.kind == "arisen" end
    return entry.kind ~= "arisen" and entry.addr ~= nil and entry.addr == P.lock.addr
end

-- Lock the highlighted character, or unlock it if it was already the locked one. Returns a flash label.
function P.toggle_lock(entry)
    if not entry then return nil end
    if P.is_locked(entry) then
        P.lock = nil
        return "[ VERROU RETIRE / LOCK CLEARED ]"
    end
    if entry.kind == "arisen" then
        P.lock = { kind = "arisen" }
    else
        P.lock = { kind = "pawn", addr = entry.addr, name = entry.name }
    end
    return "[ " .. U.upper(entry.name or "?") .. " : VERROUILLE / LOCKED ]"
end

-- Who closing the wheel should land you in: the locked character when there is a lock, otherwise whoever the top row
-- is on. A lock on a pawn that has left the party falls back to the Arisen, so the player is never stranded in a body
-- they can no longer reach. Returns a wheel entry from `pawns`, or nil when there is nothing to do.
function P.close_target(pawns, current)
    if not P.lock then return current end
    if P.lock.kind == "arisen" then
        for _, p in ipairs(pawns or {}) do if p.kind == "arisen" then return p end end
        return nil
    end
    for _, p in ipairs(pawns or {}) do
        if p.kind ~= "arisen" and p.addr == P.lock.addr then return p end
    end
    -- the locked pawn is gone: fall back to the Arisen rather than leaving the player stuck
    for _, p in ipairs(pawns or {}) do if p.kind == "arisen" then return p end end
    return nil
end

----------------------------------------------------------------------------------------------------
-- is Direct Pawn Control there, and does it still speak the same language?
----------------------------------------------------------------------------------------------------
-- 0.9.165's handle: the only one that can switch body.
local function handle()
    local h = rawget(_G, "DPC")
    if type(h) ~= "table" then return nil end
    if type(h.possess) ~= "function" or type(h.release) ~= "function" then return nil end
    return h
end

-- 0.9.170's API: reads the state, lends the camera, writes a setting. Cannot possess.
local function api()
    local a = rawget(_G, "DPC_API")
    if type(a) ~= "table" then return nil end
    if type(a.state) ~= "function" then return nil end
    return a
end

P.api = api        -- camera.lua borrows the same lookup for its claim

-- 0.9.173+: the API can start and end a possession
local MOD_TAG = { mod = "Tactical Command System" }
local function control()
    local a = api()
    if not a then return nil end
    if type(a.has) ~= "function" or type(a.possess) ~= "function" or type(a.release_pawn) ~= "function" then
        return nil
    end
    local ok, yes = pcall(a.has, "control")
    if ok and yes == true then return a end
    return nil
end

-- why a switch asked through the API did not happen in the end (DPC fires it a frame later), kept for the menu
local failed_hooked = false
local function watch_failures(a)
    if failed_hooked or type(a.on) ~= "function" then return end
    failed_hooked = true
    pcall(a.on, "control_failed", function(ev)
        P.report.last = "failed: " .. tostring(type(ev) == "table" and ev.reason or "?")
    end, MOD_TAG)
end

-- "control" = can switch body through the API (0.9.173+), "legacy" = through the patched local handle,
-- "modern" = present but read-only, nil = not installed.
function P.kind()
    if control() then return "control" end
    if handle() then return "legacy" end
    if api() then return "modern" end
    return nil
end

-- Is DPC installed at all, whichever build. The menu uses this to tell "absent" from "present but read-only".
function P.present()
    return P.kind() ~= nil
end

-- Can the wheel actually change who you play? DPC 0.9.173+ (API "control") and the patched local handle can; so
-- everything that depends on the body-switch (the character lock, the switch on close) stays off on 0.9.170 - 0.9.172
-- rather than half-working.
function P.available()
    local c = control()
    local h = not c and handle() or nil
    local a = c or (not h and api()) or nil
    P.report.found = (h or a) ~= nil
    P.report.kind = P.kind()
    if h then
        P.report.version = tostring(h.version or "?")
    elseif a then
        P.report.version = tostring(a.dpc_version or a.version or "?")
    else
        P.report.version = nil
    end
    return c ~= nil or h ~= nil
end

-- Is a pawn being played right now, and which one. Used both to label the wheel and to decide whether selecting the
-- Arisen means "come back" or "you are already him".
function P.active()
    local h = handle()
    if h and type(h.active) == "function" then
        local ok, on, idx = pcall(h.active)
        if ok then
            P.report.active, P.report.idx = on == true, idx
            return on == true, idx
        end
    else
        -- 0.9.170: the state carries the character itself, so the index is looked up from it
        local a = api()
        if a then
            local ok, st = pcall(a.state)
            if ok and type(st) == "table" then
                local on = st.active == true
                local chara = on and st.played and st.played.chara or nil
                local idx = chara and P.index_of(chara) or nil
                P.report.active, P.report.idx = on, idx
                return on, idx
            end
        end
    end
    P.report.active, P.report.idx = false, nil
    return false, nil
end

-- The address of the character currently being played through DPC, or nil when it is the Arisen (or DPC is absent).
-- Used to open the wheel already on that character: DPC gives us an index into its own list, and this turns that back
-- into the character object the wheel lists by address.
function P.active_addr()
    local on, idx = P.active()
    if not (on and idx) then return nil end
    local manager = U.safe_call(function() return sdk.get_managed_singleton("app.PawnManager") end)
    if not manager then return nil end
    local list = U.safe_call(function() return manager:call("get_PawnCharacterList") end)
    if not list then return nil end
    local chara = U.safe_call(function() return list:call("get_Item", idx) end)
        or U.safe_call(function() return list[idx] end)
    if not chara then return nil end
    return U.safe_call(function() return chara:get_address() end)
end

----------------------------------------------------------------------------------------------------
-- which number DPC knows this pawn by
----------------------------------------------------------------------------------------------------
function P.index_of(chara)
    local want = U.safe_call(function() return chara:get_address() end)
    if not want then return nil end
    local manager = U.safe_call(function() return sdk.get_managed_singleton("app.PawnManager") end)
    if not manager then return nil end
    local list = U.safe_call(function() return manager:call("get_PawnCharacterList") end)
    if not list then return nil end
    local count = tonumber(U.safe_call(function() return list:call("get_Count") end)) or 0
    for i = 0, count - 1 do
        local c = U.safe_call(function() return list:call("get_Item", i) end)
            or U.safe_call(function() return list[i] end)
        local addr = c and U.safe_call(function() return c:get_address() end)
        if addr and addr == want then return i end
    end
    return nil
end

----------------------------------------------------------------------------------------------------
-- the switch itself
----------------------------------------------------------------------------------------------------
-- Returns a message for the wheel's flash line, or nil when there is nothing to say.
--
-- The camera is handed over rather than released. This mod is holding it on the pawn (the wheel has been looking at
-- it all along) and DPC is about to hold it on the very same pawn, so the right thing is to let go without putting
-- it back: step out quietly and the view does not move at all. Releasing instead would send the camera home to the
-- Arisen for the frame or two before DPC claims it, which reads as a flinch at the exact moment the player expects
-- the smoothest part of the whole gesture.
function P.switch_to(entry)
    if not P.enabled then return nil end
    if not entry then return nil end

    if not P.available() then
        -- 0.9.170 and later: no call starts a possession, so the most the wheel can do is put DPC's own key on
        -- the right pawn. The Arisen is not aimed at: DPC's key releases by itself when a pawn is being played.
        if P.kind() == "modern" then
            if entry.kind == "arisen" then
                return "[ 0.9.170 : TOUCHE DPC POUR REVENIR / PRESS YOUR DPC KEY ]"
            end
            local a = api()
            local idx = entry.chara and P.index_of(entry.chara) or nil
            if a and idx and type(a.override) == "function" then
                local ok = pcall(a.override, "selected_pawn_idx", idx, { mod = "Tactical Command System" })
                P.report.last = ok and ("aimed " .. tostring(idx)) or "aim failed"
                if ok then
                    return "[ " .. U.upper(entry.name or "PAWN") .. " VISE : TOUCHE DPC / PRESS YOUR DPC KEY ]"
                end
            end
            return "[ DPC 0.9.170 : PRISE DE CONTROLE INDISPONIBLE / TAKING CONTROL UNAVAILABLE ]"
        end
        return "[ DIRECT PAWN CONTROL INTROUVABLE / NOT FOUND ]"
    end
    local c = control()
    local h = not c and handle() or nil
    if c then watch_failures(c) end
    local on = P.active()

    ------------------------------------------------------------------ back to the Arisen
    if entry.kind == "arisen" then
        if not on then return nil end            -- already him: the button simply closes the wheel
        if c then
            -- DPC checks at once and switches on its next frame: the camera is handed over only once it said yes
            local ok, done, why = pcall(c.release_pawn, MOD_TAG)
            P.report.last = (ok and done) and "release" or ("release refused: " .. tostring(why))
            if ok and done then Focus.handover(); return "[ DE RETOUR / BACK AS THE ARISEN ]" end
            return "[ RETOUR REFUSE / RETURN REFUSED : " .. U.upper(tostring(why or "?")) .. " ]"
        end
        Focus.handover()
        local ok = pcall(h.release)
        P.report.last = ok and "release" or "release failed"
        return ok and "[ DE RETOUR / BACK AS THE ARISEN ]" or nil
    end

    ------------------------------------------------------------------ into a pawn
    local chara = entry.chara
    if not (chara and U.is_valid_obj(chara)) then return nil end
    if U.is_dead(chara) then
        return "[ " .. U.upper(entry.name or "PAWN") .. " : A TERRE / DOWNED ]"
    end

    local idx = P.index_of(chara)
    if not idx then
        P.report.last = "index not found"
        return "[ " .. U.upper(entry.name or "PAWN") .. " : INTROUVABLE / NOT IN PARTY LIST ]"
    end

    -- already playing that one: nothing to do, the wheel just closes
    local _, cur = P.active()
    if on and cur == idx then return nil end

    if c then
        -- DPC matches the character by address, so it is passed as is; the index above only guards "already him".
        -- It checks at once and switches on its next frame: the camera is handed over only once it said yes.
        local okc, done, why = pcall(c.possess, chara, MOD_TAG)
        P.report.last = (okc and done) and ("possess " .. tostring(idx)) or ("possess refused: " .. tostring(why))
        if not (okc and done) then
            return "[ " .. U.upper(entry.name or "PAWN") .. " : REFUSE / REFUSED (" .. U.upper(tostring(why or "?")) .. ") ]"
        end
        Focus.handover()
        return "[ VOUS ETES / YOU ARE " .. U.upper(entry.name or "PAWN") .. " ]"
    end
    Focus.handover()
    local ok, took = pcall(h.possess, idx)
    P.report.last = (ok and took ~= false) and ("possess " .. tostring(idx)) or "possess failed"
    if not (ok and took ~= false) then
        return "[ " .. U.upper(entry.name or "PAWN") .. " : REFUSE / REFUSED ]"
    end
    return "[ VOUS ETES / YOU ARE " .. U.upper(entry.name or "PAWN") .. " ]"
end

return P
