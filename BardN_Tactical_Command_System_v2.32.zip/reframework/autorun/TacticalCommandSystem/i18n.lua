-- TacticalCommandSystem/i18n.lua  (BardN)
-- English / French display layer.
--   * Texts written by the mod itself are translated by hand (EXACT table + RULES for messages with variable parts).
--   * Names that come from the game (skills, items, enemies, pawns, grimoires) are NOT translated here:
--     they are read from the game, so they follow the language the game itself is running in.
-- The mod keeps working in English internally; translation only happens when a text is displayed.
-- Language setting: "auto" (follow the game language), "en", "fr", "zh" (2.22, simplified Chinese).

local I = {}

local mode = "auto"
local resolved = nil          -- "en" / "fr" once the game language is known (auto mode)
local tries, next_try = 0, 0
local cache, cache_n = {}, 0

----------------------------------------------------------------------
-- Game language detection (read only, same getter as BardN Enemy Break Equipment)
----------------------------------------------------------------------
local function game_is_french()
    local ok, res = pcall(function()
        local td = sdk.find_type_definition("via.gui.GUISystem")
        local sing = sdk.get_native_singleton("via.gui.GUISystem")
        if not (td and sing) then return nil end
        local lang = sdk.call_native_func(sing, td, "get_MessageLanguage")
        if lang == nil then return nil end
        local fr = sdk.find_type_definition("via.Language"):get_field("French"):get_data(nil)
        return tonumber(lang) == tonumber(fr)
    end)
    if ok then return res end
    return nil
end

function I.set_mode(m)
    if m ~= "en" and m ~= "fr" and m ~= "zh" then m = "auto" end
    if m ~= mode then
        mode = m
        cache, cache_n = {}, 0
    end
end

-- Current display language: "en" or "fr"
function I.lang()
    if mode == "fr" then return "fr" end
    if mode == "en" then return "en" end
    if mode == "zh" then return "zh" end
    if resolved then return resolved end
    if tries < 30 then
        local now = os.clock()
        if now >= next_try then
            tries = tries + 1
            next_try = now + 2.0
            local fr = game_is_french()
            if fr ~= nil then
                resolved = fr and "fr" or "en"
                cache, cache_n = {}, 0
                return resolved
            end
        end
    end
    return "en"
end

local ZH                      -- 2.22: filled further down, used by I.pick
-- Inline helper for menu text: I.pick("English", "Français")
function I.pick(en, fr)
    local l = I.lang()
    if l == "fr" then return fr end
    if l == "zh" then return ZH[en] or en end     -- 2.22: menu texts not translated yet fall back to English
    return en
end

----------------------------------------------------------------------
-- 2.22: simplified Chinese. Same keys as EXACT. A text missing here is shown in English, so the
-- translation can grow version after version without breaking anything. Machine-assisted, to be reviewed.
----------------------------------------------------------------------
ZH = {
    ["FIGHTER"] = "战士",
    ["ARCHER"] = "弓箭手",
    ["MAGE"] = "法师",
    ["THIEF"] = "盗贼",
    ["WARRIOR"] = "狂战士",
    ["SORCERER"] = "魔法师",
    ["PAWN UNIT"] = "仆从",
    ["FREE"] = "自由",
    ["HOLD"] = "原地待命",
    ["TACTICAL: WAIT HERE"] = "战术：在此等待",
    ["ESCORT"] = "护卫",
    ["TACTICAL: GUARD ARISEN"] = "战术：保护觉醒者",
    ["RANGED"] = "保持距离",
    ["TACTICAL: KEEP DISTANCE"] = "战术：保持距离",
    ["STANCE"] = "姿态",
    ["TEAM STANCE"] = "全队姿态",
    ["ALL PAWNS"] = "所有仆从",
    ["[ MIXED ]"] = "[ 混合 ]",
    ["[ NO PAWN ]"] = "[ 无仆从 ]",
    ["[ NO PAWN IN THE PARTY ]"] = "[ 队伍中没有仆从 ]",
    ["CANCEL"] = "取消",
    ["[ FREE ]"] = "[ 自由 ]",
    ["[ ESCORT ]"] = "[ 护卫 ]",
    ["[ HOLD ]"] = "[ 原地待命 ]",
    ["[ RANGED ]"] = "[ 保持距离 ]",
    ["STANCE: FREE"] = "姿态：自由",
    ["STANCE: HOLD"] = "姿态：原地待命",
    ["STANCE: ESCORT"] = "姿态：护卫",
    ["STANCE: RANGED"] = "姿态：保持距离",
    ["SELECT TARGET"] = "选择目标",
    ["CYCLE ENEMY / CLEAR"] = "切换敌人 / 清除",
    ["CANCEL / FREE"] = "取消 / 自由",
    ["CLEAR QUEUE & RESET"] = "清空队列并重置",
    ["EMPTY SLOT"] = "空栏位",
    ["NO SKILL EQUIPPED"] = "未装备技能",
    ["LAUNCH STANCE"] = "助跳姿势",
    ["SUPPORT / ALLY"] = "辅助 / 同伴",
    ["SELF / AREA BUFF"] = "自身 / 范围增益",
    ["ASSAULT / TARGET"] = "强攻 / 目标",
    ["SKILL"] = "技能",
    ["STAMINA"] = "耐力",
    ["STEER LEFT OR RIGHT"] = "左右推摇杆选择",
    ["SELECT A TARGET FIRST"] = "请先选择目标",
    ["CONFIRM"] = "确认",
    ["[ NO TARGET ]"] = "[ 无目标 ]",
    ["[ ACTIVE ]"] = "[ 进行中 ]",
    ["[ CHANNELING ]"] = "[ 蓄力中 ]",
    ["ORDER SENT"] = "指令已下达",
    ["CHANNELING"] = "蓄力中",
    ["IN PROGRESS"] = "进行中",
    ["[ LOW STAMINA ]"] = "[ 耐力不足 ]",
    ["[ STANCE ACTIVE ]"] = "[ 姿态生效中 ]",
    ["[ UNAVAILABLE ]"] = "[ 不可用 ]",
    ["[ NONE SELECTED ]"] = "[ 未选择 ]",
    ["ENEMY"] = "敌人",
    ["PAWN"] = "仆从",
    ["MAIN PAWN"] = "主仆从",
    ["CLEAR QUEUE"] = "清空队列",
    ["CLEAR QUEUE & TARGET"] = "清空队列和目标",
    ["MANUAL ONLY"] = "仅手动",
    ["TOGGLE ON / OFF"] = "开启 / 关闭",
    ["LOCK PLAYED CHARACTER"] = "锁定操作角色",
    ["UNLOCK PLAYED CHARACTER"] = "解锁操作角色",
    ["[ MANUAL ONLY ]"] = "[ 仅手动 ]",
    ["[ THIS SKILL CANNOT BE LOCKED ]"] = "[ 该技能无法锁定 ]",
    ["QUEUE ONLY"] = "加入队列",
    ["[ ALL PAWNS : QUEUES & TARGET CLEARED - FREE ]"] = "[ 所有仆从：队列和目标已清空 - 自由 ]",
    ["CLOSE"] = "关闭",
    ["CONFIRM & CLOSE"] = "确认并关闭",
    ["QUEUE SKILL / ALL STANCE"] = "技能入队 / 全队姿态",
    ["TARGET"] = "目标",
    ["UNBOUND"] = "未设置",
    ["D-PAD"] = "十字键",
    ["ARISEN"] = "觉醒者",
    ["ORDER & CLOSE"] = "下令并关闭",
    ["ORDER & STAY"] = "下令并保持",
    ["CHARACTER"] = "角色",
    ["TARGET LEFT / RIGHT"] = "左 / 右目标",
    ["GO"] = "确认",
    ["CHARGED"] = "蓄力版",
    ["QUICK"] = "瞬发版",
    ["BACK"] = "返回",
    ["PENDING SKILL"] = "待执行技能",
    ["[ NO TARGETING ]"] = "[ 无需选取目标 ]",
    ["NO ENEMIES IN RANGE: LAUNCH WITHOUT TARGET"] = "范围内无敌人：无目标释放",
    ["NO ENEMIES IN RANGE"] = "范围内无敌人",
    ["ORDER QUEUE"] = "指令队列",
    ["ENEMY OUT OF VIEW"] = "敌人不在视野内",
    ["TOO DARK: NO ENEMY ENGAGED"] = "太暗：未进入战斗",
    ["NO ENEMY IN SIGHT"] = "视野中没有敌人",
    ["ENEMY OUT OF VIEW: LAUNCH WITHOUT TARGET"] = "敌人不在视野内：无目标释放",
    ["TOO DARK: NO ENEMY ENGAGED: LAUNCH WITHOUT TARGET"] = "太暗：未进入战斗：无目标释放",
    ["NO ENEMY IN SIGHT: LAUNCH WITHOUT TARGET"] = "视野中没有敌人：无目标释放",
    ["[ ENEMY OUT OF VIEW ]"] = "[ 敌人不在视野内 ]",
    ["[ TOO DARK: NO ENEMY ENGAGED ]"] = "[ 太暗：未进入战斗 ]",
    ["[ NO ENEMY IN SIGHT ]"] = "[ 视野中没有敌人 ]",
    ["[ WHEEL NOT READY: USE A SKILL ONCE WITH ITS BUTTON ]"] = "[ 轮盘尚未就绪：先用按键使用一次技能 ]",
    ["[ LAUNCH ERROR (SEE LOG) ]"] = "[ 释放失败（见日志） ]",
    ["[ ! ATB INTO THE RED ! ]"] = "[ ！ATB 进入红区！ ]",
    ["[ SELECT A TARGET FIRST ]"] = "[ 请先选择目标 ]",
    ["[ ALL PAWNS : QUEUES CLEARED & FREE ]"] = "[ 所有仆从：队列已清空 - 自由 ]",
    ["[ NO ENEMIES IN RANGE ]"] = "[ 范围内无敌人 ]",
    ["[ TARGET CLEARED ]"] = "[ 目标已清除 ]",
    ["[ NO PAWN SELECTED ]"] = "[ 未选择仆从 ]",
}
----------------------------------------------------------------------
-- Exact translations (whole displayed string)
----------------------------------------------------------------------
local EXACT = {
    -- vocations
    ["FIGHTER"] = "GUERRIER",
    ["ARCHER"] = "ARCHER",
    ["MAGE"] = "MAGE",
    ["THIEF"] = "VOLEUR",
    ["WARRIOR"] = "CHAMPION",
    ["SORCERER"] = "SORCIER",
    ["PAWN UNIT"] = "PION",

    -- stances
    ["FREE"] = "LIBRE",
    ["HOLD"] = "IMMOBILE",
    ["TACTICAL: WAIT HERE"] = "TACTIQUE : ATTENDRE ICI",
    ["ESCORT"] = "ESCORTE",
    ["TACTICAL: GUARD ARISEN"] = "TACTIQUE : PROTÉGER L'INSURGÉ",
    ["RANGED"] = "À DISTANCE",
    ["TACTICAL: KEEP DISTANCE"] = "TACTIQUE : GARDER SES DISTANCES",
    ["STANCE"] = "POSTURE",
    ["TEAM STANCE"] = "POSTURE D'ÉQUIPE",
    ["ALL PAWNS"] = "TOUS LES PIONS",
    ["[ MIXED ]"] = "[ MIXTE ]",
    ["[ NO PAWN ]"] = "[ AUCUN PION ]",
    ["[ NO PAWN IN THE PARTY ]"] = "[ AUCUN PION DANS L'ÉQUIPE ]",
    ["CANCEL"] = "ANNULER",
    ["[ FREE ]"] = "[ LIBRE ]",
    ["[ ESCORT ]"] = "[ ESCORTE ]",
    ["[ HOLD ]"] = "[ IMMOBILE ]",
    ["[ RANGED ]"] = "[ À DISTANCE ]",
    ["STANCE: FREE"] = "POSTURE : LIBRE",
    ["STANCE: HOLD"] = "POSTURE : IMMOBILE",
    ["STANCE: ESCORT"] = "POSTURE : ESCORTE",
    ["STANCE: RANGED"] = "POSTURE : À DISTANCE",

    -- general commands
    ["SELECT TARGET"] = "CHOISIR UNE CIBLE",
    ["CYCLE ENEMY / CLEAR"] = "ENNEMI SUIVANT / EFFACER",
    ["CANCEL / FREE"] = "ANNULER / LIBRE",
    ["CLEAR QUEUE & RESET"] = "VIDER LA FILE ET RÉINITIALISER",
    ["EMPTY SLOT"] = "EMPLACEMENT VIDE",
    ["NO SKILL EQUIPPED"] = "AUCUNE COMPÉTENCE ÉQUIPÉE",
    ["LAUNCH STANCE"] = "POSTURE DE LANCEMENT",
    ["SUPPORT / ALLY"] = "SOUTIEN / ALLIÉ",
    ["SELF / AREA BUFF"] = "BONUS PERSO / DE ZONE",
    ["ASSAULT / TARGET"] = "ASSAUT / CIBLE",
    ["SKILL"] = "COMPÉTENCE",

    -- item wheel
    ["STAMINA"] = "ENDURANCE",

    -- centre text
    ["STEER LEFT OR RIGHT"] = "INCLINE LE STICK POUR CHOISIR",
    ["SELECT A TARGET FIRST"] = "CHOISIS D'ABORD UNE CIBLE",
    ["CONFIRM"] = "VALIDER",

    -- tags on the banners
    ["[ NO TARGET ]"] = "[ PAS DE CIBLE ]",
    ["[ ACTIVE ]"] = "[ ACTIF ]",
    ["[ CHANNELING ]"] = "[ CANALISATION ]",
    ["ORDER SENT"] = "ORDRE ENVOYÉ",
    ["CHANNELING"] = "CANALISATION",
    ["IN PROGRESS"] = "EN COURS",
    ["[ LOW STAMINA ]"] = "[ ENDURANCE FAIBLE ]",
    ["[ STANCE ACTIVE ]"] = "[ POSTURE ACTIVE ]",
    ["[ UNAVAILABLE ]"] = "[ INDISPONIBLE ]",
    ["[ NONE SELECTED ]"] = "[ AUCUNE ]",

    -- fallback names
    ["ENEMY"] = "ENNEMI",
    ["PAWN"] = "PION",
    ["MAIN PAWN"] = "PION PRINCIPAL",

    -- prompt bar
    ["CLEAR QUEUE"] = "VIDER LA FILE",
    ["CLEAR QUEUE & TARGET"] = "VIDER FILE ET CIBLE",
    ["MANUAL ONLY"] = "MANUEL SEUL",
    ["TOGGLE ON / OFF"] = "ACTIVER / DÉSACTIVER",
    ["LOCK PLAYED CHARACTER"] = "VERROUILLER LE PERSONNAGE JOUÉ",
    ["UNLOCK PLAYED CHARACTER"] = "DÉVERROUILLER LE PERSONNAGE JOUÉ",
    ["[ MANUAL ONLY ]"] = "[ MANUEL SEUL ]",
    ["[ THIS SKILL CANNOT BE LOCKED ]"] = "[ CETTE COMPÉTENCE NE PEUT PAS ÊTRE VERROUILLÉE ]",
    ["QUEUE ONLY"] = "AJOUTER À LA FILE",
    ["[ ALL PAWNS : QUEUES & TARGET CLEARED - FREE ]"] = "[ TOUS LES PIONS : FILES ET CIBLE VIDÉES - LIBRES ]",
    ["CLOSE"] = "FERMER",
    ["CONFIRM & CLOSE"] = "VALIDER ET FERMER",
    ["QUEUE SKILL / ALL STANCE"] = "FILE D'ORDRES / POSTURE POUR TOUS",
    ["TARGET"] = "CIBLE",
    ["UNBOUND"] = "NON ASSIGNÉ",
    ["D-PAD"] = "CROIX",

    -- Tactical Command System
    ["ARISEN"] = "INSURGÉ",
    ["ORDER & CLOSE"] = "ORDONNER ET FERMER",
    ["ORDER & STAY"] = "ORDONNER ET RESTER",
    ["CHARACTER"] = "PERSONNAGE",
    ["TARGET LEFT / RIGHT"] = "CIBLE À GAUCHE / À DROITE",
    ["GO"] = "VALIDER",
    ["CHARGED"] = "CHARGÉE",
    ["QUICK"] = "IMMÉDIATE",
    ["BACK"] = "RETOUR",
    ["PENDING SKILL"] = "COMPÉTENCE EN ATTENTE",
    ["[ NO TARGETING ]"] = "[ SANS CIBLAGE ]",
    ["NO ENEMIES IN RANGE: LAUNCH WITHOUT TARGET"] = "AUCUN ENNEMI À PORTÉE : LANCER SANS CIBLE",
    ["NO ENEMIES IN RANGE"] = "AUCUN ENNEMI À PORTÉE",
    ["ORDER QUEUE"] = "FILE D'ORDRES",
    ["ENEMY OUT OF VIEW"] = "ENNEMI HORS CHAMP",
    ["TOO DARK: NO ENEMY ENGAGED"] = "TROP SOMBRE : AUCUN ENNEMI ENGAGÉ",
    ["NO ENEMY IN SIGHT"] = "AUCUN ENNEMI EN VUE",
    ["ENEMY OUT OF VIEW: LAUNCH WITHOUT TARGET"] = "ENNEMI HORS CHAMP : LANCER SANS CIBLE",
    ["TOO DARK: NO ENEMY ENGAGED: LAUNCH WITHOUT TARGET"] = "TROP SOMBRE : AUCUN ENNEMI ENGAGÉ : LANCER SANS CIBLE",
    ["NO ENEMY IN SIGHT: LAUNCH WITHOUT TARGET"] = "AUCUN ENNEMI EN VUE : LANCER SANS CIBLE",
    ["[ ENEMY OUT OF VIEW ]"] = "[ ENNEMI HORS CHAMP ]",
    ["[ TOO DARK: NO ENEMY ENGAGED ]"] = "[ TROP SOMBRE : AUCUN ENNEMI ENGAGÉ ]",
    ["[ NO ENEMY IN SIGHT ]"] = "[ AUCUN ENNEMI EN VUE ]",
    ["[ WHEEL NOT READY: USE A SKILL ONCE WITH ITS BUTTON ]"] = "[ ROUE PAS ENCORE PRÊTE : LANCE UNE COMPÉTENCE UNE FOIS AVEC SON BOUTON ]",
    ["[ LAUNCH ERROR (SEE LOG) ]"] = "[ ERREUR AU LANCEMENT (VOIR LE JOURNAL) ]",
    ["[ ! ATB INTO THE RED ! ]"] = "[ ! ATB DANS LE ROUGE ! ]",

    -- flash messages without variable part
    ["[ SELECT A TARGET FIRST ]"] = "[ CHOISIS D'ABORD UNE CIBLE ]",
    ["[ ALL PAWNS : QUEUES CLEARED & FREE ]"] = "[ TOUS LES PIONS : FILES VIDÉES - LIBRES ]",
    ["[ NO ENEMIES IN RANGE ]"] = "[ AUCUN ENNEMI À PORTÉE ]",
    ["[ TARGET CLEARED ]"] = "[ CIBLE EFFACÉE ]",
    ["[ NO PAWN SELECTED ]"] = "[ AUCUN PION SÉLECTIONNÉ ]",
}

----------------------------------------------------------------------
-- Rules for messages with variable parts: %s = text, %d = number in the English format,
-- {1} {2} {3} = the captured parts, in the French format.
-- Specific rules first, the generic "[ %s >> %s ]" last.
----------------------------------------------------------------------
local RULES = {}

local function rule(en, fr, zh)
    local kinds = {}
    local tmp = en:gsub("%%([sd])", function(c) kinds[#kinds + 1] = c; return "\1" end)
    tmp = tmp:gsub("[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0")
    local i = 0
    tmp = tmp:gsub("\1", function()
        i = i + 1
        return kinds[i] == "d" and "(%-?%d+)" or "(.-)"
    end)
    RULES[#RULES + 1] = { pat = "^" .. tmp .. "$", fr = fr, zh = zh }
end

-- 2.08: chargeable skills say which version was ordered
rule("[ %s : QUEUED #%d >> %s · CHARGED ]",     "[ {1} : EN FILE N°{2} >> {3} · CHARGÉE ]", "[ {1}：队列 #{2} >> {3} · 蓄力版 ]")
rule("[ %s : QUEUED #%d >> %s · QUICK ]",       "[ {1} : EN FILE N°{2} >> {3} · IMMÉDIATE ]", "[ {1}：队列 #{2} >> {3} · 瞬发版 ]")
rule("[ %s >> %s · CHARGED ]",                  "[ {1} >> {2} · CHARGÉE ]", "[ {1} >> {2} · 蓄力版 ]")
rule("[ %s >> %s · QUICK ]",                    "[ {1} >> {2} · IMMÉDIATE ]", "[ {1} >> {2} · 瞬发版 ]")

-- order queue and stances
rule("[ %s : QUEUED #%d >> %s ]",               "[ {1} : EN FILE N°{2} >> {3} ]", "[ {1}：队列 #{2} >> {3} ]")
rule("[ %s : QUEUE FULL (MAX %d) ]",            "[ {1} : FILE PLEINE (MAX {2}) ]", "[ {1}：队列已满（上限 {2}） ]")
rule("[ %s : STANCE ENDED ]",                   "[ {1} : POSTURE TERMINÉE ]", "[ {1}：姿态结束 ]")
rule("[ ALL PAWNS >> %s ]",                     "[ TOUS LES PIONS >> {1} ]", "[ 所有仆从 >> {1} ]")
rule("[ %s : QUEUE CLEARED & FREE ]",     "[ {1} : FILE VIDÉE - LIBRE ]", "[ {1}：队列已清空 - 自由 ]")
rule("[ %s : QUEUE & TARGET CLEARED - FREE ]", "[ {1} : FILE ET CIBLE VIDÉES - LIBRE ]", "[ {1}：队列和目标已清空 - 自由 ]")
rule("[ %s : REMOVED %s FROM QUEUE (%d LEFT) ]", "[ {1} : {2} RETIRÉ DE LA FILE ({3} RESTANT) ]", "[ {1}：已从队列移除 {2}（剩余 {3}） ]")
-- dragon surge
-- target
rule("[ TARGET >> %s  %dm ]",                   "[ CIBLE >> {1}  {2}m ]", "[ 目标 >> {1}  {2}米 ]")
-- banner tags
rule("ORDER SENT · QUEUED #%d",                 "ORDRE ENVOYÉ · EN FILE N°{1}", "指令已下达 · 队列 #{1}")
rule("CHANNELING · QUEUED #%d",                 "CANALISATION · EN FILE N°{1}", "蓄力中 · 队列 #{1}")
rule("IN PROGRESS · QUEUED #%d",                "EN COURS · EN FILE N°{1}", "进行中 · 队列 #{1}")
rule("[ ACTIVE + QUEUED #%d ]",                 "[ ACTIF + EN FILE N°{1} ]", "[ 进行中 + 队列 #{1} ]")
rule("[ QUEUED #%d ]",                          "[ EN FILE N°{1} ]", "[ 队列 #{1} ]")
-- centre text
rule("QUEUED: %d/%d",                           "EN FILE : {1}/{2}", "队列：{1}/{2}")
rule("%s = ALL PAWNS | RELEASE = ONE",          "{1} = TOUS | RELÂCHER = UN SEUL", "{1} = 所有仆从 | 松开 = 单个")
rule("RELEASE / %s TO CYCLE",                   "RELÂCHER / {1} : CIBLE SUIVANTE", "松开 / {1}：切换目标")
rule("RELEASE / %s TO ORDER",                   "RELÂCHER / {1} : ORDONNER", "松开 / {1}：下令")
rule("%s = ALL PAWNS | %s = ONE",               "{1} = TOUS | {2} = UN SEUL", "{1} = 所有仆从 | {2} = 单个")
rule("%s TO CHANGE STANCE | %s = ALL PAWNS",  "{1} : CHANGER DE POSTURE | {2} = TOUS", "{1}：切换姿态 | {2} = 所有仆从")
rule("%s TO CHANGE STANCE",                     "{1} : CHANGER DE POSTURE", "{1}：切换姿态")
rule("%s = NEXT STANCE FOR ALL PAWNS",           "{1} : POSTURE SUIVANTE POUR TOUS LES PIONS", "{1}：所有仆从切换到下一姿态")
rule("%s TO CYCLE TARGET",                      "{1} : CIBLE SUIVANTE", "{1}：切换目标")
rule("[ %s : %s MANUAL ONLY ]",                 "[ {1} : {2} MANUEL SEUL ]", "[ {1}：{2} 仅手动 ]")
rule("[ %s : %s AUTO AGAIN ]",                  "[ {1} : {2} DE NOUVEAU AUTOMATIQUE ]", "[ {1}：{2} 恢复自动 ]")
rule("%s TO ORDER",                             "{1} : ORDONNER", "{1}：下令")
rule("%s TO ORDER & CLOSE | %s TO QUEUE",       "{1} : ORDONNER ET FERMER | {2} : AJOUTER À LA FILE", "{1}：下令并关闭 | {2}：加入队列")
rule("USE ON %s",                               "UTILISER SUR {1}", "对 {1} 使用")
rule("%s (ARCANIST)",                           "{1} (ARCANISTE)", "{1}（秘术师）")
rule("HIRED PAWN %d",                           "PION RECRUTÉ {1}", "雇佣仆从 {1}")
rule("%s  [x%d]",                               "{1}  [x{2}]", "{1}  [x{2}]")
-- Tactical Command System
rule("[ %s : PENDING SKILL CANCELLED ]",        "[ {1} : COMPÉTENCE EN ATTENTE ANNULÉE ]", "[ {1}：待执行技能已取消 ]")
rule("[ %s : ORDER FAILED ]",                   "[ {1} : ORDRE IMPOSSIBLE ]", "[ {1}：无法下令 ]")
rule("[ %s : REFUSED BY THE GAME ]",            "[ {1} : REFUSÉE PAR LE JEU ]", "[ {1}：被游戏拒绝 ]")
rule("TARGET: %s  %dm  (%d/%d)",                "CIBLE : {1}  {2}m  ({3}/{4})", "目标：{1}  {2}米  ({3}/{4})")
rule("%s TO ORDER & CLOSE | %s TO ORDER & STAY", "{1} : ORDONNER ET FERMER | {2} : ORDONNER ET RESTER", "{1}：下令并关闭 | {2}：下令并保持")
-- generic "[ A >> B ]" last
rule("[ %s >> %s ]",                            "[ {1} >> {2} ]", "[ {1} >> {2} ]")

local function apply_rules(s, words)
    for _, r in ipairs(RULES) do
        local fmt = (words == ZH) and r.zh or r.fr
        if fmt then
            local caps = { s:match(r.pat) }
            if caps[1] ~= nil then
                local out = fmt:gsub("{(%d)}", function(n)
                    local v = caps[tonumber(n)]
                    if v == nil then return "" end
                    return words[v] or v
                end)
                return out
            end
        end
    end
    return nil
end

-- Translate a displayed text (no-op in English)
function I.t(s)
    if type(s) ~= "string" or s == "" then return s end
    local l = I.lang()
    local words = (l == "fr" and EXACT) or (l == "zh" and ZH) or nil
    if not words then return s end
    local c = cache[s]
    if c then return c end
    local out = words[s] or apply_rules(s, words) or s
    if cache_n > 600 then cache, cache_n = {}, 0 end
    cache[s] = out
    cache_n = cache_n + 1
    return out
end

return I
