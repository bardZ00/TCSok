-- TacticalCommandSystem/config.lua
-- The settings, under the names the menu and the main file ask for them by.
--
--   conf/vault   every setting's current value, and the one road a new value travels down
--   conf/file    the saved file: where it is, its shape, and the names the mod used to go by

local Vault = require("TacticalCommandSystem.conf.vault")
local File  = require("TacticalCommandSystem.conf.file")

local C = {}

-- values and bindings, held by name: the menu reads out of these tables every frame
C.values = Vault.values
C.binds  = File.binds

-- changing something
C.set         = Vault.put
C.apply       = Vault.apply
C.reset_value = Vault.reset

-- presets
C.is_default      = Vault.is_default
C.current_preset  = Vault.named_preset
C.apply_preset    = Vault.use_preset
C.preset_names    = Vault.preset_names
C.save_preset     = Vault.save_preset
C.delete_preset   = Vault.delete_preset

-- the file
C.load       = File.read
C.save       = File.write
C.flush      = File.flush
C.mark_dirty = File.touch
C.tick       = File.tick

-- module switches
C.is_enabled  = File.is_enabled
C.set_enabled = File.set_enabled

-- `preset` and `enabled` are read directly by the menu, and live on their own modules
setmetatable(C, {
    __index = function(_, key)
        if key == "preset" then return Vault.preset end
        if key == "enabled" then return File.enabled end
        return nil
    end,
    __newindex = function(t, key, value)
        if key == "preset" then Vault.preset = value; return end
        if key == "enabled" then File.enabled = value; return end
        rawset(t, key, value)
    end,
})

return C
