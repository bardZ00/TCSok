-- TacticalCommandSystem/api.lua
-- The door between Tactical Command System and its second layer, Tactical_Command_System_with_ATB_System (a separate script in
-- the same Lua state: it finds this table in package.loaded["TacticalCommandSystem.api"]).
--
-- The ATB Combat System registers a provider:
--   API.register_atb({
--       enabled    = function() -> bool,                         ATB on (menu box / not uninstalled)
--       gauge      = function(chara_addr) -> pts, max_pts, pts_per_seg, segs   (nil = no gauge for this character)
--       cost       = function(chara_addr, skill_id) -> segments (number) or nil
--       affordable = function(chara_addr, skill_id) -> bool       enough full segments for this skill now
--       state      = function(chara_addr, skill_id) -> "ok" / "debt" (precipitation, into the red) / "no"
--   })
-- The wheel reads it (gauge in the top row, cost and grey cells, waiting queue of the pawns) and tells the ATB what
-- it shows (API.wheel), so the ATB can draw the Arisen's gauge in the middle of the screen.

local API = {
    version = 1,
    atb = nil,
    -- what the wheel shows, refreshed every frame by the wheel
    wheel = {
        open = false,
        stage = 1,              -- 1 = wheel, 2 = targeting step
        kind = nil,             -- "arisen" / "pawn" (shown character)
        addr = nil,             -- address of the shown character
        center_x = nil,         -- screen position for the Arisen's ATB gauge (under the character)
        center_y = nil,
        scale = 1.0,            -- size of the wheel (screen height / 1080 x HUD scale)
        alpha = 0.0,            -- fade of the wheel (0..1)
    },
    time_scale = function() return 1.0 end,    -- set by the wheel: current game speed of its slow motion
    -- 1.36: the wheel's ATB Combat System style settings, so the ATB Combat System can tell in its menu how its gauge is used
    wheel_look = { style = true, native = true, col_link = true },
    -- 1.52: the wheel honours the ATB Combat System's "numbers above the wheel gauge" switch (atb.wheel_value)
    wheel_value_ok = true,
}

-- Preview: the wheel is drawn without being opened (no slow motion, no input taken), to tune its look from the menus.
-- The ATB Combat System's menu can switch it too.
API.preview = false
API.preview_target = false          -- 1.38: the preview shows the targeting step instead of the wheel
function API.set_preview(on, target) API.preview = (on == true); API.preview_target = (on == true) and (target == true) end

function API.register_atb(provider)
    if type(provider) == "table" then API.atb = provider end
end

function API.atb_on()
    local p = API.atb
    if not p or type(p.enabled) ~= "function" then return false end
    local ok, on = pcall(p.enabled)
    return ok and on == true
end

local function addr_of(chara_or_addr)
    if type(chara_or_addr) == "number" then return chara_or_addr end
    local ok, a = pcall(function() return chara_or_addr:get_address() end)
    if ok then return a end
    return nil
end

-- 1.34: the ATB Combat System's own gauge colours (ABGR: full, part, empty, edge), nil when it does not give them
function API.atb_colors()
    if not API.atb_on() or type(API.atb.colors) ~= "function" then return nil end
    local ok, t = pcall(API.atb.colors)
    if ok and type(t) == "table" then return t end
    return nil
end

function API.atb_gauge(chara)
    if not API.atb_on() or type(API.atb.gauge) ~= "function" then return nil end
    local a = addr_of(chara)
    if not a then return nil end
    local ok, pts, mx, pps, segs = pcall(API.atb.gauge, a)
    if ok and type(pts) == "number" and type(mx) == "number" and mx > 0 then return pts, mx, pps, segs end
    return nil
end

function API.atb_cost(chara, skill_id)
    if not API.atb_on() or type(API.atb.cost) ~= "function" then return nil end
    local a = addr_of(chara)
    if not a then return nil end
    local ok, c = pcall(API.atb.cost, a, skill_id)
    if ok and type(c) == "number" then return c end
    return nil
end

-- 2.04: label of a two-step skill ("( - / 1 )"), nil for an ordinary skill or an older ATB Combat System
function API.atb_cost_label(chara, skill_id)
    if not API.atb_on() or type(API.atb.cost_label) ~= "function" then return nil end
    local a = addr_of(chara)
    if not a then return nil end
    local ok, t = pcall(API.atb.cost_label, a, skill_id)
    if ok and type(t) == "string" and t ~= "" then return t end
    return nil
end

-- "ok" (the gauge pays), "debt" (precipitation: the gauge will go into the red), "no" (refused)
function API.atb_state(chara, skill_id)
    if not API.atb_on() then return "ok" end
    local a = addr_of(chara)
    if not a then return "ok" end
    if type(API.atb.state) == "function" then
        local ok, r = pcall(API.atb.state, a, skill_id)
        if ok and (r == "ok" or r == "debt" or r == "no") then return r end
    end
    return API.atb_affordable(chara, skill_id) and "ok" or "no"
end

-- true when the ATB is off, unknown, or lets this skill go now
function API.atb_affordable(chara, skill_id)
    if not API.atb_on() or type(API.atb.affordable) ~= "function" then return true end
    local a = addr_of(chara)
    if not a then return true end
    local ok, r = pcall(API.atb.affordable, a, skill_id)
    if ok and r == false then return false end
    return true
end

return API
