-- TacticalCommandSystem/lib/prefs.lua
-- The handful of settings the engine itself reads, and their defaults.
--
-- These four tables are shared by name, not by copy: the settings screen writes into them, and the engine, the input
-- layer and the wheel read out of the same tables a frame later. So they are created once here, and every module that
-- holds one holds the same table -- replacing one with a new table instead of writing into it would quietly cut the
-- others off. Everything else the mod can be told lives in conf/settings.lua; only what the engine needs is here.

local Prefs = {}

-- the targeting step, and the marker it leaves behind
Prefs.TGT = {
    range          = 45.0,        -- m : enemies this close to the Arisen are offered as targets
    default_pick   = "near",      -- which enemy the targeting step offers first: "centre" (crosshair) or "near" (metres)
    marker_closed  = false,       -- keep the marker up after the wheel closes, rather than fading it
    marker_seconds = 3.0,         -- s : how long it stays when it does fade
    marker_size    = 1.0,
    marker_opacity = 1.0,
}

-- skills the player has kept for manual ordering: LOCKS[pawn name][skill id as a string] = true
-- (saved in config.json, by pawn name, so a lock follows the pawn and not the party slot)
Prefs.LOCKS = {}

-- how the locks are enforced: write the AI flags, refuse the skill outright, trace what happens
Prefs.LOCKCFG = { enforce = true, hook = true, log = true }

-- the little lamp beside each skill cell: lit when the pawn may use the skill itself, dark when it is manual only
Prefs.LAMP = { enabled = true, size = 1.0, glow = 1.0, opacity = 1.0, dx = 0.0, dy = 0.0, show_off = true }

return Prefs
