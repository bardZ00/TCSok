-- TacticalCommandSystem/lib/clock.lua
-- A clock that slows down with the game.
--
-- The wheel slows time to a few per cent of normal, and every timer in the engine -- how long a charge may take, how
-- long to wait before giving up on a pawn -- is in game seconds, not real ones. Reading the wall clock would make a
-- two-second charge time out in a tenth of a second of slowed play.
--
-- So the engine keeps its own clock: real elapsed time, multiplied by however slowed the game currently is, added up.
-- It only moves forward, and only when asked, so a frame that does not read it costs nothing.

local Clock = {}

-- the engine's own time base, advanced by tick_clock() once a frame
Clock.CLOCK = { t = os.clock(), last = nil, scale = 1.0 }

-- the slow-motion the wheel is applying. scale 0.04 is the default: four per cent of normal speed.
Clock.Slow = { active = false, releasing = false, cur = 1.0, scale = 0.04, rates = nil }

local SLOWEST = 0.005            -- never let the clock stop outright, or nothing in the engine would ever time out

-- real seconds since the process started: for anything that must happen whatever the game is doing
function Clock.wall_time()
    return os.clock()
end

-- game seconds: what every timer in the engine is measured in
function Clock.game_now()
    local wall = os.clock()
    local c = Clock.CLOCK
    if c.last then
        c.t = c.t + (wall - c.last) * c.scale
    end
    c.last = wall
    return c.t
end

-- Once a frame: takes the clock up to now, then sets the rate the next frame will be counted at.
function Clock.tick_clock()
    Clock.game_now()
    Clock.CLOCK.scale = Clock.Slow.active and math.max(SLOWEST, Clock.Slow.cur) or 1.0
end

return Clock
