-- TacticalCommandSystem/lib/text.lua
-- Reading the game's text, and writing the wheel's.
--
-- The wheel sets most of its labels in capitals, which Lua's own `upper` does not manage in French: it works a byte at
-- a time, and an accented letter is two bytes, so "épée" comes back "éPEE". The table below is built once from the one
-- rule that covers the whole Latin-1 range -- lowercase and uppercase sit 32 apart in it -- with the two places that
-- rule does not hold written out.

local Text = {}

----------------------------------------------------------------------------------------------------
-- capitals, accents included
----------------------------------------------------------------------------------------------------
-- à..þ as UTF-8 is 0xC3 followed by 0xA0..0xBE, and its capital is the same lead byte with 32 taken off
local CAPITAL = {}
do
    for low = 0xA0, 0xBE do
        CAPITAL[string.char(0xC3, low)] = string.char(0xC3, low - 0x20)
    end
    CAPITAL[string.char(0xC3, 0xB7)] = nil                      -- that slot is the division sign, not a letter
    CAPITAL[string.char(0xC5, 0x93)] = string.char(0xC5, 0x92)  -- oe ligature, which sits outside the range
end

function Text.upper(s)
    s = string.upper(tostring(s or ""))
    return (s:gsub("[\195\197][\128-\191]", function(pair)
        return CAPITAL[pair] or pair
    end))
end

----------------------------------------------------------------------------------------------------
-- the game's own strings
----------------------------------------------------------------------------------------------------
-- The game answers some name requests with markup, with blanks, or with the word "Rejected" when the text for that
-- language is not loaded yet. None of those are a name: nil says so, and the caller asks again later.
function Text.clean(s)
    if type(s) ~= "string" or s == "" then return nil end
    if s:find("Rejected", 1, true) then return nil end
    s = s:gsub("<[^>]->", "")                                   -- the game's inline tags
    s = s:gsub("^%s+", ""):gsub("%s+$", "")
    return s ~= "" and s or nil
end

-- "BlinkStrike" -> "Blink Strike", for the few skills the game will not give a name for
function Text.space_out(s)
    return (s:gsub("(%l)(%u)", "%1 %2"):gsub("(%u)(%u%l)", "%1 %2"))
end

return Text
