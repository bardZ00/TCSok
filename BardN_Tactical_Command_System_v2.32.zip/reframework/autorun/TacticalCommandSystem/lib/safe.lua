-- TacticalCommandSystem/lib/safe.lua
-- Reaching into the game without bringing it down.
--
-- Every object the mod touches belongs to the game, and the game is free to delete it between one frame and the next: a
-- pawn that leaves the party, an enemy that dies, everything at once on a load screen. A field read on one of those is
-- not an error to handle later, it is a crash to desktop in the player's game. So nothing here ever raises: a call that
-- cannot be made returns nil, and the mod carries on with one pawn fewer.
--
-- Errors are logged once per place and message. A broken read usually breaks every frame, and a log file growing by
-- sixty lines a second is worse than the bug it records.

local Safe = {}

-- The one switch for everything meant for the author rather than the player: the Diagnostics drawer, the cyan marks
-- on what is new in this version, and the inventory lines written to the REFramework log (icons, skill names).
-- Set it to false for 1.0: errors keep being logged, nothing else is.
Safe.DEV = false

-- An informational line: written only while DEV is on. Errors never come through here (see log_err_once).
function Safe.note(msg)
    if not Safe.DEV then return end
    pcall(log.info, "[Tactical_Command_System] " .. tostring(msg))
end

local said = {}

function Safe.log_err_once(where, err)
    local key = tostring(where) .. ":" .. tostring(err)
    if said[key] then return end
    said[key] = true
    pcall(log.error, "[Tactical_Command_System] Error in " .. tostring(where) .. ": " .. tostring(err))
end

-- Runs `fn`, returns its value, or nil if it raised. Pass `where` to have the failure logged once.
function Safe.call(fn, where)
    local ok, result = pcall(fn)
    if ok then return result end
    if where then Safe.log_err_once(where, result) end
    return nil
end

-- Is this still a live game object? Asked before every use of anything held from an earlier frame.
function Safe.alive(obj)
    if not obj then return false end
    local ok, yes = pcall(function()
        if type(sdk.is_managed_object) == "function" then
            return sdk.is_managed_object(obj) == true
        end
        local addr = obj:get_address()
        return addr ~= nil and addr ~= 0
    end)
    return ok and yes == true
end

-- A pointer handed in by a hook, turned into an object -- or nil, which is the usual answer for a null argument.
function Safe.from_pointer(ptr)
    if not ptr then return nil end
    local ok_addr, addr = pcall(sdk.to_int64, ptr)
    if not ok_addr or not addr or addr == 0 then return nil end
    local ok_obj, obj = pcall(sdk.to_managed_object, ptr)
    if ok_obj and Safe.alive(obj) then return obj end
    return nil
end

-- the number behind one of the game's enum members, or 0 when the game has no such member
function Safe.enum(type_name, member)
    return Safe.call(function()
        return tonumber(sdk.find_type_definition(type_name):get_field(member):get_data(nil))
    end) or 0
end

-- an enum value, a boxed number or a plain number, as a number
function Safe.number(value)
    if type(value) == "number" then return value end
    return Safe.call(function() return tonumber(value:get_field("value__")) end) or 0
end

function Safe.address(obj)
    if not Safe.alive(obj) then return nil end
    return Safe.call(function() return obj:get_address() end)
end

return Safe
