-- TacticalCommandSystem/lib/names.lua
-- Asking the game what things are called, in the player's own language.
--
-- The names are the game's to give, and it gives them late. At the moment a script loads, the text for the player's
-- language is not in memory: ask then and the answers come back in English, or as the word "Rejected", and whatever is
-- cached at that point is wrong for the rest of the session. So nothing is asked for in advance -- a name is asked for
-- the first time it is drawn, and the skill-name cache is emptied every time the wheel opens, which costs one lookup
-- per cell and is always right.
--
-- Two lookups are not there at load either -- the skill-name method and the icon catalogue -- and both have to be tried
-- again as the game finishes starting. That is the same pattern twice, so it is written once, as `gate`.

local D = require("TacticalCommandSystem.data")
local Safe = require("TacticalCommandSystem.lib.safe")
local Text = require("TacticalCommandSystem.lib.text")

local Names = {}

local ICON_MAX = 99               -- the game's own icon numbering
local SKILL_LEVELS = { 2, 1, 0 }  -- the upgraded name first: it is the one the player has

----------------------------------------------------------------------------------------------------
-- something to look up again later, but not every frame
----------------------------------------------------------------------------------------------------
-- Returns a function that calls `attempt` until it answers, then keeps answering that, and in between waits.
local function gate(every, attempt)
    local held, next_try = nil, 0
    return function()
        if held then return held end
        local now = os.clock()
        if now < next_try then return nil end
        next_try = now + every
        held = Safe.call(attempt)
        return held
    end
end

----------------------------------------------------------------------------------------------------
-- the game's naming methods
----------------------------------------------------------------------------------------------------
local gui = sdk.find_type_definition("app.GUIBase")
local name_of_character = gui and gui:get_method("getName(app.Character)")
local name_of_chara_id = gui and gui:get_method("getName(app.CharacterID)")

local skill_name_method = gate(2.0, function()
    local base = sdk.find_type_definition("app.GUIBase")
    local m = base and base:get_method("getCustomSkillName(app.HumanCustomSkillID, app.HumanCustomSkillLevelNo)")
    if m then Safe.note("getCustomSkillName found") end
    return m
end)

----------------------------------------------------------------------------------------------------
-- a character's name
----------------------------------------------------------------------------------------------------
-- Three ways of asking, in order of how likely each is to answer: by character, by character id, and -- for a hired
-- pawn, whose name is the player's and lives nowhere else -- out of its own data context.
local function ask_by_character(chara)
    if not name_of_character then return nil end
    return Safe.call(function() return Text.clean(name_of_character:call(nil, chara)) end)
end

local function ask_by_id(chara)
    if not name_of_chara_id then return nil end
    local id = Safe.call(function() return chara:call("get_CharaID") end)
    if not id then return nil end
    return Safe.call(function() return Text.clean(name_of_chara_id:call(nil, id)) end)
end

-- The pawn's own data, which is where a hired pawn's name comes from. Three places hold it depending on how the pawn
-- joined the party, so all three are tried.
function Names.pawn_context(pawn_obj, chara, human)
    local ctx

    if Safe.alive(pawn_obj) then
        pcall(function()
            local holder = pawn_obj.CachedContextHolder or pawn_obj["<CachedContextHolder>k__BackingField"]
            local contexts = holder and (holder.Contexts or holder["<Contexts>k__BackingField"])
            local entries = contexts and (contexts._entries or contexts["_entries"])
            local count = (entries and entries:get_size()) or 0
            for i = 0, count - 1 do
                local slot = entries[i] and entries[i].value
                local td = slot and slot:get_type_definition()
                if td and td:get_full_name():find("<app.PawnDataContext>", 1, true) then
                    ctx = slot:call("get_CurrentContext")
                    break
                end
            end
        end)
    end

    if not ctx and Safe.alive(chara) then
        pcall(function()
            local swapper = chara:get_field("<HumanPartSwapper>k__BackingField")
            ctx = swapper and swapper:get_field("_PawnDataContext")
        end)
    end

    if not ctx and Safe.alive(human) then
        pcall(function() ctx = human:call("get_PawnDataContext") end)
    end

    return ctx
end

function Names.of_pawn(chara, pawn_obj, fallback)
    if not Safe.alive(chara) then return fallback or "PAWN" end

    local name = ask_by_character(chara) or ask_by_id(chara)
    if not name then
        local human = Safe.call(function() return chara:call("get_Human") end) or chara["<Human>k__BackingField"]
        local ctx = Names.pawn_context(pawn_obj, chara, human)
        if ctx then
            name = Safe.call(function() return Text.clean(tostring(ctx:call("get_Name") or ctx._Name)) end)
        end
    end
    return name or fallback or "PAWN"
end

-- 1.38: a monster added by a mod may have no name in the game's text: then the name is left empty (""), and so is
-- a name that is only an internal id ("ch255000_00", "em1234", "???")
local function real_name(s)
    if not s or not s:find("%a") then return nil end
    if s:find("^[Cc][Hh]%d") or s:find("^[Ee][Mm]%d") or s:find("^MSG") then return nil end
    if not s:find(" ") and s:find("_") and s:find("%d") then return nil end
    return s
end
function Names.of_enemy(chara)
    return real_name(ask_by_character(chara)) or real_name(ask_by_id(chara)) or ""
end

----------------------------------------------------------------------------------------------------
-- a skill's name
----------------------------------------------------------------------------------------------------
local skill_names, skill_levels = {}, {}
local told_fallback, told_answers = {}, {}

-- emptied every time the wheel opens, so a name cached before the language was ready is never kept
function Names.clear_skills()
    for id in pairs(skill_names) do skill_names[id] = nil end
end

-- Kept because the wheel still calls it. Names are asked for one at a time as they are drawn; there is nothing to
-- resolve up front, and asking early is what used to cache the English names for good.
-- once per skill the wheel shows, what the game answers at each level: the first thing to look at when a name is wrong
local function log_answers(id, method)
    if told_answers[id] or not method then return end
    told_answers[id] = true
    local parts = {}
    for level = 0, 2 do
        local answer = Safe.call(function() return method:call(nil, id, level) end)
        parts[#parts + 1] = "lv" .. level .. "=" .. tostring(answer)
    end
    Safe.note("skill " .. tostring(id) .. " : " .. table.concat(parts, " | ")
        .. " | shown=" .. tostring(skill_names[id]))
end

function Names.of_skill(id)
    local method = skill_name_method()
    log_answers(id, method)

    if skill_names[id] then return skill_names[id] end

    if method then
        for _, level in ipairs(SKILL_LEVELS) do
            local answer = Safe.call(function() return Text.clean(method:call(nil, id, level)) end)
            if answer then
                skill_names[id] = answer
                skill_levels[id] = level
                return answer
            end
        end
    end

    if not told_fallback[id] then
        told_fallback[id] = true
        Safe.note("skill name fallback (English) for id " .. tostring(id)
            .. (method and " [method ok, no text]" or " [no method]"))
    end

    local ord = D.ORDERS[id]
    if ord then return Text.space_out(ord.name) end
    return "Skill " .. tostring(id)
end

----------------------------------------------------------------------------------------------------
-- a skill's icon
----------------------------------------------------------------------------------------------------
-- The game keeps its skill icons in a dictionary of dictionaries, which has to be flattened to be useful: skill id and
-- level in, icon number out.
local function dict_values(dict)
    local out = {}
    pcall(function()
        local entries = dict:get_field("_entries")
        local count = tonumber(dict:get_field("_count")) or 0
        for i = 0, count - 1 do
            local slot = entries[i]
            if slot and slot.value ~= nil then out[#out + 1] = slot.value end
        end
    end)
    return out
end

local icons = gate(3.0, function()
    local found, count = {}, 0
    local gm = sdk.get_managed_singleton("app.GuiManager")
    local outer = gm and gm:get_field("CustomSkillDefineDictionary")
    if not outer then return nil end

    for _, inner in ipairs(dict_values(outer)) do
        for _, define in ipairs(dict_values(inner)) do
            pcall(function()
                local id = tonumber(define:get_field("_SkillID"))
                local level = tonumber(define:get_field("_Level"))
                local icon = tonumber(define:get_field("_IconPattern"))
                if id and level and icon then
                    found[id] = found[id] or {}
                    found[id][level] = icon
                    count = count + 1
                end
            end)
        end
    end

    if count == 0 then return nil end
    Safe.note("skill icon catalogue: " .. count .. " entries")
    return found
end)

-- the game's own icon number for a skill (0..99), or nil while the catalogue is not loaded
function Names.skill_icon(id)
    local catalogue = icons()
    local by_level = catalogue and catalogue[id]
    if not by_level then return nil end

    -- the level the name came from is the level the player has; the others are the fallback
    local level = skill_levels[id]
    local icon = (level and by_level[level]) or by_level[1] or by_level[2] or by_level[0]
    if icon and icon >= 0 and icon <= ICON_MAX then return icon end
    return nil
end

return Names
