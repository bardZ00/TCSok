-- TacticalCommandSystem/lib/world.lua
-- Where everything is: the Arisen, the enemies, and how any of it lands on the screen.
--
-- The targeting step is what most of this is for. "The enemy on the right" has to mean the one the player sees on the
-- right, which is a question about the camera, not about the world: two enemies north of the Arisen are left and right
-- of each other or one behind the other depending on which way the player is looking. So the camera's own axes are
-- worked out first, and every enemy is placed as an angle around them.

local Safe = require("TacticalCommandSystem.lib.safe")
local Text = require("TacticalCommandSystem.lib.text")
local Names = require("TacticalCommandSystem.lib.names")

local W = {}

local FALLBACK_SCREEN = { w = 1920, h = 1080 }
local PROBE_AHEAD = 5.0           -- metres ahead of the camera used to find which way it faces
local ENEMY_LABEL_HEIGHT = 1.2    -- metres above an enemy's origin, roughly where a name should sit
local SCREEN_WEIGHT = 18.0        -- how much being near the crosshair counts against plain distance
local WORLD_WEIGHT = 0.35
local OFFSCREEN_PENALTY = 1000.0

----------------------------------------------------------------------------------------------------
-- the Arisen, and who is still standing
----------------------------------------------------------------------------------------------------
function W.player()
    local manager = sdk.get_managed_singleton("app.CharacterManager")
    if not manager then return nil end
    return Safe.call(function() return manager:call("get_ManualPlayer") end)
end

-- Anything the mod cannot ask is treated as dead: an order to a character that may not exist is worse than an order
-- not given.
function W.is_dead(chara)
    if not Safe.alive(chara) then return true end
    local ok, dead = pcall(function() return chara:call("get_IsDead") end)
    return not ok or dead == true
end

function W.alive_enemies()
    local out = {}
    pcall(function()
        local manager = sdk.get_managed_singleton("app.EnemyManager")
        local all = manager and manager:call("getAllEnemies")
        if not all then return end
        for i = 0, all:call("get_Count") - 1 do
            local chara = all[i] and all[i]:get_field("_Chara")
            if Safe.alive(chara) and not W.is_dead(chara) then
                out[#out + 1] = chara
            end
        end
    end)
    return out
end

----------------------------------------------------------------------------------------------------
-- distance
----------------------------------------------------------------------------------------------------
function W.position(chara)
    local p = chara:call("get_Transform"):call("get_UniversalPosition")
    return p.x, p.y, p.z
end

function W.distance(a, b)
    local ax, ay, az = W.position(a)
    local bx, by, bz = W.position(b)
    local dx, dy, dz = ax - bx, ay - by, az - bz
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

function W.nearest_enemy(from)
    local pick, pick_dist
    for _, enemy in ipairs(W.alive_enemies()) do
        local ok, gap = pcall(W.distance, from, enemy)
        if ok and gap and (not pick_dist or gap < pick_dist) then
            pick, pick_dist = enemy, gap
        end
    end
    return pick, pick_dist
end

----------------------------------------------------------------------------------------------------
-- the screen
----------------------------------------------------------------------------------------------------
function W.screen_size()
    local w, h = FALLBACK_SCREEN.w, FALLBACK_SCREEN.h
    pcall(function()
        local size = imgui.get_display_size()
        if size and size.x > 100 and size.y > 100 then w, h = size.x, size.y end
    end)
    return w, h
end

-- Where a character shows up on screen, `up` metres above its origin. nil when it is not on screen at all.
function W.screen_pos(chara, up)
    local ok, x, y = pcall(function()
        local pos = chara:call("get_Transform"):call("get_Position")
        local at = draw.world_to_screen(Vector3f.new(pos.x, pos.y + (up or 0), pos.z))
        if at then return at.x, at.y end
    end)
    if ok and x then return x, y end
    return nil
end

----------------------------------------------------------------------------------------------------
-- which way the camera is looking
----------------------------------------------------------------------------------------------------
-- Returns the camera's position and its forward and right axes, flattened onto the ground.
--
-- The camera's own Z axis points along its line of sight, but whether that is into the screen or out of it depends on
-- the build, so it is checked rather than assumed: a point five metres along it either lands on the screen or it does
-- not, and if it does not, the axis is the other way round. The right axis is then perpendicular to forward, and gets
-- the same treatment.
function W.camera_basis()
    return Safe.call(function()
        local camera = sdk.get_primary_camera()
        local at = camera:call("get_GameObject"):call("get_Transform")
        local eye = at:call("get_Position")
        local axis = at:call("get_AxisZ")
        local screen_w, screen_h = W.screen_size()

        local fx, fz = axis.x, axis.z
        local ahead = draw.world_to_screen(Vector3f.new(
            eye.x + fx * PROBE_AHEAD, eye.y + axis.y * PROBE_AHEAD, eye.z + fz * PROBE_AHEAD))
        local on_screen = ahead ~= nil
            and ahead.x >= 0 and ahead.x <= screen_w
            and ahead.y >= 0 and ahead.y <= screen_h
        if not on_screen then fx, fz = -fx, -fz end

        local length = math.sqrt(fx * fx + fz * fz)
        if length < 1e-6 then return nil end
        fx, fz = fx / length, fz / length

        local rx, rz = fz, -fx
        local beside = draw.world_to_screen(Vector3f.new(
            eye.x + fx * PROBE_AHEAD + rx, eye.y, eye.z + fz * PROBE_AHEAD + rz))
        if beside and beside.x < screen_w * 0.5 then rx, rz = -rx, -rz end

        return { px = eye.x, pz = eye.z, fx = fx, fz = fz, rx = rx, rz = rz }
    end)
end

-- Where each target sits, as an angle around the camera: negative to the left, positive to the right. Falls back to
-- plain screen x if any one of them cannot be placed, because half angles and half screen positions would order the
-- list wrongly.
local function bearings(list)
    local basis = W.camera_basis()
    if basis then
        local out = {}
        for i, target in ipairs(list) do
            local ok, angle = pcall(function()
                local pos = target.chara:call("get_Transform"):call("get_Position")
                local dx, dz = pos.x - basis.px, pos.z - basis.pz
                return math.atan(dx * basis.rx + dz * basis.rz, dx * basis.fx + dz * basis.fz)
            end)
            if not ok or angle == nil then out = nil; break end
            out[i] = angle
        end
        if out then return out end
    end

    local out = {}
    for i, target in ipairs(list) do out[i] = target.sx end
    return out
end

-- The target next to `cur` in direction `dir` (1 right, -1 left), or nil when there is none that way.
function W.pick_direction(list, cur, dir)
    if cur == nil or list[cur] == nil then return nil end

    local keys = bearings(list)
    local from = keys[cur]
    if from == nil then return nil end

    local pick, pick_gap
    for i, key in ipairs(keys) do
        if i ~= cur and key ~= nil then
            local gap = (key - from) * dir
            if gap > 1e-6 and (pick_gap == nil or gap < pick_gap) then
                pick, pick_gap = i, gap
            end
        end
    end
    return pick
end

----------------------------------------------------------------------------------------------------
-- what the targeting step offers
----------------------------------------------------------------------------------------------------
-- Living enemies within `reach` of the player, best first: on screen and near the crosshair beats far from it, and
-- anything off screen comes after everything on it.
function W.target_candidates(player, reach, most)
    local out = {}
    if not Safe.alive(player) then return out end

    local screen_w, screen_h = W.screen_size()
    local cx, cy = screen_w * 0.5, screen_h * 0.5
    local corner = math.sqrt(cx * cx + cy * cy)

    -- 1.13: realistic targeting (lib/vision.lua) -- only what the party can see, in front of the camera
    local Vision = package.loaded["TacticalCommandSystem.lib.vision"] or require("TacticalCommandSystem.lib.vision")
    local basis = Vision.on and Vision.front and W.camera_basis() or nil
    local now = os.clock()
    if Vision.on then Vision.last = {} end

    for _, enemy in ipairs(W.alive_enemies()) do
        local ok, gap = pcall(W.distance, player, enemy)
        if ok and gap and gap <= reach then
            local addr = Safe.address(enemy)
            if addr and not Vision.allows(player, enemy, addr, gap, basis, now) then addr = nil end
            if addr then
                local sx, sy = W.screen_pos(enemy, ENEMY_LABEL_HEIGHT)
                local on_screen = sx ~= nil and sy ~= nil
                    and sx >= 0 and sx <= screen_w and sy >= 0 and sy <= screen_h
                -- `centre` is how far off the crosshair the enemy sits, 0 at dead centre and 1 at a corner. It is
                -- kept on the candidate (not just folded into the score) because the targeting step can be asked to
                -- offer the most centred enemy first rather than the closest one.
                local score, centre
                if on_screen then
                    local from_centre = math.sqrt((sx - cx) ^ 2 + (sy - cy) ^ 2)
                    centre = from_centre / math.max(1, corner)
                    score = centre * SCREEN_WEIGHT + gap * WORLD_WEIGHT
                else
                    score = OFFSCREEN_PENALTY + gap
                end
                out[#out + 1] = { chara = enemy, addr = addr, dist = gap, score = score,
                                  on_screen = on_screen, centre = centre }
            end
        end
    end

    table.sort(out, function(a, b) return a.score < b.score end)
    while #out > most do out[#out] = nil end
    for _, candidate in ipairs(out) do
        candidate.name = Text.upper(Names.of_enemy(candidate.chara))
    end
    return out
end

return W
