-- TacticalCommandSystem/lib/party.lua
-- Who is in the party, what they have equipped, and how they are holding up.
--
-- The party is read fresh every time the wheel opens, which is the only way to be right: a pawn can be dismissed, hired
-- or changed vocation between two openings.
--
-- The reading is defensive out of necessity. The game keeps its party in three places that do not always agree -- the
-- main pawn on its own, a list of characters, a list of pawn objects -- and which of them is filled depends on where the
-- player is: a rift, a loading screen, a cutscene, mid-dismissal. So all three are read, duplicates dropped, and if the
-- result comes back empty while the last reading had pawns in it, the last reading is kept: a wheel that briefly shows
-- nobody is worse than one showing a pawn whose vitals are a frame old.

local D = require("TacticalCommandSystem.data")
local Safe = require("TacticalCommandSystem.lib.safe")
local Names = require("TacticalCommandSystem.lib.names")
local W = require("TacticalCommandSystem.lib.world")

local Party = {}

local SKILL_SLOTS = 5             -- six slots, 0..5
local MAX_CHARAS = 6
local MAX_PAWN_OBJS = 5

----------------------------------------------------------------------------------------------------
-- vocation and equipped skills
----------------------------------------------------------------------------------------------------
-- The vocation is on the character, except when it is not: a pawn mid-change, or just hired, answers from its job
-- context or from its own data instead. Fighter is the last resort, because a wheel with no skills on it is useless.
local function vocation_of(chara, human, pawn_obj)
    local job = Safe.call(function() return Safe.number(chara.WeaponJob or chara:get_field("WeaponJob")) end)
    if job and job > 0 then return job end

    local ctx = Safe.call(function() return human:call("get_JobContext") end) or human["<JobContext>k__BackingField"]
    if ctx then
        job = Safe.call(function() return Safe.number(ctx:call("get_CurrentJob")) end)
            or Safe.call(function() return Safe.number(ctx.CurrentJob) end)
            or Safe.call(function() return Safe.number(ctx:call("get_Job")) end)
        if job and job > 0 then return job end
    end

    local data = Names.pawn_context(pawn_obj, chara, human)
    if data then
        job = Safe.call(function() return Safe.number(data:call("get_Job") or data._Job) end)
        if job and job > 0 then return job end
    end

    return 1
end

-- the six skill ids of the pawn's current vocation, in slot order, blanks dropped
local function equipped_skills(human, job)
    local context = Safe.call(function() return human:call("get_SkillContext") end)
        or human["<SkillContext>k__BackingField"]
    if not Safe.alive(context) then return {} end

    local found, seen = {}, {}
    local function take(id)
        if id and id > 0 and not seen[id] then
            seen[id] = true
            found[#found + 1] = id
        end
    end

    -- straight out of the table the game keeps them in
    pcall(function()
        local slots = context.EquipedSkills[job].Skills
        for slot = 0, SKILL_SLOTS do
            take(Safe.number(slots[slot]))
        end
    end)

    -- and if that table is not reachable in this build, one slot at a time
    if #found == 0 then
        for slot = 0, SKILL_SLOTS do
            take(Safe.call(function() return Safe.number(context:call("getSkillID", job, slot)) end))
        end
    end

    return found
end

function Party.read_skills(chara, pawn_obj)
    if not Safe.alive(chara) then return 1, {} end
    local human = Safe.call(function() return chara:call("get_Human") end) or chara["<Human>k__BackingField"]
    if not Safe.alive(human) then return 1, {} end

    local job = vocation_of(chara, human, pawn_obj)
    return job, equipped_skills(human, job)
end

----------------------------------------------------------------------------------------------------
-- health and stamina, as fractions
----------------------------------------------------------------------------------------------------
local function fraction(now, most)
    if not now or not most or most <= 0 then return nil end
    return math.max(0.0, math.min(1.0, now / most))
end

-- A pawn's stamina sits on its AI stamina manager; the Arisen's on its own. Either may be missing, and a full bar is
-- the safe answer: it only greys a cell out, and greying one out wrongly is worse than not greying it.
function Party.vitals(chara, pawn_obj)
    if not Safe.alive(chara) then return 1.0, 1.0 end

    local health = 1.0
    pcall(function()
        local now = tonumber(chara:call("get_Hp"))
        local most = tonumber(chara:call("get_MaxHp")) or tonumber(chara:call("get_ReducedMaxHp"))
        health = fraction(now, most) or health
    end)

    local stamina, got = 1.0, false
    if Safe.alive(pawn_obj) then
        pcall(function()
            local manager = pawn_obj:get_field("<AIStaminaManager>k__BackingField")
            if not manager then return end
            local now = tonumber(manager:call("get_Stamina") or manager:get_field("_Stamina"))
            local most = tonumber(manager:call("get_MaxStamina") or manager:get_field("_MaxStamina"))
            local share = fraction(now, most)
            if share then stamina, got = share, true end
        end)
    end
    if not got then
        pcall(function()
            local manager = chara:call("get_StaminaManager") or chara:get_field("<StaminaManager>k__BackingField")
            if not manager then return end
            local now = tonumber(manager:call("get_Stamina") or manager:call("get_CurrentStamina")
                or manager:get_field("_Stamina"))
            local most = tonumber(manager:call("get_MaxStamina") or manager:get_field("_MaxStamina"))
            stamina = fraction(now, most) or stamina
        end)
    end

    return health, stamina
end

----------------------------------------------------------------------------------------------------
-- the party itself
----------------------------------------------------------------------------------------------------
local last_good = {}

local function cached_chara(holder)
    if not holder then return nil end
    return Safe.call(function() return holder:call("get_CachedCharacter") end)
        or holder["<CachedCharacter>k__BackingField"]
end

function Party.commandable()
    local out, seen = {}, {}
    local manager = sdk.get_managed_singleton("app.PawnManager")
    if not manager then return out end

    local function add(chara, pawn_obj, label)
        if not Safe.alive(chara) then return end
        local addr = Safe.address(chara)
        if not addr or seen[addr] then return end
        seen[addr] = true
        if W.is_dead(chara) then return end

        local job, skills = Party.read_skills(chara, pawn_obj)
        local health, stamina = Party.vitals(chara, pawn_obj)
        out[#out + 1] = {
            chara = chara,
            pawn_obj = pawn_obj,
            addr = addr,
            slot_label = label,
            name = Names.of_pawn(chara, pawn_obj, label),
            job = job,
            job_info = D.JOB_INFO[job] or D.DEFAULT_JOB_INFO,
            skills = skills,
            hp_ratio = health,
            stam_ratio = stamina,
        }
    end

    local function hired_label()
        return (#out == 0) and "MAIN PAWN" or ("HIRED PAWN " .. #out)
    end

    -- the main pawn, which is the one place its pawn object is certain to be
    pcall(function()
        local main = manager:get_field("_MainPawn")
        local chara = cached_chara(main)
        if chara then add(chara, main, "MAIN PAWN") end
    end)

    -- the character list: present in most situations, and with no pawn objects attached
    local list_ok = pcall(function()
        local list = manager:call("get_PawnCharacterList")
        if not list then return end
        local count = tonumber(Safe.call(function() return list:call("get_Count") end)) or 0
        for i = 0, math.min(count, MAX_CHARAS) - 1 do
            local ok, chara = pcall(function() return list[i] end)
            if ok and chara then add(chara, nil, hired_label()) end
        end
    end)

    -- the pawn-object list, which fills in the objects the list above does not carry
    pcall(function()
        local list = manager:call("get_PartyPawnList") or manager._PartyPawnList
        if not list then return end
        local count = tonumber(Safe.call(function() return list:call("get_Count") end) or list._size) or 0
        for i = 0, math.min(count, MAX_PAWN_OBJS) - 1 do
            local holder = Safe.call(function() return list:call("get_Item", i) end) or list[i]
            local chara = cached_chara(holder)
            if chara then add(chara, holder, hired_label()) end
        end
    end)

    if list_ok and #out > 0 then
        last_good = out
        return out
    end

    -- read nothing at all: keep the last party that read, with its vitals brought up to date
    if #out == 0 and #last_good > 0 then
        for _, entry in ipairs(last_good) do
            if Safe.alive(entry.chara) and not W.is_dead(entry.chara) then
                entry.hp_ratio, entry.stam_ratio = Party.vitals(entry.chara, entry.pawn_obj)
                out[#out + 1] = entry
            end
        end
    end
    return out
end

----------------------------------------------------------------------------------------------------
-- who needs a heal
----------------------------------------------------------------------------------------------------
-- Health against the maximum fatigue has brought it down to, which is the number that matters: a pawn at full health
-- on a halved maximum does not need healing, and one at half of a full maximum does.
local function health_share(chara)
    local ok, share = pcall(function()
        local now = tonumber(chara:call("get_Hp"))
        local most = tonumber(chara:call("get_ReducedMaxHp"))
        return (now and most and most > 0) and math.min(now / most, 1.0) or nil
    end)
    return ok and share or nil
end

-- The Arisen first if actually hurt, otherwise whoever in the party is worst off.
function Party.heal_target(pawn, player)
    local pick, lowest = player, health_share(player)
    if lowest and lowest < 0.5 then return player end

    for _, entry in ipairs(Party.commandable()) do
        if Safe.alive(entry.chara) and not W.is_dead(entry.chara) then
            local share = health_share(entry.chara)
            if share and (not lowest or share < lowest) then
                pick, lowest = entry.chara, share
            end
        end
    end
    return pick or player
end

return Party
