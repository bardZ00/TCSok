-- TacticalCommandSystem/in/veil.lua
-- Taking the controller away from the game, and giving it back.
--
-- While the wheel is open the player is driving the wheel, not the Arisen. Nothing in the game knows that, so left
-- alone every press does both: A orders a pawn *and* makes the Arisen swing, the left stick picks a cell *and* walks
-- her into the fight.
--
-- The game reads the player once a frame, through one call, into one object. So the wheel sits on the far side of that
-- call, reads the object for itself, and then blanks the parts it has claimed before the game ever looks. The game sees
-- a player who is standing still with nothing pressed.
--
-- What gets blanked is declared, not decided here: `Veil.hide` is set by the input state machine and this file only
-- applies it. Three jobs, kept apart --
--
--   read    the buttons as the game has them, which is one frame ahead of reading the device
--   ask     hand them to whoever is listening, and let it say what to hide
--   hide    blank exactly that
--
-- Two cautions. The blanking must go through pcall field by field: these field names differ between builds of the
-- engine, and one that is missing must not take the rest down with it. And the hook runs inside the game's own call
-- stack, where an error is a crash to desktop, so the whole body is wrapped.

local U = require("TacticalCommandSystem.utils")
local Pad = require("TacticalCommandSystem.in.pad")

local Veil = {}

-- the input object belongs to the player, not to a pawn or a menu
local PLAYER_GROUP = U.enum_val("app.UserInputManager.Group", "Player")

-- the button state, in the four shapes the game keeps it in
local BUTTON_FIELDS = { "PadButton", "PadButtonDown", "PadButtonUp", "PadButtonRepeat" }
local FLAG_FIELDS   = { "ButtonOnFlags", "ButtonTriggerFlags", "ButtonRepeatFlags", "ButtonReleaseFlags" }

-- the left stick, in every shape that would still walk the Arisen if it were left alone
local LEFT_AXES    = { "KeyboardMouseAxisL", "<AxisL>k__BackingField", "KeyboardMouseAxisR",
                       "<GyroAngularVelocity>k__BackingField" }
local LEFT_AMOUNTS = { "KeyboardMouseAnalogL", "<AnalogL>k__BackingField",
                       "<AxisMagnitudeL>k__BackingField", "KeyboardMouseAnalogR" }

-- the right stick, hidden only when the camera is meant to be locked too
local RIGHT_AXES    = { "<AxisR>k__BackingField" }
local RIGHT_AMOUNTS = { "<AnalogR>k__BackingField", "<AxisMagnitudeR>k__BackingField" }

local MOUSE_MOVED = "<IsMouseMovedInFrame>k__BackingField"
local RIGHT_MOVED = "<IsPadAxisRMovedInFrame>k__BackingField"

----------------------------------------------------------------------------------------------------
-- what the listener says to hide
----------------------------------------------------------------------------------------------------
-- Set by the input state machine, called once a frame with the buttons the game has:
--   held     everything down
--   pressed  what went down since the last frame, the game's own "down" edge included
-- Returns nil to leave the player alone, or a table saying what to take:
--   { buttons = true, left = true, right = true, mouse = true }
Veil.on_poll = nil

local function blank_each(input, names, value)
    for _, name in ipairs(names) do
        pcall(input.set_field, input, name, value)
    end
end

local function apply(input, hide)
    if hide.buttons then
        blank_each(input, BUTTON_FIELDS, 0)
        blank_each(input, FLAG_FIELDS, 0)
    end
    if hide.left then
        local still = Vector2f.new(0, 0)
        blank_each(input, LEFT_AXES, still)
        blank_each(input, LEFT_AMOUNTS, 0.0)
    end
    if hide.mouse then
        pcall(input.set_field, input, MOUSE_MOVED, false)
    end
    if hide.right then
        local still = Vector2f.new(0, 0)
        blank_each(input, RIGHT_AXES, still)
        blank_each(input, RIGHT_AMOUNTS, 0.0)
        pcall(input.set_field, input, RIGHT_MOVED, false)
    end
end

----------------------------------------------------------------------------------------------------
-- the hook
----------------------------------------------------------------------------------------------------
local held_before = 0

local function before_update(args)
    pcall(function()
        local store = thread.get_hook_storage()
        store.tc_input = nil
        local input = args and U.safe_managed_arg(args[2])
        if input and input:call("get_Group") == PLAYER_GROUP then
            store.tc_input = input
        end
    end)
end

local function after_update(retval)
    pcall(function()
        local input = thread.get_hook_storage().tc_input
        if not U.is_valid_obj(input) then return end

        local held = (input:get_field("PadButton") or 0) & Pad.KNOWN_BUTTONS
        local down = (input:get_field("PadButtonDown") or 0) & Pad.KNOWN_BUTTONS

        -- the game's own edge, plus the one worked out here: either on its own misses presses that land between frames
        local pressed = down | (held & (~held_before))
        held_before = held

        if not Veil.on_poll then return end
        local hide = Veil.on_poll(held, pressed)
        if hide then apply(input, hide) end
    end)
    return retval
end

function Veil.install()
    pcall(function()
        local td = sdk.find_type_definition("app.UserInput")
        local update = td and td:get_method("update")
        if update then sdk.hook(update, before_update, after_update) end
    end)
end

return Veil
