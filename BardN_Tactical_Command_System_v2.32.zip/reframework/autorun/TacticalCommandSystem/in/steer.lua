-- TacticalCommandSystem/in/steer.lua
-- Which cell the player is pointing at.
--
-- Two ways of pointing, and the wheel swaps between them on its own as soon as it sees one being used.
--
--   the stick    points a direction from the middle of the wheel. The cell nearest that direction is the one chosen,
--                wherever the cells happen to be drawn, so the layout can change without this having to know.
--   the mouse    moves a cursor, and whichever cell it is over is chosen -- or none, between them.
--
-- Mouse movement itself comes from in/mouse.lua, which is where the awkwardness of a captured pointer lives.

local U = require("TacticalCommandSystem.utils")
local SND = require("TacticalCommandSystem.sound")
local Mouse = require("TacticalCommandSystem.in.mouse")
local X = require("TacticalCommandSystem.in.shared")
local IN = X.IN
local W = IN.W

local MOUSE_WOKE   = 25          -- mouse travel in a frame that counts as the player reaching for it
local STICK_WOKE   = 0.3         -- stick lean that counts as the player reaching for that instead
local STICK_ALIVE  = 0.1         -- lean below which the stick is treated as resting
local STICK_REACH  = 100         -- the stick's lean, in the units the wheel steers in
local MOUSE_SENS   = 0.85        -- mouse pixels to those same units
local DEADZONE     = 4           -- below this nothing is pointed at
local SETTLE       = 0.92        -- how fast a let-go stick drifts back to the middle
local KEEP         = 1.12        -- the cell in hand stays in hand until another is this much nearer

IN.mouse_read = Mouse.travel

-- the mouse cursor, drawn by the wheel: on by default, and these are the player's to change
IN.mouse_mode, IN.mouse_speed, IN.mouse_margin, IN.mouse_show = true, 1.0, 6, true
IN.mouse_follow = false          -- 1.15: the cursor is independent by default (moves with the mouse, never jumps onto
                                 -- the system pointer); ticking the option lets it sit on a free pointer again

-- 1.14: some setups leave the system pointer visible while the game keeps pulling it back to one spot (its capture
-- point, usually the middle of the screen). Its position then "changes" every frame -- moved, pulled back, moved --
-- and following it made the wheel's cursor snap back to the middle as soon as the mouse moved (player report).
-- So: when the pointer keeps coming back to the same spot, it is a captured pointer being pulled home, not a free
-- one, and from then on the cursor moves by the mouse's own travel instead. Remembered for the session.
local WARP_NEAR = 2              -- px: back on the home spot
local WARP_SEEN = 2              -- returns home after moving that prove the pull
local pointer_pulled = false

----------------------------------------------------------------------------------------------------
-- pointing with the mouse
----------------------------------------------------------------------------------------------------
-- Where the cursor should start when the mouse takes over: on the cell already chosen, or in the middle of the wheel.
local function place_cursor(view)
    local chosen = W.sel and W.slices[W.sel]
    if chosen and chosen.cx then
        W.mx, W.my = view.ox + chosen.cx * view.s, view.oy + chosen.cy * view.s
    else
        W.mx, W.my = view.ox + W.aim.cx * view.s, view.oy + W.aim.cy * view.s
    end
end

-- The game normally keeps the pointer, in which case there is no position on screen to put the cursor at and it has to
-- be moved by how far the mouse travelled. But a position that *changes* between frames means the overlay has the
-- pointer after all, and then the cursor can sit exactly on it. Once seen, that is remembered.
local function follow_pointer(view)
    if pointer_pulled or not IN.mouse_follow then return false end
    local at = Mouse.on_screen()
    if at then
        if not W.abs_home then
            W.abs_home, W.abs_away, W.abs_warps = { at[1], at[2] }, false, 0
        else
            local home = math.abs(at[1] - W.abs_home[1]) <= WARP_NEAR and math.abs(at[2] - W.abs_home[2]) <= WARP_NEAR
            if not home then
                W.abs_away = true
            elseif W.abs_away then
                W.abs_away, W.abs_warps = false, (W.abs_warps or 0) + 1
                if W.abs_warps >= WARP_SEEN then
                    pointer_pulled, W.abs_ok = true, false
                    return false
                end
            end
        end
    end
    if at and W.abs_prev and (at[1] ~= W.abs_prev[1] or at[2] ~= W.abs_prev[2]) then
        W.abs_ok = true
    end
    W.abs_prev = at and { at[1], at[2] } or nil

    if not (W.abs_ok and at) then return false end
    if at[1] < 0 or at[2] < 0 or at[1] > view.sw or at[2] > view.sh then return false end
    W.mx, W.my = at[1], at[2]
    return true
end

-- the cell the cursor is inside, allowing the player's own slack around each one
local function cell_under_cursor(view)
    local slack = (IN.mouse_margin or 0) * view.s
    for _, item in ipairs(W.slices) do
        if item.bw then
            local left = view.ox + item.dx * view.s - slack
            local top = view.oy + item.dy * view.s - slack
            local right = left + item.bw * view.s + 2 * slack
            local bottom = top + item.bh * view.s + 2 * slack
            if W.mx >= left and W.mx <= right and W.my >= top and W.my <= bottom then
                return item.idx
            end
        end
    end
    return nil
end

local function steer_with_mouse(dx, dy)
    local view = W.view
    if not view or not W.aim then return end
    if not W.mx then place_cursor(view) end

    if not follow_pointer(view) then
        local speed = IN.mouse_speed or 1.0
        W.mx = math.max(0, math.min(view.sw, W.mx + dx * speed))
        W.my = math.max(0, math.min(view.sh, W.my + dy * speed))
    end

    local under = cell_under_cursor(view)
    if under ~= W.sel then W.used_multi_queue = false end
    W.sel = under
end

----------------------------------------------------------------------------------------------------
-- pointing with the stick
----------------------------------------------------------------------------------------------------
-- The direction is turned into a point on an ellipse through the cells, and the nearest cell to that point wins. A
-- little stickiness keeps the choice from flickering when the stick sits on a border between two of them.
local function cell_towards(ux, uy)
    local aim = W.aim
    if not aim then return nil end

    local px, py = aim.cx + ux * aim.rx, aim.cy + uy * aim.ry
    local nearest, nearest_gap, held_gap = nil, math.huge, nil

    for _, item in ipairs(W.slices) do
        if item.cx then
            local dx, dy = item.cx - px, item.cy - py
            local gap = dx * dx + dy * dy
            if gap < nearest_gap then nearest, nearest_gap = item, gap end
            if item.idx == W.sel then held_gap = gap end
        end
    end

    if held_gap and nearest and nearest.idx ~= W.sel and held_gap <= nearest_gap * KEEP * KEEP then
        return W.sel
    end
    return nearest and nearest.idx or nil
end

----------------------------------------------------------------------------------------------------
-- 1.22 Éventail: the stick steps along the cards (left / right, held = repeats); down-left and down-right reach
-- Cancel and Stance in the corners. The choice stays when the stick comes back to rest.
----------------------------------------------------------------------------------------------------
local fan_armed, fan_t, fan_first = true, 0, 0
local function fan_steer(x, y)
    x, y = x or 0, y or 0
    W.sx, W.sy = x * STICK_REACH, y * STICK_REACH
    local order = W.fan_order or {}
    if #order == 0 then return end
    local function pos_of(idx) for k, v in ipairs(order) do if v == idx then return k end end end
    if W.sel == nil then W.sel = order[math.ceil(#order / 2)] end
    local now = U.wall_time()
    local ax, ay = math.abs(x), math.abs(y)
    if ax < 0.35 and ay < 0.35 then fan_armed = true; return end
    if y > 0.55 and ax > 0.3 then
        local want = (x < 0) and "left" or "right"
        for _, item in ipairs(W.corner_items or {}) do
            if item.side == want and item.idx and item.idx ~= W.sel then W.sel = item.idx; W.used_multi_queue = false end
        end
        fan_armed = false
        return
    end
    if ax >= 0.55 and ax > ay then
        local wait = ((now - fan_first) > 0.45) and 0.16 or 0.45
        if fan_armed or (now - fan_t) > wait then
            if fan_armed then fan_first = now end
            local p = pos_of(W.sel)
            local nxt
            if not p then
                local cur = W.sel and W.slices[W.sel]
                nxt = (cur and cur.side == "right") and order[#order] or order[1]   -- from a corner: its own end
            else
                nxt = order[math.max(1, math.min(#order, p + ((x < 0) and -1 or 1)))]
            end
            if nxt ~= W.sel then W.used_multi_queue = false end
            W.sel = nxt
            fan_armed, fan_t = false, now
        end
    end
end

----------------------------------------------------------------------------------------------------
-- which one is in use
----------------------------------------------------------------------------------------------------
local function stick_awake(x, y, threshold)
    return x ~= nil and y ~= nil and (math.abs(x) > threshold or math.abs(y) > threshold)
end

-- Follows whatever the player last reached for, which also decides whether the prompts show buttons or keys.
local function note_device(dx, dy, stick_x, stick_y)
    local mouse_moved = (math.abs(dx) + math.abs(dy)) > MOUSE_WOKE
    if mouse_moved then W.kbm = true end
    if stick_awake(stick_x, stick_y, STICK_WOKE) then W.kbm = false end

    if IN.mouse_mode and W.mode ~= "mouse" and mouse_moved then
        W.mode, W.mx = "mouse", nil
    end
end

local function steer(stick_x, stick_y)
    if #W.slices == 0 then
        W.sel = nil
        return
    end
    W.last_steer_t = U.wall_time()

    if W.mouse_reset then
        Mouse.forget()
        W.mouse_reset = false
    end
    local dx, dy = Mouse.travel()
    note_device(dx, dy, stick_x, stick_y)

    if W.mode == "mouse" then
        if stick_awake(stick_x, stick_y, STICK_WOKE) then
            W.mode = "pad"                     -- the stick takes over again
        else
            steer_with_mouse(dx, dy)
            return
        end
    end
    if IN.mouse_mode then dx, dy = 0, 0 end    -- with a cursor available, the mouse does not also nudge the stick
    if W.layout == "fan" then fan_steer(stick_x, stick_y); return end

    if stick_awake(stick_x, stick_y, STICK_ALIVE) then
        W.sx, W.sy = stick_x * STICK_REACH, stick_y * STICK_REACH
        W.stick_was_active = true
    elseif dx ~= 0 or dy ~= 0 then
        -- the mouse nudges the direction, and leaves it where it stops
        W.stick_was_active = false
        W.sx = math.max(-STICK_REACH, math.min(STICK_REACH, W.sx + dx * MOUSE_SENS))
        W.sy = math.max(-STICK_REACH, math.min(STICK_REACH, W.sy + dy * MOUSE_SENS))
    elseif W.stick_was_active then
        -- the stick has come back to the middle: nothing is pointed at, which is how a choice is taken back
        W.sx, W.sy = 0, 0
    end

    local lean = math.sqrt(W.sx * W.sx + W.sy * W.sy)
    if lean >= DEADZONE then
        local under = cell_towards(W.sx / lean, W.sy / lean)
        if under ~= W.sel then W.used_multi_queue = false end
        W.sel = under
        return
    end

    if not stick_x and dx == 0 and dy == 0 then
        W.sx, W.sy = W.sx * SETTLE, W.sy * SETTLE
    end
    if lean < DEADZONE * 0.8 then W.sel = nil end
end

----------------------------------------------------------------------------------------------------
-- every frame
----------------------------------------------------------------------------------------------------
local sounded = nil

function IN.update_steering(stick_x, stick_y)
    steer(stick_x, stick_y)
    -- a small click each time the choice slides onto another cell
    if W.sel ~= sounded then
        if W.sel ~= nil then SND.play("cursor") end
        sounded = W.sel
    end
end
