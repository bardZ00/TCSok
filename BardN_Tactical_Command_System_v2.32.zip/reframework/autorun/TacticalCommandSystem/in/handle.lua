-- TacticalCommandSystem/in/handle.lua
-- What the player's presses mean, frame by frame.
--
-- The wheel has two stages, and a press means different things in each:
--
--   stage 1, the wheel     the stick picks a cell. Order and close, order and stay, queue, lock to manual only,
--                          the Cancel cell, back, close.
--   stage 2, targeting     the wheel fades and the stick, the D-pad, the keys or the mouse pick the enemy to the left
--                          or the right. Go, back to the wheel, close everything.
--
-- The presses themselves come from three places, and this file is where they are reconciled: the pad device
-- (in/pad.lua), the game's own copy of the pad (in/veil.lua, which is also what hides it from the game), and the
-- keyboard. The first two see the same press a frame apart, which is what in/press.lua is for.
--
-- Opening and closing has four shapes the player can choose between, and they are the fiddly part: hold the button and
-- let go, hold it for a moment first, press to open and press again to close, or tap it quickly to make it stay.

local U = require("TacticalCommandSystem.utils")
local D = require("TacticalCommandSystem.data")
local AI = require("TacticalCommandSystem.cmd.init")
local SND = require("TacticalCommandSystem.sound")
local Pad = require("TacticalCommandSystem.in.pad")
local Veil = require("TacticalCommandSystem.in.veil")
local Press = require("TacticalCommandSystem.in.press")
local P = require("TacticalCommandSystem.possess")
local X = require("TacticalCommandSystem.in.shared")
local IN = X.IN
local W = IN.W
local Slow = U.Slow

-- from in/binds
local is_vk_down, open_binds = X.is_vk_down, X.open_binds

local FRAMES_STALLED = 0.25      -- s : no frame in this long means the mod stopped running; let the wheel go
local SETTLE_WHEEL = 0.3         -- s : the press that opened the wheel never also gives an order
local SETTLE_TARGET = 0.12       -- s : nor does the press that opened the targeting step confirm it
local STICK_RELEASED = 0.3       -- the stick counts as back at rest below this
local STICK_FLICKED = 0.6        -- and as flicked above it
local MOUSE_STEP = 90            -- how far the mouse travels to step to the next target
local MOUSE_WOKE = 25            -- and how far it moves before the key prompts switch to the keyboard ones
local STICK_CLICK_BLIND = 0.15   -- s : clicking the left stick tilts it; ignore the tilt for a moment
local FLASH_SECS = 1.8

IN.open_delay = 0.30             -- s : a single opening button must be held this long before the wheel opens
IN.cam_tilt = true               -- the right stick still moves the camera while the wheel is open
IN.cam_speed = 1.0               -- how fast, as a factor
IN.cam_realtime = true           -- the camera ignores the slow motion, so it pans at normal speed

----------------------------------------------------------------------------------------------------
-- reading the pad
----------------------------------------------------------------------------------------------------
-- Is the wheel opened by a single button held down for a moment? That one is handled on the frame loop rather than in
-- the veil, because it needs to watch the button over time.
local function opens_on_hold()
    local modifier, trigger = open_binds()
    return modifier == 0 and trigger ~= 0 and (IN.open_delay or 0) > 0
end

----------------------------------------------------------------------------------------------------
-- the veil: what to hide from the game, and the presses it sees first
----------------------------------------------------------------------------------------------------
local HIDE_BUTTONS = { buttons = true }
local HIDE_DRIVING = { buttons = true, left = true, mouse = true }
local HIDE_ALL     = { buttons = true, left = true, mouse = true, right = true }

Veil.on_poll = function(held, pressed)
    -- the mod has stopped running while the wheel was open: let go of everything rather than freezing the player
    if W.open and (U.wall_time() - W.last_update_wall > FRAMES_STALLED) then
        W.open = false
        W.swallowing = false
        Slow.releasing = true
        return nil
    end

    local B = IN.BINDS
    local modifier, trigger = open_binds()
    local modifier_down = (modifier == 0) or Pad.hit(held, modifier)

    W.pad_mod_held = (modifier ~= 0 and Pad.hit(held, modifier))
        or (modifier == 0 and Pad.hit(held, trigger))

    if not W.open then
        if modifier_down and Pad.hit(pressed, trigger) and not opens_on_hold() then
            IN.last_open_src = "manette / pad"
            IN.open_wheel(U.wall_time())
        end
        -- the wheel has just closed: swallow what is still held down, or the game acts on it the moment it is let go
        if W.swallowing then
            if held == 0 then
                W.swallowing = false
                return nil
            end
            return HIDE_BUTTONS
        end
        return nil
    end

    -- The wheel is open: note what was pressed for the frame loop to act on. Set as requests rather than acted on here,
    -- because this runs inside the game's own input call and ordering a pawn from there would reach into the AI mid-frame.
    if Pad.hit(pressed, B.pad_prev_pawn) then
        W.nav_delta = -1
    elseif Pad.hit(pressed, B.pad_next_pawn_2) then
        W.nav_delta = 1
    elseif Pad.hit(pressed, B.pad_queue_toggle) then
        W.queue_req = true
    elseif Pad.hit(pressed, B.pad_confirm_close) then
        W.confirm_req = true
    elseif Pad.hit(pressed, B.pad_confirm_stay) then
        W.stay_req = true
    elseif Pad.hit(pressed, B.pad_lock_char) and P.available() then
        W.lock_char_req = true
    elseif Pad.hit(pressed, B.pad_lock_skill) then
        W.lock_req = true
    elseif Pad.hit(pressed, B.pad_quick) then
        W.quick_req = true
    elseif Pad.hit(pressed, B.pad_cancel) then
        W.back_req = true
    elseif Pad.hit(pressed, B.pad_close_open) then
        W.close_req = true
    end

    return IN.cam_tilt and HIDE_DRIVING or HIDE_ALL
end

Veil.install()

----------------------------------------------------------------------------------------------------
-- the party, as it changes under the wheel
----------------------------------------------------------------------------------------------------
-- A pawn can fall or be dismissed while the wheel is open. Whoever was selected stays selected, by address rather than
-- by position, so a pawn dying does not silently move the selection onto its neighbour.
local function refresh_party(w_now)
    local chosen = W.pawns[W.pawn_idx]
    local latest = IN.get_party(w_now)
    if #latest == 0 then return end
    W.pawns = latest

    if chosen then
        for i, entry in ipairs(latest) do
            if entry.addr == chosen.addr then
                W.pawn_idx = i
                return
            end
        end
        -- the one that was selected is gone: back to the Arisen
        W.pawn_idx = 1
        IN.build_wheel_slices()
        W.sel = nil
        if W.stage == 2 then W.stage, W.tg = 1, nil end
    end
    if W.pawn_idx > #W.pawns then W.pawn_idx = 1 end
end

----------------------------------------------------------------------------------------------------
-- stage 1: the wheel
----------------------------------------------------------------------------------------------------
local function flash(msg, w_now)
    W.flash_msg = msg
    W.flash_icon = nil
    W.flash_until = w_now + FLASH_SECS
end

-- the character carousel at the top of the wheel
local function step_character(w_now, k)
    local B = IN.BINDS
    if Press.once("nav", W.nav_delta ~= 0, w_now) then
        IN.cycle_pawn(W.nav_delta)
    elseif Press.once("nav_r", Pad.hit(k.pressed, B.pad_next_pawn_2) or k.kb_next, w_now) then
        IN.cycle_pawn(1)
    elseif Press.once("nav_l", Pad.hit(k.pressed, B.pad_prev_pawn) or k.kb_prev, w_now) then
        IN.cycle_pawn(-1)
    end
end

local function stage_wheel(w_now, g_now, k)
    local B = IN.BINDS
    step_character(w_now, k)

    local entry = W.pawns[W.pawn_idx]
    local slice = W.sel and W.slices[W.sel] or nil
    local settled = (w_now - (W.opened_t or -10)) > SETTLE_WHEEL

    -- queue: on a skill already queued it takes it back out; on Stance or Cancel it applies to the whole party
    if Press.once("queue", W.queue_req or Pad.hit(k.pressed, B.pad_queue_toggle) or k.kb_queue, w_now)
        and settled and slice and entry then
        local already = entry.kind ~= "arisen" and slice.kind == "skill"
            and AI.get_skill_queue_pos(entry.addr, slice.skill_id)
        if already then
            local what, removed, left = AI.remove_from_queue(entry, slice.skill_id)
            if what == "removed" then
                flash(string.format("[ %s : REMOVED %s FROM QUEUE (%d LEFT) ]",
                    entry.name, U.upper(U.get_skill_display_name(removed)), left or 0), w_now)
            end
        else
            IN.begin_order(slice, entry, "queue", g_now, w_now)
        end
        W.used_multi_queue = true
        if W.stage ~= 1 then return end
    end

    -- the shortcut straight to the Cancel cell, without steering to it
    if Press.once("cancel_orders", Pad.hit(k.pressed, B.pad_cancel_orders), w_now) and entry then
        for _, item in ipairs(W.corner_items) do
            if item.kind == "cancel" then
                IN.begin_order(item, entry, "close", g_now, w_now)
                break
            end
        end
    end

    -- Lock (or unlock) the highlighted character: the one closing the wheel will always return you to, instead of the
    -- body-switch an unlocked close does. No cell has to be selected -- the top row is the whole choice.
    if P.available() and Press.once("lockchar", W.lock_char_req or Pad.hit(k.pressed, B.pad_lock_char) or k.kb_lock_char, w_now)
        and settled and entry then
        local msg = P.toggle_lock(entry)
        if msg then flash(msg, w_now) end
        SND.play("decide")
    end

    -- order and close, or order and stay. A stance always stays, so the player can set several.
    local confirm = Press.once("confirm", W.confirm_req or Pad.hit(k.pressed, B.pad_confirm_close) or k.kb_confirm, w_now)
    local stay = Press.once("stay", W.stay_req or Pad.hit(k.pressed, B.pad_confirm_stay) or k.kb_stay, w_now)
    if (confirm or stay) and settled and slice and entry then
        local mode = confirm and "close" or "stay"
        if slice.kind == "stance" or slice.kind == "team" then mode = "stay" end
        local result = IN.begin_order(slice, entry, mode, g_now, w_now)
        if result == "done" and mode == "close" then IN.close_wheel(false, g_now, w_now) end
        if W.stage ~= 1 or not W.open then return end
    end

    -- keep this skill for the player to order: the pawn will not use it by itself
    if Press.once("lock", W.lock_req or Pad.hit(k.pressed, B.pad_lock_skill) or k.kb_lock_skill, w_now)
        and settled and slice and slice.kind == "skill" and entry and entry.kind ~= "arisen" then
        local locked = AI.toggle_lock(entry, slice.skill_id)
        if locked == nil then
            W.flash_msg = "[ THIS SKILL CANNOT BE LOCKED ]"
            W.flash_until = w_now + FLASH_SECS
        elseif locked then
            flash(string.format("[ %s : %s MANUAL ONLY ]", entry.name, slice.name), w_now)
        else
            flash(string.format("[ %s : %s AUTO AGAIN ]", entry.name, slice.name), w_now)
        end
        SND.play("decide")
    end

    -- away without ordering anything (closing switches body, handled in close_wheel)
    if Press.once("close", W.back_req or W.close_req
        or Pad.hit(k.pressed, B.pad_cancel)
        or Pad.hit(k.pressed, B.pad_close_open) or k.kb_cancel, w_now) then
        IN.close_wheel(false, g_now, w_now)
    end
end

----------------------------------------------------------------------------------------------------
-- stage 2: picking the enemy
----------------------------------------------------------------------------------------------------
-- Which way the player wants to go. Four ways of saying it, and the mouse needs adding up over several frames because
-- one frame of mouse movement is far too small to mean anything.
local function target_direction(w_now, k)
    local B = IN.BINDS
    local dir = 0

    if Press.once("nav", W.nav_delta ~= 0, w_now) then dir = W.nav_delta
    elseif Press.once("nav_r", Pad.hit(k.pressed, B.pad_next_pawn_2) or k.kb_next, w_now) then dir = 1
    elseif Press.once("nav_l", Pad.hit(k.pressed, B.pad_prev_pawn) or k.kb_prev, w_now) then dir = -1
    elseif Press.once("tg_r", k.kb_tr, w_now) then dir = 1
    elseif Press.once("tg_l", k.kb_tl, w_now) then dir = -1 end

    -- any real mouse movement means the player has their hand on it: show the keyboard prompts
    if IN.mouse_read and (W.mode == "mouse" or not IN.mouse_mode) then
        local dx, dy = IN.mouse_read()
        if math.abs(dx or 0) + math.abs(dy or 0) > MOUSE_WOKE then W.kbm = true end
    end

    if W.mode == "mouse" and IN.mouse_read then
        local dx = IN.mouse_read()
        W.tg_acc = (W.tg_acc or 0) + (dx or 0) * (IN.mouse_speed or 1.0)
        if math.abs(W.tg_acc) > MOUSE_STEP then
            if dir == 0 then dir = (W.tg_acc > 0) and 1 or -1 end
            W.tg_acc = 0
        end
    end

    -- a flick of the stick, which has to come back to rest before it counts again, or holding it would race through
    local tilt = k.ax or 0
    if math.abs(tilt) < STICK_RELEASED then
        W.stick_armed = true
    elseif W.stick_armed and math.abs(tilt) > STICK_FLICKED then
        W.stick_armed = false
        dir = (tilt > 0) and 1 or -1
    end

    return dir
end

local function stage_target(w_now, g_now, k)
    local B = IN.BINDS
    IN.refresh_targets(w_now)
    local settled = (w_now - (W.stage_t or -10)) > SETTLE_TARGET

    local dir = target_direction(w_now, k)
    if dir ~= 0 then IN.target_step(dir) end

    -- any of the three confirming buttons sends the order; which one was used is decided where the order is built
    local go = Press.once("confirm", W.confirm_req or Pad.hit(k.pressed, B.pad_confirm_close) or k.kb_confirm, w_now)
    local stay = Press.once("stay", W.stay_req or Pad.hit(k.pressed, B.pad_confirm_stay) or k.kb_stay, w_now)
    local queue = Press.once("queue", W.queue_req or Pad.hit(k.pressed, B.pad_queue_toggle) or k.kb_queue, w_now)
    local quick = Press.once("quick", W.quick_req or Pad.hit(k.pressed, B.pad_quick) or k.kb_quick, w_now)
    go = go or stay or queue or quick
    if go and settled then
        -- 2.23: a chargeable skill: A / RB / left click charge it fully; X (controller), or the middle mouse button
        -- or its own keyboard binding, ask for the quick one
        local sid = W.tg and W.tg.slice and W.tg.slice.skill_id
        local ord = sid and D.ORDERS[sid]
        if ord and ord.full and quick then D.charge_quick_once = sid end     -- 2.20: X / its own keyboard binding
        IN.target_confirm(g_now, w_now)
        D.charge_quick_once = nil
        return
    end

    if Press.once("back", W.back_req or Pad.hit(k.pressed, B.pad_cancel) or k.kb_cancel, w_now) then
        IN.target_back(w_now)
        return
    end
    if Press.once("close", W.close_req or Pad.hit(k.pressed, B.pad_close_open), w_now) then
        IN.close_wheel(false, g_now, w_now)
    end
end

----------------------------------------------------------------------------------------------------
-- opening
----------------------------------------------------------------------------------------------------
local keys = Press.keys()
local KB_KEYS = {}
local holding = { since = nil, spent = false }

-- The pad side of opening, which depends on how the player has set the shortcut up:
--   a single button, held      the wheel opens once it has been held long enough, and the button must then be let go
--   a single button, at once   it opens on the press
--   modifier plus button       it opens while the modifier is down and the button goes down
local function pad_wants_open(w_now, held, pressed, trigger_was_down)
    local modifier, trigger = open_binds()
    if trigger == 0 then return false end

    if modifier ~= 0 then
        return (W.pad_mod_held and (Pad.hit(held, trigger) or trigger_was_down)) or false
    end

    -- 2.18 (BardN): in Click mode the wheel opens on a short tap, when the button is let go; held longer than the
    -- hold time (0.3 s by default) it does not open at all, so the button keeps its use in the game
    if IN.open_mode ~= "hold" then
        local limit = ((IN.open_delay or 0) > 0) and IN.open_delay or 0.3
        if Pad.hit(held, trigger) then
            holding.since = holding.since or w_now
            return false
        end
        local since = holding.since
        holding.since, holding.spent = nil, false
        return since ~= nil and (w_now - since) < limit
    end

    if (IN.open_delay or 0) <= 0 then
        return Pad.hit(pressed, trigger)
    end

    if not Pad.hit(held, trigger) then
        holding.since, holding.spent = nil, false
        return false
    end
    holding.since = holding.since or w_now
    if not holding.spent and not W.open and (w_now - holding.since) >= IN.open_delay then
        holding.spent = true
        return true
    end
    return false
end

----------------------------------------------------------------------------------------------------
-- closing
----------------------------------------------------------------------------------------------------
-- Letting go of the opening shortcut closes the wheel, but only once it has been held while open: otherwise the
-- release of the very press that opened it would close it again straight away.
local function close_on_release(w_now, g_now, held, open_key_down, settled)
    local _, trigger, _, open_key = open_binds()
    local still_held = ((trigger ~= 0) and Pad.hit(held, trigger))
        or (open_key ~= 0 and open_key_down)

    if still_held and settled then W.rel_armed = true end
    if W.rel_armed and not still_held then
        W.rel_armed = false
        IN.close_wheel(IN.release_confirm == true, g_now, w_now)
        return true
    end
    return false
end

-- Pressing the shortcut again while the wheel is open closes it, in every shape but "hold": there, letting go closes
-- it, except after a quick tap, which makes the wheel stay up until the next press.
local function closing_press(w_now, g_now, held, pressed, open_key_fresh, open_key_down, settled)
    local modifier, trigger = open_binds()
    local combo_ok = (modifier == 0) or Pad.hit(held, modifier)
    local clicked = settled and ((trigger ~= 0 and combo_ok and Pad.hit(pressed, trigger)) or open_key_fresh)

    if IN.open_mode ~= "hold" or W.sticky then
        if Press.once("open_btn", clicked, w_now) then IN.close_wheel(false, g_now, w_now) end
        return
    end

    -- the shortcut still being held: whichever part of it the player set up
    local pad_held = W.pad_mod_held
        or (modifier ~= 0 and Pad.hit(held, modifier))
        or (modifier == 0 and Pad.hit(held, trigger))

    if not pad_held and not open_key_down then
        if (w_now - (W.opened_t or -10)) < (IN.TAP_KEEP or 0) then
            W.sticky = true           -- a quick tap: the wheel stays up and the next press closes it
        else
            IN.close_wheel(true, g_now, w_now)
        end
    end
end

----------------------------------------------------------------------------------------------------
-- which device the prompts should show
----------------------------------------------------------------------------------------------------
-- The key prompts follow whatever the player last touched, so a player on the pad never sees keyboard letters and the
-- other way round. The mouse mode switches on the same evidence.
local function follow_device(pad_pressed, stick_x, kb)
    local pad_used = pad_pressed ~= 0 or stick_x ~= nil
    local key_used = kb.confirm or kb.cancel or kb.stay or kb.next or kb.prev or kb.queue or kb.tl or kb.tr

    if pad_used then
        W.kbm = false
    elseif key_used then
        W.kbm = true
    end

    if not IN.mouse_mode then return end
    if W.mode == "mouse" and pad_used then
        W.mode = "pad"
    elseif W.mode ~= "mouse" and (kb.confirm or kb.cancel or kb.stay or kb.next or kb.prev or kb.queue) then
        W.mode, W.mx = "mouse", nil
    end
end

----------------------------------------------------------------------------------------------------
-- every frame
----------------------------------------------------------------------------------------------------
function IN.handle_inputs(w_now, g_now)
    -- 2.24: a full-screen menu of another mod is open (RPG Level Up Overhaul): the wheel stays shut and lets go
    if IN.modal_mod_open() then
        if W.open then IN.close_wheel(false, g_now, w_now) end
        return
    end
    local held, pressed, stick_x, stick_y, tilt = Pad.read()
    local B = IN.BINDS
    IN.diag_pad = held

    local _, trigger, open_modifier_key, open_key = open_binds()

    local open_key_down = is_vk_down(open_key)
    local open_key_fresh = keys:edge("open", open_key_down)
        and ((open_modifier_key == 0) or is_vk_down(open_modifier_key))

    local kb_keys = KB_KEYS            -- refilled in place every frame: the bindings can change in the menu
    kb_keys.next, kb_keys.prev, kb_keys.queue = B.kb_next_pawn, B.kb_prev_pawn, B.kb_queue_toggle
    kb_keys.lock_char, kb_keys.lock_skill = B.kb_lock_char, B.kb_lock_skill
    kb_keys.cancel, kb_keys.confirm, kb_keys.stay = B.kb_cancel, B.kb_confirm, B.kb_stay
    kb_keys.tl, kb_keys.tr = B.kb_target_left, B.kb_target_right
    kb_keys.quick = B.kb_quick
    local kb_down, kb = keys:read(kb_keys, is_vk_down)

    local was_open = W.open
    local trigger_was_down = keys:held("pad_trigger")
    keys.before.pad_trigger = Pad.hit(held, trigger)

    if not W.open then
        if pad_wants_open(w_now, held, pressed, trigger_was_down) or open_key_fresh then
            IN.last_open_src = open_key_fresh and "clavier / keyboard" or "manette / pad"
            IN.open_wheel(w_now)
            -- opened from the keyboard: the mouse drives the wheel, with a real cursor to hover and click with
            if open_key_fresh and IN.mouse_mode then W.mode = "mouse" end
            W.kbm = open_key_fresh and true or false
            -- opened by holding the button: letting go closes it at once, with no quick-tap grace
            local modifier = open_binds()
            if not open_key_fresh and modifier == 0 and (IN.open_delay or 0) > 0 and IN.open_mode == "hold" then
                W.rel_armed = true
            end
        end
    else
        refresh_party(w_now)

        -- clicking the left stick tilts it as well: do not read that tilt as steering
        if (Pad.hit(held, B.pad_lock_skill) and (B.pad_lock_skill & 4096) ~= 0)
            or (Pad.hit(held, B.pad_lock_char) and (B.pad_lock_char & 4096) ~= 0) then
            W.steer_hold_until = w_now + STICK_CLICK_BLIND
        end

        follow_device(pressed, stick_x, kb_down)

        local k = {
            pressed = pressed, ax = tilt,
            kb_next = kb.next, kb_prev = kb.prev, kb_queue = kb.queue, kb_cancel = kb.cancel,
            kb_confirm = kb.confirm, kb_stay = kb.stay, kb_tl = kb.tl, kb_tr = kb.tr, kb_quick = kb.quick,
            kb_lock_char = kb.lock_char, kb_lock_skill = kb.lock_skill,
        }

        if W.stage == 2 then
            stage_target(w_now, g_now, k)
        else
            stage_wheel(w_now, g_now, k)
        end

        local settled = (w_now - (W.opened_t or -10)) > SETTLE_WHEEL
        local toggles = (IN.open_mode ~= "hold")

        if W.open and IN.close_on_release and (toggles or W.sticky) then
            close_on_release(w_now, g_now, held, open_key_down, settled)
        end

        if W.open then
            closing_press(w_now, g_now, held, pressed, open_key_fresh, open_key_down, settled)
        end
    end

    -- closed while the opening button is still down: it has to be let go before it opens again
    if was_open and not W.open then holding.spent = true end

    -- the requests the veil noted are good for one frame only
    W.nav_delta = 0
    W.queue_req, W.confirm_req, W.stay_req, W.quick_req = false, false, false, false
    W.lock_char_req = false
    W.lock_req, W.back_req, W.close_req = false, false, false

    return stick_x, stick_y
end
