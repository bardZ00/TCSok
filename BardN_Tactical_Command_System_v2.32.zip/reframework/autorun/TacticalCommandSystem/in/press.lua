-- TacticalCommandSystem/in/press.lua
-- One press, one action.
--
-- The wheel sees the same button twice. It reads the pad from the device (in/pad.lua) and the game's own copy of it
-- (in/veil.lua), and those two readings are a frame apart, so a single tap of A arrives as two presses -- which orders
-- the same skill twice, or orders it and immediately closes the wheel.
--
-- Both readings are needed: the device is the only one that still answers while the wheel is open, and the game's copy
-- catches presses that land between frames. So neither is dropped, and instead an action that has just fired refuses to
-- fire again for a moment. Seventy milliseconds: longer than the gap between the two readings, shorter than any human
-- double tap.
--
-- Keyboard keys are the same problem from the other end -- a held key reads as down on every frame, and the wheel wants
-- the moment it went down -- so the edge tracking lives here too.

local Press = {}

local SAME_ACTION_GAP = 0.07     -- s : an action that just fired ignores a second sighting of it

----------------------------------------------------------------------------------------------------
-- an action that has just fired
----------------------------------------------------------------------------------------------------
local last_fired = {}

-- True once per press. `name` is the action, not the button: two buttons bound to "confirm" still only confirm once.
function Press.once(name, pressed, now)
    if not pressed then return false end
    if (now - (last_fired[name] or -10)) < SAME_ACTION_GAP then return false end
    last_fired[name] = now
    return true
end

----------------------------------------------------------------------------------------------------
-- keys going down
----------------------------------------------------------------------------------------------------
-- Tracks a set of named keys and tells you which ones went down this frame.
--
--   local keys = Press.keys()
--   local down, fresh = keys:read({ confirm = vk_a, cancel = vk_escape }, is_down)
--   -- down.confirm  : held now
--   -- fresh.confirm : went down this frame
--
-- Each tracker keeps its own record, so the wheel's keys and the menu's cannot interfere.
local Keys = {}
Keys.__index = Keys

function Press.keys()
    return setmetatable({ before = {}, down_now = {}, fresh = {} }, Keys)
end

-- Only the names given are touched, so a tracker may also hold a key or two watched on their own with `edge`
-- without `read` wiping them. The two tables returned are reused from one frame to the next (read every frame, kept by
-- nobody): use them within the frame.
function Keys:read(bindings, is_down)
    local down_now, fresh = self.down_now, self.fresh
    for name, vk in pairs(bindings) do
        local down = is_down(vk) and true or false
        down_now[name] = down
        fresh[name] = down and not self.before[name]
        self.before[name] = down
    end
    return down_now, fresh
end

-- for a single key tracked on its own (the opening shortcut, which is read before the rest)
function Keys:edge(name, down)
    local was = self.before[name]
    self.before[name] = down and true or false
    return down and not was
end

function Keys:held(name)
    return self.before[name] == true
end

return Press
