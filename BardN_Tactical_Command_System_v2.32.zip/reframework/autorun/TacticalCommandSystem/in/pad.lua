-- TacticalCommandSystem/in/pad.lua
-- The controller, read straight from the device.
--
-- There are two ways to know what the player is pressing, and the wheel needs both.
--
-- This one reads the merged device: the pad as the driver sees it, before the game has looked at it. It is the only
-- reading that still works while the wheel is open, because the wheel hides the buttons from the game (in/veil.lua)
-- and anything reading the game's own copy would see nothing.
--
-- The other one is the veil's: it sees the game's copy, one frame earlier. Both are used, which is why a press can
-- arrive twice -- see in/press.lua for what is done about that.
--
-- "Merged" means every connected pad folded into one, so a second controller works without asking which.

local Pad = {}

local DEADZONE = 0.25            -- below this the stick is resting, however the player is leaning on it
local KNOWN_BUTTONS = 0xFFFFF    -- the bits the game uses; above them is noise the wheel never reads

local singleton, type_def = nil, nil

----------------------------------------------------------------------------------------------------
-- the device
----------------------------------------------------------------------------------------------------
-- The merged device, or nil when nothing is plugged in. Looked up once; the lookup is kept even if the pad is
-- unplugged, since the device answers nothing rather than going away.
function Pad.device()
    if not singleton then
        -- the capital letter moved between builds of the engine, so both spellings are tried
        singleton = sdk.get_native_singleton("via.hid.GamePad") or sdk.get_native_singleton("via.hid.Gamepad")
        type_def = sdk.find_type_definition("via.hid.GamePad")
    end
    if not (singleton and type_def) then return nil end
    return sdk.call_native_func(singleton, type_def, "get_MergedDevice")
end

----------------------------------------------------------------------------------------------------
-- buttons
----------------------------------------------------------------------------------------------------
-- A binding is a bit mask: is any of its bits in `mask`. An unbound action has no bits and is never hit.
function Pad.hit(mask, binding)
    if not binding or binding == 0 then return false end
    return (mask & binding) ~= 0
end

function Pad.buttons()
    local held = 0
    pcall(function()
        local device = Pad.device()
        if device then held = tonumber(device:call("get_Button")) or 0 end
    end)
    return held
end

----------------------------------------------------------------------------------------------------
-- a whole reading
----------------------------------------------------------------------------------------------------
local was_held = 0

-- Everything the wheel needs from the pad this frame:
--   held      what is down now
--   pressed   what went down since the last reading
--   sx, sy    the left stick, or nil when it is resting. y is flipped: the device has down as positive, and the
--             wheel works in screen coordinates where up is negative.
--   ax        the stick's raw horizontal value, deadzone and all, for the flick that steps through targets
-- read once a frame: the work is a named function, so no closure is made for the pcall
local r_held, r_sx, r_sy, r_ax = 0, nil, nil, 0
local function read_device()
    local device = Pad.device()
    if not device then return end
    r_held = tonumber(device:call("get_Button")) or 0
    local stick = device:call("get_AxisL")
    local x, y = (stick and stick.x) or 0, (stick and stick.y) or 0
    r_ax = x
    if math.sqrt(x * x + y * y) > DEADZONE then r_sx, r_sy = x, -y end
end

function Pad.read()
    r_held, r_sx, r_sy, r_ax = 0, nil, nil, 0
    pcall(read_device)
    local held = r_held
    local pressed = held & (~was_held)
    was_held = held
    return held, pressed, r_sx, r_sy, r_ax
end

Pad.KNOWN_BUTTONS = KNOWN_BUTTONS

return Pad
