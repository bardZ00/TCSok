-- TacticalCommandSystem/in/mouse.lua
-- How far the mouse has moved since the last frame.
--
-- Harder than it sounds, because the game takes the pointer away. While the player is in the world the cursor is
-- captured: there is no cursor on screen, and asking where it is gives the same answer every frame. So the wheel asks
-- three different things and takes the first that answers:
--
--   1. the mouse device's own movement since the last frame -- the real answer, when the engine offers it
--   2. the difference between two readings of its position -- the fallback when it does not
--   3. the difference between two readings of the position the overlay sees -- which works while a menu has the pointer
--
-- Which methods the device has differs between builds of the engine, so they are not named outright: the device is
-- asked once, at the first reading, which of several names it answers to.
--
-- The overlay reading is kept separately as well: it is the only one that gives a position on screen, which is what
-- the mouse cursor the wheel draws needs.

local Mouse = {}

local DELTA_NAMES = { "get_DeltaPosition", "get_PosDelta", "get_DeltaPos", "get_Delta", "get_MoveDelta" }
local PLACE_NAMES = { "get_Position", "get_Pos", "get_CursorPosition", "get_ClientPosition" }
local ABSURD = 1e6               -- a position past this is the engine saying it has none

local probed = false
local delta_call, place_call = nil, nil
local last_place, last_overlay = nil, nil
-- 1.15: where the overlay pointer sat when the wheel opened. On setups where the game keeps pulling the pointer back
-- to that spot, a reading back on it is the pull, not the player: it must not count as movement, or every move is
-- undone at the next frame and the cursor can never leave the middle (player report, and BardN's own F4 setup).
local home = nil
local place_home = nil           -- the same, for the device's own position reading
local HOME_NEAR = 2

----------------------------------------------------------------------------------------------------
-- the device
----------------------------------------------------------------------------------------------------
-- Two ways of reaching it, depending on how the engine exposes the mouse in this build.
local function device()
    local td = sdk.find_type_definition("via.hid.Mouse")
    if not td then return nil end

    local getter = td:get_method("get_Device")
    if getter then
        local ok, dev = pcall(function() return getter:call(nil) end)
        if ok and dev then return dev end
    end

    local singleton = sdk.get_native_singleton("via.hid.Mouse")
    if singleton then
        local ok, dev = pcall(sdk.call_native_func, singleton, td, "get_Device")
        if ok and dev then return dev end
    end
    return nil
end

-- Asks the device, once, which of the names above it answers to.
local function probe()
    probed = true
    local dev = device()
    if not dev then return end

    local ok, td = pcall(function() return dev:get_type_definition() end)
    if not ok or not td then return end

    for _, name in ipairs(DELTA_NAMES) do
        if td:get_method(name) then delta_call = name; break end
    end
    for _, name in ipairs(PLACE_NAMES) do
        if td:get_method(name) then place_call = name; break end
    end
end

----------------------------------------------------------------------------------------------------
-- reading a pair of numbers out of whatever the engine hands back
----------------------------------------------------------------------------------------------------
-- A position comes back as a value type with x and y, or as an object whose x and y are fields. Neither shape is
-- guaranteed, so both are tried.
local function pair_of(value)
    if value == nil then return nil end

    local ok, x, y = pcall(function() return value.x, value.y end)
    if ok and type(x) == "number" and type(y) == "number" then return x, y end

    ok, x, y = pcall(function() return value:get_field("x"), value:get_field("y") end)
    if ok and type(x) == "number" and type(y) == "number" then return x, y end

    return nil
end

local function ask(dev, name)
    if not (dev and name) then return nil end
    local ok, value = pcall(function() return dev:call(name) end)
    return pair_of(ok and value or nil)
end

-- how far a position has moved since it was last read, remembering it for next time
local function travelled(x, y, kept)
    if not x then return 0, 0, kept end
    local dx, dy = 0, 0
    if kept then dx, dy = x - kept[1], y - kept[2] end
    return dx, dy, { x, y }
end

----------------------------------------------------------------------------------------------------
-- a reading
----------------------------------------------------------------------------------------------------
-- How far the mouse has moved since the last call. Always two numbers, 0, 0 when it has not moved or cannot be read.
function Mouse.travel()
    if not probed then probe() end

    local dev = (delta_call or place_call) and device() or nil

    -- 1. the device's own movement
    local own_dx, own_dy = 0, 0
    if dev and delta_call then
        local x, y = ask(dev, delta_call)
        if x then own_dx, own_dy = x, y end
    end

    -- 2. two readings of its position
    local place_dx, place_dy = 0, 0
    if dev and place_call then
        local x, y = ask(dev, place_call)
        if x and place_home and math.abs(x - place_home[1]) <= HOME_NEAR and math.abs(y - place_home[2]) <= HOME_NEAR then
            last_place = { x, y }                    -- pulled back home: not a move
        else
            place_dx, place_dy, last_place = travelled(x, y, last_place)
        end
    end

    -- 3. two readings of the overlay's pointer, which is also the only position on screen
    local overlay_dx, overlay_dy = 0, 0
    local ok, value = pcall(imgui.get_mouse)
    local mx, my = pair_of(ok and value or nil)
    if mx and math.abs(mx) < ABSURD and math.abs(my) < ABSURD then
        if home and math.abs(mx - home[1]) <= HOME_NEAR and math.abs(my - home[2]) <= HOME_NEAR then
            last_overlay = { mx, my }                -- pulled back home: not a move
        else
            overlay_dx, overlay_dy, last_overlay = travelled(mx, my, last_overlay)
        end
    end

    if own_dx ~= 0 or own_dy ~= 0 then return own_dx, own_dy end
    if place_dx ~= 0 or place_dy ~= 0 then return place_dx, place_dy end
    return overlay_dx, overlay_dy
end

-- Where the pointer is on screen, or nil. Only the overlay knows, and only while it has the pointer.
function Mouse.on_screen()
    return last_overlay
end

-- Forgets where the mouse was, so the next reading is a fresh start rather than one huge jump. Called when the wheel
-- opens, since the pointer may have travelled anywhere while it was closed.
function Mouse.forget()
    last_place, last_overlay, home, place_home = nil, nil, nil, nil
    Mouse.travel()
    home = last_overlay and { last_overlay[1], last_overlay[2] } or nil
    place_home = last_place and { last_place[1], last_place[2] } or nil
end

return Mouse
