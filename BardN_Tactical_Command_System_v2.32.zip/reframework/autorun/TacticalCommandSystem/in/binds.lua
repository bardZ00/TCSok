-- TacticalCommandSystem/in/binds.lua
-- Pad buttons, key names, default bindings, key reading with the Steam Input latch, raw snapshots for the capture.
-- Part of the input system (see input.lua); the public table is IN (in/shared.lua).

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local X = require("TacticalCommandSystem.in.shared")
local IN = X.IN
local W = IN.W

------------------------------------------------------------------------------------------------
-- Pad buttons, key names, default bindings, key reading (with the Steam Input latch)
------------------------------------------------------------------------------------------------
IN.BTN = {
    R3     = U.enum_val("via.hid.GamePadButton", "RStickPush"),
    L3     = U.enum_val("via.hid.GamePadButton", "LStickPush"),
    L1     = U.enum_val("via.hid.GamePadButton", "LTrigTop"),
    R1     = U.enum_val("via.hid.GamePadButton", "RTrigTop"),
    L2     = U.enum_val("via.hid.GamePadButton", "LTrigBottom"),
    R2     = U.enum_val("via.hid.GamePadButton", "RTrigBottom"),
    Up     = U.enum_val("via.hid.GamePadButton", "LUp"),
    Down   = U.enum_val("via.hid.GamePadButton", "LDown"),
    Left   = U.enum_val("via.hid.GamePadButton", "LLeft"),
    Right  = U.enum_val("via.hid.GamePadButton", "LRight"),
    A      = U.enum_val("via.hid.GamePadButton", "RDown"),
    B      = U.enum_val("via.hid.GamePadButton", "RRight"),
    X      = U.enum_val("via.hid.GamePadButton", "RLeft"),
    Y      = U.enum_val("via.hid.GamePadButton", "RUp"),
    Select = U.enum_val("via.hid.GamePadButton", "CLeft"),
    Start  = U.enum_val("via.hid.GamePadButton", "CRight"),
}
local BTN = IN.BTN

IN.PAD_BUTTON_LIST = {
    { key = "L1",     name = "L1 / LB",       val = BTN.L1 },
    { key = "R1",     name = "R1 / RB",       val = BTN.R1 },
    { key = "L2",     name = "L2 / LT",       val = BTN.L2 },
    { key = "R2",     name = "R2 / RT",       val = BTN.R2 },
    { key = "L3",     name = "L3 / LS",       val = BTN.L3 },
    { key = "R3",     name = "R3 / RS",       val = BTN.R3 },
    { key = "A",      name = "A / Cross",     val = BTN.A },
    { key = "B",      name = "B / Circle",    val = BTN.B },
    { key = "X",      name = "X / Square",    val = BTN.X },
    { key = "Y",      name = "Y / Triangle",  val = BTN.Y },
    { key = "Up",     name = "D-Pad Up",      val = BTN.Up },
    { key = "Down",   name = "D-Pad Down",    val = BTN.Down },
    { key = "Left",   name = "D-Pad Left",    val = BTN.Left },
    { key = "Right",  name = "D-Pad Right",   val = BTN.Right },
    { key = "Select", name = "Select / View", val = BTN.Select },
    { key = "Start",  name = "Start / Menu",  val = BTN.Start },
}

IN.VK_NAMES = {
    [0x00] = "NONE",
    [0x01] = "LMB", [0x02] = "RMB", [0x04] = "MMB", [0x05] = "MOUSE4", [0x06] = "MOUSE5",
    [0x08] = "BACKSPACE", [0x09] = "TAB", [0x0D] = "ENTER", [0x10] = "SHIFT",
    [0x11] = "CTRL", [0x12] = "ALT", [0x14] = "CAPSLOCK", [0x1B] = "ESC", [0x20] = "SPACE",
    [0x21] = "PGUP", [0x22] = "PGDN", [0x23] = "END", [0x24] = "HOME",
    [0x25] = "LEFT", [0x26] = "UP", [0x27] = "RIGHT", [0x28] = "DOWN",
    [0x2D] = "INS", [0x2E] = "DEL",
    [0x30] = "0", [0x31] = "1", [0x32] = "2", [0x33] = "3", [0x34] = "4",
    [0x35] = "5", [0x36] = "6", [0x37] = "7", [0x38] = "8", [0x39] = "9",
    [0x41] = "A", [0x42] = "B", [0x43] = "C", [0x44] = "D", [0x45] = "E",
    [0x46] = "F", [0x47] = "G", [0x48] = "H", [0x49] = "I", [0x4A] = "J",
    [0x4B] = "K", [0x4C] = "L", [0x4D] = "M", [0x4E] = "N", [0x4F] = "O",
    [0x50] = "P", [0x51] = "Q", [0x52] = "R", [0x53] = "S", [0x54] = "T",
    [0x55] = "U", [0x56] = "V", [0x57] = "W", [0x58] = "X", [0x59] = "Y", [0x5A] = "Z",
    [0x60] = "NUM0", [0x61] = "NUM1", [0x62] = "NUM2", [0x63] = "NUM3", [0x64] = "NUM4",
    [0x65] = "NUM5", [0x66] = "NUM6", [0x67] = "NUM7", [0x68] = "NUM8", [0x69] = "NUM9",
    [0x6A] = "NUM*", [0x6B] = "NUM+", [0x6D] = "NUM-", [0x6E] = "NUM.", [0x6F] = "NUM/",
    [0x70] = "F1", [0x71] = "F2", [0x72] = "F3", [0x73] = "F4", [0x74] = "F5", [0x75] = "F6",
    [0x76] = "F7", [0x77] = "F8", [0x78] = "F9", [0x79] = "F10", [0x7A] = "F11", [0x7B] = "F12",
    [0xA0] = "LSHIFT", [0xA1] = "RSHIFT", [0xA2] = "LCTRL", [0xA3] = "RCTRL",
    [0xA4] = "LALT", [0xA5] = "RALT",
    [0xBA] = ";", [0xBB] = "=", [0xBC] = ",", [0xBD] = "-", [0xBE] = ".", [0xBF] = "/",
    [0xC0] = "~", [0xDB] = "[", [0xDC] = "\\", [0xDD] = "]", [0xDE] = "'",
}

IN.DEFAULT_BINDS = {
    -- Keyboard / Mouse
    kb_open          = 0x51, -- Q (open the wheel)
    kb_open_mod      = 0x00, -- optional keyboard modifier held with the open key (0 = none)
    kb_next_pawn     = 0x45, -- E (next character)
    kb_prev_pawn     = 0x00, -- unbound by default
    kb_confirm       = 0x01, -- LMB (order and close; targeting: go)
    kb_stay          = 0x04, -- MMB (order and stay in the wheel)
    kb_queue_toggle  = 0x00, -- unbound (add to a pawn's queue)
    kb_lock_skill    = 0x46, -- F (2.07; unbound in 2.05-2.06): lock / unlock the highlighted pawn skill to "manual only"
    kb_lock_char     = 0x00, -- unbound (lock / unlock the highlighted character as the close-the-wheel return)
    kb_cancel        = 0x02, -- RMB (back / close the wheel)
    kb_target_left   = 0x41, -- A (targeting: enemy on the left)
    kb_target_right  = 0x44, -- D (targeting: enemy on the right)
    kb_quick         = 0x04,   -- 2.20: middle mouse button = targeting a chargeable skill: quick version, forced

    -- Gamepad (raw masks of BardN's pad: LB 256, LT 512, RT 2048, L3 4096, R3 8192)
    pad_open_trig    = 256,    -- LB held 0.3 s opens the wheel (setting "open_delay")
    pad_open_hold    = 0,      -- optional 2nd button held first (0 = a single button)
    pad_next_pawn_2  = BTN.Right,
    pad_prev_pawn    = BTN.Left,
    pad_confirm_close = BTN.A, -- A = order (targeting, then launch) AND close the wheel (closing switches body)
    -- 0.7: closing the wheel switches body, so the take-control button (R3 in 0.5-0.6) is gone; R3 held "order and
    -- stay", X "queue", LT the character lock.
    -- 0.9: the character lock moves to R3 (the more reachable button for a toggle used often), and "order and stay"
    -- takes LT in return.
    -- 2.14 (BardN): "order and stay" is gone (adding to the queue already keeps the wheel open); the queue moves to RB,
    -- "manual only" to RT, the Cancel shortcut to LT, the character lock to L3; X is the quick version when aiming.
    pad_confirm_stay = 0,      -- removed from the controller (kept for saved files; keyboard: middle button)
    pad_queue_toggle = BTN.R1, -- RB = add the order to the pawn's queue (wheel stays open); on Stance / Cancel = all pawns
    pad_lock_skill   = 2048,   -- RT = lock / unlock the highlighted pawn skill to "manual only"
    pad_lock_char    = 4096,   -- L3 = lock / unlock the highlighted character as the close-the-wheel return
    pad_cancel_orders = 512,   -- LT = the Cancel cell of the shown character
    pad_quick        = BTN.X,  -- X = targeting a chargeable skill: the quick version, forced
    pad_cancel       = BTN.B,  -- B = close the wheel; targeting: back to the wheel (closing switches body)
    pad_close_open   = 0,      -- optional extra "close" button
}

IN.BINDS = {}
for k, v in pairs(IN.DEFAULT_BINDS) do IN.BINDS[k] = v end

function IN.set_binds(tbl)
    for k, def_v in pairs(IN.DEFAULT_BINDS) do
        if type(tbl) == "table" and type(tbl[k]) == "number" then
            IN.BINDS[k] = tbl[k]
        else
            IN.BINDS[k] = def_v
        end
    end
end

function IN.reset_binds()
    for k, v in pairs(IN.DEFAULT_BINDS) do
        IN.BINDS[k] = v
    end
end

function IN.get_vk_name(vk)
    if not vk or vk <= 0 then return "NONE" end
    return IN.VK_NAMES[vk] or string.format("0x%02X", vk)
end

function IN.get_pad_name(val)
    if not val or val <= 0 then return "NONE" end
    for _, entry in ipairs(IN.PAD_BUTTON_LIST) do
        if entry.val == val and entry.val ~= 0 then
            return entry.name
        end
    end
    return string.format("BTN 0x%X", val)
end

function IN.get_pad_short_name(val)
    if not val or val <= 0 then return nil end
    for _, entry in ipairs(IN.PAD_BUTTON_LIST) do
        if entry.val == val and entry.val ~= 0 then
            return entry.key
        end
    end
    return nil
end

-- the keyboard is ALWAYS read through reframework:is_key_down (the only
-- source confirmed in game), never gated by the REFramework menu or by the device in use. Steam Input sends very brief
-- key pulses (a few ms): a key seen down stays counted down for IN.KB_LATCH seconds ("minimum hold"), so a pulse can't
-- slip between two frames. Alt / Ctrl / Shift without side count for left AND right.
IN.KB_LATCH = 0.07
IN.TAP_KEEP = 0.25      -- "hold" mode: a tap shorter than this keeps the wheel open (closes with the next press)
local latch_t = {}
local SIDED = {
    [0xA0] = { 0x10, 0xA1 }, [0xA1] = { 0x10, 0xA0 },
    [0xA2] = { 0x11, 0xA3 }, [0xA3] = { 0x11, 0xA2 },
    [0xA4] = { 0x12, 0xA5 }, [0xA5] = { 0x12, 0xA4 },
}
local is_key_down = reframework.is_key_down
local function fw_down(vk)
    local ok, res = pcall(is_key_down, reframework, vk)
    return ok and res == true
end

-- The game's merged pad device (nil without a pad). The singleton and its type are looked up once.
local pad_singleton, pad_td
local function merged_pad_device()
    if not pad_singleton then
        pad_singleton = sdk.get_native_singleton("via.hid.GamePad") or sdk.get_native_singleton("via.hid.Gamepad")
        pad_td = sdk.find_type_definition("via.hid.GamePad")
    end
    if not (pad_singleton and pad_td) then return nil end
    return sdk.call_native_func(pad_singleton, pad_td, "get_MergedDevice")
end

local function is_vk_down(vk)
    if not vk or vk <= 0 then return false end
    local down = fw_down(vk)
    if not down then
        local sd = SIDED[vk]
        if sd and fw_down(sd[1]) and not fw_down(sd[2]) then down = true end
    end
    local now = os.clock()
    if down then latch_t[vk] = now; return true end
    local lt = latch_t[vk]
    return (lt ~= nil and (now - lt) < (IN.KB_LATCH or 0))
end

-- Opening shortcut, normalised: a lone "held" key / button (no trigger set) opens the wheel by itself.
-- Returns pad_hold, pad_trigger, kb_hold, kb_key  (hold = 0 means a single key / button).
local function open_binds()
    local B = IN.BINDS
    local ph, pt = B.pad_open_hold or 0, B.pad_open_trig or 0
    if pt == 0 and ph ~= 0 then pt, ph = ph, 0 end
    local km, kk = B.kb_open_mod or 0, B.kb_open or 0
    if kk == 0 and km ~= 0 then kk, km = km, 0 end
    return ph, pt, km, kk
end
IN.open_binds = open_binds

-- raw snapshots used by the shortcut capture (which listens to keyboard AND controller at once)
function IN.keys_down_set()
    local set = {}
    for vk = 1, 254 do
        if fw_down(vk) then set[vk] = true end
    end
    return set
end

function IN.pad_mask_now()
    local btn = 0
    pcall(function()
        local dev = merged_pad_device()
        if dev then btn = tonumber(dev:call("get_Button")) or 0 end
    end)
    return btn
end

function IN.pad_names(mask)
    local out = {}
    for _, entry in ipairs(IN.PAD_BUTTON_LIST) do
        if entry.val ~= 0 and (mask & entry.val) ~= 0 then out[#out + 1] = entry.name end
    end
    return out
end

-- Diagnostic: the keys the mod sees down right now (only called while the diagnostic node is open in the menu)
function IN.diag_scan()
    local out = {}
    for vk = 1, 254 do
        if fw_down(vk) then
            out[#out + 1] = IN.get_vk_name(vk)
            if #out >= 8 then break end
        end
    end
    return out
end

-- shared with the other input files
X.is_vk_down = is_vk_down
X.open_binds = open_binds
X.merged_pad_device = merged_pad_device
