-- TacticalCommandSystem/in/shared.lua
-- The public input table (IN) and the wheel state (IN.W) shared by the input files.

local IN = {}

IN.W = {
    open = false,
    pawns = {},             -- the characters: [1] = the Arisen, then the pawns
    pawn_idx = 1,
    slices = {},
    skill_items = {},       -- the 6 skill cells (3 left, 3 right of the circle)
    corner_items = {},      -- the 2 small cells under the skills: Cancel (bottom-left), Stance (bottom-right)
    sel = nil,
    sx = 0,
    sy = 0,
    angle = nil,
    open_time = 0,
    pad_mod_held = false,
    kb_held = false,
    last_mouse = nil,
    disp_angle = nil,
    last_steer_t = nil,
    stick_was_active = false,
    flash_msg = nil,
    flash_until = 0,
    nav_delta = 0,
    back_req = false,       -- B (targeting: back to the wheel; wheel: close)
    close_req = false,      -- LT (close everything)
    queue_req = false,
    quick_req = false,      -- 2.14: X while aiming a chargeable skill
    confirm_req = false,    -- A
    stay_req = false,       -- R3
    lock_char_req = false,  -- LT
    lock_req = false,       -- L3
    stage = 1,              -- 1 = the wheel, 2 = targeting step
    stage_t = 0,
    tg = nil,               -- targeting step: { slice, entry, mode, t0 }
    tgt_idx = 0,            -- targeting step: index in W.targets
    car_pos = 1,            -- top row carousel: shown position (slides towards pawn_idx)
    used_multi_queue = false,
    swallowing = false,
    last_update_wall = 0,
    targets = {},
    targets_t = -10,
}

return { IN = IN }
