-- TacticalCommandSystem/in/slowmo.lua
-- Slow motion while the wheel is open (game speed x factor, smooth transition, original speed always restored).
-- Part of the input system (see input.lua); the public table is IN (in/shared.lua).

local U = require("TacticalCommandSystem.utils")
local X = require("TacticalCommandSystem.in.shared")
local IN = X.IN
local W = IN.W
local Slow = U.Slow

------------------------------------------------------------------------------------------------
-- Slow motion while the wheel is open
------------------------------------------------------------------------------------------------
-- slow-motion:
-- via.Application GlobalSpeed (whole game) x factor, smooth transition, written at LateUpdateBehavior.
-- Safety: the original speed is always restored; if another mod imposes its own speed we leave it alone.
IN.slowmo_enabled = true
IN.slowmo_factor = 0.10
IN.slowmo_ms = 120

local TS = { saved = nil, applied = nil, yielded = false, last_t = nil, hook = false }

local function ts_get()
    local v = nil
    pcall(function()
        local single = sdk.get_native_singleton("via.Application")
        local td = sdk.find_type_definition("via.Application")
        v = tonumber(sdk.call_native_func(single, td, "get_GlobalSpeed"))
    end)
    if v == nil or v ~= v or v <= 0 then return nil end
    return v
end

local function ts_set(v)
    local ok = pcall(function()
        local single = sdk.get_native_singleton("via.Application")
        local td = sdk.find_type_definition("via.Application")
        sdk.call_native_func(single, td, "set_GlobalSpeed", v)
    end)
    return ok
end

local function ts_apply()
    if TS.saved == nil then return end
    local cur = ts_get()
    if TS.applied ~= nil and cur ~= nil and math.abs(cur - TS.applied) > 0.002 then
        if not (math.abs(cur - 1.0) < 0.002 or math.abs(cur - TS.saved) < 0.002) then
            -- another mod imposes its own speed: leave it alone for this opening
            TS.saved, TS.applied, TS.yielded = nil, nil, true
            Slow.cur = 1.0
            return
        end
    end
    if (Slow.releasing or not IN.slowmo_enabled) and Slow.cur >= 0.999 then
        ts_set(TS.saved)
        TS.saved, TS.applied = nil, nil
        return
    end
    local v = TS.saved * Slow.cur
    if ts_set(v) then TS.applied = v end
end

pcall(function()
    if re.on_application_entry then
        re.on_application_entry("LateUpdateBehavior", function() pcall(ts_apply) end)
        TS.hook = true
    end
end)

function IN.stop_slowmo_now()
    if TS.saved ~= nil then ts_set(TS.saved) end
    TS.saved, TS.applied, TS.yielded, TS.last_t = nil, nil, false, nil
    Slow.active, Slow.releasing, Slow.cur, Slow.rates = false, false, 1.0, nil
end

function IN.update_slowmo()
    if not Slow.active then return end
    local w_now = U.wall_time()
    if W.open and (w_now - W.last_update_wall > 0.25) then
        W.open = false
        Slow.releasing = true
    end
    local dt = TS.last_t and math.max(0, math.min(0.1, w_now - TS.last_t)) or 0.016
    TS.last_t = w_now

    local factor = math.max(0.05, math.min(1.0, tonumber(IN.slowmo_factor) or 0.1))
    local want = (not Slow.releasing) and IN.slowmo_enabled ~= false and not TS.yielded
    local target = want and factor or 1.0
    local tr = math.max(0, (tonumber(IN.slowmo_ms) or 120) / 1000)
    if tr < 0.01 then
        Slow.cur = target
    elseif Slow.cur < target then
        Slow.cur = math.min(target, Slow.cur + (3 / tr) * dt)
    else
        Slow.cur = math.max(target, Slow.cur - (3 / tr) * dt)
    end
    if math.abs(Slow.cur - target) < 0.005 then Slow.cur = target end

    if want and TS.saved == nil and factor < 0.999 then
        local cur = ts_get()
        if cur == nil then
            Slow.cur = 1.0
            return
        end
        if math.abs(cur - 1.0) > 0.002 then
            -- the game or another mod already slows time: do not stack on it
            TS.yielded = true
            Slow.cur = 1.0
            return
        end
        TS.saved, TS.applied = (cur >= 0.9) and cur or 1.0, nil
    end
    if not TS.hook then pcall(ts_apply) end

    if (Slow.releasing or not want) and Slow.cur >= 0.999 and TS.saved == nil then
        if Slow.releasing then
            Slow.active, Slow.releasing, Slow.cur, TS.yielded, TS.last_t = false, false, 1.0, false, nil
        end
    end
end

pcall(function()
    local td = sdk.find_type_definition("app.RotateCameraControllerBase")
    local m = td and td:get_method("getInputRotationSpeedRate")
    if m then
        -- the camera stays still while the wheel is open, unless the light camera tilt is on (it then moves with the
        -- Right Stick, slowed down with the game, times the speed factor)
        sdk.hook(m, function()
            local active_wheel = W.open and (U.wall_time() - W.last_update_wall <= 0.25)
            -- mouse mode: the camera never moves (the mouse drives the cursor)
            local skip = active_wheel and (not IN.cam_tilt or W.mode == "mouse")
            pcall(function()
                local st = thread.get_hook_storage()
                st.pc_cam_skip = skip
                local k = (active_wheel and IN.cam_tilt) and (IN.cam_speed or 1.0) or nil
                -- the camera keeps its normal speed while time is slowed (it turned too slowly to be of use)
                if k and IN.cam_realtime ~= false and TS.applied ~= nil and Slow.cur < 0.999 then
                    k = k / math.max(0.05, Slow.cur)
                end
                st.pc_cam_scale = k
            end)
            if skip then return sdk.PreHookResult.SKIP_ORIGINAL end
        end, function(retval)
            local ok, st = pcall(thread.get_hook_storage)
            if not ok or not st then return retval end
            if st.pc_cam_skip then return sdk.float_to_ptr(0.0) end
            local k = st.pc_cam_scale
            if k and math.abs(k - 1.0) > 0.001 then
                local okf, v = pcall(sdk.to_float, retval)
                if okf and type(v) == "number" then return sdk.float_to_ptr(v * k) end
            end
            return retval
        end)
    end
end)
