-- TacticalCommandSystem/cmd/posture.lua
-- What a character's body is doing right now, read once into a single record.
--
-- A character runs a small stack of named actions (the top one is what you see). The engine needs several things from
-- that stack -- is the pawn hurt, climbing, dying, running a skill, free to take an order -- and reading it once and
-- answering all of them from one record costs a single walk per pawn per frame instead of one walk per question.
--
-- A record is a plain table, valid for the frame it was read in; the engine reads it at the top of a step and passes it
-- down. Nothing here keeps state between frames.

local D = require("TacticalCommandSystem.data")
local S = require("TacticalCommandSystem.cmd.sdkmap")

local P = {}

local STACK_DEPTH = 8                                   -- deeper than this never carries anything the engine needs
local CHARGE_WORDS = { "Prepare", "Ready", "Cast", "Start", "End", "Loop" }

----------------------------------------------------------------------------------------------------
-- name tests (also used on the bare action names that arrive through the hooks)
----------------------------------------------------------------------------------------------------
-- a job skill action, as opposed to the job's walking / guarding / reacting actions
function P.is_skill_name(name)
    if not name:find("^Job%d+_") and not name:find("^JobMagicUser_") then return false end
    for _, word in ipairs(D.NOT_SKILL) do
        if name:find(word, 1, true) then return false end
    end
    return true
end

-- the pawn is reacting to a hit (name already lowercased)
function P.hurt_name(low)
    for part in low:gmatch("[^|]+") do
        for _, word in ipairs(D.HIT_WORDS) do
            if part:find(word, 1, true) then return "layer " .. part end
        end
        if part:find("stun", 1, true) then return "layer " .. part end
    end
    return nil
end

-- the pawn cannot be ordered at all while one of these runs
local function is_blocking(name)
    return name:find("^ClimbRope") ~= nil or name:find("^Die") ~= nil
end

-- off the ground: climbing an enemy, or falling
local function is_aerial(name)
    return (name:find("Climb", 1, true) and not name:find("^ClimbRope")) ~= nil or name:find("^Fall") ~= nil
end

-- nothing is happening: no action read, or one of the resting ones
function P.is_resting_name(name)
    return name == "?" or name:find("Locomotion") ~= nil or name:find("Idle") ~= nil or name:find("Default") ~= nil
end

-- does this name mention one of the skill's keywords (name already lowercased)
function P.mentions(low, words)
    for _, word in ipairs(words or {}) do
        if low:find(word, 1, true) then return true end
    end
    return false
end

-- the part of an action name that identifies the skill, whatever stage of it is running
function P.stem(name)
    local stem = name:gsub("^Job%w*_", "")
    for _, word in ipairs(CHARGE_WORDS) do
        if stem:sub(1, #word) == word and #stem > #word then
            stem = stem:sub(#word + 1)
            break
        end
    end
    return stem:lower()
end

----------------------------------------------------------------------------------------------------
-- reading the stack
----------------------------------------------------------------------------------------------------
local EMPTY = {
    names = {}, raw = "", low = "", set = {}, top = "?",
    blocked = nil, aerial = nil, hurt = nil, skill = nil, busy = nil, empty = true,
}

-- one walk, one record
function P.read(chara)
    local names = {}
    pcall(function()
        local stack = chara[S.F.actions].CurrentActionList
        local depth = math.min(stack:call("get_Count"), STACK_DEPTH)
        for i = 0, depth - 1 do
            local ok, name = pcall(function() return stack[i].Name end)
            if not ok then break end
            names[#names + 1] = name and tostring(name) or "nil"
        end
    end)

    if #names == 0 then return EMPTY end

    local rec = { names = names, set = {}, top = names[1] or "?" }
    local busy, hurt, skill, blocked, aerial = nil, nil, nil, nil, nil

    for _, name in ipairs(names) do
        rec.set[name] = true
        local low = name:lower()
        if not blocked and is_blocking(name) then blocked = name end
        if not aerial and is_aerial(name) then aerial = name end
        if not hurt then
            for _, word in ipairs(D.HIT_WORDS) do
                if low:find(word, 1, true) then hurt = "layer " .. low; break end
            end
            if not hurt and low:find("stun", 1, true) then hurt = "layer " .. low end
        end
        if not skill and P.is_skill_name(name) then skill = name end
        if not busy and not D.IDLE_LAYERS[name] and not name:find("Idle", 1, true) then busy = "layer " .. name end
    end

    rec.raw = table.concat(names, "|")
    rec.low = rec.raw:lower()
    rec.blocked, rec.aerial, rec.hurt, rec.skill, rec.busy = blocked, aerial, hurt, skill, busy
    return rec
end

----------------------------------------------------------------------------------------------------
-- questions answered from a record
----------------------------------------------------------------------------------------------------
-- hit reaction, by action name or by the character's own damage flag
function P.shaken(rec, chara)
    if rec.hurt then return rec.hurt end
    local ok, hurt = pcall(function() return chara:get_IsDamage() end)
    if ok and hurt == true then return "IsDamage" end
    return nil
end

-- why the pawn is not free: the blocking action, death, a hit, or whatever else it is busy with
function P.obstacle(rec, chara, is_dead)
    if rec.blocked then return rec.blocked end
    if is_dead then return "dead" end
    local hit = P.shaken(rec, chara)
    if hit then return hit end
    return rec.busy
end

-- top of the stack is a resting action
function P.at_rest(rec)
    return P.is_resting_name(rec.top)
end

-- a skill action that was not in `before` and whose stem is new too: the pawn has started something fresh.
-- Returns the action name and its stem, or nil.
function P.fresh_skill(rec, before)
    local known = {}
    for name in pairs(before) do
        if P.is_skill_name(name) then known[P.stem(name)] = true end
    end
    for _, name in ipairs(rec.names) do
        if not before[name] and P.is_skill_name(name) and not name:find("End$") then
            local stem = P.stem(name)
            if not known[stem] and not known[(stem:gsub("end$", ""))] then
                return name, stem
            end
        end
    end
    return nil
end

return P
