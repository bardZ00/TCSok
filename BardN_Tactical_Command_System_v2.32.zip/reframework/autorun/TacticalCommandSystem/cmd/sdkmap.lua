-- TacticalCommandSystem/cmd/sdkmap.lua
-- Every raw reflection lookup of the command engine lives here, and nowhere else.
--
-- The names below (types, methods, backing fields, enum members) are the game's own: they are what Dragon's Dogma 2
-- calls these things, so they are the one part of the engine that cannot be written any other way. Keeping them in a
-- single map means the rest of the engine reads as plain Lua -- `S.F.decider` instead of a backing-field string -- and
-- a game patch that renames something is fixed in one file.
--
-- Nothing here touches the mod's own state; it is a lookup table with a lazy cache.

local S = {}

----------------------------------------------------------------------------------------------------
-- type definitions (memoised; a missing type yields nil instead of raising)
----------------------------------------------------------------------------------------------------
local types = {}

function S.type(full_name)
    local hit = types[full_name]
    if hit == nil then
        local ok, td = pcall(sdk.find_type_definition, full_name)
        hit = (ok and td) or false
        types[full_name] = hit
    end
    return hit or nil
end

local function method(full_name, signature)
    local td = S.type(full_name)
    if not td then return nil end
    local ok, m = pcall(td.get_method, td, signature)
    return (ok and m) or nil
end

----------------------------------------------------------------------------------------------------
-- the game's field names, by the meaning the engine gives them
----------------------------------------------------------------------------------------------------
S.F = {
    -- on app.Character
    decider      = "<AIDecisionMaker>k__BackingField",
    actions      = "<ActionManager>k__BackingField",
    human        = "<Human>k__BackingField",
    -- on app.AIDecisionMaker / its module
    module       = "<DecisionModule>k__BackingField",
    pack_handler = "<DecisionPackHandler>k__BackingField",
    active_packs = "<ActiveDecisionPacks>k__BackingField",
    main_count   = "_MainDecisionNum",
    pack_list    = "_Decisions",
    pack_ref     = "_ActInterPack",
    decision_id  = "_UniqueId",
    decision_uid = "<UniqueID>k__BackingField",
    executor     = "<DecisionExecutor>k__BackingField",
    executing    = "<ExecutingDecision>k__BackingField",
    blackboard   = "<Blackboard>k__BackingField",
    owner_go     = "<Owner>k__BackingField",
    chara        = "<Chara>k__BackingField",
    inner_maker  = "<AIDecisionMaker>k__BackingField",
    act_iface    = "<ActionInterface>k__BackingField",
    personality  = "<Personality>k__BackingField",
    -- on app.AIDecision
    off_flag     = "<DisableFlag>k__BackingField",
    cooldown     = "<CooldownTimer>k__BackingField",
    preconds     = "_Preconditions",
    precond_proc = "_Process",
    -- on app.AITarget and friends
    at_go        = "<GameObject>k__BackingField",
    at_chara     = "<Character>k__BackingField",
    at_owner     = "<Owner>k__BackingField",
    at_owner_ch  = "<OwnerCharacter>k__BackingField",
    at_context   = "<ContextHolder>k__BackingField",
    at_transform = "<Transform>k__BackingField",
    at_valid     = "<Valid>k__BackingField",
    at_target    = "<Target>k__BackingField",
    at_human     = "<TargetHuman>k__BackingField",
    at_own_human = "<OwnerHuman>k__BackingField",
    -- on the app.Pawn object (not the Character)
    skill_ctrl   = "<SkillActionController>k__BackingField",
    skill_count  = "_SkillCount",
    skill_max    = "_MaxSkillCount",
    party_pawns  = "_PartyPawnList",
    main_pawn    = "_MainPawn",
    no_target    = "_DisableTargetList",
    order_active = "<ActiveOrder>k__BackingField",
    order_next   = "_NextOrder",
    order_time   = "<ActiveOrderTime>k__BackingField",
    -- generic List<T> internals
    items        = "_items",
    size         = "_size",
}

----------------------------------------------------------------------------------------------------
-- type names the engine passes around as strings
----------------------------------------------------------------------------------------------------
S.T = {
    pack_data   = "app.ActInterPackData",
    ai_target   = "app.AITargetGameObject",
    attack_range = "app.decision.process.SetAttackRange",
    stock_cond  = "app.decision.condition.IsStockSpell",
    decision    = "app.AIDecision",
    character   = "app.Character",
}

----------------------------------------------------------------------------------------------------
-- methods the engine calls or hooks
----------------------------------------------------------------------------------------------------
S.M = {
    -- pushes a pack onto a pawn's blackboard so it executes now
    push_values = method("app.AIBlackBoardExtensions",
        "setBBValuesToExecuteActInter(app.AIBlackBoardController, app.ActInterPackData, app.AITarget)"),
    request_pack = method("app.AIBlackBoardController",
        "set_ReqMainActInterPackData(app.ActInterPackData)"),
    -- how long a spell takes to prepare (hooked to learn the real charge time)
    prepare_secs = method("app.JobPrepareSpell", "getPrepareSec()"),
    -- every action request a character makes (hooked to fence an order in)
    request_action = method("app.ActionManager", "requestActionCore"),
    -- "can this pawn use this skill?" (hooked for the manual-only locks and launch stances)
    skill_allowed = method("app.HumanSkillAvailability",
        "isCustomSkillAvailableWithoutItemCondition(app.HumanCustomSkillID)"),
}

-- the two target filters of app.AIDecision, hooked together
S.M.target_filters = {}
do
    local td = S.type("app.AIDecision")
    if td then
        for _, sig in ipairs({
            "checkTargetPreconditions(app.AIBlackBoardController, app.AITarget)",
            "checkTargetConditions(app.AIBlackBoardController, app.AITarget)",
        }) do
            local ok, m = pcall(td.get_method, td, sig)
            if ok and m then S.M.target_filters[#S.M.target_filters + 1] = m end
        end
    end
end

----------------------------------------------------------------------------------------------------
-- the pawn order enum (the game's values, with the known fallbacks when the lookup comes back empty)
----------------------------------------------------------------------------------------------------
local ORDER_FALLBACK = { NONE = 0, COME = 1, GO = 2, WAIT = 3 }

function S.build_order_enum(read_enum)
    local out = {}
    for key, member in pairs({ NONE = "None", COME = "Come", GO = "Go", WAIT = "Wait" }) do
        local v = read_enum("app.PawnOrderController.PawnOrder", member)
        if (not v or v == 0) and ORDER_FALLBACK[key] ~= 0 then v = ORDER_FALLBACK[key] end
        out[key] = v or ORDER_FALLBACK[key]
    end
    return out
end

----------------------------------------------------------------------------------------------------
-- small readers used all over the engine
----------------------------------------------------------------------------------------------------
-- walks a List<T>'s backing array: returns the array and its count
function S.list_body(list)
    if not list then return nil, 0 end
    local ok, items = pcall(list.get_field, list, S.F.items)
    if not ok or not items then return nil, 0 end
    local ok2, n = pcall(list.get_field, list, S.F.size)
    return items, (ok2 and tonumber(n)) or 0
end

-- walks a managed array (GetValue by index): calls visit(element, index)
function S.each_array(arr, visit)
    if not arr then return end
    local ok, n = pcall(arr.call, arr, "get_Length")
    if not ok or not n then return end
    for i = 0, n - 1 do
        local okv, el = pcall(arr.call, arr, "GetValue(System.Int32)", i)
        if okv and el then visit(el, i) end
    end
end

-- the decision module of a character, or nil
function S.decision_module(chara)
    local ok, maker = pcall(function() return chara[S.F.decider] end)
    if not ok or not maker then return nil end
    local ok2, mod = pcall(maker.get_field, maker, S.F.module)
    if not ok2 then return nil, maker end
    return mod, maker
end

return S
