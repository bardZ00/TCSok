-- TacticalCommandSystem/cmd/queue.lua
-- What a pawn is to do after the skill it is doing now.
--
-- Up to three skills, in the order they were given, each remembering the enemy it was aimed at. A queued skill waits
-- its turn, and with the ATB module installed it waits for the gauge to afford it too, so a queue is never stuck behind
-- something the pawn cannot pay for.

local D = require("TacticalCommandSystem.data")
local API = require("TacticalCommandSystem.api")

local Q = {}

function Q.length(rec)
    return (rec and rec.line) and #rec.line or 0
end

function Q.full(rec)
    return Q.length(rec) >= D.MAX_QUEUE
end

function Q.add(rec, skill_id, pick)
    rec.line[#rec.line + 1] = { skill = skill_id, pick = pick }
    return #rec.line
end

function Q.list(rec)
    return (rec and rec.line) or {}
end

-- 1-based place of a skill in the queue, or nil
function Q.place(rec, skill_id)
    if not rec or not rec.line then return nil end
    for i, item in ipairs(rec.line) do
        if item.skill == skill_id then return i end
    end
    return nil
end

-- Takes a skill out: the named one, or the last one queued. Returns "removed", its id and what is left.
function Q.drop(rec, skill_id)
    if not rec or not rec.line or #rec.line == 0 then return "empty" end
    local at = #rec.line
    if skill_id and skill_id > 0 then
        for i = #rec.line, 1, -1 do
            if rec.line[i].skill == skill_id then at = i; break end
        end
    end
    local gone = table.remove(rec.line, at)
    return "removed", gone.skill, #rec.line
end

-- The head of the queue, if the gauge can pay for it. nil while it cannot, so the queue holds rather than skipping.
function Q.ready_head(rec)
    local head = rec.line and rec.line[1]
    if not head then return nil end
    if not API.atb_affordable(rec.addr, head.skill) then return nil end
    return head
end

function Q.take(rec)
    return table.remove(rec.line, 1)
end

function Q.clear(rec)
    rec.line = {}
end

return Q
