-- TacticalCommandSystem/cmd/roster.lua
-- One record per pawn the engine is looking after, and the index the hooks look pawns up in.
--
-- A record is created the first time a pawn is given anything, and dropped again once it has nothing left: no order on
-- the way, nothing queued, no stance. So the roster is normally empty or nearly so, and an idle party costs nothing.
--
-- The hooks are the reason for the index. They fire on every action request in the game, several hundred times a second
-- across every character on screen, and each one has to answer "is this one of mine?" -- so instead of walking the
-- roster each time, the addresses a hook can see (action manager, blackboard, Human) are kept as keys straight to the
-- order they belong to. A hook that finds nothing in the index does one table lookup and gets out of the way.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local Brain = require("TacticalCommandSystem.cmd.brain")
local Obj = require("TacticalCommandSystem.cmd.pawnobj")

local Roster = {}

local book = {}                   -- pawn address -> record
local by_actions = {}             -- action-manager address -> the order on the way
local by_board = {}               -- blackboard address  -> the order on the way
local by_human = {}               -- Human address       -> the order on the way
local by_skill = {}               -- skill id            -> the order on the way
local waiters = {}                -- action-manager address -> a record holding still, with no order running
local running = 0                 -- how many orders are on the way

-- filled in by cmd/stance.lua, which cannot be required from here without the two chasing each other
Roster.on_stop = {}

----------------------------------------------------------------------------------------------------
-- records
----------------------------------------------------------------------------------------------------
local function fresh(addr, chara, pawn_obj)
    return {
        addr = addr,
        chara = chara,
        pawn_obj = pawn_obj,
        actions_addr = 0,
        run = nil,                -- the order on the way
        soon = nil,               -- an order waiting for the pawn to be free enough to take it
        line = {},                -- what to do after this one
        stance = "free",
        stance_token = nil,       -- what the ranged stance has muted, to give back
        stance_at = 0,
        leash_at = 0,
    }
end

function Roster.get(addr)
    return book[addr]
end

function Roster.all()
    return book
end

function Roster.ensure(addr, chara, pawn_obj)
    local rec = book[addr]
    if not rec then
        rec = fresh(addr, chara, pawn_obj)
        book[addr] = rec
    end
    if U.is_valid_obj(chara) then
        rec.chara = chara
        local actions = U.safe_call(function() return chara[S.F.actions] end)
        if U.is_valid_obj(actions) then
            local a = actions:get_address()
            if a ~= rec.actions_addr then
                if rec.actions_addr ~= 0 and waiters[rec.actions_addr] == rec then waiters[rec.actions_addr] = nil end
                rec.actions_addr = a
                Roster.reindex_wait(rec)
            end
        end
    end
    if U.is_valid_obj(pawn_obj) then rec.pawn_obj = pawn_obj end
    return rec
end

-- a record with nothing left to look after is dropped
function Roster.tidy(rec)
    if not rec then return end
    if rec.run or rec.soon then return end
    if rec.line and #rec.line > 0 then return end
    if rec.stance and rec.stance ~= "free" then return end
    book[rec.addr] = nil
    if rec.actions_addr ~= 0 and waiters[rec.actions_addr] == rec then waiters[rec.actions_addr] = nil end
end

----------------------------------------------------------------------------------------------------
-- the index
----------------------------------------------------------------------------------------------------
function Roster.reindex_wait(rec)
    local key = rec.actions_addr
    if key == 0 then return end
    if rec.stance == "wait" and not rec.run then
        waiters[key] = rec
    elseif waiters[key] == rec then
        waiters[key] = nil
    end
end

local function index_run(run)
    if run.actions_addr and run.actions_addr ~= 0 then by_actions[run.actions_addr] = run end
    if run.board_addr and run.board_addr ~= 0 then by_board[run.board_addr] = run end
    if run.human_addr and run.human_addr ~= 0 then by_human[run.human_addr] = run end
    if run.skill then by_skill[run.skill] = run end
end

local function unindex_run(run)
    if run.actions_addr and by_actions[run.actions_addr] == run then by_actions[run.actions_addr] = nil end
    if run.board_addr and by_board[run.board_addr] == run then by_board[run.board_addr] = nil end
    if run.human_addr and by_human[run.human_addr] == run then by_human[run.human_addr] = nil end
    if run.skill and by_skill[run.skill] == run then by_skill[run.skill] = nil end
end

-- what the hooks ask
function Roster.anyone_engaged()
    if running > 0 then return true end
    return next(waiters) ~= nil
end

function Roster.run_by_actions(addr) return addr ~= 0 and by_actions[addr] or nil end
function Roster.run_by_board(addr)   return addr ~= 0 and by_board[addr] or nil end
function Roster.run_by_human(addr)   return addr ~= 0 and by_human[addr] or nil end
function Roster.run_by_skill(id)     return id and by_skill[id] or nil end
function Roster.waiter_by_actions(addr) return addr ~= 0 and waiters[addr] or nil end

----------------------------------------------------------------------------------------------------
-- starting and stopping an order
----------------------------------------------------------------------------------------------------
function Roster.begin(rec, run)
    rec.run = run
    index_run(run)
    running = running + 1
    Roster.reindex_wait(rec)
end

-- Hands everything the order borrowed back to the game: the pawn's thinking, the muted decisions, the skill ration,
-- the ignore list. Safe to call when nothing is running.
function Roster.stop(rec)
    local run = rec and rec.run
    if not run then return end

    local held_still = (rec.stance == "wait")                 -- a pawn told to hold still keeps its AI switched off
    if not run.thinking and not held_still and U.is_valid_obj(run.chara) then
        Brain.of(run.chara):set_thinking(true)
    end

    Obj.give_ration(run, true)
    Obj.blinker_off(run.blinker)
    run.blinker = nil
    Brain.release(run.token)
    run.token = nil

    unindex_run(run)
    rec.run = nil
    running = math.max(0, running - 1)
    Roster.reindex_wait(rec)

    for _, after in ipairs(Roster.on_stop) do
        pcall(after, rec, run)
    end

    -- a launch stance leaves the pawn standing in its pose: put it back on its feet
    local ord = D.ORDERS[run.skill]
    if ord and ord.stance and U.is_valid_obj(run.chara) then
        pcall(function()
            run.chara[S.F.actions]:requestActionCore(0, "NormalLocomotion", 0)
        end)
    end
end

----------------------------------------------------------------------------------------------------
-- wiping everything (vocation change, new save, mod switched off)
----------------------------------------------------------------------------------------------------
function Roster.clear(release_stance)
    for _, rec in pairs(book) do
        Roster.stop(rec)
        if release_stance then release_stance(rec) end
    end
    for k in pairs(book) do book[k] = nil end
    for k in pairs(by_actions) do by_actions[k] = nil end
    for k in pairs(by_board) do by_board[k] = nil end
    for k in pairs(by_human) do by_human[k] = nil end
    for k in pairs(by_skill) do by_skill[k] = nil end
    for k in pairs(waiters) do waiters[k] = nil end
    running = 0
    Brain.forget_all()
end

return Roster
