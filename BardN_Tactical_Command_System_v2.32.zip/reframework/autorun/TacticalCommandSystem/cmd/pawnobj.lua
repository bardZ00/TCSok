-- TacticalCommandSystem/cmd/pawnobj.lua
-- The game's Pawn object, which is not the same thing as the pawn's Character.
--
-- A pawn has two sides: the Character (body, actions, AI) and the Pawn object the party system keeps (its standing
-- order, its ration of skill uses, the enemies it has been told to leave alone). Everything the engine needs from that
-- second side is here: finding it from a Character, and the three things it changes on it.

local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")

local O = {}

O.ORDER = S.build_order_enum(U.enum_val)

----------------------------------------------------------------------------------------------------
-- finding it
----------------------------------------------------------------------------------------------------
function O.find(chara)
    if not U.is_valid_obj(chara) then return nil end
    local party = sdk.get_managed_singleton("app.PawnManager")
    if not party then return nil end
    local wanted = chara:get_address()

    local function wraps(p)
        local ok, c = pcall(function() return p:call("get_CachedCharacter") end)
        return ok and c and c:get_address() == wanted
    end

    local items, count = S.list_body(party:get_field(S.F.party_pawns))
    for i = 0, count - 1 do
        if items[i] and wraps(items[i]) then return items[i] end
    end
    local main = party:get_field(S.F.main_pawn)
    if main and wraps(main) then return main end
    return nil
end

-- the Pawn object we already have, or one looked up from the Character
local function resolve(pawn_obj, chara)
    if U.is_valid_obj(pawn_obj) then return pawn_obj end
    return O.find(chara)
end

----------------------------------------------------------------------------------------------------
-- the standing order the party screen would show (Come / Go / Wait / none)
----------------------------------------------------------------------------------------------------
function O.set_order(pawn_obj, chara, order_value)
    local p = resolve(pawn_obj, chara)
    if not U.is_valid_obj(p) then return false end
    local ok = pcall(function()
        p:set_field(S.F.order_active, order_value)
        p:set_field(S.F.order_next, order_value)
        p:set_field(S.F.order_time, 0.0)
    end)
    return ok
end

----------------------------------------------------------------------------------------------------
-- the pawn's ration of skill uses
--
-- A pawn may only use so many skills before its ration refills. An order should not spend from that ration: the player
-- asked for this skill, the pawn did not choose it. So the count is read before the order, zeroed while the pawn's own
-- AI is doing the aiming (or it would spend a use picking the decision up), and put back once the skill is on its way.
----------------------------------------------------------------------------------------------------
local function ration(chara)
    local p = O.find(chara)
    local ctrl = p and p:get_field(S.F.skill_ctrl)
    if not ctrl then return nil end
    return ctrl, tonumber(ctrl:get_field(S.F.skill_count)), tonumber(ctrl:get_field(S.F.skill_max))
end

-- Reads the ration into `hold.ration`, and spends it down to zero when `freeze` is set.
function O.hold_ration(hold, freeze)
    local ok, ctrl, used, cap = pcall(ration, hold.chara or hold.pawn)
    if not ok or not used then return end
    hold.ration = { used = used, cap = cap }
    if freeze and used > 0 then
        pcall(function() ctrl:set_field(S.F.skill_count, 0) end)
    end
end

-- Puts the ration back. `done` forgets it, so a later call cannot put a stale count back.
function O.give_ration(hold, done)
    local kept = hold and hold.ration
    if not kept then return end
    if done then hold.ration = nil end
    local ok, ctrl, used, cap = pcall(ration, hold.chara or hold.pawn)
    if not ok or not used then return end
    if cap ~= kept.cap then
        hold.ration = nil                      -- the pawn levelled or changed vocation: the old count means nothing
        return
    end
    if used ~= kept.used then
        pcall(function() ctrl:set_field(S.F.skill_count, kept.used) end)
    end
end

----------------------------------------------------------------------------------------------------
-- the "leave these alone" list
--
-- The pawn aims at whatever its AI likes. To make it aim where the player pointed, every other living enemy goes on the
-- pawn's own ignore list for as long as the order takes, then comes straight back off it.
----------------------------------------------------------------------------------------------------
function O.blinker_on(chara, keep)
    if not U.is_valid_obj(chara) or not U.is_valid_obj(keep) then return nil end
    local held = nil
    pcall(function()
        local p = O.find(chara)
        local list = p and p:get_field(S.F.no_target)
        if not list then return end
        held = { list = list, added = {} }
        local spared = keep:get_address()
        for _, enemy in ipairs(U.alive_enemies()) do
            if enemy:get_address() ~= spared then
                local go = U.safe_call(function() return enemy:get_GameObject() end)
                if U.is_valid_obj(go) and not list:call("Contains", go) then
                    list:call("Add", go)
                    held.added[#held.added + 1] = go
                end
            end
        end
    end)
    return held
end

function O.blinker_off(held)
    if not held or not U.is_valid_obj(held.list) then return end
    pcall(function()
        for _, go in ipairs(held.added) do
            if U.is_valid_obj(go) then held.list:call("Remove", go) end
        end
    end)
end

return O
