-- TacticalCommandSystem/cmd/brain.lua
-- A pawn's AI decision table, as something the engine can hold and give back.
--
-- The pawn's AI picks what to do from a list of decisions, each with a disable flag. That flag is the whole lever the
-- engine has: to make a pawn use one skill now, mute every decision but that skill's and let its own AI do the aiming
-- and the approach; to lock a skill away, keep its decisions muted.
--
-- Muting is borrowed, never given: every change hands back a token, and the token puts the original flags back. That
-- way an order, a stance and a lock can each hold their own token on the same pawn without losing track of what the
-- game had set.
--
--   local brain = Brain.of(pawn)
--   local token = brain:focus(rule)      -- this skill through, the rest muted
--   brain:refocus(token)                 -- the pawn's list changed under us; apply again
--   brain:release(token)                 -- back to how the game had it

local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local Match = require("TacticalCommandSystem.cmd.matcher")

local B = {}

local OFF_BIT = 1                 -- bit 0 of the disable flag: the pawn skips this decision
local LIST_TTL = 3.0              -- seconds a read list is trusted while the pawn's decision count holds still
local RUNTIME_LISTS = { "Main", "Pre", "Post" }

-- pawn address -> { at, count, runtime = {...}, packs = {...} }
local shelf = {}
-- decision-definition address -> true/false : does this decision need a stocked spell
local stock_marks = {}

local Brain = {}
Brain.__index = Brain

----------------------------------------------------------------------------------------------------
-- reading the table
----------------------------------------------------------------------------------------------------
-- Walks the packs the pawn has active. Returns:
--   by_id : decision id (string) -> { stem, data }   -- to match the runtime lists against
--   packs : { { stem, pack } }                       -- the pack objects themselves
local function read_packs(module)
    local by_id, packs = {}, {}
    local handler = module:get_field(S.F.pack_handler)
    local active = handler and handler:get_field(S.F.active_packs)
    local items, count = S.list_body(active)
    for i = 0, count - 1 do
        local pack = items and items[i]
        local defs = pack and pack:get_field(S.F.pack_list)
        S.each_array(defs, function(def)
            pcall(function()
                local ref = def:get_field(S.F.pack_ref)
                local path = ref and ref:call("get_Path")
                local stem = path and path:match("([^/\\]+)%.user[^/\\]*$")
                if not stem then return end
                stem = stem:lower()
                packs[#packs + 1] = { stem = stem, pack = ref }
                local id = def:get_field(S.F.decision_id)
                id = id and id:call("ToString")
                if id then by_id[id] = { stem = stem, data = def } end
            end)
        end)
    end
    return by_id, packs
end

-- The decisions actually in play, in the order the AI weighs them.
local function read_runtime(module, by_id)
    local out = {}
    for _, which in ipairs(RUNTIME_LISTS) do
        local list = module:get_field("<" .. which .. "Decisions>k__BackingField")
        local items, count = S.list_body(list)
        for i = 0, count - 1 do
            local d = items and items[i]
            if d then
                local ok, id = pcall(function() return d:get_field(S.F.decision_uid):call("ToString") end)
                local known = ok and by_id[id]
                if known then
                    out[#out + 1] = { d = d, stem = known.stem, data = known.data, list = which }
                end
            end
        end
    end
    return out
end

function B.of(chara)
    return setmetatable({ chara = chara, addr = U.safe_call(function() return chara:get_address() end) }, Brain)
end

-- Both views of the table, read together and kept for a few frames.
-- `fresh` forces a read even when the shelved copy still looks good.
function Brain:_load(fresh)
    local module = S.decision_module(self.chara)
    if not module then return nil end
    local count = tonumber(module:get_field(S.F.main_count)) or 0
    local now = U.game_now()
    local kept = self.addr and shelf[self.addr]
    if not fresh and kept and kept.count == count and (now - kept.at) < LIST_TTL then
        return kept
    end

    local by_id, packs = read_packs(module)
    local entry = { at = now, count = count, runtime = read_runtime(module, by_id), packs = packs }
    if self.addr then shelf[self.addr] = entry end
    return entry
end

-- the decisions in play (what muting acts on)
function Brain:entries(fresh)
    local loaded = self:_load(fresh)
    return loaded and loaded.runtime or nil
end

-- the packs the pawn holds (what an order is fired with)
function Brain:packs(fresh)
    local loaded = self:_load(fresh)
    return loaded and loaded.packs or nil
end

-- the pack object this pawn already holds for the order, if any
function Brain:pack_for(ord)
    local packs = self:packs()
    return packs and Match.pack_of(packs, ord) or nil
end

function B.forget(addr)
    if addr then shelf[addr] = nil end
end

function B.forget_all()
    for k in pairs(shelf) do shelf[k] = nil end
end

----------------------------------------------------------------------------------------------------
-- stocked spells: their decisions look like the plain spell's but need a charge in hand
----------------------------------------------------------------------------------------------------
local function needs_stock(data)
    local addr = U.safe_call(function() return data:get_address() end)
    if not addr then return false end
    local mark = stock_marks[addr]
    if mark == nil then
        mark = false
        pcall(function()
            S.each_array(data:get_field(S.F.preconds), function(cond)
                if mark then return end
                local proc = cond:get_field(S.F.precond_proc)
                if proc and proc:get_type_definition():get_full_name() == S.T.stock_cond then mark = true end
            end)
        end)
        stock_marks[addr] = mark
    end
    return mark
end

-- the decision belongs to the order: by name, and not a stocked variant
local function belongs(entry, rule, loose)
    return Match.named_for(rule, entry.stem, loose) and not needs_stock(entry.data)
end

----------------------------------------------------------------------------------------------------
-- muting and giving back
----------------------------------------------------------------------------------------------------
local function remember(token, d)
    local addr = U.safe_call(function() return d:get_address() end)
    if not addr or token.seen[addr] then return addr end
    token.seen[addr] = true
    token.saved[#token.saved + 1] = { d = d, flags = d:get_field(S.F.off_flag) }
    return addr
end

local function set_muted(d, muted)
    local flags = d:get_field(S.F.off_flag)
    if muted then
        d:set_field(S.F.off_flag, flags | OFF_BIT)
    else
        d:set_field(S.F.off_flag, flags & ~OFF_BIT)
        pcall(function() d:set_field(S.F.cooldown, 0.0) end)
    end
end

-- Which of the pawn's decisions are this order's? Strict naming first; only if that finds nothing does the
-- keyword fallback get a turn, so a loose keyword never outvotes an exact name.
-- Returns the map addr -> stem, and whether the fallback was used.
function Brain:claim(entries, rule)
    local mine = {}
    for _, e in ipairs(entries) do
        if belongs(e, rule, false) then
            local addr = U.safe_call(function() return e.d:get_address() end)
            if addr then mine[addr] = e.stem end
        end
    end
    if next(mine) or not rule.keyword then return mine, false end

    for _, e in ipairs(entries) do
        if belongs(e, rule, true) then
            local addr = U.safe_call(function() return e.d:get_address() end)
            if addr then mine[addr] = e.stem end
        end
    end
    return mine, true
end

-- This order's decisions through, every other one muted. Returns a token, or nil when the pawn has none of them.
function Brain:focus(rule)
    local entries = self:entries()
    if not entries then return nil end
    local mine, loose = self:claim(entries, rule)
    if not next(mine) then return nil end

    local token = { saved = {}, seen = {}, mine = mine, rule = rule, loose = loose, at = 0 }
    local ok = pcall(function()
        for _, e in ipairs(entries) do
            local addr = remember(token, e.d)
            set_muted(e.d, not (addr and token.mine[addr]))
        end
    end)
    if not ok then
        self:release(token)
        return nil
    end
    return token
end

-- The pawn's list is rebuilt as it fights, which hands decisions back their own flags: apply the token again.
function Brain:refocus(token)
    if not token then return end
    local entries = self:entries()
    if not entries then return end
    pcall(function()
        for _, e in ipairs(entries) do
            local addr = remember(token, e.d)
            local mine = addr and token.mine[addr]
            if not mine and Match.named_for(token.rule, e.stem, token.loose) and not needs_stock(e.data) then
                mine = true
                if addr then token.mine[addr] = e.stem end
            end
            set_muted(e.d, not mine)
        end
    end)
end

-- Mute only what `pick(stem)` says, leaving the rest of the table alone. Adds to `token` when one is given.
--
-- Called again on a token it has already muted (the pawn's list is rebuilt as it fights, and an order that ends gives
-- the flags back), it mutes afresh but keeps the first flags it recorded: those are the game's, the ones in between are
-- whatever the engine itself last left behind.
function Brain:mute(pick, token)
    local entries = self:entries()
    if not entries then return token end
    token = token or { saved = {}, seen = {}, mine = {}, at = 0 }
    pcall(function()
        for _, e in ipairs(entries) do
            if pick(e.stem) then
                remember(token, e.d)
                set_muted(e.d, true)
            end
        end
    end)
    return token
end

-- Put back exactly the flags the game had.
function Brain:release(token)
    if not token or not token.saved then return end
    for _, kept in ipairs(token.saved) do
        pcall(function() kept.d:set_field(S.F.off_flag, kept.flags) end)
    end
    token.saved, token.seen = nil, nil
end

-- release() without a brain in hand (teardown paths that only kept the token)
function B.release(token)
    if not token or not token.saved then return end
    for _, kept in ipairs(token.saved) do
        pcall(function() kept.d:set_field(S.F.off_flag, kept.flags) end)
    end
    token.saved, token.seen = nil, nil
end

-- flip one decision's mute without a token (the locks keep their own book)
function B.set_muted(d, muted)
    if not U.is_valid_obj(d) then return false end
    local flags = d:get_field(S.F.off_flag)
    local already = (flags & OFF_BIT) ~= 0
    if muted == already then return false end
    d:set_field(S.F.off_flag, muted and (flags | OFF_BIT) or (flags & ~OFF_BIT))
    return true
end

----------------------------------------------------------------------------------------------------
-- what the pawn is running out of its table right now
----------------------------------------------------------------------------------------------------
local decision_field = nil        -- the field of the executing-decision record that holds the decision itself

-- Returns the raw record and a name: a stem from `stems` when it is one the caller knows, else "none" / "?" /
-- "decision@<addr>" for one it does not.
function Brain:running(stems)
    local module = S.decision_module(self.chara)
    local executor = module and module:get_field(S.F.executor)
    local record = executor and executor:get_field(S.F.executing)
    if not record then return nil, "none" end

    if decision_field == nil then
        decision_field = false
        for _, f in ipairs(record:get_type_definition():get_fields()) do
            if not f:is_static() and f:get_type():get_full_name() == S.T.decision then
                decision_field = f:get_name()
                break
            end
        end
    end
    if not decision_field then return record, "?" end

    local d = record:get_field(decision_field)
    if not d then return record, "none" end
    local addr = d:get_address()
    return record, (stems and stems[addr]) or ("decision@" .. string.format("%x", addr))
end

-- the pawn is running one of the order's own decisions
function Brain:running_ours(mine)
    local ok, _, name = pcall(Brain.running, self, mine)
    if not ok or type(name) ~= "string" then return false end
    return name ~= "none" and name ~= "?" and not name:find("^decision@")
end

-- let the pawn weigh its table from scratch
function Brain:restart_iteration()
    pcall(function()
        local module = S.decision_module(self.chara)
        if module then module:call("clearIteration") end
    end)
end

function Brain:set_thinking(on)
    local ok, maker = pcall(function() return self.chara[S.F.decider] end)
    if not ok or not U.is_valid_obj(maker) then return end
    pcall(function() maker:set_Enabled(on and true or false) end)
end

return B
