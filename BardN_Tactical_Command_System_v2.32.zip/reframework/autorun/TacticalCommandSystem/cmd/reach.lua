-- TacticalCommandSystem/cmd/reach.lua
-- How close a pawn walks before it uses the skill it was told to use.
--
-- Left alone, a pawn closes to its own idea of fighting distance, which for a mage or a sorcerer means walking up to a
-- drake to cast a spell that works from forty metres. The game decides that distance in one of its own AI steps, so the
-- engine builds that step itself, with the distance it wants, and runs it on the pawn before the order goes out.
--
-- Running a game AI step by hand means handing it the arguments it expects, whatever they happen to be: that is what
-- `furnish` does -- it reads the argument type's fields and fills each from what the pawn's decision module can supply.

local D = require("TacticalCommandSystem.data")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local Aim = require("TacticalCommandSystem.cmd.aim")
local Brain = require("TacticalCommandSystem.cmd.brain")

local R = {}

-- the AI steps that read a distance; whichever of them the built step has, gets run
local DISTANCE_STEPS = { "execute", "getMagicLockOnRange", "getPawnOverridAttackRange" }

local built = {}                  -- "job_skill" -> the step object, kept because building one is not cheap

----------------------------------------------------------------------------------------------------
-- the distance an order wants
----------------------------------------------------------------------------------------------------
-- Returns the distance to hold and the job key that owns it, or nil for an order that should just walk in.
function R.wanted(skill_id)
    local ord = D.ORDERS[skill_id]
    if not ord or ord.target ~= "enemy" or D.RANGE_CLOSE_SPELL[skill_id] then return nil end
    if ord.direct then return (ord.direct.range or D.ARCHER_RANGE), "job02" end

    local job = (ord.pack:find("job03_mage", 1, true) and "job03")
        or (ord.pack:find("job06_sorcerer", 1, true) and "job06")
    if not job then return nil end
    return D.RANGE_MAX[skill_id] or D.RANGE_FAR, job
end

-- the job key to run the step as, for a job that has no distance of its own in the table
function R.job_key(job_number)
    return (job_number == 2 and "job02") or (job_number == 3 and "job03") or "job06"
end

----------------------------------------------------------------------------------------------------
-- building the step
----------------------------------------------------------------------------------------------------
local function step_for(job, skill_id)
    skill_id = skill_id or D.SAR_SKILL[job][2]
    local key = job .. "_" .. skill_id
    if built[key] then return built[key] end

    local step = sdk.create_instance(S.T.attack_range, true)
    if not step then return nil end
    pcall(function() step = step:add_ref() or step end)

    step:set_field("_IsEnable", true)
    step:set_field("IsReset", false)
    step:set_field("_IsLockOnDist", true)
    step:set_field("_Job", D.SAR_SKILL[job][1])
    step:set_field("Category", 1)
    step:set_field("SkillActionID", skill_id)

    -- one skill of the set is indexed by action as well, and the field it lives in is not named the same in every build
    if skill_id == 35 then
        for _, field in ipairs({ "_ActionID", "ActionID" }) do
            local ok, value = pcall(function()
                step:set_field(field, 1)
                return step:get_field(field)
            end)
            if ok and tonumber(value) == 1 then break end
        end
    end

    built[key] = step
    return step
end

----------------------------------------------------------------------------------------------------
-- filling an argument the game's AI step expects
----------------------------------------------------------------------------------------------------
-- Builds a value of type `type_name` for `pawn`'s AI step. Returns nil when a field cannot be supplied, since a
-- half-filled argument is worse than not running the step at all.
function R.furnish(type_name, pawn, decision, target)
    local td = S.type(type_name)
    if not td then return nil end

    local module = S.decision_module(pawn)
    if not module then return nil end
    local self_chara = module:get_field(S.F.chara)
    local self_human = self_chara and self_chara:get_field(S.F.human)

    local by_field = {
        [S.F.at_valid]     = true,
        [S.F.owner_go]     = self_chara and Aim.node_for(self_chara, pawn),
        [S.F.human]        = self_human,
        [S.F.at_own_human] = self_human,
        [S.F.at_target]    = target and Aim.node_for(target, pawn),
        [S.F.at_human]     = target and target:get_field(S.F.human),
    }
    local may_be_missing = { [S.F.at_human] = true }

    local by_type = {
        [S.T.character]                 = self_chara,
        ["app.DecisionEvaluationModule"] = module,
        ["app.AIDecisionModule"]         = module,
        ["app.AIBlackBoardController"]   = module:get_field(S.F.blackboard),
        ["via.GameObject"]               = module:get_field(S.F.owner_go),
        ["app.AIDecisionMaker"]          = module:get_field(S.F.inner_maker),
        ["app.ActionInterface"]          = module:get_field(S.F.act_iface),
        ["app.Personality"]              = module:get_field(S.F.personality),
        [S.T.decision]                   = decision,
    }

    local arg = td:is_value_type() and ValueType.new(td) or sdk.create_instance(type_name, true)
    if not arg then return nil end

    local unfilled = 0
    local walk = td
    while walk do
        local full = walk:get_full_name()
        if full == "System.Object" or full == "System.ValueType" then break end
        for _, f in ipairs(walk:get_fields()) do
            if not f:is_static() then
                local name = f:get_name()
                local ftype = f:get_type()
                local value = by_field[name]
                if value == nil then value = by_type[ftype:get_full_name()] end
                if value ~= nil then
                    arg:set_field(name, value)
                elseif not may_be_missing[name] and not ftype:is_value_type() then
                    unfilled = unfilled + 1
                end
            end
        end
        walk = walk:get_parent_type()
    end

    return (unfilled == 0) and arg or nil
end

----------------------------------------------------------------------------------------------------
-- running it
----------------------------------------------------------------------------------------------------
-- Tells `pawn` to hold the distance its job wants against `target`. Silent when anything is missing: the order still
-- goes out, the pawn just picks its own distance.
function R.apply(pawn, target, job, skill_id)
    pcall(function()
        if not job then return end
        local entries = Brain.of(pawn):entries()
        local first = entries and entries[1]
        if not first then return end

        local step = step_for(job, skill_id)
        if not step then return end

        for _, m in ipairs(step:get_type_definition():get_methods()) do
            local name = m:get_name()
            local wanted = false
            for _, which in ipairs(DISTANCE_STEPS) do
                if name == which then wanted = true; break end
            end
            if wanted then
                local args, complete = {}, true
                for _, pt in ipairs(m:get_param_types()) do
                    local type_name = pt:get_full_name()
                    local arg = (type_name == S.T.character) and pawn
                        or R.furnish(type_name, pawn, first.d, target)
                    if not arg then complete = false end
                    args[#args + 1] = arg
                end
                if complete then pcall(m.call, m, step, table.unpack(args)) end
            end
        end
    end)
end

return R
