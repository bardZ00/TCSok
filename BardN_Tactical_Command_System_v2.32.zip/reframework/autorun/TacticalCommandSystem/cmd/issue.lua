-- TacticalCommandSystem/cmd/issue.lua
-- Putting an order out, by one of two routes.
--
-- **Through the pawn's own head.** Mute every decision but this skill's and leave the pawn thinking. It then does all
-- the work the engine would do badly: turning, closing in, picking the part of a big enemy worth hitting, waiting for
-- an opening. Used for anything aimed at an enemy within reach, and it is what makes an ordered skill look like a
-- skill the pawn chose.
--
-- **Straight onto the blackboard.** Hand the pawn the skill's pack and switch its thinking off for the duration. Blunt,
-- and it aims at whatever it is given, but it fires at once and works for skills its AI would never pick: buffs on the
-- party, launch stances, a mage's heal on a particular ally, a skill whose enemy is too far for the pawn to bother.
--
-- The route is chosen here, per order, and the caller never needs to know which one it got.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local P = require("TacticalCommandSystem.cmd.posture")
local Match = require("TacticalCommandSystem.cmd.matcher")
local Brain = require("TacticalCommandSystem.cmd.brain")
local Obj = require("TacticalCommandSystem.cmd.pawnobj")
local Aim = require("TacticalCommandSystem.cmd.aim")
local Reach = require("TacticalCommandSystem.cmd.reach")
local Roster = require("TacticalCommandSystem.cmd.roster")

local I = {}

-- True while the engine is the one asking. The hooks fence a running order in by refusing action requests that would
-- cut it short, and this is how they tell the engine's own requests from the game's.
I.ours = false

local packs_by_path = {}

local function pack_from_path(path)
    local held = packs_by_path[path]
    if held == nil then
        local ok, made = pcall(sdk.create_userdata, S.T.pack_data, path)
        held = (ok and made) or false
        packs_by_path[path] = held
    end
    return held or nil
end

local function address_of(obj)
    if not U.is_valid_obj(obj) then return 0 end
    return U.safe_call(function() return obj:get_address() end) or 0
end

local function human_address(chara)
    return U.safe_call(function() return chara:get_field(S.F.human):get_address() end) or 0
end

----------------------------------------------------------------------------------------------------
-- pushing a pack (the blunt route, also used by the stances for the game's own common packs)
----------------------------------------------------------------------------------------------------
-- Hands `pack` to the pawn's blackboard with `at` as its target. Returns false when the pawn has no blackboard.
function I.push(chara, pack, at)
    local board = U.safe_call(function() return chara:get_AIBlackBoardController() end)
    local node = Aim.node_for(at or chara, chara)
    if not (board and pack and node and S.M.push_values) then return false, nil end

    I.ours = true
    local ok = pcall(function()
        S.M.push_values:call(nil, board, pack, node)
        board:set_ReqMainActInterPackData(pack)
    end)
    I.ours = false
    return ok, board
end

-- one of the game's shared packs, by path (stand still, run to someone)
function I.push_common(chara, path, at)
    if not U.is_valid_obj(chara) or not S.M.push_values then return false end
    local ok = I.push(chara, pack_from_path(path), at)
    return ok
end

----------------------------------------------------------------------------------------------------
-- route one: through the pawn's own head
----------------------------------------------------------------------------------------------------
local function through_brain(rec, skill_id, now, enemy)
    local chara = rec.chara
    local ord = D.ORDERS[skill_id]
    local brain = Brain.of(chara)
    local rule = Match.order_rule(ord)

    -- nothing of this skill in the pawn's table (wrong vocation, skill not equipped): the caller falls back
    local entries = brain:entries()
    if not entries then return false end
    local mine = brain:claim(entries, rule)
    if not next(mine) then return false end

    Roster.stop(rec)

    local token = brain:focus(rule)
    if not token then return false end

    brain:set_thinking(true)
    brain:restart_iteration()

    local keys = {}
    for i, word in ipairs(ord.keys or {}) do keys[i] = word end
    local stack = P.read(chara)

    local run = {
        skill = skill_id,
        chara = chara,
        pawn_addr = rec.addr,
        mode = "brain",
        actions_addr = address_of(U.safe_call(function() return chara[S.F.actions] end)),
        board_addr = address_of(U.safe_call(function() return chara:get_AIBlackBoardController() end)),
        human_addr = human_address(chara),
        pack_addr = 0,
        token = token,
        mine = token.mine,
        keys = keys,
        at_fire = now,
        refocus_at = now,
        stack = stack.raw,
        stack_at_fire = stack.set,
        shaken_at_fire = P.shaken(stack, chara) ~= nil,
        thinking = true,
        target = enemy,
        target_addr = address_of(enemy),
        target_go_addr = enemy and address_of(U.safe_call(function() return enemy:get_GameObject() end)) or 0,
        blinker = Obj.blinker_on(chara, enemy),
    }
    Obj.hold_ration(run, true)
    -- 2.23 (BardN): the pawn never charges by itself, so A now forces the charged version (run.full, 2.08 engine)
    -- and X forces the quick one. 2.13 left the choice to the pawn, which never charged.
    local quick_once = ord.full and D.charge_quick_once == skill_id or nil
    run.quick = quick_once
    run.full  = (ord.full and not quick_once) or nil
    D.charge_quick_once = nil
    Roster.begin(rec, run)
    return true
end

----------------------------------------------------------------------------------------------------
-- route two: straight onto the blackboard
----------------------------------------------------------------------------------------------------
local function onto_board(rec, skill_id, now, ord, aim_at, pick, nudged, want_range, range_job)
    local chara = rec.chara
    local brain = Brain.of(chara)
    local pack = brain:pack_for(ord) or pack_from_path(ord.pack)
    if not pack then return "failed" end

    Roster.stop(rec)

    -- hold the job's own distance rather than the pawn's idea of it
    if aim_at ~= chara and (want_range or rec.stance == "ranged") then
        local job = range_job or Reach.job_key(ord.job)
        Reach.apply(chara, aim_at, job, (job == "job02") and skill_id or nil)
    elseif D.RANGE_HEAL[skill_id] and aim_at ~= chara then
        Reach.apply(chara, aim_at, "job03", skill_id)
    end

    local ok, board = I.push(chara, pack, aim_at)
    if not ok or not board then return "failed" end

    brain:set_thinking(false)

    local keys = {}
    for i, word in ipairs(ord.keys or {}) do keys[i] = word end
    local stack = P.read(chara)

    local run = {
        skill = skill_id,
        chara = chara,
        pawn_addr = rec.addr,
        mode = "push",
        actions_addr = address_of(U.safe_call(function() return chara[S.F.actions] end)),
        board_addr = address_of(board),
        human_addr = human_address(chara),
        pack_addr = address_of(pack),
        keys = keys,
        at_fire = now,
        stack = stack.raw,
        stack_at_fire = stack.set,
        shaken_at_fire = P.shaken(stack, chara) ~= nil,
        thinking = false,
        target = aim_at,
        target_pick = pick,
        hold = (D.CASTER_JOBS[ord.job] == true),
        nudged = nudged,
    }
    Obj.hold_ration(run, false)
    -- 2.23 (BardN): the pawn never charges by itself, so A now forces the charged version (run.full, 2.08 engine)
    -- and X forces the quick one. 2.13 left the choice to the pawn, which never charged.
    local quick_once = ord.full and D.charge_quick_once == skill_id or nil
    run.quick = quick_once
    run.full  = (ord.full and not quick_once) or nil
    D.charge_quick_once = nil
    Roster.begin(rec, run)
    return "ordered"
end

----------------------------------------------------------------------------------------------------
-- the order itself
----------------------------------------------------------------------------------------------------
-- `our_way`:
--   nil / false  -- let the pawn's head do it when the skill and the distance allow
--   true         -- straight onto the blackboard, no matter what
--   "unstuck"    -- the same, and marked as the second attempt so it is not retried again
--
-- Returns "ordered", "stance_off", "no_target" or "failed".
function I.order(rec, skill_id, now, our_way, chosen)
    local chara = rec and rec.chara
    if not U.is_valid_obj(chara) or U.is_dead(chara) then return "failed" end

    local ord = D.ORDERS[skill_id]
    local player = U.get_player()
    if not ord or not U.is_valid_obj(player) then return "failed" end

    local pick = Aim.settle(skill_id, chosen, chara)
    if Aim.must_have_enemy(skill_id) and not pick then return "no_target" end
    -- 1.06: marked "without targeting" and no enemy around: straight onto the blackboard, aimed at the pawn itself
    local alone = (not pick) and Aim.needs_enemy(skill_id)

    local stack = P.read(chara)
    if stack.blocked then return "failed" end

    local actions = U.safe_call(function() return chara[S.F.actions] end)
    if not U.is_valid_obj(actions) then return "failed" end

    -- a launch stance is a toggle: ordering it again, or catching the pawn already standing in it, puts it away
    if ord.stance then
        local already = (rec.run and rec.run.skill == skill_id) or stack.raw:find("Springboard", 1, true)
        if already then
            rec.soon = nil
            Roster.stop(rec)
            pcall(function() actions:requestActionCore(0, "NormalLocomotion", 0) end)
            return "stance_off"
        end
    end

    local blunt = (our_way ~= false and our_way ~= nil) or alone

    -- too far for the pawn's own evaluation to bother closing in: push it instead
    local want_range, range_job = Reach.wanted(skill_id)
    if want_range and not blunt then
        local enemy = (pick and pick.chara) or U.pick_nearest_enemy(chara)
        local ok, gap = pcall(U.distance, chara, enemy)
        if ok and gap and gap > want_range then blunt = true end
    end

    if ord.target == "enemy" and not ord.stance and not blunt then
        if through_brain(rec, skill_id, now, pick and pick.chara or nil) then return "ordered" end
    end

    local aim_at = player
    if ord.target == "self" then
        aim_at = chara
    elseif ord.target == "enemy" then
        if pick then
            aim_at = pick.chara
        elseif alone then
            aim_at = chara
        else
            return "no_target"
        end
    end
    if pick and pick.ally and ord.ally then
        aim_at = pick.chara                       -- 2.31: the ally chosen in the targeting step (the pawn itself too)
    elseif D.RANGE_HEAL[skill_id] then
        aim_at = U.pick_heal_target(chara, player)
    end

    return onto_board(rec, skill_id, now, ord, aim_at, pick, (our_way == "unstuck"), want_range, range_job)
end

-- an action the engine asks for itself, fenced so the hooks let it through
function I.request_action(chara, priority, name, slot)
    I.ours = true
    pcall(function()
        chara[S.F.actions]:requestActionCore(priority, name, slot or 0)
    end)
    I.ours = false
end

return I
