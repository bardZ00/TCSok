-- TacticalCommandSystem/cmd/stance.lua
-- The standing posture a pawn keeps until told otherwise: free, escort, hold, ranged.
--
-- A stance is not a one-off order. The pawn's own AI pulls against it constantly -- it wants to charge in, to wander, to
-- pick its own distance -- so each stance is written here as three things: the party order it sets, what it does the
-- moment it is taken, and what it does on every tick to keep the pawn in it. The engine then only has to know which
-- stance a pawn is in, never what that stance has to do.
--
--   free    nothing held: the pawn fights as it likes
--   escort  stays near the Arisen, and is sent running back when it drifts
--   hold    stands where it is, its thinking switched off so it does not talk itself out of it
--   ranged  keeps its distance, with the decisions that would close the gap muted

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local P = require("TacticalCommandSystem.cmd.posture")
local Brain = require("TacticalCommandSystem.cmd.brain")
local Obj = require("TacticalCommandSystem.cmd.pawnobj")
local Reach = require("TacticalCommandSystem.cmd.reach")
local Roster = require("TacticalCommandSystem.cmd.roster")
local Issue = require("TacticalCommandSystem.cmd.issue")

local St = {}

local ORDER = Obj.ORDER

----------------------------------------------------------------------------------------------------
-- the decisions a ranged pawn must not act on
----------------------------------------------------------------------------------------------------
local function closes_the_gap(stem)
    for _, word in ipairs(D.RANGED_BLOCK_STEMS) do
        if stem:find(word, 1, true) then return true end
    end
    return false
end

local function mute_approach(rec)
    if not U.is_valid_obj(rec.chara) then return end
    rec.stance_token = Brain.of(rec.chara):mute(closes_the_gap, rec.stance_token)
end

function St.release(rec)
    if not rec or not rec.stance_token then return end
    Brain.release(rec.stance_token)
    rec.stance_token = nil
end

-- an order that ends gives every flag back, the ranged mute included: put it on again
table.insert(Roster.on_stop, function(rec)
    if rec.stance == "ranged" and U.is_valid_obj(rec.chara) then
        mute_approach(rec)
    end
end)

----------------------------------------------------------------------------------------------------
-- small moves the stances share
----------------------------------------------------------------------------------------------------
local function thinking(rec, on)
    if U.is_valid_obj(rec.chara) then Brain.of(rec.chara):set_thinking(on) end
end

local function cancel_action(rec)
    pcall(function()
        rec.chara[S.F.actions]:requestActionCore(10, "DefaultCancelAction", 0)
    end)
end

-- how far the pawn has drifted from the Arisen, or nil
local function gap_to_player(rec)
    local player = U.get_player()
    if not U.is_valid_obj(player) then return nil, nil end
    local ok, gap = pcall(U.distance, rec.chara, player)
    return (ok and gap) or nil, player
end

local function send_back(rec, player, now)
    rec.leash_at = now or U.game_now()
    Obj.set_order(rec.pawn_obj, rec.chara, ORDER.COME)
    Issue.push_common(rec.chara, D.COMMON_PACKS.RUN_TARGET, player)
end

local function hold_distance(rec, job_number)
    local enemy = U.pick_nearest_enemy(rec.chara)
    if not enemy then return end
    Reach.apply(rec.chara, enemy, Reach.job_key(job_number), nil)
end

local function weapon_job(rec)
    return U.safe_call(function()
        return U.num_val(rec.chara.WeaponJob or rec.chara:get_field("WeaponJob"))
    end) or 6
end

----------------------------------------------------------------------------------------------------
-- the stances
----------------------------------------------------------------------------------------------------
local KIND = {}

KIND.free = {
    order = ORDER.NONE,
    enter = function(rec)
        if not rec.run then thinking(rec, true) end
        Obj.set_order(rec.pawn_obj, rec.chara, ORDER.NONE)
    end,
}

KIND.wait = {
    order = ORDER.WAIT,
    enter = function(rec)
        Obj.set_order(rec.pawn_obj, rec.chara, ORDER.WAIT)
        if rec.run then return end
        thinking(rec, false)
        Issue.push_common(rec.chara, D.COMMON_PACKS.IDLE, rec.chara)
        cancel_action(rec)
    end,
    tick = function(rec)
        Obj.set_order(rec.pawn_obj, rec.chara, ORDER.WAIT)
        thinking(rec, false)
        local stack = P.read(rec.chara)
        if not P.at_rest(stack) and not D.IDLE_LAYERS[stack.top] then
            cancel_action(rec)
        end
    end,
}

KIND.close = {
    order = ORDER.COME,
    enter = function(rec, now)
        if not rec.run then thinking(rec, true) end
        Obj.set_order(rec.pawn_obj, rec.chara, ORDER.COME)
        if rec.run then return end
        local gap, player = gap_to_player(rec)
        if gap and gap > D.LEASH_DIST then send_back(rec, player, now) end
    end,
    tick = function(rec, now)
        thinking(rec, true)
        local gap, player = gap_to_player(rec)
        if gap and gap > D.LEASH_DIST and (now - (rec.leash_at or 0) >= D.LEASH_REFIRE) then
            send_back(rec, player, now)
        end
    end,
}

KIND.ranged = {
    order = ORDER.GO,
    enter = function(rec, now, job_number)
        if not rec.run then thinking(rec, true) end
        Obj.set_order(rec.pawn_obj, rec.chara, ORDER.GO)
        mute_approach(rec)
        hold_distance(rec, job_number)
    end,
    tick = function(rec)
        thinking(rec, true)
        mute_approach(rec)
        hold_distance(rec, weapon_job(rec))
    end,
}

----------------------------------------------------------------------------------------------------
-- taking a stance
----------------------------------------------------------------------------------------------------
function St.of(addr)
    local rec = Roster.get(addr)
    return (rec and rec.stance) or "free"
end

-- Puts `mode` on one pawn. Taking the stance it already holds drops it back to free, unless `keep` says the stance is
-- being set across the whole party and should not toggle.
function St.set(entry, mode, now, keep)
    if not entry or not U.is_valid_obj(entry.chara) then return "free" end
    local addr = entry.addr or entry.chara:get_address()
    local rec = Roster.ensure(addr, entry.chara, entry.pawn_obj)

    if not keep and mode ~= "free" and rec.stance == mode then mode = "free" end

    St.release(rec)
    rec.stance = mode
    rec.stance_at = 0
    Roster.reindex_wait(rec)

    local kind = KIND[mode] or KIND.free
    kind.enter(rec, now or U.game_now(), entry.job)

    if mode == "free" then Roster.tidy(rec) end
    return rec.stance
end

-- Puts `mode` on every pawn at once, whatever each one held before. Ordering the stance the whole party already holds
-- drops them all back to free.
function St.set_all(list, mode, now)
    if not list or #list == 0 then return "free" end

    local uniform = true
    for _, p in ipairs(list) do
        if St.of(p.addr) ~= mode then uniform = false; break end
    end
    local wanted = (mode ~= "free" and uniform) and "free" or mode

    for _, p in ipairs(list) do
        St.set(p, wanted, now, true)
    end
    return wanted
end

----------------------------------------------------------------------------------------------------
-- keeping it
----------------------------------------------------------------------------------------------------
function St.keep(rec, now)
    local mode = rec.stance
    if not mode or mode == "free" then return end
    if not U.is_valid_obj(rec.chara) or U.is_dead(rec.chara) then return end
    if rec.run or rec.soon then return end
    if now - (rec.stance_at or 0) < D.STANCE_TICK_DT then return end
    rec.stance_at = now

    local kind = KIND[mode]
    if kind and kind.tick then kind.tick(rec, now) end
end

return St
