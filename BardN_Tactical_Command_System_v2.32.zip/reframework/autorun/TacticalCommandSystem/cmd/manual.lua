-- TacticalCommandSystem/cmd/manual.lua
-- Skills kept for the player to order, and never used by the pawn on its own.
--
-- A pawn with a well-aimed Maelstrom will cast it at the first goblin it sees. Locking the skill keeps its decisions
-- muted so the pawn never picks it, while an order from the wheel re-enables it for the length of the order and mutes
-- it again afterwards.
--
-- Two belts for the same trousers, because a muted decision is not quite a guarantee: the mute, kept up on a slow tick,
-- and a veto on the game's own "can this pawn use this skill" question. Either alone mostly works; together they hold.
--
-- The counters are for the diagnostics drawer -- they are what a bug report about a leaking lock is written from.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local Safe = require("TacticalCommandSystem.lib.safe")
local S = require("TacticalCommandSystem.cmd.sdkmap")
local Match = require("TacticalCommandSystem.cmd.matcher")
local Brain = require("TacticalCommandSystem.cmd.brain")
local Roster = require("TacticalCommandSystem.cmd.roster")

local L = {}

local TICK_DT = 0.12              -- how often the mutes are kept up
local PARTY_DT = 1.5              -- how often the party is looked up again
local TRACE_MAX = 8               -- lines kept for the drawer
local TRACE_FILE_MAX = 400        -- lines written to the REFramework log before it stops

local report = {
    ticks = 0, applied = 0, matched = 0, errors = 0, last_err = nil,
    pawns = 0, vetoed = 0, leaks = 0, recent = {},
}

local muted_for = {}              -- pawn address -> { [skill id as string] = true }
local party, party_at, tick_at = {}, -10, -10
local humans = {}                 -- Human address -> { name, addr } of the pawns that have locks
local last_seen, logged_once, log_lines = {}, {}, 0

function L.report() return report end

----------------------------------------------------------------------------------------------------
-- trace
----------------------------------------------------------------------------------------------------
local function trace(line, to_file)
    if not U.LOCKCFG.log then return end
    local recent = report.recent
    recent[#recent + 1] = line
    if #recent > TRACE_MAX then table.remove(recent, 1) end
    if to_file ~= false and log_lines < TRACE_FILE_MAX then
        log_lines = log_lines + 1
        if Safe.DEV then pcall(log.info, "[TC lock] " .. line) end
    end
end

----------------------------------------------------------------------------------------------------
-- what is locked
----------------------------------------------------------------------------------------------------
function L.is_locked(pawn_name, skill_id)
    local held = pawn_name and U.LOCKS[pawn_name]
    return held ~= nil and held[tostring(skill_id)] == true
end

local function locks_of(pawn_name)
    if not U.LOCKCFG.enforce then return nil end
    return U.LOCKS[pawn_name]
end

----------------------------------------------------------------------------------------------------
-- keeping the mutes up
----------------------------------------------------------------------------------------------------
-- What is this pawn running? Logged once per pawn and decision, and flagged when it is a locked skill getting through.
local function watch(p, entries, locks)
    local stems, by_stem = {}, {}
    for _, e in ipairs(entries) do
        local addr = U.safe_call(function() return e.d:get_address() end)
        if addr then stems[addr] = e.stem end
        by_stem[e.stem] = e
    end

    local ok, _, name = pcall(Brain.running, Brain.of(p.chara), stems)
    if not ok or not name or name == "none" or name == last_seen[p.addr] then return end
    last_seen[p.addr] = name

    local leaked
    for sid in pairs(locks) do
        local ord = D.ORDERS[tonumber(sid)]
        if ord then
            for _, e in ipairs(Match.locked_entries(entries, ord)) do
                if e.stem == name then leaked = ord.name end
            end
        end
    end

    if leaked then
        report.leaks = report.leaks + 1
        local e = by_stem[name]
        local flags = e and tonumber(e.d:get_field(S.F.off_flag)) or -1
        trace(string.format("%s runs %s <<< LOCKED skill %s (flag=%s)", p.name, name, leaked, tostring(flags)))
    else
        local key = p.name .. "|" .. name
        trace(string.format("%s runs %s", p.name, name), not logged_once[key])
        logged_once[key] = true
    end
end

local function keep_for(p)
    -- while an order is running, its own token owns these flags: leave them be
    local rec = Roster.get(p.addr)
    if rec and (rec.run or rec.soon) then return end

    local locks = locks_of(p.name)
    local already = muted_for[p.addr]
    if not locks and not already then return end

    local entries = Brain.of(p.chara):entries()
    if not entries then return end

    if locks then
        for sid in pairs(locks) do
            local ord = D.ORDERS[tonumber(sid)]
            if ord then
                local matched = Match.locked_entries(entries, ord)
                report.matched = #matched
                for _, e in ipairs(matched) do
                    if Brain.set_muted(e.d, true) then report.applied = report.applied + 1 end
                end
                if #matched > 0 then
                    muted_for[p.addr] = muted_for[p.addr] or {}
                    muted_for[p.addr][sid] = true
                end
            end
        end
        if U.LOCKCFG.log then pcall(watch, p, entries, locks) end
    end

    -- a skill that is no longer locked gets its decisions back
    already = muted_for[p.addr]
    if already then
        for sid in pairs(already) do
            if not (locks and locks[sid]) then
                local ord = D.ORDERS[tonumber(sid)]
                if ord then
                    for _, e in ipairs(Match.locked_entries(entries, ord)) do
                        Brain.set_muted(e.d, false)
                    end
                end
                already[sid] = nil
            end
        end
        if not next(already) then muted_for[p.addr] = nil end
    end
end

function L.step(now_wall)
    if now_wall - tick_at < TICK_DT then return end
    tick_at = now_wall
    if not next(U.LOCKS) and not next(muted_for) then return end

    if now_wall - party_at > PARTY_DT then
        party_at = now_wall
        local ok, found = pcall(U.get_commandable_pawns)
        party = (ok and found) or party
        local seats = {}
        for _, p in ipairs(party) do
            local h = U.safe_call(function() return p.chara:get_field(S.F.human):get_address() end)
            if h and h ~= 0 then seats[h] = { name = p.name, addr = p.addr } end
        end
        humans = seats
    end

    report.ticks = report.ticks + 1
    report.pawns = #party
    for _, p in ipairs(party) do
        local ok, err = pcall(keep_for, p)
        if not ok then
            report.errors = report.errors + 1
            report.last_err = tostring(err)
        end
    end
end

----------------------------------------------------------------------------------------------------
-- the veto, asked by the skill-availability hook
----------------------------------------------------------------------------------------------------
-- Is this skill locked for the pawn that owns this Human component?
function L.vetoes(this_ptr, skill_id)
    if not U.LOCKCFG.hook or not next(U.LOCKS) then return false end
    local obj = U.safe_managed_arg(this_ptr)
    local h = obj and obj:get_field("Human")
    if not U.is_valid_obj(h) then return false end

    local seat = humans[h:get_address()]
    if not seat then return false end
    local locks = U.LOCKS[seat.name]
    if not locks or not locks[tostring(skill_id)] then return false end

    local rec = Roster.get(seat.addr)
    if rec and (rec.run or rec.soon) then return false end     -- the player's own order must get through

    report.vetoed = report.vetoed + 1
    return true
end

----------------------------------------------------------------------------------------------------
-- turning a lock on and off
----------------------------------------------------------------------------------------------------
-- Returns whether the skill is now locked, and how many of the pawn's decisions the lock found (nil when the skill has
-- no pack the engine can match).
function L.toggle(entry, skill_id)
    local ord = D.ORDERS[skill_id]
    if not entry or not entry.name or not ord or not ord.pack then return nil end

    local key = tostring(skill_id)
    local held = U.LOCKS[entry.name]
    local now_locked

    if held and held[key] then
        held[key] = nil
        if not next(held) then U.LOCKS[entry.name] = nil end
        now_locked = false
    else
        U.LOCKS[entry.name] = held or {}
        U.LOCKS[entry.name][key] = true
        now_locked = true
    end

    local found
    pcall(function()
        local entries = Brain.of(entry.chara):entries(true)
        local matched = Match.locked_entries(entries, ord)
        found = #matched

        local names, all = {}, {}
        for _, e in ipairs(matched) do names[#names + 1] = e.stem end
        for _, e in ipairs(entries) do all[#all + 1] = e.stem end
        trace(string.format("%s %s %s: %d match(es) [%s]",
            now_locked and "LOCK" or "UNLOCK", entry.name, ord.name, #matched, table.concat(names, ", ")))
        if U.LOCKCFG.log and Safe.DEV then
            pcall(log.info, string.format("[TC lock] %s decisions: %s",
                entry.name, table.concat(all, ", "):sub(1, 3500)))
        end
    end)

    tick_at = -10                 -- apply or release on the next frame rather than in half a second
    if U.on_locks_changed then pcall(U.on_locks_changed) end
    return now_locked, found
end

function L.clear_all()
    for name in pairs(U.LOCKS) do U.LOCKS[name] = nil end
    tick_at = -10
    if U.on_locks_changed then pcall(U.on_locks_changed) end
end

return L
