-- TacticalCommandSystem/cmd/matcher.lua
-- Which of a pawn's AI decisions belong to a given skill.
--
-- A pawn's AI is a list of decisions, each named after the pack file it runs ("job03_mage_highlevin", and variants like
-- "job03_mage_highlevin_targetmember"). Deciding which of them are "this skill" is guesswork on a name, and the engine
-- needs three slightly different answers:
--   * ordering  -- the decisions to let through while the order runs, everything else muted
--   * locking   -- the decisions to keep muted so the pawn never picks the skill itself
--   * the pack  -- the pack object the pawn already holds for this skill, preferred over one built from the path
-- They differ in how forgiving they are, so each is written out here as its own rule instead of being guessed at the
-- three call sites.
--
-- Every function takes and returns plain values; nothing here reads the game.

local M = {}

-- the pack file's own name, which is what a decision is named after
function M.family(pack_path)
    local name = pack_path and pack_path:match("([^\\]+)%.user$")
    return name and name:lower() or nil
end

local function mentions(stem, word) return stem:find(word, 1, true) ~= nil end

-- a stock spell has its own decisions ("..._spellstock"); so do the NPC copies. Neither is ours.
local function is_understudy(stem)
    return mentions(stem, "spellstock") or mentions(stem, "npc")
end

----------------------------------------------------------------------------------------------------
-- ordering: strict first, then a keyword fallback for the skills whose decisions are named loosely
----------------------------------------------------------------------------------------------------
-- rule for the decisions of `ord`: { family, keyword } (keyword only when the order allows the fallback)
function M.order_rule(ord)
    return {
        family  = M.family(ord.pack),
        keyword = (ord.ai_fuzzy and ord.keys and ord.keys[1]) or nil,
    }
end

-- the decision is this skill's, by name alone
function M.named_for(rule, stem, loose)
    if not stem then return false end
    if mentions(stem, "_multiple") then return false end
    if loose then
        local word = rule.keyword
        return word ~= nil and mentions(stem, word) and not is_understudy(stem)
    end
    local family = rule.family
    if not family then return false end
    if stem == family then return true end
    return stem:sub(1, #family + 1) == family .. "_" and not is_understudy(stem)
end

----------------------------------------------------------------------------------------------------
-- locking: deliberately wider than ordering, so no variant of the skill slips past
----------------------------------------------------------------------------------------------------
-- Returns the matching entries of `entries` (each with a .stem), in order, without duplicates.
function M.locked_entries(entries, ord)
    local family = M.family(ord.pack)
    if not family then return {} end
    local out, taken = {}, {}

    for _, e in ipairs(entries) do
        local stem = e.stem
        if stem == family or stem:sub(1, #family + 1) == family .. "_" then
            out[#out + 1] = e
            taken[e] = true
        end
    end

    -- the same spell aimed at an ally is a separate decision with its own name: catch it by keyword, but only with a
    -- keyword long enough not to drag half the job's decisions in with it
    local word = ord.keys and ord.keys[1]
    if word and #word >= 6 then
        for _, e in ipairs(entries) do
            if not taken[e] and mentions(e.stem, word) and not mentions(e.stem, "npc") then
                out[#out + 1] = e
                taken[e] = true
            end
        end
    end

    return out
end

----------------------------------------------------------------------------------------------------
-- the pack the pawn already holds for this skill
----------------------------------------------------------------------------------------------------
function M.pack_of(entries, ord)
    local family = M.family(ord.pack)
    if not family then return nil end
    for _, e in ipairs(entries) do
        if e.stem == family then return e.pack end
    end
    local word = ord.ai_fuzzy and ord.keys and ord.keys[1]
    if word then
        for _, e in ipairs(entries) do
            if mentions(e.stem, word) and not mentions(e.stem, "npc") then return e.pack end
        end
    end
    return nil
end

return M
