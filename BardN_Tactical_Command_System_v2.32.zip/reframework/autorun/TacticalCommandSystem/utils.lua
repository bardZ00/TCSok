-- TacticalCommandSystem/utils.lua
-- The shared helpers, under the one name the rest of the mod asks for them by.
--
-- What used to be a single long file of unrelated helpers is now six small ones under lib/, each about one subject, and
-- this file puts them together. Everything in the mod requires this module, so the names here are the ones that must not
-- move; inside lib/, each piece is free to change shape.
--
--   lib/safe    reaching into the game without bringing it down
--   lib/text    capitals with accents, and cleaning the game's own strings
--   lib/clock   a clock that slows down with the game
--   lib/names   asking the game what things are called, in the player's language
--   lib/world   where everything is, and how it lands on the screen
--   lib/party   who is in the party, what they have equipped, how they are holding up
--   lib/prefs   the few settings the engine reads, shared by name with the settings screen

local Safe  = require("TacticalCommandSystem.lib.safe")
local Text  = require("TacticalCommandSystem.lib.text")
local Clock = require("TacticalCommandSystem.lib.clock")
local Names = require("TacticalCommandSystem.lib.names")
local World = require("TacticalCommandSystem.lib.world")
local Party = require("TacticalCommandSystem.lib.party")
local Prefs = require("TacticalCommandSystem.lib.prefs")

local U = {}

----------------------------------------------------------------------------------------------------
-- reaching into the game
----------------------------------------------------------------------------------------------------
U.log_err_once     = Safe.log_err_once
U.safe_call        = Safe.call
U.is_valid_obj     = Safe.alive
U.safe_managed_arg = Safe.from_pointer
U.enum_val         = Safe.enum
U.num_val          = Safe.number

----------------------------------------------------------------------------------------------------
-- text
----------------------------------------------------------------------------------------------------
U.clean_text  = Text.clean
U.upper       = Text.upper
U.split_camel = Text.space_out

----------------------------------------------------------------------------------------------------
-- time
----------------------------------------------------------------------------------------------------
U.CLOCK      = Clock.CLOCK          -- shared by name with the slow-motion code
U.Slow       = Clock.Slow
U.wall_time  = Clock.wall_time
U.game_now   = Clock.game_now
U.tick_clock = Clock.tick_clock

----------------------------------------------------------------------------------------------------
-- names
----------------------------------------------------------------------------------------------------
U.pawn_name              = Names.of_pawn
U.enemy_name             = Names.of_enemy
U.get_skill_display_name = Names.of_skill
U.get_skill_icon_no      = Names.skill_icon
U.clear_skill_names      = Names.clear_skills
U.get_pawn_data_context  = Names.pawn_context

----------------------------------------------------------------------------------------------------
-- the world
----------------------------------------------------------------------------------------------------
U.get_player            = World.player
U.is_dead               = World.is_dead
U.position              = World.position
U.distance              = World.distance
U.alive_enemies         = World.alive_enemies
U.pick_nearest_enemy    = World.nearest_enemy
U.screen_pos            = World.screen_pos
U.camera_basis          = World.camera_basis
U.pick_direction        = World.pick_direction
U.list_target_candidates = World.target_candidates

----------------------------------------------------------------------------------------------------
-- the party
----------------------------------------------------------------------------------------------------
U.read_pawn_equipped_skills = Party.read_skills
U.get_vitals                = Party.vitals
U.get_commandable_pawns     = Party.commandable
U.pick_heal_target          = Party.heal_target

----------------------------------------------------------------------------------------------------
-- settings the engine reads (the same tables the settings screen writes into)
----------------------------------------------------------------------------------------------------
U.TGT     = Prefs.TGT
U.LOCKS   = Prefs.LOCKS
U.LOCKCFG = Prefs.LOCKCFG
U.LAMP    = Prefs.LAMP

-- set by the input layer, called by the locks when one is turned on or off
U.on_locks_changed = nil

return U
