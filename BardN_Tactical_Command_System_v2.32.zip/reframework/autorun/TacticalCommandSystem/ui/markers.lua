-- TacticalCommandSystem/ui/markers.lua
-- World markers on targets, life / stamina bars.
-- Part of the HUD drawing code (see ui.lua); state shared with the other ui files lives in ui/shared.lua.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local IN = require("TacticalCommandSystem.input")
local X = require("TacticalCommandSystem.ui.shared")
local COL = D.COL
local W = IN.W

-- from ui/shapes
local draw_aligned_text, draw_diamond, with_alpha = X.draw_aligned_text, X.draw_diamond, X.with_alpha

------------------------------------------------------------------------------------------------
-- Target Markers (drawn over the world at each enemy's position)
------------------------------------------------------------------------------------------------
-- 1.38: looks of the marker (setting marker_style): turning arcs + diamond, a glowing diamond, a gold line, line + HP
local arc = X.draw_arc
local text_size = X.text_size
local LIGHT = 0xFFC8F3FF                         -- pale gold, the heart of the glowing diamond (ABGR)
local function marker_label(cur)
    local label = cur.name or ""                 -- 1.38: an unknown name stays empty
    local ok, d = pcall(function() return U.distance(U.get_player(), cur.chara) end)
    if ok and d then
        label = (label == "") and string.format("%dm", math.floor(d + 0.5)) or string.format("%s  %dm", label, math.floor(d + 0.5))
    end
    return label
end
-- 1.38: a horizontal line or band that fades away on both sides (screen pixels; centre x, half width)
local function fade_line(cx, y, half, h, col, a)
    local n = 20                                   -- 1.40: finer steps, no visible staircase
    for k = 0, n - 1 do
        local x0, x1 = half * k / n, half * (k + 1) / n
        local f = a * (1 - (k + 0.5) / n)
        draw.filled_rect(cx + x0, y, x1 - x0 + 1, h, with_alpha(col, f))
        draw.filled_rect(cx - x1, y, x1 - x0 + 1, h, with_alpha(col, f))
    end
end
local function target_hp(chara)
    local r = nil
    pcall(function()
        local now, most = tonumber(chara:call("get_Hp")), tonumber(chara:call("get_MaxHp"))
        if now and most and most > 0 then r = math.max(0, math.min(1, now / most)) end
    end)
    return r
end
local function down_triangle(x, y, sc, col)      -- small gold arrow, its tip at (x, y)
    pcall(draw.filled_quad, x - 8 * sc, y - 10 * sc, x + 8 * sc, y - 10 * sc, x, y, x, y, col)
end

local function draw_selected_marker(cur, scale, a, pulse, font, show_label)
    local sx, sy = U.screen_pos(cur.chara, 1.3)
    if not sx then return end
    local hx, hy = U.screen_pos(cur.chara, 2.1)  -- above the head
    if not hx then hx, hy = sx, sy - 40 * scale end
    scale = scale * (U.TGT.marker_size or 1.0)      -- size and opacity settings
    a = a * (U.TGT.marker_opacity or 1.0)
    local MC = U.TGT.marker_color or COL.GOLD_BRIGHT      -- 1.45: the marker's colour is a setting
    local gold = with_alpha(MC, a)
    local style = U.TGT.marker_style or "line"
    if style == "line" or style == "life" then
        local ty = hy - 6 * scale
        down_triangle(hx, ty, scale, gold)
        if not show_label then return end
        local pushed = font and pcall(imgui.push_font, font)
        local _, th = text_size("X", nil)
        if pushed then pcall(imgui.pop_font) end
        if style == "line" then
            local ly = ty - 16 * scale
            fade_line(hx, ly, 110 * scale, math.max(1, 2 * scale), MC, a)
            draw_aligned_text(marker_label(cur), hx, ly - th - 4 * scale, COL.TEXT, a, font, "center")
            return
        end
        -- life: a dark band fading on both sides, the name, a thin life bar and the distance, a gold line under it
        local ly = ty - 16 * scale
        local band_h = th + 22 * scale
        local top = ly - band_h
        -- 1.40: the smooth dark wash pictures of the wheel's cells (no stepped rectangles)
        local hw = math.floor(115 * scale + 0.5)
        local slots = X.iconSlots
        if X.images and X.images["cell_fade_l"] then
            slots[#slots + 1] = { img = "cell_fade_l", x = math.floor(hx - hw + 0.5), y = math.floor(top + 0.5), w = hw, h = math.floor(band_h + 0.5), alpha = a * 0.9 }
            slots[#slots + 1] = { img = "cell_fade_r", x = math.floor(hx + 0.5), y = math.floor(top + 0.5), w = hw, h = math.floor(band_h + 0.5), alpha = a * 0.9 }
        end
        fade_line(hx, ly, 115 * scale, math.max(1, 2 * scale), MC, a)
        if (cur.name or "") ~= "" then draw_aligned_text(cur.name, hx, top + 3 * scale, 0xFFFFFFFF, a, font, "center") end
        local bw, bh = 120 * scale, math.max(5, 8 * scale)
        local bx, by = hx - bw * 0.5, top + th + 8 * scale
        local hp = target_hp(cur.chara) or 1.0
        -- 1.45: the game's own enemy life bar: a magenta glow, a pink band, a white-hot core (colours are settings)
        local hc, kc = U.TGT.hp_color or 0xFF763C8C, U.TGT.hp_core or 0xFFF6F6F6
        draw.filled_rect(bx, by, bw, bh, with_alpha(0xFF161C1E, a * 0.75))
        local fw = bw * hp
        if fw > 0.5 then
            draw.filled_rect(bx, by, fw, bh, with_alpha(hc, a * 0.85))
            draw.filled_rect(bx, by + bh * 0.25, fw, bh * 0.5, with_alpha(hc, a))
            local r, g, b = hc & 0xFF, (hc >> 8) & 0xFF, (hc >> 16) & 0xFF
            local pr, pg, pb = (r + 255) // 2 + 20, (g + 255) // 2, (b + 255) // 2 + 10
            local pink = 0xFF000000 | (math.min(255, pb) << 16) | (math.min(255, pg) << 8) | math.min(255, pr)
            draw.filled_rect(bx, by + bh * 0.35, fw, bh * 0.3, with_alpha(pink, a))
            draw.filled_rect(bx, by + bh * 0.42, fw, math.max(1, bh * 0.16), with_alpha(kc, a))
            -- 1.50: a light liquid flowing through the bar (as in the game, whose life bars move): soft waves of pink
            -- drifting along, a glint running through the core, a brighter crest at the front. Thin columns (one or two
            -- screen pixels), each a shade apart from the next: smooth, no visible steps
            local t = os.clock()
            local cw = math.max(1, math.floor(scale + 0.5))
            local n = math.floor(fw / cw)
            local glint = (t * 0.45) % 1.6 - 0.3                 -- position of the glint along the bar (0..1, then rest)
            for i = 0, n - 1 do
                local x = bx + i * cw
                local u = (i * cw) / bw
                local wave = 0.5 + 0.25 * math.sin(u * 14 - t * 2.2) + 0.25 * math.sin(u * 5.3 + t * 1.3)
                draw.filled_rect(x, by + bh * 0.25, cw, bh * 0.5, with_alpha(pink, a * 0.28 * wave))
                local gl = math.exp(-((u - glint) / 0.06) ^ 2)
                if gl > 0.02 then draw.filled_rect(x, by + bh * 0.3, cw, bh * 0.4, with_alpha(kc, a * 0.55 * gl)) end
            end
            -- the front: a soft crest that breathes
            local crest = 0.55 + 0.25 * math.sin(t * 3.1)
            for k = 0, 3 do
                local cxp = bx + fw - (k + 1) * cw
                if cxp >= bx then draw.filled_rect(cxp, by + bh * 0.15, cw, bh * 0.7, with_alpha(kc, a * crest * (1 - k / 4) * 0.5)) end
            end
            -- a faint light on the top edge, a faint shade on the bottom one (the volume of a tube)
            draw.filled_rect(bx, by, fw, math.max(1, bh * 0.12), with_alpha(0xFFFFFFFF, a * 0.12))
            draw.filled_rect(bx, by + bh * 0.88, fw, math.max(1, bh * 0.12), with_alpha(0xFF000000, a * 0.25))
        end
        local ok, d = pcall(function() return U.distance(U.get_player(), cur.chara) end)
        if ok and d then
            draw_aligned_text(string.format("%dm", math.floor(d + 0.5)), bx + bw + 8 * scale, by - th * 0.5 + bh * 0.5,
                MC, a, nil, "left")
        end
        return
    end
    -- 1.42: the name plate look is gone (an old "plate" choice now shows the default arcs)
    if style == "glow" then
        -- 1.40: a little lower (just above the head), and a halo made of many thin discs (one screen pixel apart,
        -- each very faint, 48 sides): a smooth glow instead of visible rings
        local gy = hy + 14 * scale
        local r_out = 32 * scale * (0.92 + 0.08 * pulse)
        local steps = math.max(8, math.min(40, math.floor(r_out)))
        local per = a * 0.55 / steps
        for i = 0, steps - 1 do
            pcall(draw.filled_circle, hx, gy, r_out * (1 - i / steps) + 2, with_alpha(MC, per), 48)
        end
        draw_diamond(hx, gy, 15 * scale, 21 * scale, gold)
        draw_diamond(hx, gy, 8 * scale, 12 * scale, with_alpha(LIGHT, a * (0.7 + 0.3 * pulse)))
        if show_label then draw_aligned_text(marker_label(cur), sx, sy + 26 * scale, COL.TEXT, a, font, "center") end
        return
    end
    -- arcs: a faint ring, two thick arcs turning around it, the diamond above
    local r = 22 * scale
    local rot = (os.clock() * 1.4 * (U.TGT.marker_speed or 1.0)) % (2 * math.pi)
    pcall(draw.outline_circle, sx, sy, r, with_alpha(MC, a * 0.35), 40)
    local t = math.max(1.5, 2 * scale)
    arc(sx, sy, r - t, r + t, rot, rot + 1.75, gold, 4)
    arc(sx, sy, r - t, r + t, rot + math.pi, rot + math.pi + 1.75, gold, 4)
    draw_diamond(sx, sy - r - 12 * scale, 9 * scale, 11 * scale * (0.92 + 0.08 * pulse), gold)
    if show_label then draw_aligned_text(marker_label(cur), sx, sy + r + 6 * scale, COL.TEXT, a, font, "center") end
end

local function draw_target_markers(cur, scale, a, pulse, font)
    for _, c in ipairs(W.targets or {}) do
        if not (cur and cur.addr == c.addr) and not U.is_dead(c.chara) then
            local sx, sy = U.screen_pos(c.chara, 1.3)
            if sx then
                local ms, mo = (U.TGT.marker_size or 1.0), (U.TGT.marker_opacity or 1.0)
                draw_diamond(sx, sy, 6 * scale * ms, 6 * scale * ms, with_alpha(COL.GOLD, 0.6 * a * mo))
            end
        end
    end
    if cur then draw_selected_marker(cur, scale, a, pulse, font, true) end
end

------------------------------------------------------------------------------------------------
-- Life and stamina bars (x, y = top-left corner in screen pixels)
------------------------------------------------------------------------------------------------
-- atb = true: the second bar is the ATB gauge (FF XIII-2 colours) instead of the stamina
local function draw_bars(x, y, w, h, gap, hp_r, st_r, a, atb)
    x, y, w = math.floor(x + 0.5), math.floor(y + 0.5), math.floor(w + 0.5)
    h, gap = math.max(2, math.floor(h + 0.5)), math.max(1, math.floor(gap + 0.5))
    draw.filled_rect(x, y, w, h, with_alpha(COL.BAR_HP_BG, a))
    draw.filled_rect(x, y, math.floor(w * math.max(0, math.min(1, hp_r or 1.0)) + 0.5), h, with_alpha(COL.GREEN, a))
    local sy = y + h + gap
    if atb then
        draw.filled_rect(x, sy, w, h, with_alpha(0xFF180A06, a))
        draw.filled_rect(x, sy, math.floor(w * math.max(0, math.min(1, st_r or 0)) + 0.5), h, with_alpha(0xFF5C8DFF, a))
        return
    end
    draw.filled_rect(x, sy, w, h, with_alpha(COL.BAR_ST_BG, a))
    draw.filled_rect(x, sy, math.floor(w * math.max(0, math.min(1, st_r or 1.0)) + 0.5), h,
        with_alpha((st_r and st_r < 0.15) and COL.AMBER or COL.STAMINA, a))
end

-- shared with the other ui files
X.draw_bars = draw_bars
X.draw_selected_marker = draw_selected_marker
X.draw_target_markers = draw_target_markers
