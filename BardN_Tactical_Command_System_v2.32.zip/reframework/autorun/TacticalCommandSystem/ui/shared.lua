-- TacticalCommandSystem/ui/shared.lua
-- State shared by the HUD drawing files: the public table (UI), loaded images, the icon list drawn by d2d, HUD scale.

local X = {
    UI = {},
    images = {},                                  -- d2d images by name
    iconSlots = {},                               -- icons to draw this frame (read by the d2d callback)
    hud_scale = 1.0,
    d2d_available = type(d2d) == "table" and type(d2d.register) == "function",
}

-- Vocation icon options (written by conf/settings.lua)
X.UI.VOC = { enabled = true, size = 1.0, dx = 0, dy = 0, opacity = 1.0, show_name = true }

-- Look of the wheel (written by conf/settings.lua)
X.UI.LOOK = { tint = true, crescents = true, top_row = true,
              glyph_scale = 1.26,                 -- size of the key pictures, independent of the wheel size
              dpad_hint = "arrow", dpad_size = 1.0, -- previous / next pawn: D-pad picture and its direction marker
              ring_thin = true,                   -- thin vocation-colour line around the circle
              cell_shape = "hex",                 -- shape of the cells
              center_arisen = 0.0,                -- opacity of the centre circle on the Arisen (0 = hidden)
              center_fade_ms = 150,               -- fade of the centre when switching Arisen <-> pawn
              carousel_ms = 150,                  -- slide of the top row
              center_mode = "bottom",             -- "bottom" = information on a plate at the bottom middle,
                                                  --       "circle" = the old big circle
              tgt_solo = true,                    -- targeting: only the chosen skill, at the bottom middle
              tgt_solo_y = 0.70,                  -- ... its height on the screen (0 = top, 1 = bottom)
              tgt_hide_row = true,                -- ... and the top row of characters fades out too
              slot_keys = false,                  -- (hidden by default) the game's button of each skill on the Arisen's cells
              slot_keys_size = 0.8,
              row_icon_size = 1.0,                -- top row: size of the character emblems
              row_sel_scale = 1.4,                -- top row: enlargement of the selected character's emblem
              row_arisen_size = 1.0 }             -- top row: extra size of the Arisen's heart              -- ... their size (x the size of the key pictures)

-- Dark filter over the game while the wheel is open (ABGR colour, its alpha = opacity)
X.UI.FILTER = { enabled = true, color = 0x59000000,
    vig = 0.55, vig_size = 0.28, vig_color = 0xFF000000 }   -- vignette (darker edges) while the wheel is open

-- Curved line from the character to the enemy during the targeting step (ABGR colour)
X.UI.LINE = { enabled = true, color = 0xE692CEF3, width = 3, outline = true, curve = 0.20, comet_speed = 1.0, style = "comet",
    breath_wave = 0.18, breath_glow = 0.5, arrow_width = 3, arrow_head = 1.0 }

-- Position of the cells (written by conf/settings.lua), in design pixels of the 1920 x 1080 mock-up
X.UI.POS = { skill_gap = 36, skill_dist = 12, skill_dy = 0, skill_w = 1.0, skill_mid_dx = 0,     -- the 6 skills (3 left, 3 right)
             corner_dx = 312, corner_dy = 0, corner_w = 1.0 }                  -- Cancel (bottom-left) and Stance (bottom-right)

-- Text font (written by conf/settings.lua): file in reframework/fonts (nil = the REFramework default) and a size factor
X.UI.FONT = { file = "TCS_Pagella.ttf", scale = 1.0 }   -- Palatino style, until the setting applies

-- Called at the start of every drawn frame: empties the list in place
function X.clear_icons()
    local slots = X.iconSlots
    for i = #slots, 1, -1 do slots[i] = nil end
end

return X
