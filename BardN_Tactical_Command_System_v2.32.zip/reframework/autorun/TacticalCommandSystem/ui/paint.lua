-- TacticalCommandSystem/ui/paint.lua
-- The handful of shapes the wheel is drawn out of.
--
-- Everything here goes through REFramework's own drawing, which has no curves and no rounded corners: a ring is a strip
-- of flat quads, and a glow is the same shape drawn several times, larger and fainter each time. Low-level enough that
-- the only thing to get right is not drawing more than is needed -- the wheel redraws completely every frame, so a ring
-- cut into twice as many pieces as the eye can tell apart is twice the work for nothing.
--
-- Colours arrive as ABGR (see data.lua) with their own opacity, and are faded by the wheel's own fade-in on the way
-- past, which is what `fade` is for.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local I18 = require("TacticalCommandSystem.i18n")

local Paint = {}

local COL = D.COL
local SEGMENT_PX = 7              -- an arc is cut into pieces about this long on screen
local GLOW_RINGS = 4              -- copies drawn around a lit lamp
local LAMP_CORE = 0.72            -- the bright middle of a lamp, as a fraction of its size

----------------------------------------------------------------------------------------------------
-- opacity
----------------------------------------------------------------------------------------------------
-- `col` at `amount` of its own opacity. Takes the colour's alpha down, never up, so a colour that is already partly
-- transparent stays that way.
function Paint.fade(col, amount)
    col = col or 0xFFFFFFFF
    amount = amount or 1.0
    local own = (col >> 24) & 0xFF
    local alpha = math.max(0, math.min(255, math.floor(own * amount + 0.5)))
    return (col & 0x00FFFFFF) | (alpha << 24)
end

local fade = Paint.fade

----------------------------------------------------------------------------------------------------
-- fonts
----------------------------------------------------------------------------------------------------
-- Runs `body` with `font` in use, and puts the previous one back even if the body fails. Passing no font runs the body
-- with whatever font is already in use, which is how the text drawing measures and draws under the same one.
local function under_font(font, body)
    local pushed = font and pcall(imgui.push_font, font)
    local ok, a, b = pcall(body)
    if pushed then pcall(imgui.pop_font) end
    if ok then return a, b end
    return nil
end

-- How wide and tall a string comes out. Falls back to a rough guess rather than nothing, so a label with no
-- measurement still lands somewhere sensible instead of on top of its neighbour.
function Paint.text_size(str, font)
    str = tostring(str or "")
    local w, h = under_font(font, function()
        local size = imgui.calc_text_size(str)
        if size then return tonumber(size.x), tonumber(size.y) end
    end)
    if w and h then return w, h end
    return #str * 8, 16
end

----------------------------------------------------------------------------------------------------
-- text
----------------------------------------------------------------------------------------------------
-- Every label goes through the French layer on its way out, so the labels can be written in English wherever they are
-- drawn from. Drawn twice, once a pixel down and right in the shadow colour: the wheel sits over the game, and white
-- text on a snowfield is otherwise unreadable.
function Paint.text(str, x, y, col, alpha, font, align)
    str = I18.t(tostring(str or ""))

    local pushed = font and pcall(imgui.push_font, font)

    local w, h = Paint.text_size(str, nil)
    if align == "center" then
        x = x - w * 0.5
    elseif align == "right" then
        x = x - w
    end
    x, y = math.floor(x + 0.5), math.floor(y + 0.5)

    draw.text(str, x + 1, y + 1, fade(COL.SHADOW, alpha))
    draw.text(str, x, y, fade(col, alpha))

    if pushed then pcall(imgui.pop_font) end
    return w, h
end

----------------------------------------------------------------------------------------------------
-- shapes
----------------------------------------------------------------------------------------------------
-- A four-pointed diamond, filled. The wheel's one ornament, used for the lamps and the small markers.
function Paint.diamond(cx, cy, rx, ry, col)
    draw.filled_quad(cx - rx, cy, cx, cy - ry, cx + rx, cy, cx, cy + ry, col)
end

-- A ring sector between two radii, from `from` to `to` in radians (0 is to the right, angles run clockwise on screen).
-- Cut into as many quads as its length on screen needs and no more.
function Paint.arc(cx, cy, r_inner, r_outer, from, to, col, piece)
    local span = to - from
    if span == 0 or r_outer <= 0 then return end

    local pieces = math.max(1, math.floor(math.abs(span) * r_outer / (piece or SEGMENT_PX) + 0.5))
    local cos, sin = math.cos, math.sin
    local cx0, sy0 = cos(from), sin(from)

    for i = 1, pieces do
        local angle = from + span * i / pieces
        local cx1, sy1 = cos(angle), sin(angle)
        pcall(draw.filled_quad,
            cx + cx0 * r_outer, cy + sy0 * r_outer,
            cx + cx1 * r_outer, cy + sy1 * r_outer,
            cx + cx1 * r_inner, cy + sy1 * r_inner,
            cx + cx0 * r_inner, cy + sy0 * r_inner, col)
        cx0, sy0 = cx1, sy1
    end
end

-- A flat panel with a thin rim, used in place of the wheel's artwork when D2DX is not installed. Snapped to whole
-- pixels, or the rim comes out two pixels thick on one side and none on the other.
function Paint.panel(x, y, w, h, fill, rim, alpha)
    x, y = math.floor(x + 0.5), math.floor(y + 0.5)
    w, h = math.floor(w + 0.5), math.floor(h + 0.5)
    draw.filled_rect(x, y, w, h, fade(fill, alpha))
    draw.outline_rect(x, y, w, h, fade(rim, alpha))
end

----------------------------------------------------------------------------------------------------
-- the lamp beside a skill cell
----------------------------------------------------------------------------------------------------
local LAMP_LIT   = { halo = 0xFF60D878, rim = 0xFF2C9A48, core = 0xFF8CE57F }
local LAMP_DARK  = { rim = 0xFF3A3632, core = 0xFF12100F }

-- Lit means the pawn may use the skill on its own; dark means the player has kept it for ordering. Size, glow and
-- opacity are the player's, from the settings.
function Paint.status_lamp(cx, cy, r, lit, alpha)
    local look = U.LAMP
    alpha = alpha * (look.opacity or 1.0)
    if alpha <= 0.01 then return end

    if not lit then
        if look.show_off == false then return end
        Paint.diamond(cx, cy, r, r, fade(LAMP_DARK.rim, alpha))
        Paint.diamond(cx, cy, r * LAMP_CORE, r * LAMP_CORE, fade(LAMP_DARK.core, alpha))
        return
    end

    local glow = look.glow or 1.0
    if glow > 0.01 then
        local strength = math.min(glow, 2.0)
        for ring = GLOW_RINGS, 1, -1 do
            local step = ring / GLOW_RINGS
            local radius = r * (1.0 + 0.9 * glow * step)
            Paint.diamond(cx, cy, radius, radius,
                fade(LAMP_LIT.halo, 0.10 * strength * (1.0 - 0.5 * step) * alpha))
        end
    end
    Paint.diamond(cx, cy, r, r, fade(LAMP_LIT.rim, alpha))
    Paint.diamond(cx, cy, r * LAMP_CORE, r * LAMP_CORE, fade(LAMP_LIT.core, alpha))
end

return Paint
