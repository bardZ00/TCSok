-- TacticalCommandSystem/ui/prompts.lua
-- Key prompts: pad glyphs and the prompt bar under the wheel.
-- Part of the HUD drawing code (see ui.lua); state shared with the other ui files lives in ui/shared.lua.

local D = require("TacticalCommandSystem.data")
local IN = require("TacticalCommandSystem.input")
local I18 = require("TacticalCommandSystem.i18n")
local X = require("TacticalCommandSystem.ui.shared")
local COL = D.COL
local images, iconSlots = X.images, X.iconSlots

-- from ui/shapes
local draw_aligned_text, text_size, with_alpha = X.draw_aligned_text, X.text_size, X.with_alpha

-- key prompts = a bar of pad glyphs UNDER the wheel.
-- A / B / X / Y use the medallions in images/Tactical_Command_System/buttons;
-- triggers, bumpers, sticks and the D-pad are drawn. No background panel: D2D images are drawn under imgui.
local GLYPH_FACE_COL = { A = 0xFF7CC35E, B = 0xFFE2635B, X = 0xFF4E9BE3, Y = 0xFFE3C14E }
local GLYPH_NAME = { L1 = "LB", R1 = "RB", L2 = "LT", R2 = "RT", L3 = "L3", R3 = "R3",
    A = "A", B = "B", X = "X", Y = "Y", Up = "DUp", Down = "DDown", Left = "DLeft", Right = "DRight",
    Select = "Select", Start = "Start" }
-- image glyphs: { width / height of the picture, height as a fraction of the glyph size }
local GLYPH_IMG = {
    LB = { 2.48, 0.72 }, RB = { 2.46, 0.72 }, LT = { 1.38, 0.95 }, RT = { 1.36, 0.95 },
    L3 = { 1.0, 1.0 }, R3 = { 1.0, 1.0 }, Start = { 1.49, 0.95 }, Select = { 1.58, 0.95 }, DPAD_H = { 1.0, 1.0 },
}
local function glyph_img_key(name) return (name == "DPAD_H") and "btn_DPad" or ("btn_" .. name) end
local GLYPH_DARK, GLYPH_RIM, GLYPH_PALE = 0xFF1D1B19, 0xFF3A3632, 0xFFE9E1D2

-- keyboard / mouse keys, drawn as key caps ("K:" + the key's name)
local KB_SHORT = { LMB = { "LMB", "Clic G" }, RMB = { "RMB", "Clic D" }, MMB = { "MMB", "Clic M" },
    MOUSE4 = { "MB4", "Souris 4" }, MOUSE5 = { "MB5", "Souris 5" } }
local function kb_label(v)
    if v == "mouse_lr" then return I18.pick("Mouse <->", "Souris <->") end
    if type(v) ~= "number" or v <= 0 then return nil end
    local n = IN.get_vk_name(v)
    local sh = KB_SHORT[n]
    if sh then return I18.pick(sh[1], sh[2]) end
    return n
end

local function bind_glyph(val)
    local k = IN.get_pad_short_name(val)
    return k and GLYPH_NAME[k] or nil
end

local function glyph_width(name, s)
    if name:sub(1, 2) == "K:" then
        local f = X.F_KEYCAP
        local tw = f and text_size(name:sub(3), f) or (#name - 2) * s * 0.4
        return math.max(s, tw + s * 0.6)
    end
    local g = GLYPH_IMG[name]
    if g and X.d2d_available and images[glyph_img_key(name)] then return s * g[1] * g[2] end
    if name == "LB" or name == "RB" or name == "LT" or name == "RT" then return s * 1.5 end
    if name == "Start" or name == "Select" then return s * 1.4 end
    return s
end

local function glyph_disc(cx, cy, r, a)
    pcall(draw.filled_circle, cx, cy, r * 1.12, with_alpha(0x66000000, a), 28)
    pcall(draw.filled_circle, cx, cy, r, with_alpha(GLYPH_RIM, a), 28)
    pcall(draw.filled_circle, cx, cy, r * 0.88, with_alpha(GLYPH_DARK, a), 28)
end

local function draw_dpad(cx, cy, s, a, lit_l, lit_r, lit_u, lit_d)
    local arm = s * 0.34
    local len = s * 0.5
    local function box(x, y, w, h, lit)
        draw.filled_rect(math.floor(x + 0.5), math.floor(y + 0.5), math.floor(w + 0.5), math.floor(h + 0.5),
            with_alpha(lit and GLYPH_PALE or GLYPH_RIM, a))
    end
    box(cx - len, cy - arm * 0.5, len - arm * 0.5, arm, lit_l)
    box(cx + arm * 0.5, cy - arm * 0.5, len - arm * 0.5, arm, lit_r)
    box(cx - arm * 0.5, cy - len, arm, len - arm * 0.5, lit_u)
    box(cx - arm * 0.5, cy + arm * 0.5, arm, len - arm * 0.5, lit_d)
    box(cx - arm * 0.5, cy - arm * 0.5, arm, arm, false)
end

local function draw_keycap(label, cx, cy, s, a, font, th)
    local w, h = glyph_width("K:" .. label, s), s * 0.86
    local x0, y0 = math.floor(cx - w * 0.5 + 0.5), math.floor(cy - h * 0.5 + 0.5)
    pcall(draw.filled_rect, x0 - 2, y0 - 2, math.floor(w + 4), math.floor(h + 5), with_alpha(0x66000000, a))
    pcall(draw.filled_rect, x0, y0, math.floor(w), math.floor(h), with_alpha(GLYPH_RIM, a))
    pcall(draw.filled_rect, x0 + 2, y0 + 2, math.floor(w - 4), math.floor(h - 6), with_alpha(GLYPH_DARK, a))
    draw_aligned_text(label, cx, cy - th * 0.5 - 1, GLYPH_PALE, a, X.F_KEYCAP or font, "center")
end

local function draw_glyph(name, cx, cy, s, a, font, th)
    if name:sub(1, 2) == "K:" then return draw_keycap(name:sub(3), cx, cy, s, a, font, th) end
    local gi = GLYPH_IMG[name]
    local gimg = gi and X.d2d_available and images[glyph_img_key(name)] or nil
    if gimg and a >= 0.95 then
        local h = s * gi[2]
        local w = h * gi[1]
        iconSlots[#iconSlots + 1] = { img = glyph_img_key(name), x = math.floor(cx - w * 0.5 + 0.5), y = math.floor(cy - h * 0.5 + 0.5),
            w = math.floor(w + 0.5), h = math.floor(h + 0.5) }
        return
    end
    if GLYPH_FACE_COL[name] then
        local img = images["btn_" .. name]
        if X.d2d_available and img and a >= 0.95 then
            iconSlots[#iconSlots + 1] = { img = "btn_" .. name, x = math.floor(cx - s * 0.5 + 0.5), y = math.floor(cy - s * 0.5 + 0.5), size = math.floor(s + 0.5) }
        else
            glyph_disc(cx, cy, s * 0.5, a)
            draw_aligned_text(name, cx, cy - th * 0.5, GLYPH_FACE_COL[name], a, font, "center")
        end
    elseif name == "LB" or name == "RB" or name == "LT" or name == "RT" then
        local w, h = glyph_width(name, s), s * 0.72
        local x0, x1 = cx - w * 0.5, cx + w * 0.5
        local r = h * 0.5
        local function body(e, col)
            draw.filled_rect(math.floor(x0 + r - e), math.floor(cy - r - e), math.floor((x1 - x0) - 2 * r + 2 * e), math.floor(h + 2 * e), col)
            pcall(draw.filled_circle, x0 + r, cy, r + e, col, 20)
            pcall(draw.filled_circle, x1 - r, cy, r + e, col, 20)
        end
        body(h * 0.1, with_alpha(0x66000000, a))
        body(h * 0.05, with_alpha(GLYPH_RIM, a))
        body(0, with_alpha(GLYPH_DARK, a))
        draw_aligned_text(name, cx, cy - th * 0.5, GLYPH_PALE, a, font, "center")
    elseif name == "L3" or name == "R3" then
        glyph_disc(cx, cy, s * 0.5, a)
        draw_aligned_text(name, cx, cy - th * 0.5, GLYPH_PALE, a, font, "center")
    elseif name == "Start" or name == "Select" then
        local w, h = glyph_width(name, s), s * 0.6
        pcall(draw.filled_rect, math.floor(cx - w * 0.5), math.floor(cy - h * 0.5), math.floor(w), math.floor(h), with_alpha(GLYPH_RIM, a))
        draw_aligned_text(name == "Start" and "ST" or "SE", cx, cy - th * 0.5, GLYPH_PALE, a, font, "center")
    elseif name == "DPAD_H" then
        draw_dpad(cx, cy, s, a, true, true, false, false)
    elseif name == "DLeft" then
        draw_dpad(cx, cy, s, a, true, false, false, false)
    elseif name == "DRight" then
        draw_dpad(cx, cy, s, a, false, true, false, false)
    elseif name == "DUp" then
        draw_dpad(cx, cy, s, a, false, false, true, false)
    elseif name == "DDown" then
        draw_dpad(cx, cy, s, a, false, false, false, true)
    end
end

-- The D-pad beside the pawn row: the picture (or the drawn D-pad), with a direction marker.
-- dir = -1 (previous pawn, left arm) / +1 (next pawn, right arm). hint = "arrow" | "highlight" | "both" | "none".
local function draw_dpad_switch(cx, cy, size, a, dir, hint)
    local has_img = X.d2d_available and images["btn_DPad"] ~= nil
    if has_img and a >= 0.95 then
        iconSlots[#iconSlots + 1] = { img = "btn_DPad", x = math.floor(cx - size * 0.5 + 0.5), y = math.floor(cy - size * 0.5 + 0.5),
            w = math.floor(size + 0.5), h = math.floor(size + 0.5) }
    else
        draw_dpad(cx, cy, size, a, dir < 0, dir > 0, false, false)
    end
    if hint == "highlight" or hint == "both" then
        -- a pale triangle laid over the arrow of the arm (imgui draws above d2d)
        local tip_x = cx + dir * size * 0.34
        local base_x = cx + dir * size * 0.19
        local hh = size * 0.13
        pcall(draw.filled_quad, tip_x, cy, base_x, cy - hh, base_x, cy + hh, base_x, cy + hh, with_alpha(0xCCFFFFFF, a))
    end
    if hint == "arrow" or hint == "both" then
        -- a small chevron just outside the D-pad
        local ax = cx + dir * size * 0.84          -- apex of the chevron, just outside the D-pad
        local l = size * 0.22
        local col = with_alpha(GLYPH_PALE, a)
        for i = 0, math.max(2, math.floor(size * 0.07 + 0.5)) - 1 do     -- a few 1 px lines side by side = thickness
            local o = dir * i
            draw.line(ax - dir * l + o, cy - l, ax + o, cy, col)
            draw.line(ax - dir * l + o, cy + l, ax + o, cy, col)
        end
    end
end

-- entries = { { binds = { pad bind values... }, dpad = true (Left + Right shown as one D-pad), t = "LABEL" }, ... }
local function draw_prompt_bar(sw, sh, scale, a, font, center_x, top_y, entries)
    local _, th = text_size("X", font)

    X.F_KEYCAP = font
    local function glyph_list(vals)
        local out, seen = {}, {}
        for _, v in ipairs(vals) do
            local g = bind_glyph(v)
            if g and not seen[g] then seen[g] = true; out[#out + 1] = g end
        end
        return out
    end
    local function kb_list(vals)
        local out, seen = {}, {}
        for _, v in ipairs(vals) do
            local l = kb_label(v)
            if l and not seen[l] then seen[l] = true; out[#out + 1] = "K:" .. l end
        end
        return out
    end
    local resolved = {}
    for _, e in ipairs(entries or {}) do
        local g = e.kb and kb_list(e.kb) or glyph_list(e.binds or {})
        if e.dpad and #g == 2 and g[1] == "DLeft" and g[2] == "DRight" then g = { "DPAD_H" } end
        resolved[#resolved + 1] = { g = g, t = e.t }
    end
    entries = resolved

    -- size of the key pictures: tied to the screen and the "size of the key pictures" setting, not to the wheel size
    local s = math.floor(27 * (sh / 1080) * (X.UI.LOOK.glyph_scale or 1.26) + 0.5)
    local gap_g = math.floor(4 * scale + 0.5)     -- between glyphs of one entry
    local gap_t = math.floor(8 * scale + 0.5)     -- glyphs -> label
    local gap_e = math.floor(26 * scale + 0.5)    -- between entries

    local list = {}
    for _, e in ipairs(entries) do
        if #e.g > 0 and e.t ~= "" then
            local label = I18.t(e.t)
            local gw = 0
            for i, g in ipairs(e.g) do gw = gw + glyph_width(g, s) + ((i > 1) and gap_g or 0) end
            local tw = text_size(label, font)
            list[#list + 1] = { g = e.g, label = label, gw = gw, w = gw + gap_t + tw }
        end
    end
    if #list == 0 then return end

    -- pack into rows no wider than 62 % of the screen
    local max_w = sw * 0.62
    local rows, cur, cur_w = {}, {}, 0
    for _, e in ipairs(list) do
        local add = e.w + ((#cur > 0) and gap_e or 0)
        if #cur > 0 and cur_w + add > max_w then
            rows[#rows + 1] = { items = cur, w = cur_w }
            cur, cur_w, add = {}, 0, e.w
        end
        cur[#cur + 1] = e
        cur_w = cur_w + add
    end
    rows[#rows + 1] = { items = cur, w = cur_w }

    local row_h = s + math.floor(8 * scale + 0.5)
    for ri, row in ipairs(rows) do
        local x = center_x - row.w * 0.5
        local cy = top_y + (ri - 1) * row_h + s * 0.5
        for _, e in ipairs(row.items) do
            for i, g in ipairs(e.g) do
                if i > 1 then x = x + gap_g end
                local gw = glyph_width(g, s)
                draw_glyph(g, x + gw * 0.5, cy, s, a, font, th)
                x = x + gw
            end
            draw_aligned_text(e.label, x + gap_t, cy - th * 0.5, COL.TEXT, a, font, "left")
            x = x + gap_t + text_size(e.label, font) + gap_e
        end
    end
end

-- shared with the other ui files
X.draw_prompt_bar = draw_prompt_bar
X.bind_glyph = bind_glyph
X.kb_label = kb_label
X.draw_glyph = draw_glyph
X.glyph_width = glyph_width
X.draw_dpad_switch = draw_dpad_switch
