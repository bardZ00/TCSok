-- TacticalCommandSystem/ui/shapes.lua
-- The drawing primitives are in ui/paint.lua; this puts them on the table the other ui files share.

local X = require("TacticalCommandSystem.ui.shared")
local Paint = require("TacticalCommandSystem.ui.paint")

X.with_alpha        = Paint.fade
X.text_size         = Paint.text_size
X.draw_aligned_text = Paint.text
X.draw_diamond      = Paint.diamond
X.draw_arc          = Paint.arc
X.draw_panel        = Paint.panel
X.draw_status_lamp  = Paint.status_lamp

return Paint
