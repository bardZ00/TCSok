-- TacticalCommandSystem/ui/banner.lua
-- What is drawn while the wheel is closed: the target marker and the short flash messages.
-- Part of the HUD drawing code (see ui.lua); state shared with the other ui files lives in ui/shared.lua.

local D = require("TacticalCommandSystem.data")
local U = require("TacticalCommandSystem.utils")
local AI = require("TacticalCommandSystem.cmd.init")
local IN = require("TacticalCommandSystem.input")
local X = require("TacticalCommandSystem.ui.shared")
local UI = X.UI
local COL = D.COL
local W = IN.W
local images, iconSlots = X.images, X.iconSlots

-- from ui/shapes
local draw_aligned_text, draw_panel, text_size = X.draw_aligned_text, X.draw_panel, X.text_size
-- from ui/markers
local draw_selected_marker = X.draw_selected_marker
-- from ui/assets
local get_screen_size = X.get_screen_size

function UI.draw_status_banner(w_now)
    X.clear_icons()

    -- most frames: no marker to show and no message: nothing to measure
    local secs = U.TGT.marker_seconds or 3.0
    local since = w_now - (W.closed_t or -99)
    local show_marker = W.open or U.TGT.marker_closed or (since < secs)
    local cur_target = show_marker and AI.get_target() or nil     -- the target is only checked when it could be shown
    local flashing = W.flash_msg and w_now < (W.flash_until or 0)
    if not flashing and not (cur_target and show_marker) then return end

    local sw, sh = get_screen_size()
    local scale = (sh / 1080) * X.hud_scale
    local font_msg = UI.get_scaled_font(16)

    -- the marker is only shown while the wheel is open and a few seconds after (or always, if the option is ticked)
    if cur_target and show_marker then
        local fade = 1.0
        if not W.open and not U.TGT.marker_closed then fade = math.max(0.0, math.min(1.0, (secs - since) / 0.4)) end
        draw_selected_marker(cur_target, scale * 0.65, 0.9 * fade, 0.65 + 0.35 * math.sin(w_now * 4.0), nil, false)
    end

    UI.draw_flash(sw, sh, scale, w_now, sh * 0.16, font_msg)
end

-- The short message after an order (also drawn while the wheel stays open, under the top row).
-- 1.52 (F3): the same band as the targeting step: a dark wash between two gold lines that fade away, the skill's
-- medallion when the order launches a skill, the action in white, who acts in gold. The message is split from its
-- text form "[ WHO >> WHAT ]" / "[ WHO : WHAT ]" / "[ WHAT ]" (after translation).
local I18 = require("TacticalCommandSystem.i18n")
local GOLD = 0xD9B358
local function gold_line(cx, y, half, t, a)        -- screen pixels: a gold line fading towards both ends
    local n = 12
    for side = -1, 1, 2 do
        for k = 0, n - 1 do
            local x0, x1 = cx + side * half * k / n, cx + side * half * (k + 1) / n
            local f = a * (1 - (k + 0.5) / n)
            if f > 0.01 then
                iconSlots[#iconSlots + 1] = { line = true, x1 = x0, y1 = y, x2 = x1, y2 = y, t = t,
                    color = (math.floor(f * 255 + 0.5) << 24) | GOLD }
            end
        end
    end
end
local function split_msg(msg)
    local m = msg:match("^%[%s*(.-)%s*%]$") or msg
    local who, what = m:match("^(.-)%s+:%s+(.+)$")
    if not who then who, what = m:match("^(.-)%s+>>%s+(.+)$") end
    if not who then return nil, m end
    what = what:gsub("%s+>>%s+", " · ")
    return who, what
end

function UI.draw_flash(sw, sh, scale, w_now, by, font_msg)
    if not (W.flash_msg and w_now < W.flash_until) then return end
    local a = math.min(1.0, math.max(0.05, (W.flash_until - w_now) / 0.4))
    local who, what = split_msg(I18.t(W.flash_msg))
    local big = UI.get_scaled_font(20) or font_msg
    local ww, wh = text_size(what, big)
    local hw = who and select(1, text_size(who, font_msg)) or 0
    local icon = W.flash_icon and images["skill_" .. W.flash_icon] and W.flash_icon or nil
    local msz = 40 * scale
    local gap = 14 * scale
    local total = ww + (who and (gap * 2 + hw) or 0) + (icon and (msz + gap) or 0)
    local half = math.max(250 * scale, total * 0.5 + 80 * scale)
    local bh = 40 * scale
    local cx = sw * 0.5
    -- the wash (the cells' smooth gradient pictures) and the two gold lines
    local hwp = math.floor(half + 0.5)
    iconSlots[#iconSlots + 1] = { img = "cell_fade_l", x = math.floor(cx - hwp), y = math.floor(by), w = hwp, h = math.floor(bh + 0.5), alpha = a * 0.9 }
    iconSlots[#iconSlots + 1] = { img = "cell_fade_r", x = math.floor(cx), y = math.floor(by), w = hwp, h = math.floor(bh + 0.5), alpha = a * 0.9 }
    gold_line(cx, by, half, math.max(1, 1.3 * scale), a)
    gold_line(cx, by + bh, half, math.max(1, 1.3 * scale), a)
    -- content, centred as a whole
    local x = cx - total * 0.5
    local mid = by + bh * 0.5
    if icon then
        local m = math.floor(msz + 0.5)
        iconSlots[#iconSlots + 1] = { img = "med", x = math.floor(x), y = math.floor(mid - m * 0.5), w = m, h = m, alpha = a }
        local isz = math.floor(msz * 1.1 + 0.5)          -- same ratio as in the wheel (64 px medallion, ~70 px picture)
        iconSlots[#iconSlots + 1] = { img = "skill_" .. icon, x = math.floor(x + m * 0.5 - isz * 0.5), y = math.floor(mid - isz * 0.5),
            w = isz, h = isz, alpha = a }
        x = x + msz + gap
    end
    draw_aligned_text(what, x, mid - wh * 0.5, 0xFFFFFFFF, a, big, "left")
    if who then
        local _, sh2 = text_size(who, font_msg)
        draw_aligned_text(who, x + ww + gap * 2, mid - sh2 * 0.5, COL.GOLD_BRIGHT, a, font_msg, "left")
    end
end
