-- TacticalCommandSystem/sound.lua  
-- Wheel sound effects = the game's own menu sounds:
-- instance methods of app.GUIBase (parent of the game's screens): callCursorSe(), callDecideSe(),
-- callCancelSe(), callDisableSe(). A game screen is needed to call them: the first component of
-- app.GuiManager._GUIList that derives from app.GUIBase, looked up again each time (never kept between frames).
-- Sounds are queued during the frame and played at the start of UpdateBehavior.

local SND = { queue = {}, played = 0, fails = 0, ok = nil }
SND.enabled = function() return true end      -- replaced by input.lua (option "sounds")

local METHOD = { cursor = "callCursorSe", decide = "callDecideSe", cancel = "callCancelSe", disable = "callDisableSe" }
local last_cursor = 0

function SND.play(kind)
    if not METHOD[kind] or SND.ok == false then return end
    local okc, on = pcall(SND.enabled)
    if not okc or not on then return end
    if kind == "cursor" then
        local now = os.clock()
        if now - last_cursor < 0.05 then return end      -- no burst when the stick sweeps across cells
        last_cursor = now
    end
    if #SND.queue < 4 then SND.queue[#SND.queue + 1] = kind end
end

local gui_base = nil
local function any_gui()
    local found = nil
    pcall(function()
        gui_base = gui_base or sdk.typeof("app.GUIBase")
        local list = sdk.get_managed_singleton("app.GuiManager"):get_field("_GUIList")
        local n = list:call("get_Count") or 0
        for i = 0, n - 1 do
            local comp = list[i]
            if comp then
                local yes = false
                pcall(function() yes = comp:GetType():IsSubclassOf(gui_base) end)
                if yes then found = comp; return end
            end
        end
    end)
    return found
end

local function run()
    if #SND.queue == 0 then return end
    local q = SND.queue
    SND.queue = {}
    local comp = any_gui()
    if not comp then return end
    for _, kind in ipairs(q) do
        local ok = pcall(function() comp:call(METHOD[kind]) end)
        if ok then
            SND.played = SND.played + 1
        else
            SND.fails = SND.fails + 1
            if SND.fails >= 10 then
                SND.ok = false
                pcall(log.warn, "[Tactical_Command_System] sounds disabled for this session: the game refused 10 times")
            end
        end
    end
end

function SND.install()
    if re and re.on_pre_application_entry then
        pcall(re.on_pre_application_entry, "UpdateBehavior", function() pcall(run) end)
    end
end

return SND
