-- TacticalCommandSystem/ui.lua
-- HUD drawing facade. The public table is UI (UI.draw_wheel, UI.draw_status_banner, UI.set_scale, UI.get_scaled_font).
-- The work is split over several files, loaded in this order:
--   ui/shared   the UI table, loaded images, the icon list, HUD scale
--   ui/assets   d2d pictures (frames, circle, crescents, emblems, icons), screen size, scaled fonts
--   ui/shapes   drawing primitives (text, diamond, lock lamp, plain panel)
--   ui/prompts  pad glyphs and the prompt bar
--   ui/markers  target markers, life / stamina bars
--   ui/wheel    the wheel
--   ui/banner   status banner while the wheel is closed

local X = require("TacticalCommandSystem.ui.shared")

require("TacticalCommandSystem.ui.assets")
require("TacticalCommandSystem.ui.shapes")
require("TacticalCommandSystem.ui.prompts")
require("TacticalCommandSystem.ui.markers")
require("TacticalCommandSystem.ui.wheel")
require("TacticalCommandSystem.ui.banner")

return X.UI
